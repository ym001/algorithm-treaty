# clustering-research

Workspace Rust pour un article de recherche comparant les principaux
algorithmes de clustering de la littérature à un nouvel algorithme fondé
sur le transport optimal, sur bancs d'essai synthétiques reproductibles.

## État d'avancement — Phase 3 / 7 terminée, Phase 4-5 en cours (PoWKM)

- [x] **Phase 1 — Socle** : traits communs (`cluster-core`), générateurs de
      données synthétiques reproductibles (`cluster-data`), métriques
      d'évaluation externes et internes (`cluster-metrics`).
- [x] **Phase 2 — Algorithmes classiques** (`cluster-algos`) :
      - [x] **K-Means** (Lloyd + k-means++) — 7 tests unitaires (dont cas
        calculé à la main, non-convergence sur données non convexes
        documentée comme comportement attendu, gestion de cluster vide) +
        **validation croisée numérique contre scikit-learn 1.8.0** à
        initialisation identique : écart relatif sur l'inertie = 3×10⁻¹⁶
        (précision machine), ARI = 1.0 (voir `validation/compare_kmeans.py`).
      - [x] **Mean-Shift** (noyau plat, entièrement déterministe — pas de
        graine) — 8 tests unitaires (dont cas calculé à la main, monotonie
        du nombre de clusters en fonction du bandwidth, point isolé) +
        **validation croisée contre scikit-learn 1.8.0** sur blobs
        (bandwidth=2.5) : ARI = 1.0, même nombre de clusters (voir
        `validation/compare_mean_shift.py`). Comportement documenté par
        balayage de bandwidth sur les 7 bancs d'essai plutôt que supposé
        (voir tableau ci-dessous) : robuste sur données à clusters
        globalement denses, structurellement limité sur lunes/cercles pour
        la même raison que DBSCAN classique (un seul bandwidth global).
      - [x] **DBSCAN** — 11 tests unitaires (dont 2 cas calculés à la main,
        cas limites min_samples=1/eps→∞ et min_samples>n, rejet de bruit)
        + **validation croisée contre scikit-learn 1.8.0** sur blobs et
        moons : accord **exact** (100% des labels identiques, y compris
        l'étiquette de bruit -1, pas seulement à permutation près — voir
        `validation/compare_dbscan.py`). Confirme la propriété distinctive
        de DBSCAN : ARI=1.000 sur moons et circles (échec total de K-Means
        et Mean-Shift sur ces mêmes jeux en Phase 2). Point à noter
        honnêtement : la limitation théorique de DBSCAN sur densité
        hétérogène (`varied_density`) **ne s'est pas manifestée** de façon
        nette sur notre jeu de données synthétique actuel (ARI=0.983,
        4 clusters trouvés au lieu de 3 — fragmentation partielle, pas
        d'échec net) ; un jeu de données conçu spécifiquement pour stresser
        cette limitation sera nécessaire pour l'article (voir
        `dbscan::tests::documented_behavior_on_varied_density`).
      - [x] **Regroupement hiérarchique agglomératif** (single/complete/
        average/Ward via récurrence de Lance-Williams) — 11 tests
        unitaires, dont 3 tests isolant la formule de mise à jour seule
        (single/complete/average/Ward vérifiés indépendamment, Ward
        recoupé par un calcul direct de l'augmentation de variance) +
        **validation croisée contre `scipy.cluster.hierarchy.linkage`**
        pour les 4 critères : **ARI = 1.000 exact** (partition identique,
        voir `validation/compare_hierarchical.py`). Un test d'hypothèse
        initiale s'est révélé faux et a été corrigé après vérification
        empirique plutôt que forcé (voir
        `single_linkage_chains_through_bridge_complete_does_not`) — le
        chaînage de single linkage absorbe tout le pont d'un seul côté au
        lieu de fusionner les deux blobs, contrairement à l'intuition
        initiale. Découverte notable : single linkage atteint ARI=0.980
        sur les lunes, mais seulement à **k=3** (k=2 échoue à ARI=0, un
        point aberrant volant un cluster entier) — illustration directe de
        la fragilité au bruit de single linkage sans mécanisme de rejet
        explicite, contrairement à DBSCAN.
      - [x] **BIRCH** (arbre CF en une passe + clustering global Ward +
        réaffectation finale) — 9 tests unitaires, dont vérification directe
        de la formule CF (rayon recoupé par un calcul indépendant),
        invariant "aucune entrée-feuille ne dépasse le seuil" vérifié sur
        l'arbre réel après insertion, robustesse à un arbre multi-niveaux
        forcé (`branching_factor=2`) + **validation croisée contre
        `sklearn.cluster.Birch` 1.8.0** : ARI = 1.000 exact sur blobs (voir
        `validation/compare_birch.py`). Hérite du biais de Ward vers les
        clusters compacts (échec sur lunes/cercles, comme K-Means), mais
        confirme la promesse de passage à l'échelle de BIRCH : temps
        d'exécution en microsecondes contre millisecondes pour les 4
        algorithmes précédents (O(n) contre O(n²)/O(n³)), seul algorithme
        de la Phase 2 dont la complexité ne dépend pas quadratiquement de n.

**Phase 2 terminée : 67/67 tests, 0 warning clippy sur tout le workspace.**
Les 5 algorithmes demandés initialement (K-Means, Mean-Shift, DBSCAN,
Regroupement hiérarchique, BIRCH) sont implémentés, testés et validés
numériquement contre des références externes (scikit-learn, scipy).
- [x] **Phase 3 — Algorithmes récents** (baselines) : HDBSCAN, OPTICS,
      Spectral Clustering.
      - [x] **Jeu de données adverse** (`make_adversarial_density`,
        `cluster-data`) : conçu spécifiquement pour stresser la limitation
        théorique du eps global unique de DBSCAN, après qu'une première
        tentative à 2 clusters (Phase 2/3) s'est révélée non adverse
        (DBSCAN y atteignait ARI=1.000). Recherche empirique sur une
        vingtaine de configurations (voir `examples/adversarial_search.rs`) :
        une chaîne de **6 niveaux de densité géométriquement croissants**
        s'est révélée la plus adverse, plafonnant DBSCAN à ARI=0.713 quel
        que soit (eps, min_samples).
      - [x] **HDBSCAN** (distance de atteignabilité mutuelle, MST de Prim,
        dendrogramme single-linkage, condensation, extraction
        Excess-of-Mass) — 9 tests unitaires (dont distance de coeur et MST
        calculés à la main). **Deux bugs corrigés après diagnostic
        systématique** plutôt que devinés : (1) l'algorithme de Prim
        ajoutait une arête fantôme pour le premier noeud (auto-boucle de
        poids 0), faussant la taille de l'arbre ; (2) la remontée
        post-sélection EOM confondait deux cas structurellement différents
        — un point ayant quitté un cluster *avant* sa scission ne doit pas
        être rattaché à un ancêtre sélectionné (il doit devenir bruit),
        contrairement à un point appartenant à un sous-arbre jamais visité
        par la sélection (qui doit remonter). Corrigé en distinguant
        explicitement les noeuds *visités* des noeuds *sélectionnés*.
        **Validation croisée contre `sklearn.cluster.HDBSCAN` 1.8.0** :
        accord **exact** (ARI=1.000, 100% des labels identiques) sur blobs
        et sur `adversarial_density` (voir `validation/compare_hdbscan.py`).
      - [x] **OPTICS** (ordonnancement par distance de atteignabilité +
        extraction façon DBSCAN, méthode simple de l'article original —
        la méthode « xi » par détection de pente, par défaut dans
        scikit-learn, n'est pas implémentée, documentée comme hors
        périmètre) — 8 tests unitaires, dont une **propriété
        d'auto-cohérence forte** : à `eps_extract == eps`, l'extraction
        OPTICS reproduit *exactement* `Dbscan` au même (eps, min_samples)
        — vérifié directement contre l'implémentation DBSCAN déjà validée
        du crate, avant même toute comparaison externe. **Validation
        croisée contre `sklearn.cluster.OPTICS(cluster_method='dbscan')`
        1.8.0** : accord exact (ARI=1.000, 100% des labels identiques, voir
        `validation/compare_optics.py`).
      - [x] **Spectral Clustering** (affinité RBF, laplacien normalisé
        symétrique, **solveur de valeurs propres maison** par itération de
        puissance + déflation — aucune dépendance à une bibliothèque
        d'algèbre linéaire externe, étape K-Means finale réutilisant
        directement `KMeans::lloyd` déjà validé) — 9 tests unitaires, dont
        2 qui isolent le solveur de valeurs propres seul (matrice 2×2 à
        valeurs propres connues analytiquement : 3 et 1). Une hypothèse de
        paramétrage fausse corrigée après balayage (gamma=15, qui marche
        pour les lunes, donnait ARI=-0.003 sur les cercles — corrigé à
        gamma=50 après vérification). **Validation croisée contre
        `sklearn.cluster.SpectralClustering` 1.8.0** : ARI=1.000 exact sur
        blobs, **et validation indépendante du solveur de valeurs propres
        lui-même** contre `numpy.linalg.eigh` sur la même matrice
        d'affinité normalisée (voir `validation/compare_spectral.py`) —
        validation à un niveau plus fin que la simple comparaison des
        labels finaux, isolant le solveur de l'étape K-Means qui suit.

**Phase 3 terminée : 94/94 tests, 0 warning clippy sur tout le workspace.**
Les 8 algorithmes de la littérature (K-Means, Mean-Shift, DBSCAN,
Regroupement hiérarchique, BIRCH, HDBSCAN, OPTICS, Spectral Clustering)
sont implémentés, testés et validés numériquement contre des références
externes (scikit-learn, scipy, numpy).

- [x] **Phase 4 — Primitives de transport optimal** (`cluster-ot`) :
      - [x] **Sinkhorn** (transport optimal entropique, domaine
        logarithmique) — 5 tests unitaires (marges exactement satisfaites,
        convergence vers le couplage indépendant à ε→∞, concentration sur
        l'appariement optimal à ε→0).
      - [x] **Newton pour le semi-dual entropique** (`newton_ot.rs`) —
        alternative à convergence locale **quadratique** au point fixe de
        Sinkhorn, sur le même problème. Voir section dédiée ci-dessous.
      - [x] **Borne globale de warm-start** (`warm_start_bound.rs`) —
        relie `‖g₀-g*_new‖` au déplacement des centres `‖Y_old-Y_new‖`
        (lemme de sensibilité élémentaire, pas Delalande-Mérigot /
        Bansil-Kitagawa — voir section dédiée pour le pourquoi). 8 tests.

- [~] **Phase 5 — PoWKM** (`cluster-ot::powkm`) : **la contribution
      originale de l'article.** Clustering par recuit déterministe sur
      l'énergie libre entropique (Rose, Gurewitz & Fox, 1990 ; Rose,
      1998), reformulé et étendu — nombre de classes **émergent**, pas
      fixé a priori, stabilisé par détection du plateau le plus large en
      échelle log(β). Voir section dédiée ci-dessous pour la dérivation
      mathématique complète, l'historique de débogage, et les résultats.
      Statut : machinerie mathématique validée et testée (14 tests,
      dont 2 reproduisant exactement un résultat analytique de la
      littérature), fonctionne sur données convexes/gaussiennes avec
      découverte automatique de K correcte. Limitations honnêtement
      documentées : échoue sur données non convexes (même limitation
      structurelle que K-Means/Ward/BIRCH) et temps d'exécution actuel
      élevé (non optimisé) sur les jeux à plusieurs niveaux de densité.
- [ ] **Phase 4 — Primitives de transport optimal** : Sinkhorn, barycentres
      entropiques, potentiels duaux de Kantorovich.
- [ ] **Phase 5 — PoWKM** (*Potential-warm-started Wasserstein K-Means*) :
      nouvel algorithme, clustering de données distribution-valued par
      minimisation d'énergie de transport globale, potentiels dual
      warm-started d'une itération de Lloyd à l'autre.
- [ ] **Phase 6 — Harnais d'expériences** : exécution systématique de tous
      les algorithmes sur tous les bancs d'essai, export CSV/JSON,
      agrégation des métriques, mesures de temps d'exécution et de
      passage à l'échelle.
- [ ] **Phase 7 — Rédaction** : structuration de l'article (JGAA).

## Structure du workspace

```
clustering-research/
├── Cargo.toml                  # workspace
├── validation/                 # scripts Python de validation croisée contre des références externes
└── crates/
    ├── cluster-core/           # Dataset, ClusterResult, trait ClusteringAlgorithm
    ├── cluster-data/           # générateurs synthétiques (blobs, moons, circles, ...)
    ├── cluster-metrics/        # ARI, NMI, Silhouette, Davies-Bouldin, Calinski-Harabasz
    └── cluster-algos/          # implémentations des algorithmes (Phase 2-3 complètes)
        ├── src/                 # kmeans.rs, mean_shift.rs, dbscan.rs, hierarchical.rs,
        │                        # birch.rs, hdbscan.rs, optics.rs, spectral.rs
        └── examples/            # balayages d'hyperparamètres, aperçus benchmark, exports de validation
    └── cluster-ot/              # transport optimal (Phase 4) + PoWKM (Phase 5, contribution originale)
        ├── src/                 # sinkhorn.rs, powkm.rs
        └── examples/            # powkm_benchmark_preview.rs
```

## Résultats K-Means (aperçu qualitatif, `n=300`, graine 42)

| Banc d'essai | k | ARI | Silhouette | Interprétation |
|---|---|---|---|---|
| blobs | 3 | 1.000 | 0.907 | cas facile, recouvrement parfait |
| anisotropic | 3 | 1.000 | 0.758 | séparation suffisante malgré le cisaillement |
| varied_blobs | 3 | 1.000 | 0.845 | robuste aux variances hétérogènes ici |
| moons | 2 | 0.261 | 0.487 | échec attendu (non convexe) |
| circles | 2 | -0.003 | 0.356 | échec quasi total attendu (non convexe, symétrie radiale) |
| varied_density | 3 | 1.000 | 0.883 | robuste ici (clusters encore bien séparés) |

Ces résultats sont cohérents avec les limites théoriques connues de
K-Means (hypothèse implicite de cellules de Voronoï convexes) : utile comme
test de non-régression qualitatif, pas comme résultat final de l'article.

## Résultats Mean-Shift (balayage de bandwidth sur 8 valeurs, `n=300`, graine 42)

| Banc d'essai | meilleur bandwidth | ARI | n_clusters | Interprétation |
|---|---|---|---|---|
| blobs | 1.8 | 1.000 | 3 | parfait dès que bandwidth > écart intra-cluster |
| anisotropic | 2.5 | 1.000 | 3 | fenêtre de bandwidth utile plus étroite qu'attendu (échoue déjà à 3.5) |
| varied_blobs | 5.0 | 1.000 | 3 | nécessite un grand bandwidth à cause du cluster à forte variance |
| moons | 0.5 | 0.262 | 6 | échec structurel : aucun bandwidth testé ne sépare proprement |
| circles | 0.3 | 0.114 | 20 | échec quasi total, pire que moons |
| varied_density | 3.5 | 1.000 | 3 | robuste malgré la densité hétérogène, contrairement à DBSCAN classique attendu |
| uniform_noise | ≥0.8 | n/a | 1 | comportement sain : reconnaît l'absence de structure |

Contrairement à K-Means, Mean-Shift est **entièrement déterministe** (pas
de graine). En contrepartie, son unique hyperparamètre (bandwidth) est
sensible et son réglage optimal varie fortement d'un jeu de données à
l'autre — un point qui devra être discuté explicitement dans le protocole
expérimental de l'article (sélection de bandwidth non supervisée, ex. règle
de Silverman ou validation par Silhouette interne).

## Résultats DBSCAN (meilleurs (eps, min_samples) trouvés par balayage, `n=300`, graine 42)

| Banc d'essai | eps | min_samples | ARI | n_clusters | n_noise |
|---|---|---|---|---|---|
| blobs | 2.0 | 3 | 1.000 | 3 | 0 |
| anisotropic | 2.0 | 3 | 1.000 | 3 | 0 |
| varied_blobs | 2.0 | 3 | 0.985 | 3 | 3 |
| moons | 0.2 | 10 | 1.000 | 2 | 0 |
| circles | 0.2 | 3 | 1.000 | 2 | 0 |
| varied_density | 3.0 | tout min_samples testé | 1.000 | 3 | 0 |
| uniform_noise | 0.1 | 5 | n/a | 16 | 54% |

Point méthodologique important pour l'article : la ligne `varied_density`
ci-dessus montre un ARI=1.000 au meilleur réglage — ce qui **contredit
l'intuition théorique initiale** (DBSCAN classique est censé échouer sur
densité hétérogène à cause d'un eps global unique). Le balayage complet
(`examples/dbscan_verify_test_params.rs`) montre que même des réglages très
différents (eps=0.5 à eps=3.0) donnent presque tous ARI > 0.9. Explication
probable : les centres de `varied_density` sont proportionnellement trop
séparés par rapport aux écarts-types choisis pour stresser réellement cette
limitation. **Action à prévoir avant la rédaction** : concevoir un second
jeu de données "densité hétérogène adverse" avec des centres plus
rapprochés, spécifiquement calibré pour faire échouer DBSCAN et réussir
HDBSCAN (Phase 3) — sans quoi l'argument central de HDBSCAN vs DBSCAN
manquerait de support empirique.

## Résultats regroupement hiérarchique (`n=300` sauf mention contraire, graine 42)

| Comparaison | Résultat |
|---|---|
| blobs, 4 linkages, k=3 | ARI=1.000 pour les 4 critères (cas facile, tous s'accordent) |
| moons, single, k=2 | ARI=0.000 — un point aberrant vole un cluster entier |
| moons, single, k=3 | **ARI=0.980** — quasi parfait dès qu'on laisse une place à l'aberrant |
| moons, Ward, k=2 | ARI=0.358 — échec structurel (clusters compacts, comme K-Means) |
| pont (blob-pont-blob synthétique) | single : cluster déséquilibré 14/5, étendue 18 unités (chaînage) ; complete : 8/11, plus compact |

Enseignement méthodologique clé pour la rédaction : **le choix de k
interagit fortement avec le choix du critère de liaison**, en particulier
pour single linkage, extrêmement sensible aux points aberrants isolés (un
seul point peut « voler » un cluster entier). Ce point devra être discuté
explicitement dans le protocole expérimental — soit en balayant k autour
de la valeur attendue, soit en signalant les clusters singletons comme
quasi-bruit lors de l'agrégation des résultats.

## Résultats BIRCH (threshold=1.0, branching_factor=8, `n=300`, graine 42)

| Banc d'essai | k | ARI | temps |
|---|---|---|---|
| blobs | 3 | 1.000 | ~107 µs |
| anisotropic | 3 | 1.000 | ~65 µs |
| varied_blobs | 3 | 1.000 | ~165 µs |
| moons | 2 | 0.138 | ~25 µs |
| circles | 2 | 0.007 | ~29 µs |
| varied_density | 3 | 1.000 | ~66 µs |
| uniform_noise | 3 | n/a | ~23 µs |

Deux points à retenir pour l'article : (1) BIRCH hérite du biais de son
étape de clustering global (Ward par défaut) vers des clusters compacts —
échec sur lunes/cercles, comme K-Means et Ward hiérarchique ; changer
`global_linkage` en `Linkage::Single` devrait changer ce comportement, à
tester en Phase 6. (2) **Écart de temps d'exécution de 2 à 3 ordres de
grandeur** par rapport aux 4 autres algorithmes (microsecondes contre
dixièmes de milliseconde) : seul algorithme de la Phase 2 dont la
construction est O(n) plutôt que O(n²)/O(n³), confirmant empiriquement la
promesse de passage à l'échelle de l'article original de Zhang et al.
(1996) — un argument expérimental concret à exploiter dans la Phase 6
(comparaison de temps d'exécution en fonction de n).

## HDBSCAN vs DBSCAN sur densité hétérogène : résultat contre-intuitif

Point le plus important de la Phase 3 à ce stade, à traiter explicitement
dans l'article plutôt qu'à passer sous silence.

**Attente initiale** (littérature, motivation habituelle de HDBSCAN) :
DBSCAN échoue sur données à densité hétérogène car il impose un seul eps
global ; HDBSCAN, qui construit une hiérarchie sur la distance de
atteignabilité mutuelle, devrait s'adapter localement et faire mieux.

**Résultat empirique obtenu** (jeu `adversarial_density`, 6 niveaux de
densité, balayage complet des hyperparamètres des deux côtés) :

| Algorithme | Meilleur ARI trouvé |
|---|---|
| DBSCAN (balayage eps × min_samples) | 0.713 |
| HDBSCAN (balayage min_cluster_size × min_samples) | 0.708 |

Quasiment à égalité — **HDBSCAN ne domine pas ici**. Ce résultat a été
recoupé sur 4 configurations synthétiques supplémentaires, à géométrie
variée (2 et 3 clusters, séparés ou rapprochés, écarts de densité modérés
à extrêmes) — voir `examples/hdbscan_vs_dbscan_comparison.rs` — et dans les
4 cas, **DBSCAN égale ou dépasse HDBSCAN**, jamais l'inverse.

**Ce résultat n'est pas un bug d'implémentation** : validation croisée
contre `sklearn.cluster.HDBSCAN` 1.8.0 avec accord exact (ARI=1.000, 100%
des labels identiques, pas seulement à permutation près) sur les deux jeux
de données testés. La référence scikit-learn produit exactement le même
plafond.

**Interprétation à affiner en Phase 6** : l'avantage réel de HDBSCAN en
pratique n'est probablement pas "un plafond de performance plus élevé à
hyperparamètres optimaux" (ce que ce protocole mesure), mais plutôt une
**robustesse accrue au choix des hyperparamètres** — HDBSCAN pourrait
atteindre un bon ARI sur une plage plus large de `min_cluster_size` /
`min_samples`, alors que DBSCAN nécessiterait un réglage plus précis de
`eps` pour atteindre son propre plafond. Cette hypothèse (variance des ARI
sur la grille plutôt que le seul maximum) est vérifiable directement avec
les données déjà collectées par `hdbscan_param_sweep.rs` et
`dbscan_adversarial_check.rs`, à formaliser en Phase 6. Si elle se
confirme, c'est un angle plus nuancé et plus intéressant pour l'article
que la comparaison naïve "qui gagne", et plus honnête vis-à-vis des
résultats obtenus.

## Résultats Spectral Clustering (meilleur gamma par jeu, `n=300`, graine 42)

| Banc d'essai | k | gamma | ARI | temps |
|---|---|---|---|---|
| blobs | 3 | 0.05 | 1.000 | ~111 ms |
| anisotropic | 3 | 0.05 | 1.000 | ~60 ms |
| varied_blobs | 3 | 0.05 | 1.000 | ~112 ms |
| moons | 2 | 25 | 1.000 | ~109 ms |
| circles | 2 | 50 | 1.000 | ~110 ms |
| varied_density | 3 | 0.05 | 1.000 | ~73 ms |

Résultat net : contrairement à K-Means/Ward/BIRCH, Spectral Clustering
réussit sur **tous** les bancs d'essai (y compris lunes et cercles, non
convexes) — à condition de régler `gamma` correctement par banc d'essai
(0.05 pour les blobs, 25-50 pour les formes non convexes, un écart de
3 ordres de grandeur). C'est la même sensibilité aux hyperparamètres que
Mean-Shift (bandwidth) et DBSCAN/HDBSCAN (eps), mais ici sur un paramètre
d'échelle de similarité plutôt que de distance directe. Point à noter :
temps d'exécution nettement plus élevé (dizaines à centaines de
millisecondes) que les algorithmes O(n²) simples, à cause du coût de
l'itération de puissance répétée (k fois, jusqu'à convergence) — à
comparer formellement en Phase 6.

## PoWKM — la contribution originale (Phase 4-5)

### Cadre mathématique

Reformulation du recuit déterministe de Rose (1990) dans le langage du
transport optimal entropique. Univers de données `μ=(1/n)Σδ_{x_i}`,
atomes libres `{y_k}` à poids **auto-cohérents** (E-step + poids, proche
de Sinkhorn mais sans contrainte de marge cible fixée) :

```
r_ik = w_k·exp(-β·c(x_i,y_k)) / Σ_l w_l·exp(-β·c(x_i,y_l))     (E-step)
w_k  = (1/n)·Σ_i r_ik                                            (poids)
y_k  = (Σ_i r_ik·x_i) / (Σ_i r_ik)                               (M-step, forme close)
```

Énergie libre (forme log-partition, robuste) :
```
F_β(Y,w) = -(1/(nβ))·Σ_i log(Σ_k w_k·exp(-β·c(x_i,y_k)))
```

**Lemme (gradient, prouvé par calcul direct + théorème de l'enveloppe,
vérifié par différences finies dans les tests)** :
`∂F/∂y_k = (1/n)·Σ_i r_ik·(y_k - x_i)`.

**Critère de scission** : pour chaque centre, on construit un système
augmenté à K+1 centres (le centre dédoublé selon la direction principale
de sa covariance locale pondérée), on relaxe **tout** le système par EM
complet (pas seulement la paire dédoublée — c'est ce qui rend le critère
global et non local, comme demandé), et on compare l'énergie libre
convergée avant/après. Scission acceptée ssi amélioration relative
significative (voir historique de débogage ci-dessous pour pourquoi
*relative* et pas absolue).

Le nombre de classes n'est **jamais fixé** : on part de K=1 (moyenne
globale), on augmente β progressivement (recuit), et le K retenu au final
est celui du **plateau le plus large en log(β)** — la plage de température
sur laquelle le nombre de clusters reste stable, opérationnalisant
directement le critère demandé plutôt que de prendre K à un β final
arbitraire.

### Historique de débogage (aucune étape masquée)

1. **Erreur de convention de coût.** Premier test de validation contre le
   point de bifurcation connu de Rose (1990) écrit avec β_c=1/(2λ_max(Σ))
   recopié directement de la littérature — échec. La formule de la
   littérature suppose un coût `‖x-y‖²` sans facteur ½ ; ce module utilise
   `c=½‖x-y‖²`. Refait à la main proprement (voir dérivation complète en
   commentaire dans `powkm.rs`) : **β_c=0.2** pour l'exemple test, pas 0.1.
2. **Bug de méthode numérique.** Une fois la bonne valeur cible identifiée,
   l'itération de puissance simple sur `-H` convergeait systématiquement
   vers un mode symétrique trivial (tous les centres bougent ensemble,
   valeur propre constante = 0.5, indépendante de β) plutôt que vers le
   mode antisymétrique de séparation qui porte réellement la bifurcation
   — parce que le mode trivial domine en magnitude sauf loin du point
   critique. Corrigé en matérialisant le hessien complet et en **déflatant
   tout le spectre** (comme `spectral::top_k_eigenvectors`) plutôt qu'en
   espérant que la première direction trouvée soit la bonne.
3. **Sur-segmentation à grand β.** Premier test de bout en bout sur des
   blobs (K vrai=3) donnant K=24 — pas un bug : à β→∞ la pénalité
   d'entropie s'annule et K→n est le comportement mathématiquement attendu
   du recuit. Le vrai manque était l'absence de détection de plateau
   stable. Diagnostiqué en traçant K en fonction de β.
4. **Seuil de scission absolu → relatif.** Le même diagnostic a montré des
   scissions acceptées pour une amélioration d'énergie libre de 10⁻⁵ sur
   une échelle ~1 (0.001 %, du bruit de convergence de l'EM interne, pas
   un signal réel). Remplacé par un seuil relatif (0.1 % par défaut).
5. **Bug de construction des plateaux** (trouvé via le test de stress
   "chevauchement croissant", ci-dessous) : au moment de fermer un
   plateau, le code lui associait les centres *après* le changement de K
   plutôt qu'avant — `n_clusters` annoncé et nombre réel de labels
   distincts divergeaient silencieusement. Invisible avant ce test précis
   car masqué par un `debug_assert!` (désactivé en mode release, le mode
   utilisé pour tous les benchmarks). Remplacé par un `assert_eq!` réel,
   et test de non-régression dédié ajouté.
6. **Largeur de plateau artificielle aux deux extrémités**, trouvée en
   deux temps sur ce même test de stress. D'abord le premier plateau
   (K=1, avant toute scission) : sa largeur dépend de la distance
   arbitraire entre `beta_min` et le premier β critique, pas d'une vraie
   stabilité — il battait un vrai plateau K=3 deux fois plus étroit mais
   borné par deux vraies transitions. Puis, symétriquement, le *dernier*
   plateau (celui actif à `beta_max` ou à l'arrêt anticipé, typiquement un
   régime de sur-segmentation où plus aucune scission ne réussit faute de
   points par groupe) souffrait du même biais côté opposé. Corrigé en
   n'acceptant comme candidats que les plateaux bornés des deux côtés par
   de vraies transitions (ni le premier, ni le dernier).
7. **Arrêt anticipé prématuré**, trouvé juste après le bug 6 sur le même
   test à séparation 4σ : la condition d'arrêt anticipé pouvait se
   déclencher *avant même la première scission*, parce qu'à séparation
   plus faible le premier β critique naturel est plus élevé (un nuage de
   sous-blobs proches, vu comme un seul blob, a une variance globale plus
   petite) — l'algorithme abandonnait alors en pleine confiance sur K=1
   sans qu'aucune structure n'ait eu la moindre chance d'émerger. Corrigé
   en interdisant l'arrêt anticipé tant qu'aucune vraie scission n'a eu
   lieu.

Sept bugs réels trouvés et corrigés par des tests ciblés, pas par
intuition — chacun avec un test de non-régression dédié dans
`powkm.rs`.

### Comparaison avec la littérature sur la découverte de K

Méthodologie : hyperparamètres **génériques**, calculés uniquement à
partir des données (distance au k-ième plus proche voisin façon article
original de DBSCAN, estimation de bandwidth façon
`sklearn.estimate_bandwidth`), **jamais** ajustés en regardant les
labels — même standard pour tous les algorithmes, y compris PoWKM.

**K variable (2,3,4,6,8), blobs standards** (voir
`k_discovery_by_complexity.rs`) : PoWKM égale exactement HDBSCAN, K
correct et ARI=NMI=1.000 sur les 5 niveaux — DBSCAN/OPTICS sur-segmentent
systématiquement, Mean-Shift échoue totalement à K=4.

**Chevauchement croissant, K vrai=3 fixe** (voir `stress_overlap.rs`) —
c'est le résultat le plus important du projet à ce stade :

| séparation | DBSCAN | HDBSCAN | OPTICS | Mean-Shift | **PoWKM** |
|---|---|---|---|---|---|
| 6σ | K=3 ARI=0.52 | K=3 ARI=0.91 | K=3 ARI=0.51 | K=3 ARI=0.95 | **K=3 ARI=0.95** |
| 5σ | K=3 ARI=0.51 | K=3 ARI=0.78 | K=3 ARI=0.50 | K=3 ARI=0.90 | **K=3 ARI=0.90** |
| 4σ | K=3 ARI=0.48 | K=3 ARI=0.47 | K=3 ARI=0.48 | K=3 ARI=0.81 | **K=3 ARI=0.82** |
| 3σ | K=3 ARI=0.22 | K=6 ARI=0.11 | K=3 ARI=0.22 | K=2 ARI=0.25 | **K=3 ARI=0.64** |
| 2.5σ | K=3 ARI=0.00 | K=7 ARI=0.03 | K=3 ARI=0.01 | K=2 ARI=0.21 | **K=3 ARI=0.45** |
| 2σ | K=3 ARI=0.01 | K=6 ARI=0.03 | K=3 ARI=0.01 | K=1 ARI=0.00 | **K=3 ARI=0.36** |

**PoWKM retrouve K=3 exactement à chaque niveau de séparation testé, du
plus facile (6σ) au plus difficile (2σ)** — aucun autre algorithme n'y
arrive de façon stable. Et l'écart **s'élargit** quand le problème devient
difficile : à 2σ, PoWKM (ARI=0.36) fait plus de 10× mieux que DBSCAN/OPTICS
(~0.01) et HDBSCAN (0.03), largement mieux que Mean-Shift (qui s'effondre
à K=1). Ce n'est pas un résultat forcé : obtenu après correction des 7
bugs ci-dessus, sur des hyperparamètres génériques identiques pour tous.

### Le solveur de Newton (théorie)

Point de rigueur à clarifier avant tout : le théorème original de
Kitagawa, Mérigot & Thibert (2019) porte sur le transport semi-discret
entre une mesure source **continue** (à densité) et une cible discrète —
le functional de Kantorovich y est deux fois dérivable (hessien = mesure
de frontière entre cellules de Laguerre) *parce que* la densité rend cette
mesure continue. Nos données sont une mesure **empirique** (somme de
Diracs) : le functional non régularisé y est seulement linéaire par
morceaux — pas de hessien classique, donc le Newton de KMT ne s'applique
pas tel quel à des données discrètes brutes.

La régularisation entropique résout exactement ce problème : elle rend le
functional lisse et strictement concave **même pour une source
empirique**. C'est le **semi-dual entropique** (`newton_ot.rs`) — même
famille mathématique que Sinkhorn, mais résolu par une méthode de Newton
amortie (recherche linéaire par rétrécissement de pas) plutôt que par
point fixe.

**Dérivé et prouvé** (pas seulement codé) :
```
S(g) = Σ_j b_j g_j - ε Σ_i a_i·logsumexp_j((g_j-C_ij)/ε)      (concave en g)
∂S/∂g_j = b_j - Σ_i a_i·r_ij
∂²S/∂g_j² = -(1/ε)Σ_i a_i r_ij(1-r_ij),  ∂²S/∂g_j∂g_l = (1/ε)Σ_i a_i r_ij r_il (j≠l)
```

**6 tests, tous passés du premier coup** : hessien vérifié par différences
finies (indépendant de la dérivation analytique), et surtout **Newton
converge vers exactement le même plan de transport que Sinkhorn**
(`newton_matches_sinkhorn_fixed_point`) — deux solveurs indépendants,
même réponse, la validation croisée la plus forte possible ici puisque
aucune référence externe n'existe pour ce problème précis. Convergence
**quadratique** confirmée empiriquement (`newton_converges_quadratically`).

**Le théorème (établi, pas nouveau — correctement appliqué)** : Newton
amorti sur un functional lisse strictement concave à hessien lipschitzien
converge **localement quadratiquement** (résultat standard, voir Boyd &
Vandenberghe, *Convex Optimization*, §9.5). Appliqué ici : si le
warm-start `g₀` est assez proche de l'optimum, le nombre de chiffres
corrects double environ à chaque itération.

**Démonstration warm-start** (`newton_warm_start_trajectory.rs`, jeu
synthétique à chevauchement 2.5σ, 8 déplacements successifs de centres) :
warm-start ne fait **jamais pire** que redémarrage à froid (3 itérations
contre 3-4), réduction totale de 18 %. Modeste en valeur absolue — Newton
converge déjà si vite (3-4 itérations) qu'il y a un effet plancher — mais
réel et systématique.

**Ce qui reste ouvert, honnêtement** : j'ai un théorème LOCAL (convergence
rapide si le warm-start est déjà proche) et une confirmation empirique,
mais pas encore le théorème GLOBAL qui bornerait rigoureusement la
distance `‖g₀-g*_new‖` en fonction du déplacement des centres `‖Y_old-Y_new‖`
— c'est exactement là que les résultats de stabilité quantitative de
Delalande-Mérigot / Bansil-Kitagawa entreraient en jeu pour compléter la
preuve de bout en bout. Le solveur Newton n'est pas non plus encore
branché sur la boucle de recuit de PoWKM lui-même (qui utilise toujours le
E-step de Gibbs à poids libres de Rose) — les deux formulations
(poids libres vs. poids prescrits façon KMT) ont un statut différent et le
choix entre les deux reste à trancher avant intégration.

### Mise à jour : la borne globale de warm-start (`warm_start_bound.rs`)

**Point de rigueur d'abord** : Delalande-Mérigot et Bansil-Kitagawa ne
s'appliquent en réalité **pas tels quels** à notre cadre — vérifié en
lisant leurs énoncés précis avant d'écrire quoi que ce soit, pas supposé
de mémoire. Les deux portent sur une source **continue** (densité), alors
que la nôtre est empirique — même défaut que celui déjà identifié pour
KMT. Bansil-Kitagawa, en plus, bornent la stabilité pour des perturbations
des **poids** à atomes fixés, pas des positions des centres — l'inverse
de ce dont on a besoin ici. Les citer tels quels aurait été malhonnête.

**Ce qui a été fait à la place** : la régularisation entropique rend déjà
`S(·,Y)` lisse et fortement concave, ce qui permet une preuve de stabilité
**élémentaire et autonome** (lemme de sensibilité standard d'analyse
convexe — aucun résultat de transport optimal nécessaire) :

```text
m ≥ ρ_min²/((K-1)ε)                    (forte concavité de S(·,Y), pigeon-hole sur la variance catégorielle)
L_Y = D/(4ε)                           (Lipschitz de ∇_gS en Y, borne inconditionnelle via r(1-r)≤1/4)
Lip(g*) ≤ L_Y/m                        (lemme de sensibilité : m-forte concavité + L-Lipschitz ⟹ argmax (L/m)-Lipschitz)
```
composé avec le bassin de convergence quadratique (Newton-Kantorovich,
`M` = Lipschitz du hessien en `g`, borne grossière non optimisée) :
`e_0 < 2m/M ⟹` convergence quadratique garantie, budget d'itérations
explicite.

**8 nouveaux tests, tous passés — dont deux qui ont d'abord échoué et ont
forcé une vraie correction** (pas un ajustement de seuil) :
solveur de valeurs propres de Jacobi maison cross-validé contre `numpy`
(3 matrices de référence), puis utilisé pour vérifier que la borne de
forte concavité prédite ne dépasse **jamais** la vraie plus petite valeur
propre du hessien réduit (200 instances, y compris adversariales) ; borne
de Lipschitz en `Y` vérifiée empiriquement sur des déplacements non
infinitésimaux ; lemme de sensibilité vérifié sur un cas abstrait
indépendant du transport optimal ; et surtout — le test de bout en bout —
`‖g*(Y_old)-g*(Y_new)‖` mesuré sur de vrais solves de Newton reste
systématiquement sous la borne prédite, y compris en régime **volontairement
mal conditionné** (`ε` petit devant l'étalement des points, `ρ_min` observé
jusqu'à `~1e-30`).

**Ce que le diagnostic de cet essai mal conditionné a révélé** (pas caché,
documenté) : dans ce régime la borne reste correcte mais devient
**vacueusement lâche** — exactement la dégénérescence en `e^{O(1/ε)}`
anticipée dans la dérivation (`ρ_min` s'effondre exponentiellement quand
l'écart de coût dépasse `O(ε)`). Un premier essai de démonstration
« pratique » avec un déplacement choisi à l'œil (0.02–0.05 sur un nuage
d'échelle ~1) est tombé à **0/40 dans le bassin garanti** — pas un bug,
juste la conséquence du `M` volontairement grossier (`K^{3/2}/(4ε²)`, non
optimisé) qui rend le bassin `2m/M` réellement petit avec ces constantes.
Plutôt que de deviner un déplacement qui « marche » (ce qui aurait été un
ajustement déguisé), le test final calcule le seuil `2m²/(M·L_Y)` **a
priori** (à partir de `g*(Y_old)` seul, avant de résoudre le nouveau
problème) et vérifie que la théorie est auto-cohérente à cette échelle —
ce qu'elle est. **Resserrer `M`** (borne de Lipschitz du hessien,
actuellement non optimisée) pour élargir le bassin garanti à des
déplacements de warm-start réalistes reste un travail ouvert.

**Statut** : le maillon manquant (`‖g₀-g*_new‖` borné en fonction de
`‖Y_old-Y_new‖`) est maintenant établi et testé — mais par une preuve de
convexité élémentaire propre à la régularisation entropique, pas par
Delalande-Mérigot / Bansil-Kitagawa. Le lien authentique avec ces deux
papiers reste ouvert : ce serait l'outil pertinent pour la limite `ε→0`
(régime où notre borne élémentaire dégénère, cf. ci-dessus), pour la
mesure source continue-limite — pas directement pour la nôtre. Pont non
établi, non nécessaire pour la garantie de bout en bout à `ε` fixé
ci-dessus.

### Mise à jour : resserrement de `M` (Lipschitz du hessien en `g`)

Le point faible identifié ci-dessus (`M` grossier, `K^{3/2}/(4ε²)`,
gonflant artificiellement pour les grands `K` — précisément le régime que
la cascade de bifurcations de PoWKM explore) a été retravaillé. Seconde
dérivation, **indépendante de `K`** : `M ≤ 3(1-1/K)/ε²`, en exploitant que
le jacobien du softmax `∂r_i/∂g` est exactement `D_i(g)/ε` (la matrice de
covariance catégorielle qui apparaît déjà dans le hessien lui-même), et
que `λ_max(D_i) ≤ tr(D_i) = 1-Σr_ij² ≤ 1-1/K` (PSD + Cauchy-Schwarz). La
brique `λ_max(D)≤1-1/K` a été vérifiée numériquement (20 000 tirages
Dirichlet, y compris très piqués, avant tout portage en Rust) avant
d'être utilisée. `M` retenu = le minimum des deux bornes valides.

Gain quantifié (calcul vérifié, pas estimé à l'œil) :

| K  | ε=0.5 | gain | ε=2.5 | gain |
|----|-------|------|-------|------|
| 2  | 2.83  | ×2.1 | 0.113 | ×2.1 |
| 5  | 9.60  | ×1.2 | 0.384 | ×1.2 |
| 10 | 10.8  | ×2.9 | 0.432 | ×2.9 |
| 20 | 11.4  | ×7.9 | 0.456 | ×7.9 |

Le bassin garanti `2m/M` croît d'autant — utile précisément là où l'ancien
bornage était le plus pénalisant. 2 tests supplémentaires (la brique
`λ_max` elle-même, puis `M` composé contre de vraies différences finies de
hessien jusqu'à `K=10`) : **10/10 tests du module, 127/127 sur tout le
workspace, 0 warning clippy.**

### Expérience d'efficacité (`examples/warm_start_bound_efficacy.rs`)

Démonstration du gain sur du **vrai clustering**, pas des chiffres Python
isolés : boucle de Lloyd (E-step OT entropique + M-step barycentrique) sur
données synthétiques (`make_blobs`), pour `K∈{2,3,5,8,12,20}`.

**Un vrai bug rencontré et corrigé au passage** (pas ignoré) : la première
version, avec `ε=2.0` fixé et une init par tirage uniforme, a fait planter
le solveur Newton (`pivot quasi nul`) dès `K=5`. Diagnostic : `make_blobs`
espace ses centres en `5√K` (croissant avec `K`), donc un `ε` fixe devient
minuscule devant l'écart réel entre clusters à mesure que `K` grandit —
exactement la dégénérescence `ρ_min→0` déjà documentée plus haut, ici
provoquée involontairement par le script d'expérience lui-même. Corrigé
par un `ε` adaptatif (fraction de l'écart quadratique moyen entre les
vrais centroïdes) et une init k-means++ plutôt qu'un tirage uniforme.

```
cargo run --release --example warm_start_bound_efficacy -p cluster-ot
```

Premier tableau (gain de `M` et itérations Newton réelles, mesurées
indépendamment de toute borne) :

| K  | M avant | M après | gain  | itérations warm | itérations froid |
|----|---------|---------|-------|------------------|-------------------|
| 2  | 0.001   | 0.001   | 1.00× | 1.3              | 2.0               |
| 5  | 0.002   | 0.002   | 1.16× | 2.5              | 3.0               |
| 12 | 0.002   | 0.000   | 3.78× | 2.2              | 2.0               |
| 20 | 0.001   | 0.000   | **7.85×** | 2.2          | 2.0               |

Le facteur `×7.85` annoncé se reproduit **exactement** à partir du vrai
code Rust sur données réelles, pas seulement de l'arithmétique Python.
Second tableau (seuil de déplacement `2m²/(M·L_Y)` en dessous duquel la
convergence quadratique est *garantie*, calculé au point de convergence de
la trajectoire) : le gain de seuil suit la même progression (×1.16 à
K=5, ×7.85 à K=20) — cohérence interne vérifiée.

**Honnêteté sur la portée** : dans cette expérience, aucun pas réel de
Lloyd ne tombe dans le bassin *garanti* (les seuils calculés sont
minuscules, jusqu'à `~1e-21` à K=20) — Newton converge vite en pratique
(2-3 itérations, tableau 1) mais ce n'est pas *prouvé* par la borne
actuelle à cette échelle. C'est la même limite déjà documentée plus haut
(`M` non optimisé), pas un nouveau problème. Le gain démontré ici porte
sur le **facteur d'amélioration de la garantie théorique**, pas encore sur
son atteignabilité pratique à l'échelle d'un vrai pas de clustering.

### Ce qui reste ouvert pour l'article

Le programme théorique complet discuté (Newton global sur potentiels de
Kantorovich, théorie de stabilité quantitative de Delalande-Mérigot /
Bansil-Kitagawa pour le warm-start, connexion à la théorie de régularité
Monge-Ampère/MTW de Figalli-De Philippis) n'est **pas** entièrement mis en
œuvre dans le code actuel. **Mise à jour** : le solveur Newton (poids
prescrits) est maintenant branché sur le même squelette de recuit/scission
que PoWKM — voir `PoWKMPrescribed` ci-dessous — mais comme variante
**séparée**, conservée à côté de `PoWKM` (poids libres, Gibbs) pour
comparaison empirique, pas comme remplacement. La théorie de stabilité
quantitative de Delalande-Mérigot / Bansil-Kitagawa pour le warm-start
reste non branchée à cette intégration (le lien ε→0 documenté dans
`warm_start_bound.rs` reste un chantier distinct). Prochaine étape
empirique suggérée : comparer `PoWKM` vs `PoWKMPrescribed` sur les mêmes
bancs d'essai (voir script de comparaison), puis stresser d'autres axes
(variance hétérogène, tailles déséquilibrées, dimension plus haute).

## PoWKM à poids prescrits + warm-start intégré (`powkm_prescribed.rs`)

Deuxième variante de PoWKM, gardée à côté de l'originale (poids libres,
inchangée) pour comparaison empirique directe sur les mêmes bancs d'essai.
Même squelette (recuit sur β, cascade de bifurcations, sélection du
plateau le plus stable) ; l'E-step de Gibbs à poids libres est remplacé
par un solve du semi-dual entropique à **poids prescrits** via
`newton_ot::newton_semidiscrete_ot`, warm-démarré à chaque étape (potentiel
dual porté d'un pas de β au suivant, et d'un parent à ses deux enfants à
chaque scission).

**Règle de poids prescrits** : à `K=1`, `b=[1]`. Une scission acceptée
partage le poids du parent en deux moitiés égales — exactement la
perturbation symétrique analysée par Rose (1990), pas un choix arbitraire.

**Quatre vrais bugs trouvés et corrigés, pas masqués** (méthode : dériver
à la main, vérifier numériquement en Python indépendamment avant de
porter en Rust, ne jamais ajuster un test pour qu'il passe) :

1. **Fuite de dimension dans le filet de sécurité.** À `ε` très petit
   (fin de recuit), le hessien de Newton peut devenir numériquement
   singulier (mêmes causes que la dégénérescence `ρ_min→0` de
   `warm_start_bound.rs`) — `solve_linear_system` a été modifié pour
   retourner `Option<Vec<f64>>` plutôt que paniquer (`newton_ot.rs`),
   avec Sinkhorn comme filet de sécurité (plus lent, jamais singulier).
   Premier essai du filet : un `zip` divisait chaque ligne (K colonnes)
   par le mauvais vecteur (n éléments), tronquant silencieusement les
   dimensions — planté avec `index 90 out of bounds` dès K=91, diagnostiqué
   précisément avant correction.
2. **Critère de scission artefactuel.** Contrairement au cas libre, où
   l'auto-consolidation des poids empêche naturellement les fausses
   scissions, la comparaison brute d'énergie libre prescrite accepte des
   scissions même très loin de tout point de bifurcation réel — quantifié
   : à `ε=100` (K=1, données `~N(0,1.5²)`), scinder donnait une
   "amélioration" de **+2976%**, pur artefact du changement d'échelle de
   `S` avec `ε`. Corrigé par une porte de stabilité (critère de Rose,
   `β·λ_max(Σ_k) > 1`, calculée sans solve Newton supplémentaire à partir
   de la covariance déjà nécessaire pour la direction de sonde).
3. **Absence de mécanisme d'arrêt intrinsèque.** Un poids prescrit ne
   s'auto-consolide jamais vers 0 (contrairement au cas libre) — sans
   limite explicite, K dépassait 115 sur 90 points en une seule itération
   de β. Corrigé par une limite de résolution (une scission est refusée
   sous l'équivalent de 10 points de données).
4. **`β_c` prescrit ≠ `β_c` libre — découverte, pas une supposition
   confirmée.** J'avais supposé que les deux formulations coïncidaient
   exactement au point symétrique de scission (poids `[0.5,0.5]` dans les
   deux cas). Vrai pour la valeur des poids, faux pour la stabilité : le
   poids est un degré de liberté supplémentaire dans le cas libre, qui
   peut déstabiliser plus tôt. Vérifié numériquement (balayage Python
   indépendant, cas hand-verified `{-3,-1,1,3}`, variance=5) :
   **`β_c^prescrit = 2·β_c^libre` exactement** (0.2 contre 0.1, passage par
   zéro net). Une première version de la porte de stabilité utilisait par
   erreur la formule libre — corrigé, avec un gain de performance
   spectaculaire en prime (suite de tests : de >8 minutes bloquée à 7.7
   secondes).

**10/10 tests du module, 137/137 sur tout le workspace, 0 warning
clippy.** Résultat concret mesuré sur un run complet (`make_blobs(90,3,...)`,
`beta_max=6.0`) : **808 itérations Newton avec warm-start contre 2347 à
froid — réduction de 65.6%.** C'est le premier chiffre de speedup réel
pour le système PoWKM+warm-start intégré (les chiffres précédents,
`newton_warm_start_trajectory` et `warm_start_bound_efficacy`, portaient
sur le solveur Newton isolé, pas sur un vrai run PoWKM).

### Comparaison directe sur le banc d'essai principal (`powkm_free_vs_prescribed.rs`)

Même protocole que le résultat empirique principal (`stress_overlap.rs`,
chevauchement croissant 6σ→2σ) : PoWKM (poids libres) vs PoWKM-prescribed
(Newton + warm-start), qualité (K, ARI, NMI) et temps d'exécution.

```
cargo run --release --example powkm_free_vs_prescribed -p cluster-ot
```

**Vitesse** : PoWKM-prescribed est systématiquement **~3× plus rapide en
temps réel** (ex. 1.19s contre 4.43s à séparation 6σ), cohérent avec la
réduction de 65-73% des itérations Newton mesurée en parallèle sur chaque
niveau de séparation. Aucun déclenchement du filet de sécurité Sinkhorn
sur toute la plage testée (bonne nouvelle : le régime testé reste bien
conditionné pour Newton).

**Qualité — comparable, avec une exception honnête à documenter, pas à
cacher** : aux séparations 6σ, 5σ, 4σ, 3σ et 2σ, les deux variantes
trouvent K=3 avec un ARI quasi identique (écart ≤0.02). **À 2.5σ**,
PoWKM-prescribed trouve K=9 (ARI=0.20) contre K=3 (ARI=0.45) pour la
version libre — un vrai écart de robustesse à ce niveau de difficulté
intermédiaire, pas un artefact du script de comparaison. Cause probable
(à confirmer) : le seuil de masse minimale (10 points, cf. section
précédente) et la porte de stabilité par covariance locale, calibrés pour
éviter la cascade de scissions non bornée, semblent laisser passer une
scission superflue précisément dans cette zone de chevauchement
intermédiaire. Investigation approfondie non faite ici — chantier ouvert
pour la suite, à traiter avant toute affirmation d'équivalence de
robustesse entre les deux variantes.

## Comparaison sur données réelles (finance + défense) et découverte du problème de corrélation

`examples/real_world_finance_defense.rs` compare PoWKM (libre et
prescrit) contre les 8 algorithmes de la littérature déjà implémentés,
sur deux jeux **réels**, pas synthétiques (méthode standard du domaine :
Xu & Wunsch 2005 — traiter la classe d'un jeu de classification comme
vérité terrain pour évaluer du clustering non supervisé) :

- **Finance** : German Credit (Statlog, Hofmann 1994) — 1000 clients, 24
  variables numériques, 2 classes (risque de crédit). Source :
  `zergtant/pytorch-handbook` (GitHub), qui redistribue le fichier
  officiel `german.data-numeric`.
- **Défense/radar** : Ionosphere (Sigillito et al. 1989, Johns Hopkins
  APL) — 351 retours radar du système à réseau phasé de Goose Bay
  (Labrador), 34 variables numériques, 2 classes (structure ionosphérique
  détectée ou non). Source : `selva86/datasets` (GitHub), qui redistribue
  le jeu UCI original.

Fichiers dans `data/real/`, standardisation z-score, hyperparamètres
label-blind (même méthodologie que `k_discovery_comparison.rs`).

```
cargo run --release --example real_world_finance_defense -p cluster-ot
```

**Premier constat, sans appel** : sur German Credit standardisé, PoWKM
(libre) produit **K=294 sur 300 points** (sur-segmentation quasi totale,
ARI=0.000) en **11 minutes** — comportement catastrophique, jamais observé
sur données synthétiques isotropes. PoWKM-prescribed y survit (K=17, 1.7s)
mais reste très en dessous de tous les autres algorithmes (ARI=0.015 —
ceci dit, TOUS les algorithmes échouent sur ce jeu, ARI≤0.05 partout :
German Credit est un problème de classification connu pour être faiblement
séparable en espace euclidien brut, pas un artefact de PoWKM spécifiquement).

**Diagnostic précis avant toute correction** (`crates/cluster-ot/src/linalg.rs`) :
sur German Credit standardisé, `λ_max(Σ)=2.52` pour le nuage entier — alors
qu'une porte de stabilité isotrope l'attendrait proche de 1. Le `β_c` d'une
seule composante réelle (aucune vraie sous-structure) tombe donc à
`1/2.52≈0.40`, bien en dessous de tout `beta_max` raisonnable : la porte de
stabilité de Rose (`β·λ_max(Σ_k)>1`, dérivée pour un bruit intra-cluster à
peu près isotrope) se déclenche sur la **corrélation entre variables**,
pas sur une vraie sous-structure multimodale — les données réelles sont
corrélées (finance, radar), contrairement aux blobs gaussiens isotropes
utilisés pour calibrer/tester l'algorithme jusqu'ici.

**Correctif standard de la littérature, pas spécifique à PoWKM** :
blanchiment PCA (décorréler puis remettre chaque composante principale à
variance 1) avant clustering — implémenté dans `linalg.rs` (solveur de
valeurs **et vecteurs** propres par méthode de Jacobi, étendu depuis le
solveur valeurs-propres-seules de `warm_start_bound.rs`, cross-validé
contre `numpy.linalg.eigh`, 4 tests dont la propriété centrale vérifiée
directement : `λ_max(Σ)=1` exactement après blanchiment).

**Résultat mesuré, progrès réel mais partiel — les deux, honnêtement** :
- **Ionosphere** : PoWKM-prescribed passe de **ARI=0.089 → 0.212** (NMI
  0.238→0.306) après blanchiment — dépasse alors Spectral (0.149),
  s'approche de K-Means/BIRCH/Hiérarchique (~0.17). Reste en dessous de
  DBSCAN/OPTICS (0.37-0.38) et Mean-Shift (0.298) : ces méthodes
  exploitent une structure de densité qu'une approche à centroïdes ne
  capture pas nécessairement aussi bien sur ce jeu.
- **German Credit** : bascule à K=1 (ARI=0.000) après blanchiment — pas
  une amélioration numérique, mais cohérent avec un jeu où aucune méthode
  ne trouve de structure réelle (K=1 = « pas de structure trouvée avec
  confiance » est arguably plus honnête que K=17 avec ARI=0.015).
- **K reste surestimé sur Ionosphere** (K=21, K_vrai=2) malgré le
  blanchiment — le blanchiment corrige la qualité de la partition mais
  pas le nombre de scissions : le seuil de masse minimale (10 points fixe,
  cf. section précédente) est le suspect suivant, pas encore investigué
  (35 scissions possibles avant la limite de résolution sur n=351).
- **PoWKM (libre) blanchi non testé** — désactivé par prudence dans le
  script (pas vérifié séparément que le blanchiment corrige aussi sa
  lenteur catastrophique, contrairement à la version prescrite dont le
  ralentissement avait une cause distincte déjà corrigée, cf. section
  précédente).

**4 nouveaux tests (`linalg.rs`), 141/141 sur tout le workspace, 0
warning clippy.**

## Le vrai correctif : seuil de masse minimale dépendant de la dimension

Le blanchiment PCA améliorait la **qualité** de la partition (ARI×2.4 sur
Ionosphere) mais ne corrigeait pas le **nombre** de scissions (K=21 restait
K=21). Cause creusée plus loin : le seuil de masse minimale (section
précédente) était une constante fixe (10 points), indépendante de la
dimension `d`. Or la porte de stabilité repose sur `λ_max(Σ_k)`, une
estimation de covariance locale — sa fiabilité dépend du nombre de points
**par rapport à** `d`, pas du nombre de points seul. Vérifié avant de
corriger : à K=21 sur Ionosphere (d=34), chaque cluster n'avait en moyenne
que **~17 points pour estimer une covariance à 34 dimensions** — très en
dessous de la règle usuelle (~3d à 10d points pour une direction propre
dominante à peu près stable, soit 102 à 340 points ici).

**Correctif** : seuil `max(10, 3·d)` points au lieu de `10` fixe (`10`
comme plancher pour les petits `d`, comportement inchangé sur les tests
synthétiques 2D déjà validés — vérifié, `warm=808 cold=2347` identique).

**Résultat, meilleur que le blanchiment PCA seul** :

| | K=21 initial | + blanchiment PCA seul | + seuil dépendant de `d` (sans blanchiment) |
|---|---|---|---|
| Ionosphere K | 21 | 21 | **2 (= K_vrai exactement)** |
| Ionosphere ARI | 0.089 | 0.212 | **0.164** |
| Ionosphere NMI | 0.238 | 0.306 | 0.129 |

PoWKM-prescribed retrouve maintenant K=2 exactement sur Ionosphere — la
toute première fois que la découverte automatique de K fonctionne
correctement sur un jeu réel dans cette session — avec un ARI comparable
aux méthodes recevant K_vrai en entrée (K-Means 0.168, Hiérarchique 0.177,
BIRCH 0.173). Reste en dessous de DBSCAN/OPTICS (0.379/0.372), qui
exploitent une structure de densité différente.

**Trouvaille honnête sur l'interaction des deux correctifs** : combiner
blanchiment PCA **et** seuil dépendant de `d` est **pire** que le seuil
seul — la version blanchie retombe à K=1 (sous-scission), les deux
correctifs se chevauchant partiellement (le blanchiment réduit déjà
`λ_max(Σ)` vers 1, et le seuil relevé réduit indépendamment le nombre de
scissions ; ensemble, trop conservateur). **Recommandation actuelle** :
seuil dépendant de `d`, sans blanchiment, comme réglage par défaut — le
blanchiment reste un outil disponible (`pca_whiten`, testé
indépendamment) mais pas à combiner aveuglément avec ce correctif.

German Credit : K=17→3 avec le nouveau seuil (ARI reste faible, ~0.012 —
cohérent, ce jeu reste intrinsèquement difficile pour tous les
algorithmes testés, cf. ci-dessus).

## Domination confirmée dans le régime où l'annealing entropique a un avantage structurel légitime

Point important avant tout chiffre : « être nettement devant » n'est pas
un objectif cohérent sur *tous* les jeux de données — DBSCAN/OPTICS
excellent sur des structures de densité non convexes (Ionosphere plus
haut), PoWKM excelle sur des populations qui se chevauchent
progressivement (le résultat phare déjà prouvé, `stress_overlap.rs`).
`examples/stress_overlap_with_prescribed.rs` reprend ce protocole exact
(même générateur, mêmes hyperparamètres label-blind) en y ajoutant
PoWKM-prescribed, pour vérifier s'il tient la corde dans son propre
régime — avec `beta_max=50` (valeur par défaut, pas réduite comme dans
les scripts précédents) :

```
cargo run --release --example stress_overlap_with_prescribed -p cluster-ot
```

| sep(σ) | Meilleur concurrent (DBSCAN/HDBSCAN/OPTICS/Mean-Shift) | PoWKM (libre) | PoWKM-prescribed |
|--------|---------------------------------------------------------|---------------|--------------------|
| 3.0    | ARI=0.25 (Mean-Shift)                                    | **ARI=0.64**  | **ARI=0.63**       |
| 2.5    | ARI=0.21 (Mean-Shift)                                    | **ARI=0.45**  | ARI=0.20 (K=9, anomalie — voir ci-dessous) |
| 2.0    | ARI=0.21 (Mean-Shift)                                    | **ARI=0.36**  | **ARI=0.34**       |

À 3σ et 2σ, PoWKM-prescribed **domine nettement** tous les algorithmes de
la littérature testés (×2.5 à ×1.6 l'ARI du meilleur concurrent),
pratiquement à égalité avec PoWKM libre. Aux séparations faciles (6σ, 5σ,
4σ), toutes les méthodes centroïdes se valent (~0.81-0.95), sans surprise.

**L'anomalie à 2.5σ, investiguée, pas juste re-signalée** : trace complète
(`POWKM_PRESCRIBED_DEBUG=1`) montre que la trajectoire saute directement
de K=1 à K=4 en une seule itération de β (cascade de 3 scissions
simultanées dans le même pas), sans jamais se stabiliser sur K=3 — la
plage de β où K=3 serait stable, si elle existe, est trop étroite pour
être capturée comme plateau distinct. Deux corrections testées sans
succès : `beta_growth` plus fin (1.03 au lieu de 1.15, toujours K=10) et
seuil d'amélioration relative plus strict (5% au lieu de 0.1%, toujours
K=9). Hypothèse non résolue : la rigidité des poids prescrits (division
stricte par deux, pas d'auto-consolidation possible comme en poids
libres) rendrait le système plus sujet à des cascades simultanées près
d'un point de bifurcation à symétrie élevée (3 clusters en triangle
équilatéral) — cohérent avec la découverte déjà documentée que le
degré de liberté du poids stabilise le système plus tôt côté libre. Reste
un chantier ouvert ; même dans cet état, PoWKM-prescribed à 2.5σ (0.20)
reste comparable au meilleur concurrent de la littérature (Mean-Shift,
0.21), pas en dessous.

## Reproductibilité

- Tous les générateurs de `cluster-data` prennent une graine `seed: u64`
  explicite et utilisent `ChaCha8Rng` (déterministe, indépendant de la
  plateforme). À graine fixée, deux exécutions produisent des jeux de
  données **bit-à-bit identiques** (voir `same_seed_is_bit_for_bit_reproducible`
  dans `crates/cluster-data/src/lib.rs`).
- Toutes les métriques de `cluster-metrics` sont des fonctions pures, sans
  aléa : à entrée fixée, sortie strictement reproductible.
- `DEFAULT_SEED = 42` sera la graine documentée dans le papier pour tous
  les résultats de la Phase 6, sauf étude de sensibilité explicite à la
  graine (à prévoir : moyenner sur plusieurs graines pour les intervalles
  de confiance des métriques).

## Suite de bancs d'essai synthétiques (`standard_benchmark_suite`)

Reprend la suite standard de la littérature en clustering (comparable aux
figures de comparaison d'algorithmes usuelles) :

| Jeu de données | Ce qu'il teste |
|---|---|
| `blobs` | cas isotrope facile (référence) |
| `anisotropic` | covariance non isotrope (casse l'hypothèse sphérique de K-Means) |
| `varied_blobs` | variances intra-cluster hétérogènes |
| `moons` | non-convexité (translation) |
| `circles` | non-convexité (symétrie radiale) |
| `varied_density` | densités hétérogènes entre clusters |
| `uniform_noise` | témoin négatif — absence de structure |

## Métriques

**Externes** (nécessitent la vérité terrain, disponible sur synthétique) :
- Indice de Rand ajusté (ARI) — Hubert & Arabie, 1985
- Information mutuelle normalisée (NMI)

**Internes** (aucune vérité terrain requise, utilisables sur données réelles) :
- Silhouette (Rousseeuw, 1987) — plus haut = mieux
- Davies-Bouldin (1979) — plus **bas** = mieux (attention au sens lors de
  l'agrégation des résultats, à l'inverse des autres métriques)
- Calinski-Harabasz (1974) — plus haut = mieux

Chaque métrique est testée contre au moins un exemple calculé à la main
(voir modules `tests` de chaque crate) — pas seulement contre son propre
code, pour éviter les faux positifs de tests circulaires.

## Comment exécuter spécifiquement la Phase 3 (HDBSCAN + OPTICS + Spectral Clustering)

Section dédiée, en plus du guide général ci-dessous : toutes les commandes
qui suivent ont été **exécutées et vérifiées à l'instant** (pas juste
rédigées) — la sortie réelle obtenue est indiquée en commentaire sous
chaque bloc.

### 1. Tests Phase 3 uniquement (26 tests : 9 HDBSCAN + 8 OPTICS + 9 Spectral Clustering)

```bash
cargo test -p cluster-algos hdbscan
# test result: ok. 9 passed; 0 failed; ... 54 filtered out

cargo test -p cluster-algos optics
# test result: ok. 8 passed; 0 failed; ... 55 filtered out

cargo test -p cluster-algos spectral
# test result: ok. 9 passed; 0 failed; ... 63 filtered out
```

### 2. Régénérer les découvertes empiriques de la Phase 3

```bash
# Recherche du jeu de données adverse (une vingtaine de configs testées)
cargo run --release --example adversarial_search -p cluster-algos
# ... chaîne v7 (6 niveaux): meilleur ARI DBSCAN (large balayage) = 0.670

# Confirmation sur la config finale retenue dans cluster-data
cargo run --release --example dbscan_adversarial_check -p cluster-algos
# Meilleur trouvé: eps=0.25, min_samples=3 -> ARI=0.713
# CONFIRMÉ adverse: aucun (eps, min_samples) testé ne dépasse ARI=0.85

# Balayage HDBSCAN sur ce même jeu adverse
cargo run --release --example hdbscan_param_sweep -p cluster-algos
# Meilleur: min_cluster_size=8, min_samples=1 -> ARI=0.708
# Rappel plafond DBSCAN sur ce même jeu: 0.713

# Comparaison HDBSCAN vs DBSCAN sur 4 configurations différentes
cargo run --release --example hdbscan_vs_dbscan_comparison -p cluster-algos
# 3 clusters bien séparés, écart densité extrême: DBSCAN=1.000  HDBSCAN=0.995

# Aperçu OPTICS sur toute la suite de bancs d'essai (comportement ~DBSCAN)
cargo run --release --example optics_benchmark_preview -p cluster-algos

# Balayage gamma Spectral Clustering sur toute la suite (12 valeurs testées)
cargo run --release --example spectral_gamma_sweep -p cluster-algos
# circles: gamma=15 (marche pour les lunes) donne ARI=-0.003 -> gamma=50 nécessaire

# Aperçu Spectral Clustering avec les meilleurs gamma trouvés
cargo run --release --example spectral_benchmark_preview -p cluster-algos
# ARI=1.000 sur les 6 jeux (y compris lunes/cercles, non convexes)
```

### 3. Validation croisée contre scikit-learn / numpy (Phase 3)

```bash
cargo run --release --example hdbscan_export_for_sklearn -p cluster-algos
python3 validation/compare_hdbscan.py
# blobs               : ARI Rust vs scikit-learn = 1.000000 (100% labels identiques)
# adversarial_density : ARI Rust vs scikit-learn = 1.000000 (100% labels identiques)

cargo run --release --example optics_export_for_sklearn -p cluster-algos
python3 validation/compare_optics.py
# ARI Rust vs scikit-learn: 1.000000
# RESULTAT: PASS

cargo run --release --example spectral_export_for_sklearn -p cluster-algos
python3 validation/compare_spectral.py
# ARI Rust vs scikit-learn: 1.000000
# Plus grandes valeurs propres de M (numpy.linalg.eigh, reference): [1. 1. 1. 0.4325 0.4015]
# RESULTAT: PASS
```

## Comment exécuter spécifiquement la Phase 4-5 (Sinkhorn + PoWKM)

Toutes les commandes ci-dessous ont été **exécutées et vérifiées à
l'instant**.

```bash
# Tests (14 : 5 Sinkhorn + 9 PoWKM)
cargo test -p cluster-ot sinkhorn
# test result: ok. 5 passed; 0 failed; ... 9 filtered out

cargo test -p cluster-ot powkm::tests
# test result: ok. 12 passed; 0 failed; ... 31 filtered out (filtre
# précis : 'powkm' seul matche aussi powkm_prescribed depuis son ajout,
# cf. ci-dessous — le compte "17" d'une version antérieure de ce README
# n'était plus à jour, corrigé ici après re-vérification)

cargo test -p cluster-ot newton_ot
# test result: ok. 6 passed; 0 failed; ... 25 filtered out

cargo test -p cluster-ot warm_start_bound
# test result: ok. 10 passed; 0 failed; ... 23 filtered out

cargo test -p cluster-ot powkm_prescribed
# test result: ok. 10 passed; 0 failed; ... 33 filtered out (~8s, rapide)

cargo test -p cluster-ot linalg
# test result: ok. 4 passed; 0 failed; ... 43 filtered out

# Les deux modules PoWKM à la fois (~470s à cause du test libre le plus
# lent) :
cargo test -p cluster-ot powkm
# test result: ok. 22 passed; 0 failed; ... 21 filtered out

# Comparaison sur données réelles (finance + défense) — nécessite
# data/real/german_credit_numeric.txt et data/real/ionosphere.csv
# (téléchargés depuis GitHub, cf. section dédiée pour les sources et
# licences ; pas suivis par git, à retélécharger si absents)
cargo run --release --example real_world_finance_defense -p cluster-ot

# Démonstration warm-start sur trajectoire de centroïdes (jeu synthétique
# à chevauchement contrôlé 2.5σ, 8 déplacements successifs)
cargo run --release --example newton_warm_start_trajectory -p cluster-ot
# warm-start ne fait jamais pire que froid ; réduction totale ~18%

# Aperçu K émergent vs K réel sur toute la suite (⚠ plusieurs dizaines de
# secondes au total, temps d'exécution non optimisé — voir section PoWKM)
cargo run --release --example powkm_benchmark_preview -p cluster-ot

# Comparaison honnête avec la littérature (hyperparamètres génériques,
# aucun accès aux labels) sur la suite standard
cargo run --release --example k_discovery_comparison -p cluster-ot

# Étude approfondie : K vrai variable (2,3,4,6,8), 4 métriques par algo
cargo run --release --example k_discovery_by_complexity -p cluster-ot

# Test de stress : chevauchement croissant entre clusters (résultat le
# plus important à ce stade — voir section PoWKM ci-dessus). ~2-3 min.
cargo run --release --example stress_overlap -p cluster-ot
```

Point d'attention particulier pour la relecture : les tests
`rose_bifurcation_point_duplicated_pair_hand_verified` et
`rose_bifurcation_crossing_is_near_predicted_beta_c` dans
`crates/cluster-ot/src/powkm.rs` contiennent la dérivation mathématique
complète en commentaire (valeurs numériques prédites analytiquement,
recoupées avec le résultat du code) — c'est le garde-fou de correction le
plus important de tout le module PoWKM.

## Comment exécuter le projet (guide général, tests + résultats Phase 1-2)

### 1. Prérequis

```bash
rustc --version   # testé avec 1.75.0
cargo --version
python3 --version # requis uniquement pour la validation croisée (Rust seul suffit pour tests/exemples)
pip install scikit-learn scipy numpy --break-system-packages   # requis uniquement pour validation/
```

### 2. Lancer toute la suite de tests (67 tests)

```bash
cargo test --workspace
```

Pour un crate ou un algorithme précis :

```bash
cargo test -p cluster-algos              # les 46 tests d'algorithmes uniquement
cargo test -p cluster-algos kmeans       # uniquement les tests K-Means
cargo test -p cluster-algos -- --nocapture   # affiche aussi les println! de documentation
```

### 3. Vérifier la qualité du code (0 warning attendu)

```bash
cargo clippy --workspace --all-targets -- -D warnings
```

### 4. Voir les tableaux de résultats de ce README (les régénérer soi-même)

Chaque tableau ci-dessus provient d'un `example` Rust exécutable, pas d'un
chiffre saisi à la main. Depuis la racine du workspace :

```bash
cargo run --release --example kmeans_benchmark_preview       -p cluster-algos
cargo run --release --example mean_shift_bandwidth_sweep     -p cluster-algos
cargo run --release --example dbscan_param_sweep             -p cluster-algos
cargo run --release --example dbscan_verify_test_params      -p cluster-algos
cargo run --release --example hierarchical_explore           -p cluster-algos
cargo run --release --example birch_benchmark_preview        -p cluster-algos
cargo run --release --example adversarial_search              -p cluster-algos
cargo run --release --example dbscan_adversarial_check        -p cluster-algos
cargo run --release --example hdbscan_param_sweep              -p cluster-algos
cargo run --release --example hdbscan_vs_dbscan_comparison    -p cluster-algos
cargo run --release --example optics_benchmark_preview        -p cluster-algos
cargo run --release --example spectral_gamma_sweep             -p cluster-algos
cargo run --release --example spectral_benchmark_preview      -p cluster-algos
```

(`--release` recommandé : certains balayages lancent des dizaines de runs.)

### 5. Reproduire les validations croisées contre scikit-learn / scipy

Chaque validation est un export Rust suivi d'un script Python de
comparaison, à lancer **depuis la racine du workspace** (les chemins
`validation/*.csv` sont relatifs) :

```bash
# K-Means (précision machine attendue)
cargo run --release --example kmeans_export_for_sklearn -p cluster-algos
python3 validation/compare_kmeans.py

# Mean-Shift (accord structurel attendu)
cargo run --release --example mean_shift_export_for_sklearn -p cluster-algos
python3 validation/compare_mean_shift.py

# DBSCAN (accord exact attendu, y compris label de bruit)
cargo run --release --example dbscan_export_for_sklearn -p cluster-algos
python3 validation/compare_dbscan.py

# Regroupement hiérarchique, 4 linkages (ARI=1.000 exact attendu contre scipy)
cargo run --release --example hierarchical_export_for_scipy -p cluster-algos
python3 validation/compare_hierarchical.py

# BIRCH (accord structurel attendu)
cargo run --release --example birch_export_for_sklearn -p cluster-algos
python3 validation/compare_birch.py

# HDBSCAN (accord exact attendu, y compris label de bruit)
cargo run --release --example hdbscan_export_for_sklearn -p cluster-algos
python3 validation/compare_hdbscan.py

# OPTICS (accord exact attendu)
cargo run --release --example optics_export_for_sklearn -p cluster-algos
python3 validation/compare_optics.py

# Spectral Clustering (accord structurel attendu + validation numpy du solveur)
cargo run --release --example spectral_export_for_sklearn -p cluster-algos
python3 validation/compare_spectral.py
```

Chaque script Python affiche `RESULTAT: PASS` ou `FAIL` en dernière ligne.

### 6. Utiliser le workspace dans son propre code

```rust
use cluster_algos::{KMeans, MeanShift, Dbscan, HierarchicalClustering, Linkage, Birch, Hdbscan, Optics, SpectralClustering};
use cluster_core::ClusteringAlgorithm;
use cluster_data::{make_blobs, standard_benchmark_suite, DEFAULT_SEED};
use cluster_metrics::{adjusted_rand_index, silhouette_score};

let dataset = make_blobs(300, 3, 0.8, DEFAULT_SEED);

let mut km = KMeans::new(3, 42);
let result = km.fit(&dataset);   // -> ClusterResult { labels, n_clusters, runtime, algorithm }

let ari = adjusted_rand_index(dataset.labels_true.as_ref().unwrap(), &result.labels);
let sil = silhouette_score(&dataset.points, &result.labels);

// Chaque algorithme implémente le même trait ClusteringAlgorithm :
let mut db = Dbscan::new(1.5, 5);
let mut hc = HierarchicalClustering::new(3, Linkage::Ward);
let mut birch = Birch::new(1.0, 8, 3);
let mut hdb = Hdbscan::new(15, 5);
let mut optics = Optics::new(1.5, 5, 1.5);
let mut spectral = SpectralClustering::new(3, 0.5, 7);

// PoWKM (Phase 5) : le nombre de clusters n'est PAS un paramètre.
use cluster_ot::PoWKM;
let mut powkm = PoWKM::new(7);
let result = powkm.fit(&dataset);  // result.n_clusters émerge du recuit
```

## Prochaine étape

Le solveur de Newton pour le semi-dual entropique est maintenant implémenté
et validé (6/6 tests, convergence quadratique confirmée, plan de transport
identique à Sinkhorn). Trois chantiers avant rédaction :
1. **Théorème global de warm-start** : relier rigoureusement le
   déplacement des centres `‖Y_old-Y_new‖` à la distance initiale
   `‖g₀-g*_new‖` via les résultats de stabilité quantitative
   (Delalande-Mérigot, Bansil-Kitagawa) — c'est la pièce théorique
   manquante pour transformer la convergence locale (déjà prouvée) en
   borne de bout en bout.
2. **Brancher Newton dans la boucle de PoWKM elle-même** (actuellement
   toujours sur le E-step de Gibbs à poids libres de Rose) — nécessite de
   trancher entre poids libres (caractère actuel de PoWKM, gère les
   tailles de cluster inégales) et poids prescrits (façon KMT, seul cadre
   où le théorème de warm-start s'applique proprement).
3. **Stresser d'autres axes** (variance hétérogène entre clusters, tailles
   déséquilibrées, dimension plus haute) pour tracer le profil complet
   forces/faiblesses de PoWKM — le chevauchement n'est qu'un axe parmi
   d'autres.

Une fois ces points traités : Phase 6 (harnais d'expériences complet,
comparaison des 9 algorithmes) puis Phase 7 (rédaction).
