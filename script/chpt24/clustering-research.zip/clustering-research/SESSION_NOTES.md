# Notes de session — nouveaux jeux de données, diagnostic et corrections PoWKM-prescribed

Résumé complet pour reprise ultérieure. Tout le code livré compile sans
warning et passe 146/146 tests (`cargo test --release --workspace`).

## 1. Nouveaux jeux de données réels

Ajoutés dans `data/real/` avec chargeurs dans
`crates/cluster-ot/examples/real_world_extended_benchmark.rs` :

| Dataset | n | d | K vrai | Source |
|---|---|---|---|---|
| Iris | 150 | 4 | 3 | scikit-learn (officiel) |
| Wine | 178 | 13 | 3 | scikit-learn (officiel) |
| Seeds | 210 | 7 | 3 | jbrownlee/Datasets (UCI) |
| Breast Cancer Wisconsin | 569 | 30 | 2 | scikit-learn (officiel) |
| Sonar | 208 | 60 | 2 | selva86/datasets (même dépôt qu'Ionosphere) |
| Wholesale Customers | 440 | 6 | 2 | TrainingByPackt (UCI), `Channel` comme vérité terrain |

Motivation initiale : German Credit et Ionosphere (déjà présents) sont
difficiles (haute dimension, classes chevauchantes) — ces 6 nouveaux
jeux, mieux séparés (sauf Sonar, volontairement gardé comme cas
difficile de référence, thème défense), permettent de mieux évaluer
PoWKM face à la littérature.

## 2. Bugs corrigés dans `powkm_prescribed.rs` (variante à poids prescrits)

### 2.1 Non-monotonicité de K(β) — corrigée (SQUAREM)

**Diagnostic** : `em_converge_prescribed` utilisait un point fixe EM à
convergence géométrique — près d'une bifurcation, le taux de
convergence tend vers 1 (ralentissement critique, signature
dynamique-des-systèmes standard, vérifié par traçage direct du shift
itération par itération : décroissance lisse mais de plus en plus
lente, jamais d'oscillation). Le plafond fixe de 50-60 itérations était
structurellement insuffisant *quel que soit sa valeur* près du point
critique, produisant des positions non convergées, donc des tests
d'acceptation de scission peu fiables — d'où K(β) qui décroît parfois
(Seeds : 3→2→2→4→3→5, observé avant correction).

**Correction** : accélération SQUAREM (Varadhan & Roland 2008,
*Simple and Globally Convergent Methods for Accelerating the
Convergence of Any EM Algorithm*, Scand. J. Statistics) — vérifiée
numériquement sur suite synthétique à λ=0.99 (1659 pas bruts → 81
évaluations pour 1e-6, ~20×) avant portage Rust.

**Effet mesuré** : cascade K(β) parfaitement monotone sur Seeds après
correction. Tests plus rapides qu'avant (50.7s vs 63.4s sur la suite
cluster-ot), SQUAREM étant plus efficace même hors régime critique.

### 2.2 Cascade gloutonne non bornée — corrigée (une scission par pas de β)

**Diagnostic** : la boucle de scission continuait à accepter des
scissions tant que le critère d'énergie libre s'améliorait, à β FIXE
(pas d'incrément entre deux scissions du même pas). Sur Breast Cancer à
rang réduit, ça donnait K=1→7 en un seul pas de β.

**Correction** : limite à une scission acceptée par pas de β (`break`
après acceptation). Les centres encore instables sont retestés au pas
suivant plutôt que traités en rafale.

**Effet de bord découvert** : cette correction, plus fidèle à la
théorie de Rose, expose que le critère de sélection de plateau par
largeur (hérité du code d'origine) était protégé *par accident* par le
comportement glouton (les sur-segmentations transitoires étaient
absorbées dans un même pas que la vraie scission, invisibles). Une fois
la cascade résolue une scission à la fois, ces sur-segmentations
transitoires deviennent leurs propres plateaux étroits qui concurrencent
le vrai plateau dans la sélection par largeur → régression sur
`recovers_k_on_well_separated_blobs` (K trouvé=4 au lieu de 3),
diagnostiquée et corrigée en 2.4.

### 2.3 Ratio de partage 50/50 forcé — remplacé par un ratio data-driven (impact limité, documenté)

**Diagnostic initial** : la règle « chaque scission partage exactement
en deux moitiés égales » ne peut jamais retomber sur des proportions de
classes réellement inégales (Wine : 59/71/48).

**Tentatives et rejets, dans l'ordre** :
1. EM libre local itéré à convergence, température β courante — rejeté
   (échec de tests : effondrement sur partition dégénérée, même
   pathologie que K-means à K=2 sur données quasi unimodales).
2. Une seule étape E, température courante, perturbation infinitésimale
   — rejeté (signal trop faible, toujours ~0.5/0.5).
3. **Retenu** : court EM libre (10 itérations), à la température
   **critique** β_c=1/λ_max(Σ_k) (pas la β courante) — évite le
   durcissement prématuré tout en donnant un signal exploitable.

**Résultat honnête** : le mécanisme répond bien aux données (vérifié à
haute précision, pas un bug), mais la déviation par rapport à 0.5 reste
systématiquement petite sur les jeux testés — parce que la direction
propre dominante (direction de variance maximale) n'a structurellement
aucune raison de s'aligner avec l'axe de déséquilibre en taille des
sous-populations. **N'a pas résolu le problème initial sur Wine**, mais
reste en place car théoriquement plus correct sans coût de régression
mesuré.

### 2.4 Sélection de plateau final — trois critères essayés

**Ordre chronologique, chacun avec son verdict** :

1. **Largeur de plateau (log β) + exclusion 1er/dernier plateau**
   (méthode d'origine, affinée en cours de session avec
   `blocked_split_pending` pour distinguer plateau réellement stable de
   plateau juste bloqué par la garde de masse minimale). Fonctionne
   bien sur Breast Cancer standard (K=2 correct) mais fragile aux
   sur-segmentations transitoires révélées par la correction 2.2 (blobs
   K=4 au lieu de 3).

2. **Persistance topologique (ToMATo-like, arbre de fusion complet,
   gap sur les persistances triées)** — mathématiquement mieux fondé
   (garantie de stabilité de Cohen-Steiner-Edelsbrunner-Harer 2007),
   mais **rejeté après test** : notre filtration en β est non bornée
   (contrairement à ToMATo où le paramètre est une densité bornée par
   les données), donc "encore vivant à β_max" ne veut pas dire
   "significatif" — juste "pas encore eu l'occasion de mourir". A donné
   un résultat *pire* que la largeur de plateau sur le cas de test
   (K=5 au lieu de 3).

3. **Magnitude du gain d'énergie libre par scission (retenu
   actuellement)** — le gain relatif `(f_before-f_after)/|f_before|` de
   chaque scission acceptée, jusque-là calculé pour le test
   d'acceptation binaire mais jeté, ne dépend pas de β_max. Sélection
   par plus grand écart RELATIF dans les gains triés. **Corrige le cas
   des blobs (K=3 correct) et confirme Wine à rang réduit (K=3
   correct)**, mais **régresse sur Breast Cancer standard** (K=2→3).
   146/146 tests passent (le test invariant a aussi été durci : K
   rapporté = nombre de labels réellement distincts après assignation
   au plus proche centre, pas `centers.len()` aveuglément — un centre
   à masse non nulle peut ne jamais être le plus proche voisin d'aucun
   point).

**Aucun des trois n'est un remplacement strictement meilleur des deux
autres sur l'ensemble des jeux testés.** État actuel : critère 3 en
place, régression connue sur Breast Cancer standard non résolue.

**Piste de recherche ouverte, non aboutie cette session** (documentée
en tête de `powkm_prescribed.rs`) : notre arbre de cascade est un arbre
phylogénétique/ultramétrique au sens d'Ardila & Klivans (2006,
isomorphisme précis avec le complexe de Bergman du matroïde graphique de
K_n), et Huh (2012) établit la log-concavité des coefficients du
polynôme chromatique d'un graphe via la théorie de Hodge du fibré de
Milnor. Si la suite des gains (ou persistances) correspondait à un
invariant standard de ce matroïde, on aurait une garantie de
log-concavité PROUVÉE (donc un unique maximum garanti). **Ce qui manque
pour une application rigoureuse** : établir cette correspondance
précise, ou construire le bon matroïde/polymatroïde spécifique au
recuit de Rose. Travail de recherche à part entière, non entrepris.

## 3. Blanchiment PCA — résultat négatif solide sur German Credit vs. jeux redondants

Documenté en tête de `linalg.rs`. Trois variantes implémentées et
testées :

- `pca_whiten` (existant, inchangé) : corrige German Credit (spike de
  covariance isolé, condition number sain ≈16) mais fait s'effondrer
  Wine/Seeds/Breast Cancer à K=1 (forte redondance de variables →
  valeurs propres quasi nulles → amplification 1/√λ jusqu'à 87×).
- `pca_whiten_shrunk` (nouveau, shrinkage Ledoit-Wolf 2004, **validé à
  la précision machine contre `sklearn.covariance.ledoit_wolf_shrinkage`**,
  7 tests dont cas limites colonne nulle et covariance quasi-singulière) :
  réduit l'amplification (86.7×→7.0× sur Breast Cancer) mais
  **insuffisant seul** — le δ optimal au sens Frobenius global est tiré
  vers le bas par les directions déjà bien estimées.
- `pca_whiten_mp_floor` (nouveau, plancher explicite au bord inférieur
  de Marchenko-Pastur, formule fermée fonction de (n,d) uniquement) :
  amplification ramenée à 1.2-1.4× (quasi le régime sain de German
  Credit) — **mais collapse persiste identiquement sur Wine/Breast
  Cancer**. Résultat négatif décisif : élimine l'hypothèse "amplification
  numérique" comme cause du collapse sur ces jeux.
- `pca_whiten_rank_reduced` (nouveau, ne garde que les directions
  au-dessus du bord SUPÉRIEUR de Marchenko-Pastur — réduction de rang,
  pas juste régularisation) : **succès net sur Wine** (K=3 exact,
  d=13→2), mais résultat mitigé ailleurs (Seeds réduit trop
  agressivement à d=1 ; Breast Cancer régresse même, K=2→13-19 selon le
  critère de sélection utilisé en aval).

**Conclusion pratique documentée dans le code** : le blanchiment (sous
toutes ses formes ici) n'est pas un préconditionnement à appliquer
uniformément — conditionnel à un diagnostic spectral préalable (spike
isolé = bénéfique, redondance diffuse = nuisible quelle que soit la
régularisation).

## 4. Comment tester

```bash
cargo test --release --workspace          # 146 tests, ~55s (cluster-ot domine)
cargo run --release --example real_world_extended_benchmark -p cluster-ot   # ~90s
```

Variables d'environnement de diagnostic disponibles dans
`powkm_prescribed.rs` (aucun coût si non définies) :
- `POWKM_PRESCRIBED_DEBUG=1` : trace détaillée par pas de β (K, tests
  de scission, gains, garde de masse).
- `POWKM_TRACE_SHIFT=1` (avec le précédent) : trace de la convergence
  SQUAREM cycle par cycle.
- `POWKM_DEBUG_PLATEAUS=1` : cascade de plateaux (variante libre,
  `powkm.rs`).

## 5. Limites connues à reprendre en priorité

1. **Régression Breast Cancer standard** (K=2→3 avec le critère de gain
   actuel) — pas encore diagnostiquée en détail, contrairement aux
   autres problèmes de cette session.
2. **Rang réduit sur Seeds/Breast Cancer** ne reproduit pas le succès
   observé sur Wine — cause pas comprise (Seeds : réduction trop
   agressive à d=1 ; Breast Cancer : dégradation nette avec le nouveau
   critère de sélection).
3. **Piste Hodge-Riemann/matroïdes** : ouverte, non commencée
   techniquement.
