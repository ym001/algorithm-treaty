//! `cluster-core`: traits et structures de données partagés par tout le
//! workspace `clustering-research`.
//!
//! Ce crate ne contient volontairement aucune logique d'algorithme ni de
//! génération de données : il définit uniquement le contrat commun
//! (`Dataset`, `ClusterResult`, `ClusteringAlgorithm`) sur lequel s'appuient
//! `cluster-data` (Phase 1), `cluster-algos` (Phases 2-3), `cluster-ot` /
//! l'algorithme PoWKM (Phase 4-5) et `cluster-metrics`.

use std::time::Duration;

/// Un jeu de données de `n` points en dimension `d`.
///
/// `labels_true` est `Some(..)` pour les jeux de données synthétiques
/// (vérité terrain connue par construction, utilisée uniquement pour
/// l'évaluation via des métriques externes comme l'ARI ou la NMI) et `None`
/// pour des données réelles sans étiquette de référence.
#[derive(Debug, Clone)]
pub struct Dataset {
    /// Matrice n x d, une ligne par point.
    pub points: Vec<Vec<f64>>,
    /// Étiquettes de vérité terrain, si connues.
    pub labels_true: Option<Vec<i32>>,
    /// Nom lisible du jeu de données (utilisé dans les rapports/CSV).
    pub name: String,
}

impl Dataset {
    pub fn new(points: Vec<Vec<f64>>, labels_true: Option<Vec<i32>>, name: impl Into<String>) -> Self {
        if let Some(ref labels) = labels_true {
            debug_assert_eq!(
                points.len(),
                labels.len(),
                "labels_true doit avoir la même longueur que points"
            );
        }
        Self {
            points,
            labels_true,
            name: name.into(),
        }
    }

    pub fn n_samples(&self) -> usize {
        self.points.len()
    }

    pub fn n_features(&self) -> usize {
        self.points.first().map_or(0, |p| p.len())
    }
}

/// Résultat produit par l'exécution d'un algorithme de clustering.
#[derive(Debug, Clone)]
pub struct ClusterResult {
    /// Étiquette prédite par point. La convention `-1` désigne le bruit
    /// (utilisée par les méthodes à base de densité comme DBSCAN/HDBSCAN).
    pub labels: Vec<i32>,
    /// Nombre de clusters trouvés (le bruit, label -1, n'est pas compté).
    pub n_clusters: usize,
    /// Temps d'exécution mesuré (méthode `fit` uniquement).
    pub runtime: Duration,
    /// Nom de l'algorithme ayant produit ce résultat (pour les rapports).
    pub algorithm: String,
}

/// Interface commune implémentée par chaque algorithme de clustering du
/// workspace. Les algorithmes stochastiques doivent être entièrement
/// reproductibles à graine fixée (le générateur de nombres aléatoires est
/// la responsabilité de chaque implémentation, généralement fourni au
/// constructeur).
pub trait ClusteringAlgorithm {
    /// Nom court de l'algorithme (utilisé pour l'affichage et les CSV de résultats).
    fn name(&self) -> &str;

    /// Exécute l'algorithme sur `data` et retourne le résultat.
    /// Le chronométrage du temps d'exécution est laissé à l'implémentation
    /// (voir `timed_fit` pour un helper standard) afin de ne mesurer que le
    /// calcul proprement dit, hors préparation des données.
    fn fit(&mut self, data: &Dataset) -> ClusterResult;
}

/// Aide à l'implémentation de `ClusteringAlgorithm::fit` : exécute la
/// closure `f` (qui doit retourner les labels prédits et le nombre de
/// clusters), mesure le temps écoulé et construit le `ClusterResult`
/// correspondant. Centraliser ce chronométrage garantit que toutes les
/// implémentations mesurent le temps de la même façon (reproductibilité
/// méthodologique entre algorithmes).
pub fn timed_fit<F>(name: &str, f: F) -> ClusterResult
where
    F: FnOnce() -> (Vec<i32>, usize),
{
    let start = std::time::Instant::now();
    let (labels, n_clusters) = f();
    let runtime = start.elapsed();
    ClusterResult {
        labels,
        n_clusters,
        runtime,
        algorithm: name.to_string(),
    }
}

/// Distance euclidienne entre deux points de même dimension.
/// Utilitaire partagé par plusieurs algorithmes et métriques.
pub fn euclidean(a: &[f64], b: &[f64]) -> f64 {
    debug_assert_eq!(a.len(), b.len());
    a.iter()
        .zip(b.iter())
        .map(|(x, y)| (x - y).powi(2))
        .sum::<f64>()
        .sqrt()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dataset_dims() {
        let d = Dataset::new(vec![vec![1.0, 2.0], vec![3.0, 4.0]], None, "toy");
        assert_eq!(d.n_samples(), 2);
        assert_eq!(d.n_features(), 2);
    }

    #[test]
    fn dataset_empty() {
        let d = Dataset::new(vec![], None, "empty");
        assert_eq!(d.n_samples(), 0);
        assert_eq!(d.n_features(), 0);
    }

    #[test]
    fn euclidean_known_value() {
        // Triangle 3-4-5
        let a = vec![0.0, 0.0];
        let b = vec![3.0, 4.0];
        assert!((euclidean(&a, &b) - 5.0).abs() < 1e-12);
    }

    #[test]
    fn timed_fit_reports_runtime_and_algo_name() {
        let result = timed_fit("dummy", || (vec![0, 0, 1, 1], 2));
        assert_eq!(result.algorithm, "dummy");
        assert_eq!(result.n_clusters, 2);
        assert_eq!(result.labels, vec![0, 0, 1, 1]);
    }
}
