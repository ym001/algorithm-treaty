//! `cluster-ot` : primitives de transport optimal (Phase 4) et PoWKM
//! (Phase 5) — clustering par recuit sur l'énergie libre entropique, à
//! nombre de classes émergent plutôt que fixé a priori.
//!
//! Statut :
//! - [x] Sinkhorn (transport optimal entropique, domaine logarithmique)
//! - [ ] PoWKM (recuit + scission par hessien)

mod linalg;
mod newton_ot;
mod powkm;
mod powkm_prescribed;
mod sinkhorn;
mod warm_start_bound;
mod tomato_hybrid;

pub use tomato_hybrid::{TomatoHybrid, AIC_COEF_CALIBRATED};
pub use linalg::{pca_whiten, pca_whiten_mp_floor, pca_whiten_rank_reduced, pca_whiten_shrunk};
pub use newton_ot::{newton_semidiscrete_ot, transport_plan_from_g, NewtonOtResult};
pub use powkm::{local_stability, PoWKM};
pub use powkm_prescribed::{local_stability_prescribed, NewtonUsageStats, PoWKMPrescribed};
pub use sinkhorn::{logsumexp, sinkhorn, SinkhornResult};
pub use warm_start_bound::{
    centers_distance, certify_warm_start, diam_bound, gradient_lipschitz_in_y, hessian_lipschitz_crude, hessian_lipschitz_in_g, hessian_lipschitz_k_independent, min_responsibility,
    quadratic_basin_radius, quadratic_iterations_bound, strong_concavity_modulus, verify_warm_start, WarmStartCertificate,
};
