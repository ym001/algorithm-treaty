//! Solveur de Newton pour le **semi-dual** du transport optimal
//! entropique — alternative à convergence locale quadratique au point
//! fixe de Sinkhorn (`sinkhorn.rs`), sur le même problème.
//!
//! ## Pourquoi le semi-dual, pas le dual complet de Kitagawa-Mérigot-Thibert
//!
//! Le théorème original de Kitagawa, Mérigot & Thibert (2019) porte sur le
//! transport semi-discret entre une mesure source **continue** (à densité)
//! et une cible discrète : le functional de Kantorovich y est deux fois
//! dérivable (hessien = mesure de frontière entre cellules de Laguerre)
//! parce que la densité rend les cellules de mesure qui varie
//! continûment avec les potentiels. Nos données sont une mesure
//! **empirique** (somme de Diracs) : le functional non régularisé y est
//! seulement **linéaire par morceaux** (les cellules changent par sauts
//! quand un point traverse une frontière) — pas de hessien classique, donc
//! Newton au sens littéral de KMT ne s'applique pas tel quel à des
//! données discrètes.
//!
//! La régularisation entropique résout exactement ce problème : elle lisse
//! le functional (plus de cellules dures, des responsabilités souples),
//! le rend strictement concave et deux fois dérivable **même pour une
//! source empirique**. C'est le semi-dual ci-dessous.
//!
//! ## Le problème résolu
//!
//! Pour un coût `C` (n×K), poids source `a` (n, fixés), poids cible `b`
//! (K, **fixés** — contrairement à PoWKM/Rose où les poids sont libres),
//! régularisation `ε` :
//! ```text
//! S(g) = Σ_j b_j g_j - ε Σ_i a_i · logsumexp_j((g_j - C_ij)/ε)
//! ```
//! concave en `g` (potentiels de Kantorovich côté cible), à une constante
//! additive près (`S(g+t·1) = S(g)` pour tout `t` — jauge fixée ici en
//! imposant `g_{K-1}=0`).
//!
//! **Gradient** (théorème de l'enveloppe, `r` = responsabilités softmax) :
//! ```text
//! ∂S/∂g_j = b_j - Σ_i a_i·r_ij,   r_ij = exp((g_j-C_ij)/ε) / Σ_l exp((g_l-C_il)/ε)
//! ```
//! **Hessien** (calcul direct, vérifié par différences finies dans les tests) :
//! ```text
//! ∂²S/∂g_j²   = -(1/ε)·Σ_i a_i·r_ij·(1-r_ij)
//! ∂²S/∂g_j∂g_l = (1/ε)·Σ_i a_i·r_ij·r_il      (j≠l)
//! ```

#![allow(clippy::needless_range_loop)]

use crate::logsumexp;

/// Calcule uniquement la matrice de responsabilités `r` (n×K) pour `g`
/// donné — extraite pour être réutilisée telle quelle (même code, pas de
/// second calcul qui pourrait diverger silencieusement) par
/// `warm_start_bound.rs`, qui a besoin de `r` seule sans le hessien.
pub(crate) fn responsibilities_ot(cost: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g: &[f64]) -> Vec<Vec<f64>> {
    let n = a.len();
    let k = b.len();
    (0..n)
        .map(|i| {
            let logits: Vec<f64> = (0..k).map(|j| (g[j] - cost[i][j]) / epsilon).collect();
            let lse = logsumexp(&logits);
            logits.iter().map(|&l| (l - lse).exp()).collect()
        })
        .collect()
}

/// Calcule (r, gradient, hessien réduit KxK) pour g donné. Retourne aussi
/// la valeur de S(g) (utile pour la recherche linéaire du pas de Newton).
fn gradient_hessian_value(cost: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g: &[f64]) -> (Vec<f64>, Vec<Vec<f64>>, f64) {
    let n = a.len();
    let k = b.len();
    let mut grad = b.to_vec();
    let mut hess = vec![vec![0.0; k]; k];
    let mut s_value = 0.0;

    for i in 0..n {
        let logits: Vec<f64> = (0..k).map(|j| (g[j] - cost[i][j]) / epsilon).collect();
        let lse = logsumexp(&logits);
        s_value -= epsilon * a[i] * lse;
        let r: Vec<f64> = logits.iter().map(|&l| (l - lse).exp()).collect();

        for j in 0..k {
            grad[j] -= a[i] * r[j];
            hess[j][j] -= a[i] * r[j] * (1.0 - r[j]) / epsilon;
            for l in (j + 1)..k {
                let cross = a[i] * r[j] * r[l] / epsilon;
                hess[j][l] += cross;
                hess[l][j] += cross;
            }
        }
    }
    for j in 0..k {
        s_value += b[j] * g[j];
    }
    (grad, hess, s_value)
}

fn semi_dual_value(cost: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g: &[f64]) -> f64 {
    let n = a.len();
    let k = b.len();
    let mut s_value: f64 = (0..k).map(|j| b[j] * g[j]).sum();
    for i in 0..n {
        let logits: Vec<f64> = (0..k).map(|j| (g[j] - cost[i][j]) / epsilon).collect();
        s_value -= epsilon * a[i] * logsumexp(&logits);
    }
    s_value
}

/// Résout `A·x = rhs` par élimination de Gauss à pivot partiel. `A` doit
/// être carrée. `None` si le système est numériquement singulier (pivot
/// quasi nul) — cas réel et attendu à `ε` très petit devant l'échelle des
/// coûts (responsabilités quasi indicatrices 0/1, hessien quasi
/// singulier ; cf. `warm_start_bound.rs`, dégénérescence `ρ_min→0`), pas
/// une erreur de programmation. Historique : ce cas provoquait un panic
/// (`assert!`) qui faisait s'écrouler tout appelant sans recours,
/// diagnostiqué en pratique dans `powkm_prescribed.rs` (le recuit sur β
/// explore justement des `ε=1/β` petits par construction). Retourner
/// `None` permet à `newton_semidiscrete_ot` de signaler `converged=false`
/// plutôt que de paniquer — l'appelant décide alors quoi faire (ex.
/// re-essayer à `ε` plus grand, ou accepter le dernier `g` valide).
fn solve_linear_system(a: &[Vec<f64>], rhs: &[f64]) -> Option<Vec<f64>> {
    let m = rhs.len();
    if m == 0 {
        return Some(Vec::new());
    }
    let mut aug: Vec<Vec<f64>> = a
        .iter()
        .enumerate()
        .map(|(i, row)| {
            let mut r = row.clone();
            r.push(rhs[i]);
            r
        })
        .collect();

    for col in 0..m {
        let pivot = (col..m).max_by(|&r1, &r2| aug[r1][col].abs().partial_cmp(&aug[r2][col].abs()).unwrap()).unwrap();
        aug.swap(col, pivot);
        let pivot_val = aug[col][col];
        if pivot_val.abs() <= 1e-12 {
            return None;
        }
        for r in (col + 1)..m {
            let factor = aug[r][col] / pivot_val;
            for c in col..=m {
                aug[r][c] -= factor * aug[col][c];
            }
        }
    }
    let mut x = vec![0.0; m];
    for row in (0..m).rev() {
        let mut sum = aug[row][m];
        for c in (row + 1)..m {
            sum -= aug[row][c] * x[c];
        }
        x[row] = sum / aug[row][row];
    }
    Some(x)
}

#[derive(Debug, Clone)]
pub struct NewtonOtResult {
    pub g: Vec<f64>,
    pub iterations: usize,
    pub converged: bool,
    /// Norme du gradient à chaque itération — permet de vérifier
    /// empiriquement la convergence quadratique (signature de Newton).
    pub gradient_norm_history: Vec<f64>,
}

/// Newton amorti (avec recherche linéaire par rétrécissement de pas) pour
/// le semi-dual entropique, jauge fixée en imposant `g[K-1]=0`.
pub fn newton_semidiscrete_ot(cost: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g_init: Vec<f64>, max_iter: usize, tol: f64) -> NewtonOtResult {
    let k = b.len();
    assert!(k >= 1, "au moins un atome cible requis");
    let mut g = g_init;
    g[k - 1] = 0.0;
    let mut history = Vec::with_capacity(max_iter);

    for iter in 0..max_iter {
        let (grad, hess, s_old) = gradient_hessian_value(cost, a, b, epsilon, &g);
        let grad_norm: f64 = grad.iter().map(|x| x.abs()).sum();
        history.push(grad_norm);
        if grad_norm < tol {
            return NewtonOtResult { g, iterations: iter, converged: true, gradient_norm_history: history };
        }

        let kk = k - 1;
        if kk == 0 {
            // K=1 : un seul atome, g[0]=0 fixé par jauge, rien à optimiser.
            return NewtonOtResult { g, iterations: iter, converged: true, gradient_norm_history: history };
        }
        let h_reduced: Vec<Vec<f64>> = (0..kk).map(|j| (0..kk).map(|l| hess[j][l]).collect()).collect();
        let neg_grad_reduced: Vec<f64> = (0..kk).map(|j| -grad[j]).collect();
        let delta = match solve_linear_system(&h_reduced, &neg_grad_reduced) {
            Some(d) => d,
            None => return NewtonOtResult { g, iterations: iter, converged: false, gradient_norm_history: history },
        };

        let mut step = 1.0;
        loop {
            let mut g_trial = g.clone();
            for j in 0..kk {
                g_trial[j] = g[j] + step * delta[j];
            }
            g_trial[k - 1] = 0.0;
            let s_new = semi_dual_value(cost, a, b, epsilon, &g_trial);
            if s_new > s_old || step < 1e-10 {
                g = g_trial;
                break;
            }
            step *= 0.5;
        }
    }
    let (final_grad, _, _) = gradient_hessian_value(cost, a, b, epsilon, &g);
    let final_norm = final_grad.iter().map(|x| x.abs()).sum();
    history.push(final_norm);
    NewtonOtResult { g, iterations: max_iter, converged: final_norm < tol, gradient_norm_history: history }
}

/// Reconstruit le plan de transport à partir des potentiels g convergés
/// (l'autre potentiel, f, est implicite via sa forme close en fonction de g).
pub fn transport_plan_from_g(cost: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g: &[f64]) -> Vec<Vec<f64>> {
    let n = a.len();
    let k = b.len();
    let mut plan = vec![vec![0.0; k]; n];
    for i in 0..n {
        let logits: Vec<f64> = (0..k).map(|j| (g[j] - cost[i][j]) / epsilon).collect();
        let lse = logsumexp(&logits);
        for j in 0..k {
            plan[i][j] = a[i] * (logits[j] - lse).exp();
        }
    }
    plan
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::sinkhorn;

    #[test]
    fn gradient_hand_computed_symmetric_case() {
        // Cas symétrique : par symétrie, g=[0,0] doit déjà annuler le
        // gradient (vérifié aussi à la main dans le texte de conception).
        let cost = vec![vec![0.0, 0.5], vec![0.5, 0.0]];
        let a = vec![0.5, 0.5];
        let b = vec![0.5, 0.5];
        let (grad, _, _) = gradient_hessian_value(&cost, &a, &b, 1.0, &[0.0, 0.0]);
        assert!(grad.iter().all(|&g| g.abs() < 1e-12), "grad={grad:?}");
    }

    #[test]
    fn hessian_matches_finite_difference_of_gradient() {
        // Vérification indépendante : le hessien analytique doit
        // correspondre à la différence finie du gradient lui-même.
        let cost = vec![vec![0.0, 0.5, 1.5], vec![0.5, 0.0, 0.8], vec![1.2, 0.3, 0.0], vec![2.0, 1.0, 0.1]];
        let a = vec![0.2, 0.3, 0.1, 0.4];
        let b = vec![0.5, 0.3, 0.2];
        let epsilon = 0.7;
        let g = vec![0.3, -0.2, 0.0];
        let h = 1e-6;

        let (_, hess, _) = gradient_hessian_value(&cost, &a, &b, epsilon, &g);

        for j in 0..3 {
            let mut g_plus = g.clone();
            g_plus[j] += h;
            let (grad_plus, _, _) = gradient_hessian_value(&cost, &a, &b, epsilon, &g_plus);
            let mut g_minus = g.clone();
            g_minus[j] -= h;
            let (grad_minus, _, _) = gradient_hessian_value(&cost, &a, &b, epsilon, &g_minus);

            for l in 0..3 {
                let numeric = (grad_plus[l] - grad_minus[l]) / (2.0 * h);
                assert!((numeric - hess[l][j]).abs() < 1e-3, "hess[{l}][{j}]={}, numérique={numeric}", hess[l][j]);
            }
        }
    }

    #[test]
    fn newton_matches_sinkhorn_fixed_point() {
        // Validation croisée directe (même problème, deux solveurs
        // indépendants déjà chacun testés séparément) : Newton sur le
        // semi-dual doit converger vers le MÊME plan de transport que le
        // point fixe de Sinkhorn déjà validé dans cluster-ot.
        let cost = vec![vec![0.0, 1.0, 2.0], vec![1.0, 0.0, 1.0], vec![2.0, 1.0, 0.0], vec![0.5, 1.5, 2.5]];
        let a = vec![0.3, 0.2, 0.3, 0.2];
        let b = vec![0.5, 0.3, 0.2];
        let epsilon = 0.5;

        let newton_result = newton_semidiscrete_ot(&cost, &a, &b, epsilon, vec![0.0; 3], 100, 1e-12);
        assert!(newton_result.converged, "Newton devrait converger");
        let newton_plan = transport_plan_from_g(&cost, &a, &b, epsilon, &newton_result.g);

        let sinkhorn_result = sinkhorn(&cost, &a, &b, epsilon, 5000, 1e-14);

        for i in 0..4 {
            for j in 0..3 {
                assert!(
                    (newton_plan[i][j] - sinkhorn_result.plan[i][j]).abs() < 1e-6,
                    "plan[{i}][{j}]: Newton={}, Sinkhorn={}",
                    newton_plan[i][j],
                    sinkhorn_result.plan[i][j]
                );
            }
        }
    }

    #[test]
    fn newton_converges_quadratically() {
        // Signature de Newton : une fois assez proche de l'optimum, le
        // nombre de chiffres corrects double environ à chaque itération
        // (log(norme du gradient) doit décroître en gros comme -2^t).
        let cost = vec![vec![0.0, 1.0, 2.0, 0.3], vec![1.0, 0.0, 1.0, 0.7], vec![2.0, 1.0, 0.0, 1.5], vec![0.5, 1.5, 2.5, 0.2], vec![0.1, 0.9, 1.8, 0.4]];
        let a = vec![0.25, 0.25, 0.2, 0.15, 0.15];
        let b = vec![0.3, 0.3, 0.2, 0.2];
        let epsilon = 0.3;

        let result = newton_semidiscrete_ot(&cost, &a, &b, epsilon, vec![0.0; 4], 50, 1e-14);
        assert!(result.converged);
        // Sur les 3 dernières itérations avant convergence, la décroissance
        // doit être nettement plus rapide que linéaire.
        let h = &result.gradient_norm_history;
        assert!(h.len() >= 4, "pas assez d'itérations pour juger de la vitesse: {}", h.len());
        let n = h.len();
        if h[n - 3] > 1e-10 {
            let ratio_1 = h[n - 2] / h[n - 3];
            let ratio_2 = h[n - 1] / h[n - 2].max(1e-300);
            assert!(ratio_2 < ratio_1 * 0.5 || h[n - 1] < 1e-10, "convergence pas clairement accélérée: {h:?}");
        }
    }

    #[test]
    fn warm_start_needs_fewer_iterations_than_cold_start() {
        // Démonstration empirique directe du bénéfice de warm-start :
        // après une petite perturbation du coût (analogue à un petit
        // déplacement des centres Y), repartir de la solution précédente
        // converge en moins d'itérations qu'un départ à zéro.
        let cost_a = vec![vec![0.0, 1.0, 2.0], vec![1.0, 0.0, 1.0], vec![2.0, 1.0, 0.0], vec![0.5, 1.5, 2.5]];
        let a = vec![0.3, 0.2, 0.3, 0.2];
        let b = vec![0.5, 0.3, 0.2];
        let epsilon = 0.5;

        let cold = newton_semidiscrete_ot(&cost_a, &a, &b, epsilon, vec![0.0; 3], 100, 1e-10);
        assert!(cold.converged);

        // Petite perturbation du coût (analogue à un léger déplacement des centres).
        let cost_b: Vec<Vec<f64>> = cost_a.iter().map(|row| row.iter().map(|&c| c + 0.01).collect()).collect();

        let warm = newton_semidiscrete_ot(&cost_b, &a, &b, epsilon, cold.g.clone(), 100, 1e-10);
        let coldstart_on_b = newton_semidiscrete_ot(&cost_b, &a, &b, epsilon, vec![0.0; 3], 100, 1e-10);

        assert!(warm.converged);
        assert!(coldstart_on_b.converged);
        assert!(
            warm.iterations <= coldstart_on_b.iterations,
            "warm-start ({} itér.) ne devrait pas être plus lent que cold-start ({} itér.)",
            warm.iterations,
            coldstart_on_b.iterations
        );
    }

    #[test]
    fn handles_single_atom_trivially() {
        let cost = vec![vec![1.0], vec![2.0], vec![0.5]];
        let a = vec![0.3, 0.3, 0.4];
        let b = vec![1.0];
        let result = newton_semidiscrete_ot(&cost, &a, &b, 0.5, vec![0.0], 50, 1e-10);
        assert!(result.converged);
        assert_eq!(result.g, vec![0.0]);
    }
}
