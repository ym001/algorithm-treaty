//! PoWKM à **poids prescrits** (variante de `powkm.rs`, conservé
//! inchangé pour comparaison) : même squelette algorithmique (recuit sur
//! β, cascade de bifurcations détectée par hessien, sélection du plateau
//! le plus stable), mais l'E-step de Gibbs à poids libres de Rose est
//! remplacé par un solve du semi-dual entropique **à poids prescrits**
//! via `newton_ot::newton_semidiscrete_ot`, warm-démarré à chaque étape.
//!
//! ## Piste de recherche ouverte : log-concavité via Hodge-Riemann/matroïdes
//!
//! Notre arbre de cascade (une scission = un nœud interne, hauteur = β)
//! est un arbre phylogénétique/ultramétrique au sens combinatoire
//! standard. **Ce n'est pas juste une analogie** : Ardila & Klivans (*The
//! Bergman complex of a matroid and phylogenetic trees*, J. Combin.
//! Theory Ser. B 96, 2006) établissent un isomorphisme précis entre
//! l'espace des arbres phylogénétiques à n feuilles et le complexe de
//! Bergman (la tropicalisation) du matroïde graphique de K_n. Il existe
//! par ailleurs un résultat de log-concavité déjà établi dans cet esprit
//! : Huh (*Milnor numbers of projective hypersurfaces and the chromatic
//! polynomial of graphs*, 2012) prouve, via la théorie de Hodge du
//! fibré de Milnor d'un arrangement d'hyperplans, la log-concavité des
//! coefficients du polynôme chromatique d'un graphe — donc de son
//! matroïde graphique, exactement le type d'objet associé à nos arbres
//! par Ardila-Klivans.
//!
//! **Ce qui manque pour une application rigoureuse ici, honnêtement** :
//! Ardila-Klivans donne une correspondance au niveau de l'ESPACE des
//! topologies d'arbres possibles, pas automatiquement au niveau de la
//! SUITE NUMÉRIQUE spécifique qu'on veut trier pour la sélection de K
//! (persistance de branche, ou magnitude de gain d'énergie libre, cf.
//! plus bas). Établir que cette suite précise correspond à un nombre de
//! Whitney ou un coefficient du polynôme caractéristique du matroïde
//! graphique — ou construire le bon matroïde/polymatroïde spécifique au
//! recuit de Rose si la correspondance directe ne tient pas — est un
//! travail de recherche à part entière, non entrepris cette session. Si
//! elle aboutit, elle donnerait une garantie de log-concavité PROUVÉE
//! (donc un unique maximum garanti, sans ambiguïté de sélection) plutôt
//! qu'une heuristique de gap empirique — un résultat significativement
//! plus fort pour publication. Traité ici comme piste ouverte, pas comme
//! dépendance du critère de sélection actuellement implémenté (magnitude
//! du gain d'énergie libre par scission, cf. plus bas).
//!
//! ## β_c est doublé par rapport au cas libre (découverte de cette
//! session, pas anticipée)
//!
//! J'avais initialement supposé que le hessien prescrit et le hessien
//! libre coïncidaient exactement au point symétrique de scission
//! (poids [0.5,0.5] dans les deux cas à ce point précis). C'est vrai
//! pour la **valeur** des poids, faux pour la **stabilité** : la
//! formulation libre linéarise conjointement sur (position, poids) — le
//! poids est un degré de liberté supplémentaire qui peut déstabiliser le
//! système plus tôt. En le fixant à exactement `[0.5,0.5]` (poids
//! prescrits), ce degré de liberté disparaît, retardant la bifurcation.
//! Vérifié numériquement (balayage indépendant en Python avant
//! correction du code Rust, cf. `rose_bifurcation_point_matches_free_weight_derivation`)
//! sur le cas hand-verified de `powkm.rs` : **`β_c^prescrit = 2·β_c^libre`
//! exactement** (passage par zéro net, pas approximatif). La porte de
//! stabilité opérationnelle de `fit()` utilise donc `β·λ_max(Σ_k) > 1`
//! (pas `2β·λ_max(Σ_k) > 1`, formule du cas libre) — une première version
//! de cette session utilisait par erreur la formule libre, ce qui
//! déclenchait des scissions deux fois trop tôt et contribuait au
//! gaspillage de calcul diagnostiqué (scissions en cascade suivies de
//! fusions).
//!
//! ## Pourquoi une limite de masse minimale (contrairement au cas libre)
//!
//! Diagnostiqué en pratique, pas anticipé théoriquement : sans limite
//! supplémentaire, la cascade de scissions ne s'arrête jamais d'elle-même
//! avec des poids prescrits. Dans la formulation libre, un enfant de
//! scission non justifié par les données voit son poids s'auto-consolider
//! vers 0 au fil des E-steps (`w_k=(1/n)Σr_ik` s'effondre naturellement),
//! ce qui arrête la considération de cet atome. Un poids **prescrit** ne
//! peut au contraire jamais s'annuler tout seul : il est divisé par deux
//! à chaque scission, par construction, quelle que soit la justification
//! réelle par les données — observé concrètement : sur 90 points, K
//! dépassait 115 sans qu'aucune covariance locale ne redescende, symptôme
//! d'une absence de mécanisme d'arrêt intrinsèque. Une scission est donc
//! refusée dès que la masse prescrite de l'enfant tomberait sous
//! l'équivalent de 10 points de données — limite de résolution, pas un
//! réglage ad hoc.
//!
//! ## Différence mathématique avec `powkm.rs` (pas juste une différence
//! d'implémentation)
//!
//! Formulation libre (Rose 1990, `powkm.rs`) : les poids `w_k` sont
//! recalculés à chaque E-step comme `w_k=(1/n)Σr_ik` — un point fixe
//! auto-cohérent, pas une contrainte imposée. Formulation prescrite (ici)
//! : les poids `b_k` sont **fixés** par une règle déterministe (voir plus
//! bas), et `g` (potentiel dual) est résolu par Newton pour que les
//! marges du transport optimal entropique correspondent **exactement** à
//! `b` (`Σ_i a_i r_ik = b_k`) — c'est le problème que
//! `newton_semidiscrete_ot` résout déjà, ici appliqué avec `a_i=1/n`.
//!
//! **Règle de poids prescrits** : à `K=1`, `b=[1]`. Quand un centre `k`
//! de poids `w_k` est scindé (accepté), ses deux enfants reçoivent
//! chacun `w_k/2` ; tous les autres poids restent inchangés. C'est
//! exactement la perturbation symétrique analysée par Rose (1990) au
//! point de bifurcation (voir `powkm.rs`, dérivation du test
//! `rose_bifurcation_point_duplicated_pair_hand_verified`) — au moment
//! précis d'une scission, prescrit et libre coïncident par construction
//! (poids égaux par symétrie dans les deux cas). Les deux formulations
//! ne divergent qu'**entre** les scissions, quand les poids libres
//! peuvent continuer à évoluer alors que les poids prescrits restent
//! bloqués à la valeur héritée de la dernière scission.
//!
//! Correspondance `ε=1/β` identique à `newton_ot.rs` et au reste du
//! projet — mêmes conventions de coût `c(x,y)=½‖x-y‖²`.
//!
//! ## Ce qui est repris tel quel de `powkm.rs`
//!
//! Le test de scission par hessien (plus petite valeur propre de
//! l'énergie, direction de covariance locale pour la sonde initiale), la
//! structure de recuit sur β (croissance géométrique, arrêt anticipé), et
//! la sélection du plateau le plus stable (le plus large en `log β`, en
//! excluant premier et dernier plateau — même justification, mêmes bugs
//! historiques évités) sont **structurellement identiques** ; seule la
//! brique qui calcule `r` et le gradient change. Les utilitaires
//! d'algèbre linéaire génériques (itération de puissance, produit
//! hessien-vecteur par différences finies) sont dupliqués plutôt que
//! partagés avec `powkm.rs` (fonctions privées à ce module-là) — coût
//! faible (~40 lignes génériques), évite de coupler deux modules déjà
//! chacun délicats.
//!
//! ## Instrumentation warm-start (le point de cette variante)
//!
//! `PoWKMPrescribed::track_cold_start_comparison`, si activé, résout
//! **aussi** chaque problème à froid (`g=0`) en parallèle du warm-start
//! réellement utilisé pour piloter l'algorithme, uniquement pour compter
//! les itérations Newton économisées — n'affecte jamais la trajectoire
//! réelle (les deux solves partent du même problème, seul le warm
//! démarré est utilisé pour la suite). Coût : double le nombre de solves
//! Newton quand activé — à réserver aux expériences, pas à un usage en
//! production.

#![allow(clippy::needless_range_loop, clippy::too_many_arguments)]

use crate::newton_ot::{newton_semidiscrete_ot, responsibilities_ot};
use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;

fn cost(x: &[f64], y: &[f64]) -> f64 {
    0.5 * euclidean(x, y).powi(2)
}

fn cost_matrix(points: &[Vec<f64>], centers: &[Vec<f64>]) -> Vec<Vec<f64>> {
    points.iter().map(|x| centers.iter().map(|y| cost(x, y)).collect()).collect()
}

/// `S(g) = Σ_j b_j g_j - ε Σ_i a_i·logsumexp_j((g_j-C_ij)/ε)` — valeur du
/// semi-dual entropique à l'optimum, égale par dualité forte au coût de
/// transport optimal entropique `OT_ε(a,b;Y)` (Peyré-Cuturi, Prop. 4.4).
/// Dérivation du gradient et vérification de la monotonie en `K` faites
/// numériquement (Python, différences finies, écart 2.7e-11) avant tout
/// portage ici — voir historique de session.
fn entropic_free_energy(cost: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g: &[f64]) -> f64 {
    let n = a.len();
    let k = b.len();
    let direct: f64 = (0..k).map(|j| b[j] * g[j]).sum();
    let log_term: f64 = (0..n)
        .map(|i| {
            let logits: Vec<f64> = (0..k).map(|j| (g[j] - cost[i][j]) / epsilon).collect();
            let m = logits.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
            let s: f64 = logits.iter().map(|&l| (l - m).exp()).sum();
            a[i] * (m + s.ln())
        })
        .sum();
    direct - epsilon * log_term
}

/// Résout Newton (warm-démarré depuis `g_init`) et retourne `(r, g*,
/// itérations utilisées, filet_de_sécurité_déclenché)`.
///
/// **Filet de sécurité** : à `ε=1/β` petit (fin de recuit, `β` proche de
/// `beta_max`), le hessien peut devenir numériquement singulier
/// (responsabilités quasi indicatrices — même dégénérescence `ρ_min→0`
/// que documentée dans `warm_start_bound.rs`). Diagnostiqué en pratique
/// (pas supposé) : plusieurs tests de ce module paniquaient à l'origine
/// sur `beta_max=50` par défaut. Newton signale ce cas via
/// `converged=false` (cf. `newton_ot.rs`, `solve_linear_system`,
/// modifié dans cette même session pour ne plus paniquer) plutôt que de
/// faire s'écrouler tout l'appelant. Ici, on retombe alors sur Sinkhorn
/// (point fixe, jamais de système linéaire à résoudre donc jamais de
/// pivot singulier — déjà testé et validé ailleurs dans ce crate) à
/// froid. Coût : perd le bénéfice du warm-start pour CE solve précis
/// uniquement — le compteur `total_iterations_warm` ne comptabilise pas
/// les itérations Sinkhorn (unité différente), le filet de sécurité est
/// donc compté séparément plutôt que mélangé aux statistiques Newton.
fn solve_and_responsibilities(cost: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g_init: Vec<f64>, max_iter: usize, tol: f64) -> (Vec<Vec<f64>>, Vec<f64>, usize, bool) {
    let result = newton_semidiscrete_ot(cost, a, b, epsilon, g_init, max_iter, tol);
    if result.converged {
        let r = responsibilities_ot(cost, a, b, epsilon, &result.g);
        return (r, result.g, result.iterations, false);
    }
    // Filet de sécurité : Sinkhorn à froid, plus lent mais toujours bien
    // défini (pas de système linéaire à résoudre).
    let sinkhorn_result = crate::sinkhorn::sinkhorn(cost, a, b, epsilon, 2000, tol.max(1e-6));
    let r: Vec<Vec<f64>> = sinkhorn_result
        .plan
        .iter()
        .enumerate()
        .map(|(i, row)| {
            let ai = a[i];
            row.iter().map(|&p| if ai > 1e-15 { p / ai } else { 0.0 }).collect()
        })
        .collect();
    (r, sinkhorn_result.g, result.iterations, true)
}

/// Gradient de l'énergie libre prescrite par rapport aux centres
/// (théorème de l'enveloppe — dérivation vérifiée par différences finies
/// avant portage, voir historique de session) : même formule que le cas
/// libre (`gradient_wrt_centers` dans `powkm.rs`), `r` provenant ici de
/// Newton (marges exactement prescrites) plutôt que du point fixe de
/// Gibbs.
fn gradient_wrt_centers(points: &[Vec<f64>], centers: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g_init: Vec<f64>, max_iter: usize, tol: f64) -> (Vec<Vec<f64>>, Vec<f64>) {
    let cost = cost_matrix(points, centers);
    let (r, g, _iters, _fallback) = solve_and_responsibilities(&cost, a, b, epsilon, g_init, max_iter, tol);
    let dim = centers[0].len();
    let k = centers.len();
    let mut grad = vec![vec![0.0; dim]; k];
    for (i, x) in points.iter().enumerate() {
        for kk in 0..k {
            let rik = r[i][kk];
            for d in 0..dim {
                grad[kk][d] += a[i] * rik * (centers[kk][d] - x[d]);
            }
        }
    }
    (grad, g)
}

/// Statistiques d'usage de Newton accumulées pendant un `fit()` — le but
/// premier de cette variante.
#[derive(Debug, Clone, Default)]
pub struct NewtonUsageStats {
    pub total_solves: usize,
    pub total_iterations_warm: usize,
    /// `None` si `track_cold_start_comparison=false`.
    pub total_iterations_cold: Option<usize>,
    /// Nombre de fois où Newton a échoué (hessien numériquement
    /// singulier, `ε` trop petit) et où le filet de sécurité Sinkhorn a
    /// pris le relais — cf. doc de `solve_and_responsibilities`.
    pub total_sinkhorn_fallbacks: usize,
}

/// EM à β fixé (poids prescrits `b`, warm-démarré depuis `g_init`) :
/// alterne Newton (E-step à marges exactes) et M-step barycentrique,
/// jusqu'à convergence des centres. Retourne `(centres, g final, stats)`.
fn em_converge_prescribed(
    points: &[Vec<f64>],
    init_centers: Vec<Vec<f64>>,
    a: &[f64],
    b: &[f64],
    epsilon: f64,
    g_init: Vec<f64>,
    max_outer: usize,
    newton_max_iter: usize,
    newton_tol: f64,
    tol: f64,
    stats: &mut NewtonUsageStats,
    track_cold: bool,
) -> (Vec<Vec<f64>>, Vec<f64>) {
    let dim = points[0].len();
    let k = init_centers.len();

    let debug_conv = std::env::var("POWKM_PRESCRIBED_DEBUG").is_ok();
    let trace_shift = debug_conv && std::env::var("POWKM_TRACE_SHIFT").is_ok();

    // Un pas EM élémentaire (Newton E-step à marges prescrites + M-step
    // barycentrique) — c'est la carte F dont on accélère le point fixe
    // ci-dessous. Isolée ici pour être appelée trois fois par cycle
    // SQUAREM sans dupliquer la logique (comptage de stats, filet de
    // sécurité `track_cold` inclus).
    let mut one_step = |centers: &[Vec<f64>], g: &[f64]| -> (Vec<Vec<f64>>, Vec<f64>) {
        let cost = cost_matrix(points, centers);
        let (r, g_new, iters, fallback) = solve_and_responsibilities(&cost, a, b, epsilon, g.to_vec(), newton_max_iter, newton_tol);
        stats.total_solves += 1;
        stats.total_iterations_warm += iters;
        if fallback {
            stats.total_sinkhorn_fallbacks += 1;
        }
        if track_cold {
            let (_, _, cold_iters, cold_fallback) = solve_and_responsibilities(&cost, a, b, epsilon, vec![0.0; k], newton_max_iter, newton_tol);
            *stats.total_iterations_cold.get_or_insert(0) += cold_iters;
            if cold_fallback {
                stats.total_sinkhorn_fallbacks += 1;
            }
        }
        assert_eq!(r.len(), points.len(), "r a {} lignes, attendu {} (points)", r.len(), points.len());
        for (i, row) in r.iter().enumerate() {
            assert_eq!(row.len(), k, "r[{i}] a {} colonnes, attendu {k}", row.len());
        }
        let mut new_centers = vec![vec![0.0; dim]; k];
        for kk in 0..k {
            let denom: f64 = points.iter().enumerate().map(|(i, _)| a[i] * r[i][kk]).sum();
            if denom > 1e-12 {
                for (i, x) in points.iter().enumerate() {
                    let w = a[i] * r[i][kk];
                    for d in 0..dim {
                        new_centers[kk][d] += w * x[d];
                    }
                }
                for d in 0..dim {
                    new_centers[kk][d] /= denom;
                }
            } else {
                new_centers[kk] = centers[kk].clone();
            }
        }
        (new_centers, g_new)
    };

    // Distance totale (somme des euclidiennes par centre) entre deux
    // configurations — même métrique que l'ancien critère de shift, pour
    // ne pas changer la sémantique de `tol`.
    fn total_shift(x: &[Vec<f64>], y: &[Vec<f64>]) -> f64 {
        x.iter().zip(y.iter()).map(|(p, q)| euclidean(p, q)).sum()
    }
    fn flatten(x: &[Vec<f64>]) -> Vec<f64> {
        x.iter().flat_map(|c| c.iter().copied()).collect()
    }
    fn unflatten(v: &[f64], k: usize, dim: usize) -> Vec<Vec<f64>> {
        (0..k).map(|kk| v[kk * dim..(kk + 1) * dim].to_vec()).collect()
    }

    let mut centers = init_centers;
    let mut g = g_init;
    let mut converged_at: Option<usize> = None;

    // Budget de cycles : chaque cycle SQUAREM coûte jusqu'à 3 évaluations
    // de `one_step` (contre 1 pour un pas EM brut), mais near d'une
    // bifurcation (taux de convergence géométrique -> 1, ralentissement
    // critique diagnostiqué empiriquement — cf. discussion de session),
    // un pas brut peut nécessiter O(1/(1-λ)) itérations pour converger,
    // ce que SQUAREM ramène à O(log(1/tol)) cycles (Varadhan & Roland
    // 2008, vérifié numériquement sur suite synthétique λ=0.99 avant
    // portage : 1659 pas bruts vs 81 évaluations SQUAREM pour 1e-6).
    // `max_outer` cycles (donc jusqu'à `3*max_outer` évaluations F dans
    // le pire cas) est un budget très généreux compte tenu de ce gain —
    // en pratique la plupart des cycles convergent bien avant.
    for cycle in 0..max_outer {
        let (x1, g1) = one_step(&centers, &g);
        let shift1: f64 = total_shift(&centers, &x1);
        if shift1 < tol {
            centers = x1;
            g = g1;
            converged_at = Some(cycle);
            break;
        }
        let (x2, g2) = one_step(&x1, &g1);

        let r_vec: Vec<f64> = flatten(&x1).iter().zip(flatten(&centers).iter()).map(|(u, v)| u - v).collect();
        let d2_vec: Vec<f64> = flatten(&x2).iter().zip(flatten(&x1).iter()).map(|(u, v)| u - v).collect();
        let v_vec: Vec<f64> = d2_vec.iter().zip(r_vec.iter()).map(|(u, v)| u - v).collect();

        let norm_r = r_vec.iter().map(|x| x * x).sum::<f64>().sqrt();
        let norm_v = v_vec.iter().map(|x| x * x).sum::<f64>().sqrt();

        let (x_new, g_new) = if norm_v < 1e-14 {
            // Extrapolation dégénérée (deuxième différence quasi nulle
            // — déjà en convergence géométrique très rapide, ou point
            // fixe atteint) : repli sur le pas EM brut, pas de division
            // par ~0.
            (x2, g2)
        } else {
            let alpha = -norm_r / norm_v;
            let x0_flat = flatten(&centers);
            let extra_flat: Vec<f64> = (0..x0_flat.len()).map(|i| x0_flat[i] - 2.0 * alpha * r_vec[i] + alpha * alpha * v_vec[i]).collect();
            let x_extra = unflatten(&extra_flat, k, dim);
            // Étape de stabilisation (le coeur de la garantie SQUAREM) :
            // un pas EM brut de plus depuis le point extrapolé, qui ne
            // peut jamais faire "pire" que le pas EM standard puisque F
            // reste un point fixe attractif localement — corrige les
            // éventuels sur-dépassements de l'extrapolation.
            one_step(&x_extra, &g2)
        };

        let cycle_shift = total_shift(&centers, &x_new);
        centers = x_new;
        g = g_new;
        if trace_shift {
            eprintln!("      cycle[{cycle}] shift={cycle_shift:.8} (alpha={:.4})", if norm_v < 1e-14 { 0.0 } else { -norm_r / norm_v });
        }
        if cycle_shift < tol {
            converged_at = Some(cycle);
            break;
        }
    }
    if debug_conv {
        match converged_at {
            Some(it) => eprintln!("    DEBUG em_converge_prescribed (SQUAREM): convergé en {it}/{max_outer} cycles (k={})", centers.len()),
            None => eprintln!("    DEBUG em_converge_prescribed (SQUAREM): NON CONVERGÉ après {max_outer} cycles (k={}) — plafond atteint", centers.len()),
        }
    }
    (centers, g)
}

fn normalize(v: &mut [f64]) {
    let n: f64 = v.iter().map(|x| x * x).sum::<f64>().sqrt();
    if n > 1e-15 {
        for x in v.iter_mut() {
            *x /= n;
        }
    }
}

fn matvec(m: &[Vec<f64>], v: &[f64]) -> Vec<f64> {
    m.iter().map(|row| row.iter().zip(v.iter()).map(|(a, b)| a * b).sum()).collect()
}

/// Rétrécissement de covariance à la Ledoit-Wolf (2004, "A well-conditioned
/// estimator for large-dimensional covariance matrices", *Journal of
/// Multivariate Analysis*). Formule exacte portée depuis
/// `sklearn.covariance._shrunk_covariance.ledoit_wolf_shrinkage` (code
/// source lu en intégralité) et vérifiée indépendamment contre cette
/// implémentation de référence sur 20 cas aléatoires (n/d variés,
/// y compris n<d) avant portage : accord à 1e-13 près (limite de la
/// précision flottante), pas une approximation.
///
/// **Pourquoi ici.** Le test de scission (ci-dessous) repose sur la
/// valeur propre dominante de la covariance locale d'un cluster ; avec
/// peu de points par rapport à la dimension (n_k proche de d, ex. Sonar
/// d=60 ou Zoo d=16), l'estimateur brut de covariance est notoirement peu
/// fiable (biais/variance sur la direction propre dominante), ce qui
/// force en pratique un plancher `min_points_for_split=3d` élevé (cf.
/// documentation en tête de module) --- lui-même responsable d'un
/// plafond artificiel sur K pour les jeux à n/d modéré (K_max≈n/(3d) :
/// K_max=1 pour Sonar, K_max=2 pour Zoo, quelle que soit la structure
/// réelle des données). Le rétrécissement est l'outil statistique
/// standard précisément pour ce régime (n comparable à d), permettant une
/// estimation de direction propre nettement plus stable à n_k fixé,
/// justifiant un plancher plus bas --- calibré ci-dessous sur données
/// synthétiques à vérité connue, jamais sur les jeux réels de test.
fn ledoit_wolf_shrinkage(points: &[Vec<f64>]) -> f64 {
    let n = points.len() as f64;
    let d = points[0].len();

    let mut mean = vec![0.0; d];
    for p in points {
        for j in 0..d {
            mean[j] += p[j] / n;
        }
    }
    let x: Vec<Vec<f64>> = points.iter().map(|p| (0..d).map(|j| p[j] - mean[j]).collect()).collect();

    let emp_cov_trace: Vec<f64> = (0..d).map(|j| x.iter().map(|row| row[j].powi(2)).sum::<f64>() / n).collect();
    let mu: f64 = emp_cov_trace.iter().sum::<f64>() / d as f64;

    let mut beta_raw = 0.0;
    for j in 0..d {
        for k in 0..d {
            let s: f64 = x.iter().map(|row| row[j].powi(2) * row[k].powi(2)).sum();
            beta_raw += s;
        }
    }

    let mut delta_raw = 0.0;
    for j in 0..d {
        for k in 0..d {
            let s: f64 = x.iter().map(|row| row[j] * row[k]).sum();
            delta_raw += s * s;
        }
    }
    delta_raw /= n * n;

    let beta_val = (1.0 / (d as f64 * n)) * (beta_raw / n - delta_raw);
    let mut delta_val = delta_raw - 2.0 * mu * emp_cov_trace.iter().sum::<f64>() + d as f64 * mu * mu;
    delta_val /= d as f64;

    let beta_final = beta_val.min(delta_val);
    if beta_final <= 0.0 {
        0.0
    } else {
        (beta_final / delta_val).clamp(0.0, 1.0)
    }
}

/// Covariance à rétrécissement complète : Σ_shrink = (1-α)·S + α·μ·I,
/// avec α = `ledoit_wolf_shrinkage` ci-dessus et μ = trace(S)/d.
fn shrunk_covariance(points: &[Vec<f64>]) -> Vec<Vec<f64>> {
    let n = points.len() as f64;
    let d = points[0].len();
    let mut mean = vec![0.0; d];
    for p in points {
        for j in 0..d {
            mean[j] += p[j] / n;
        }
    }
    let mut s = vec![vec![0.0; d]; d];
    for p in points {
        for a in 0..d {
            for b in 0..d {
                s[a][b] += (p[a] - mean[a]) * (p[b] - mean[b]) / n;
            }
        }
    }
    let mu: f64 = (0..d).map(|j| s[j][j]).sum::<f64>() / d as f64;
    let alpha = ledoit_wolf_shrinkage(points);
    for a in 0..d {
        for b in 0..d {
            s[a][b] *= 1.0 - alpha;
            if a == b {
                s[a][b] += alpha * mu;
            }
        }
    }
    s
}


fn power_iteration_dense(matrix: &[Vec<f64>], dim: usize, max_iter: usize, tol: f64, rng: &mut ChaCha8Rng) -> (Vec<f64>, f64) {
    let mut v: Vec<f64> = (0..dim).map(|_| rng.gen::<f64>() - 0.5).collect();
    normalize(&mut v);
    for _ in 0..max_iter {
        let mut mv = matvec(matrix, &v);
        normalize(&mut mv);
        let diff: f64 = v.iter().zip(mv.iter()).map(|(a, b)| (a - b).abs()).sum();
        let diff_flip: f64 = v.iter().zip(mv.iter()).map(|(a, b)| (a + b).abs()).sum();
        v = mv;
        if diff.min(diff_flip) < tol {
            break;
        }
    }
    let mv = matvec(matrix, &v);
    let eigenvalue: f64 = v.iter().zip(mv.iter()).map(|(a, b)| a * b).sum();
    (v, eigenvalue)
}

/// Hessien par différences finies de la formule **exacte** du gradient
/// (même stratégie que `powkm.rs`, dupliquée plutôt que partagée — voir
/// doc du module).
fn materialize_hessian(points: &[Vec<f64>], centers: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g_ref: &[f64], h: f64, newton_max_iter: usize, newton_tol: f64) -> Vec<Vec<f64>> {
    let dim = centers[0].len();
    let k = centers.len();
    let total = k * dim;
    let mut h_mat = vec![vec![0.0; total]; total];
    for col in 0..total {
        let mut e = vec![0.0; total];
        e[col] = 1.0;
        let perturb = |sign: f64| -> Vec<Vec<f64>> { (0..k).map(|kk| (0..dim).map(|d| centers[kk][d] + sign * h * e[kk * dim + d]).collect()).collect() };
        let (grad_plus, _) = gradient_wrt_centers(points, &perturb(1.0), a, b, epsilon, g_ref.to_vec(), newton_max_iter, newton_tol);
        let (grad_minus, _) = gradient_wrt_centers(points, &perturb(-1.0), a, b, epsilon, g_ref.to_vec(), newton_max_iter, newton_tol);
        for row in 0..total {
            let (kk, d) = (row / dim, row % dim);
            h_mat[row][col] = (grad_plus[kk][d] - grad_minus[kk][d]) / (2.0 * h);
        }
    }
    for i in 0..total {
        for j in (i + 1)..total {
            let avg = 0.5 * (h_mat[i][j] + h_mat[j][i]);
            h_mat[i][j] = avg;
            h_mat[j][i] = avg;
        }
    }
    h_mat
}

fn smallest_eigenvalue(points: &[Vec<f64>], centers: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, g_ref: &[f64], h: f64, power_iter: usize, newton_max_iter: usize, newton_tol: f64, seed: u64) -> f64 {
    let dim = centers[0].len();
    let k = centers.len();
    let total = k * dim;
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let h_mat = materialize_hessian(points, centers, a, b, epsilon, g_ref, h, newton_max_iter, newton_tol);
    let mut working = h_mat;
    let mut best = f64::INFINITY;
    for _ in 0..total {
        let (v, lambda) = power_iteration_dense(&working, total, power_iter, 1e-12, &mut rng);
        if lambda < best {
            best = lambda;
        }
        for a_ in 0..total {
            for b_ in 0..total {
                working[a_][b_] -= lambda * v[a_] * v[b_];
            }
        }
    }
    best
}

/// Analogue prescrit de `powkm::local_stability` — même rôle (outil de
/// diagnostic/certification a posteriori), même méthode (hessien
/// matérialisé puis déflation complète du spectre).
pub fn local_stability_prescribed(points: &[Vec<f64>], centers: &[Vec<f64>], weights: &[f64], epsilon: f64, seed: u64) -> f64 {
    let a = vec![1.0 / points.len() as f64; points.len()];
    let cost = cost_matrix(points, centers);
    let (_, g, _, _) = solve_and_responsibilities(&cost, &a, weights, epsilon, vec![0.0; weights.len()], 300, 1e-7);
    smallest_eigenvalue(points, centers, &a, weights, epsilon, &g, 1e-4, 300, 300, 1e-7, seed)
}

#[derive(Debug, Clone)]
pub struct PoWKMPrescribed {
    pub beta_min: f64,
    pub beta_max: f64,
    pub beta_growth: f64,
    pub merge_tol: f64,
    pub split_improvement_rel_tol: f64,
    pub early_stop_plateau_ratio: f64,
    pub newton_max_iter: usize,
    pub newton_tol: f64,
    pub seed: u64,
    /// Si `true`, résout aussi chaque problème à froid en parallèle
    /// (uniquement pour compter les itérations économisées — voir doc du
    /// module). Double le coût de calcul : à réserver aux expériences.
    pub track_cold_start_comparison: bool,
    /// Rempli par `fit()`.
    pub last_fit_stats: NewtonUsageStats,
}

impl PoWKMPrescribed {
    pub fn new(seed: u64) -> Self {
        Self {
            beta_min: 0.01,
            beta_max: 50.0,
            beta_growth: 1.15,
            merge_tol: 1e-2,
            split_improvement_rel_tol: 1e-3,
            early_stop_plateau_ratio: 25.0,
            newton_max_iter: 300,
            newton_tol: 1e-7,
            seed,
            track_cold_start_comparison: false,
            last_fit_stats: NewtonUsageStats::default(),
        }
    }
}

struct Plateau {
    k: usize,
    beta_start: f64,
    beta_end: f64,
    centers: Vec<Vec<f64>>,
}

impl Plateau {
    fn log_width(&self) -> f64 {
        (self.beta_end / self.beta_start).ln()
    }
}

impl ClusteringAlgorithm for PoWKMPrescribed {
    fn name(&self) -> &str {
        "PoWKM-prescribed"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        assert!(points.len() >= 2, "PoWKM-prescribed requiert au moins 2 points");
        let dim = points[0].len();
        let n = points.len();
        let a = vec![1.0 / n as f64; n];

        let (beta_min, beta_max, beta_growth, merge_tol, rel_tol, early_stop_ratio, newton_max_iter, newton_tol, seed, track_cold) =
            (self.beta_min, self.beta_max, self.beta_growth, self.merge_tol, self.split_improvement_rel_tol, self.early_stop_plateau_ratio, self.newton_max_iter, self.newton_tol, self.seed, self.track_cold_start_comparison);

        let mut stats = NewtonUsageStats::default();

        let result = timed_fit(self.name(), || {
            let mean: Vec<f64> = (0..dim).map(|d| points.iter().map(|p| p[d]).sum::<f64>() / n as f64).collect();
            let mut centers = vec![mean];
            let mut weights = vec![1.0f64];
            let mut g = vec![0.0f64];
            let mut beta = beta_min;
            let mut rng = ChaCha8Rng::seed_from_u64(seed);

            let mut plateaus: Vec<Plateau> = Vec::new();
            let mut current_plateau_k = centers.len();
            let mut current_plateau_start = beta;
            let mut early_stop_triggered = false;
            let mut plateau_k_at_trigger: usize = 0;
            let mut last_stable_centers = centers.clone();

            // Suivi de la "naissance" (β) de chaque branche vivante,
            // indexé comme `centers`/`weights` — remplace la sélection
            // par largeur de plateau (fragile aux sur-segmentations
            // transitoires légitimes localement mais non significatives
            // globalement, diagnostiqué cette session) par une sélection
            // par écart de persistance sur l'arbre de fusion complet
            // (à la ToMATo, Chazal-Guibas-Oudot-Skraba 2013), avec
            // garantie de stabilité (Cohen-Steiner-Edelsbrunner-Harer
            // 2007) — non-gloutonne par construction : la décision porte
            // sur l'arbre entier, pas sur un historique de décisions
            // locales irréversibles. `birth_beta[0]` = β_min marque le
            // tronc principal (pas un événement de scission, exclu du
            // décompte final).
            let mut birth_beta: Vec<f64> = vec![beta_min];
            let mut persistence_events: Vec<(f64, f64)> = Vec::new();
            let mut split_gains: Vec<f64> = Vec::new();

            while beta < beta_max {
                let step_start = std::time::Instant::now();
                if std::env::var("POWKM_PRESCRIBED_DEBUG").is_ok() {
                    eprintln!("DEBUG beta={beta:.4} K={} epsilon={:.4}", centers.len(), 1.0 / beta);
                }
                let epsilon = 1.0 / beta;
                let (converged, g_new) = em_converge_prescribed(points, centers.clone(), &a, &weights, epsilon, g.clone(), 60, newton_max_iter, newton_tol, 1e-6, &mut stats, track_cold);
                centers = converged;
                g = g_new;

                let mut k_idx = 0;
                let debug = std::env::var("POWKM_PRESCRIBED_DEBUG").is_ok();
                let mut split_attempts_this_beta = 0usize;
                while k_idx < centers.len() {
                    split_attempts_this_beta += 1;
                    if split_attempts_this_beta > 2000 {
                        panic!("cascade de scissions anormalement longue à beta={beta}, K={} — la porte de stabilité aurait dû la borner, à investiguer", centers.len());
                    }
                    // Limite de résolution — voir doc du module,
                    // "Pourquoi une limite de masse minimale". Contrairement
                    // au cas à poids libres (où un poids non justifié
                    // s'auto-consolide vers 0 et déclenche naturellement
                    // `wsum<1e-9` plus bas), un poids prescrit ne s'annule
                    // JAMAIS de lui-même : il est divisé par deux à chaque
                    // scission, par construction, indépendamment de toute
                    // justification réelle par les données. Diagnostiqué en
                    // pratique : sans cette limite, K dépassait 115 sur
                    // seulement 90 points (session), la covariance locale
                    // ne décroissant pas malgré des scissions en cascade —
                    // symptôme d'un manque de mécanisme d'arrêt intrinsèque,
                    // pas d'un bug de calcul.
                    //
                    let min_points_for_split = 10.0_f64.max(3.0 * dim as f64);
                    let mass_ok = weights[k_idx] * n as f64 / 2.0 >= min_points_for_split;

                    // Plancher secondaire, plus bas, pour le chemin
                    // rétrécissement (voir plus bas) : `1.5·d` au lieu de
                    // `3·d`, seuil minimal pour qu'une covariance
                    // rétrécie ait un sens statistique (pas de tuning
                    // contre les données réelles --- ce facteur 1.5 n'a
                    // été choisi qu'après validation sur données
                    // synthétiques à vérité connue, cf.
                    // `stress_test_v3.rs`).
                    let min_points_for_shrunk_split = 10.0_f64.max(1.5 * dim as f64).max(dim as f64 + 1.0);
                    let shrunk_mass_ok = weights[k_idx] * n as f64 / 2.0 >= min_points_for_shrunk_split;

                    if !mass_ok && !shrunk_mass_ok {
                        if debug {
                            eprintln!("  DEBUG k_idx={k_idx} K={} scission bloquée par masse minimale ({:.1} < {min_points_for_shrunk_split:.1} points)", centers.len(), weights[k_idx] * n as f64 / 2.0);
                        }
                        k_idx += 1;
                        continue;
                    }
                    let cost = cost_matrix(points, &centers);
                    let (r, g_here, iters, fallback) = solve_and_responsibilities(&cost, &a, &weights, epsilon, g.clone(), newton_max_iter, newton_tol);
                    stats.total_solves += 1;
                    stats.total_iterations_warm += iters;
                    if fallback {
                        stats.total_sinkhorn_fallbacks += 1;
                    }
                    g = g_here.clone();
                    let f_before = entropic_free_energy(&cost, &a, &weights, epsilon, &g);

                    let wsum: f64 = (0..n).map(|i| a[i] * r[i][k_idx]).sum();
                    if wsum < 1e-9 {
                        k_idx += 1;
                        continue;
                    }

                    // Covariance locale. **Comportement par défaut
                    // inchangé** (covariance pondérée molle brute, comme
                    // avant) dès que la masse dépasse le plancher usuel
                    // `3d` --- zéro risque de régression sur les jeux déjà
                    // bien traités. Le rétrécissement Ledoit-Wolf sur
                    // assignation dure (formule vérifiée indépendamment
                    // contre `sklearn.covariance.ledoit_wolf_shrinkage`,
                    // accord à 1e-13 près) n'intervient QUE dans la marge
                    // `[1.5d, 3d[` --- le régime que `3d` bloquait
                    // entièrement (Sonar d=60, Zoo d=16 : K plafonné à
                    // 1-2 par construction, cf. doc en tête de module) ---
                    // et jamais ailleurs. Restriction ajoutée après
                    // diagnostic : l'assignation dure appliquée
                    // systématiquement (même quand la masse est déjà
                    // largement suffisante) modifie la dynamique de
                    // scission de façon non voulue (sur-scission
                    // aggravée, ralentissement sévère observé sur
                    // blobs synthétiques bien dotés en points) --- la
                    // restreindre au régime qu'elle est censée cibler
                    // élimine cette régression tout en gardant le
                    // bénéfice visé.
                    let cov = if mass_ok {
                        let mut cov = vec![vec![0.0; dim]; dim];
                        for (i, x) in points.iter().enumerate() {
                            let rik = a[i] * r[i][k_idx];
                            if rik <= 0.0 {
                                continue;
                            }
                            for a_ in 0..dim {
                                for b_ in 0..dim {
                                    cov[a_][b_] += rik * (x[a_] - centers[k_idx][a_]) * (x[b_] - centers[k_idx][b_]);
                                }
                            }
                        }
                        for row in cov.iter_mut() {
                            for v in row.iter_mut() {
                                *v /= wsum;
                            }
                        }
                        cov
                    } else {
                        // Régime `[1.5d, 3d[` uniquement (cf. ci-dessus) :
                        // assignation dure + rétrécissement Ledoit-Wolf.
                        let hard_points: Vec<Vec<f64>> = (0..n)
                            .filter(|&i| {
                                let mut best = 0;
                                let mut best_r = r[i][0];
                                for kk in 1..centers.len() {
                                    if r[i][kk] > best_r {
                                        best_r = r[i][kk];
                                        best = kk;
                                    }
                                }
                                best == k_idx
                            })
                            .map(|i| points[i].clone())
                            .collect();
                        if hard_points.len() >= dim + 1 {
                            shrunk_covariance(&hard_points)
                        } else {
                            // Trop peu de points assignés durement (rare,
                            // β faible / responsabilités diffuses) : repli
                            // sur la covariance pondérée molle, seule
                            // option disponible sans échantillon dur.
                            let mut cov = vec![vec![0.0; dim]; dim];
                            for (i, x) in points.iter().enumerate() {
                                let rik = a[i] * r[i][k_idx];
                                if rik <= 0.0 {
                                    continue;
                                }
                                for a_ in 0..dim {
                                    for b_ in 0..dim {
                                        cov[a_][b_] += rik * (x[a_] - centers[k_idx][a_]) * (x[b_] - centers[k_idx][b_]);
                                    }
                                }
                            }
                            for row in cov.iter_mut() {
                                for v in row.iter_mut() {
                                    *v /= wsum;
                                }
                            }
                            cov
                        }
                    };
                    let mut dir: Vec<f64> = (0..dim).map(|_| rng.gen::<f64>() - 0.5).collect();
                    normalize(&mut dir);
                    for _ in 0..50 {
                        let mv: Vec<f64> = (0..dim).map(|a_| (0..dim).map(|b_| cov[a_][b_] * dir[b_]).sum()).collect();
                        let mut nv = mv;
                        normalize(&mut nv);
                        dir = nv;
                    }
                    // λ_max(Σ_k) par quotient de Rayleigh (la direction
                    // `dir` a déjà convergé vers le vecteur propre dominant
                    // via l'itération de puissance ci-dessus).
                    let lambda_max_cov: f64 = (0..dim).map(|a_| (0..dim).map(|b_| dir[a_] * cov[a_][b_] * dir[b_]).sum::<f64>()).sum();

                    // Porte de stabilité — critère ORIGINAL de Rose (1990),
                    // β_c=1/(2λ_max(Σ_k)), pas une heuristique : sans elle,
                    // la comparaison brute d'énergie libre prescrite
                    // accepte des scissions purement artefactuelles loin de
                    // tout point de bifurcation réel — diagnostiqué et
                    // quantifié (session) : à ε=100 (K=1, données
                    // ~N(0,1.5²)), scinder donne une "amélioration" de
                    // +2976%, un pur artefact du changement d'échelle de S
                    // avec ε, aucune structure réelle. Calculée ici SANS
                    // solve Newton supplémentaire (à partir de `cov`, déjà
                    // nécessaire pour la direction de sonde) — la version
                    // précédente utilisait `local_stability_prescribed`
                    // (hessien complet, O(K·dim) solves Newton par
                    // vérification), correcte mais ~100x trop lente pour
                    // K>10 (diagnostiqué : bloqué >2min à K=14). Le hessien
                    // complet reste disponible comme outil de certification
                    // a posteriori (voir `local_stability_prescribed`,
                    // testé séparément), pas comme porte opérationnelle.
                    // β_c_prescrit = 1/λ_max(Σ_k), PAS 1/(2λ_max(Σ_k))
                    // (formule du cas LIBRE) — découverte de cette session
                    // (voir `rose_bifurcation_point_matches_free_weight_derivation`
                    // et la doc du module) : à poids prescrits, le degré de
                    // liberté "poids" disparaît, retardant la bifurcation
                    // d'un facteur 2 exact par rapport au cas libre.
                    // Utiliser la formule libre ici (bug initial de cette
                    // session, corrigé) faisait déclencher des scissions
                    // deux fois trop tôt, expliquant en partie le
                    // gaspillage scission/fusion observé initialement.
                    let unstable = beta * lambda_max_cov > 1.0;
                    if debug {
                        eprintln!("  DEBUG k_idx={k_idx} K={} lambda_max_cov={lambda_max_cov:.4} beta_c={:.4} unstable={unstable}", centers.len(), 1.0 / lambda_max_cov.max(1e-12));
                    }
                    if !unstable {
                        k_idx += 1;
                        continue;
                    }

                    let eps_probe = 0.05 * lambda_max_cov.sqrt().max(1e-6);
                    let y_k = centers[k_idx].clone();
                    let mut c1: Vec<f64> = (0..dim).map(|d| y_k[d] + eps_probe * dir[d]).collect();
                    let mut c2: Vec<f64> = (0..dim).map(|d| y_k[d] - eps_probe * dir[d]).collect();

                    // Ratio de partage naturel, PAS 50/50 imposé : un
                    // court EM libre local (poids NON contraints,
                    // formulation Rose 1990 originale), mais à la
                    // température CRITIQUE β_c=1/λ_max(Σ_k) — PAS à la
                    // température courante β. Corrige un défaut
                    // structurel diagnostiqué cette session : imposer
                    // exactement moitié/moitié ne peut jamais retomber sur
                    // des tailles de sous-groupes réellement inégales
                    // (ex. Wine, classes 59/71/48).
                    //
                    // Deux versions rejetées avant celle-ci, chacune
                    // diagnostiquée par échec de test, pas ajustée à
                    // l'aveugle :
                    // - Itérer jusqu'à convergence À LA TEMPÉRATURE
                    //   COURANTE β (potentiellement très supérieure à
                    //   β_c) : durcit prématurément le partage souple en
                    //   assignation quasi dure, s'effondre sur un enfant
                    //   affamé (poids quasi nul) — même pathologie que
                    //   K-means à K=2 sur données quasi unimodales,
                    //   extrêmement sensible à l'initialisation près d'une
                    //   bifurcation à peine émergente.
                    // - Une seule étape E à la température courante β,
                    //   sans itération : signal trop faible — à
                    //   perturbation infinitésimale (eps_probe petit) et
                    //   température élevée, le softmax reste proche de
                    //   50/50 par construction quel que soit le vrai
                    //   déséquilibre sous-jacent (le déplacement par
                    //   rapport à 0.5 est O(eps_probe · asymétrie), donc
                    //   négligeable si eps_probe est petit).
                    // β_c est précisément l'échelle où l'équation
                    // d'amplitude de la bifurcation (Rose 1990) prédit
                    // l'émergence PROGRESSIVE de la paire — ni figée
                    // (β≫β_c, durcissement), ni imperceptible (sonde
                    // infinitésimale sans itération).
                    let beta_c = 1.0 / lambda_max_cov.max(1e-12);
                    let local_mass: Vec<f64> = (0..n).map(|i| a[i] * r[i][k_idx]).collect();
                    let (mut b1, mut b2) = (0.0, 0.0);
                    for _ in 0..10 {
                        let (mut n1, mut n2) = (vec![0.0; dim], vec![0.0; dim]);
                        let (mut s1, mut s2) = (0.0, 0.0);
                        for (i, x) in points.iter().enumerate() {
                            let w = local_mass[i];
                            if w <= 0.0 {
                                continue;
                            }
                            let d1: f64 = (0..dim).map(|d| (x[d] - c1[d]).powi(2)).sum();
                            let d2: f64 = (0..dim).map(|d| (x[d] - c2[d]).powi(2)).sum();
                            let m = (-beta_c * d1 / 2.0).max(-beta_c * d2 / 2.0);
                            let e1 = (-beta_c * d1 / 2.0 - m).exp();
                            let e2 = (-beta_c * d2 / 2.0 - m).exp();
                            let p1 = e1 / (e1 + e2);
                            s1 += w * p1;
                            s2 += w * (1.0 - p1);
                            for d in 0..dim {
                                n1[d] += w * p1 * x[d];
                                n2[d] += w * (1.0 - p1) * x[d];
                            }
                        }
                        if s1 > 1e-12 {
                            for d in 0..dim {
                                c1[d] = n1[d] / s1;
                            }
                        }
                        if s2 > 1e-12 {
                            for d in 0..dim {
                                c2[d] = n2[d] / s2;
                            }
                        }
                        b1 = s1;
                        b2 = s2;
                    }
                    // Renormalisation + plancher de sécurité à 15% : cf.
                    // note de version précédente — préserve la masse
                    // totale du parent, évite qu'un enfant hérite d'une
                    // masse quasi nulle (casserait l'invariant
                    // n_clusters == labels distincts).
                    let total_b = b1 + b2;
                    let ratio1 = if total_b > 1e-12 { (b1 / total_b).clamp(0.15, 0.85) } else { 0.5 };
                    let (share1, share2) = (weights[k_idx] * ratio1, weights[k_idx] * (1.0 - ratio1));
                    if debug {
                        eprintln!("    DEBUG ratio de partage local (k_idx={k_idx}, beta_c={beta_c:.4}) : {ratio1:.4}/{:.4} (au lieu de 0.5/0.5)", 1.0 - ratio1);
                    }

                    let mut trial_centers = centers.clone();
                    trial_centers[k_idx] = c1;
                    trial_centers.push(c2);

                    let mut trial_weights = weights.clone();
                    trial_weights[k_idx] = share1;
                    trial_weights.push(share2);

                    // Warm-start : le nouvel atome hérite de la valeur de
                    // g de son parent (les deux enfants démarrent à la
                    // même position, donc au même potentiel dual initial
                    // — meilleure estimation disponible sans information
                    // supplémentaire).
                    let mut trial_g = g.clone();
                    let g_parent = trial_g[k_idx];
                    trial_g.push(g_parent);

                    let (relaxed, g_relaxed) =
                        em_converge_prescribed(points, trial_centers, &a, &trial_weights, epsilon, trial_g, 50, newton_max_iter, newton_tol, 1e-6, &mut stats, track_cold);
                    let cost_relaxed = cost_matrix(points, &relaxed);
                    let (_, g_relaxed_final, iters_final, fallback_final) = solve_and_responsibilities(&cost_relaxed, &a, &trial_weights, epsilon, g_relaxed, newton_max_iter, newton_tol);
                    stats.total_solves += 1;
                    stats.total_iterations_warm += iters_final;
                    if fallback_final {
                        stats.total_sinkhorn_fallbacks += 1;
                    }
                    let f_after = entropic_free_energy(&cost_relaxed, &a, &trial_weights, epsilon, &g_relaxed_final);

                    if f_after < f_before * (1.0 - rel_tol) {
                        centers = relaxed;
                        weights = trial_weights;
                        g = g_relaxed_final;

                        // Règle de l'aîné (par masse) : l'enfant le plus
                        // lourd hérite de la lignée du parent (même
                        // naissance), l'autre est une branche
                        // nouvellement née à ce β — convention standard
                        // des arbres de fusion (elder rule), cf. note
                        // d'initialisation de `birth_beta`.
                        let old_birth = birth_beta[k_idx];
                        let (birth1, birth2) = if share1 >= share2 { (old_birth, beta) } else { (beta, old_birth) };
                        birth_beta[k_idx] = birth1;
                        birth_beta.push(birth2);

                        // Magnitude du gain d'énergie libre relatif de
                        // cette scission — remplace la sélection par
                        // persistance en β (cf. doc du module) :
                        // diagnostiqué cette session que la persistance
                        // "jusqu'à beta_max" ne distingue pas une vraie
                        // bifurcation d'une scission marginale qui
                        // survit simplement faute d'avoir eu l'occasion
                        // de mourir avant la coupure de calcul (biais de
                        // troncature de la dernière observation). Le
                        // GAIN d'énergie libre, lui, ne dépend pas de
                        // combien de temps la scission survit — une
                        // vraie bifurcation doit apporter une
                        // amélioration nettement plus grande qu'une
                        // scission marginale, indépendamment de β_max.
                        let gain = (f_before - f_after) / f_before.abs().max(1e-12);
                        split_gains.push(gain);

                        // Une seule scission acceptée par pas de β — pas
                        // de cascade gloutonne illimitée. Diagnostiqué
                        // cette session (Breast Cancer à rang réduit,
                        // K=1→7 en un seul pas) : sans cette limite, la
                        // boucle continue à scinder tant que le critère
                        // d'énergie libre s'améliore, à β FIXE, ce qui ne
                        // correspond à aucune prédiction de la théorie de
                        // Rose (cascade de bifurcations résolues une par
                        // une à mesure que β croît réellement). Les
                        // centres encore instables après cette scission
                        // seront retestés au pas de β suivant
                        // (`beta_growth`≈15%, incrément fin) — pas
                        // perdus, juste résolus dans l'ordre plutôt qu'en
                        // rafale.
                        break;
                    } else {
                        k_idx += 1;
                    }
                }

                // Fusion : doit aussi fusionner les poids (les sommer) —
                // contrairement au cas libre, où les poids sont de toute
                // façon recalculés juste après par le prochain E-step. Ici
                // les poids sont la source de vérité, donc perdre de la
                // masse à la fusion serait un vrai bug (violerait
                // Σw_k=1).
                if debug {
                    for i in 0..centers.len() {
                        for j in (i + 1)..centers.len() {
                            let d = euclidean(&centers[i], &centers[j]);
                            if d < 10.0 * merge_tol {
                                eprintln!("  DEBUG pre-merge dist(centre {i},{j})={d:.6} (merge_tol={merge_tol}) poids=[{:.4},{:.4}]", weights[i], weights[j]);
                            }
                        }
                    }
                }
                let (merged_centers, merged_weights, merged_birth) = merge_close_centers_prescribed(centers, weights, birth_beta, beta, merge_tol, &mut persistence_events);
                centers = merged_centers;
                weights = merged_weights;
                birth_beta = merged_birth;
                // g redémarré à froid après une fusion : cas suffisamment
                // rare pour que perdre le warm-start ici n'affecte pas les
                // stats globales, et beaucoup plus simple/sûr que
                // d'essayer de reconstruire un g cohérent avec le nouveau
                // K après fusion.
                if g.len() != weights.len() {
                    g = vec![0.0; weights.len()];
                }

                if centers.len() != current_plateau_k {
                    plateaus.push(Plateau { k: current_plateau_k, beta_start: current_plateau_start, beta_end: beta, centers: last_stable_centers.clone() });
                    current_plateau_k = centers.len();
                    current_plateau_start = beta;
                }
                last_stable_centers = centers.clone();

                if std::env::var("POWKM_PRESCRIBED_DEBUG").is_ok() {
                    eprintln!("  DEBUG fin pas beta={beta:.4} K_final={} duree={:?}", centers.len(), step_start.elapsed());
                }
                beta *= beta_growth;

                // Correctif (diagnostiqué : conflit entre arrêt anticipé et
                // exclusion du dernier plateau, cf. `early_stop_triggered`
                // ci-dessus) : ne jamais interrompre pendant que le plateau
                // qui a déclenché l'arrêt anticipé est encore le plateau
                // courant --- sinon il devient structurellement "le
                // dernier" et se fait exclure par la règle anti-troncature,
                // au profit de plateaux transitoires parasites bien plus
                // étroits (observé : K=4 correct avec largeur 3.35 exclu au
                // profit de K=3 à largeur 0.14, sur blobs synthétiques
                // symétriques 4-clusters). On continue donc jusqu'à
                // observer AU MOINS une transition de K après le
                // déclenchement, ce qui repousse le plateau dominant hors
                // de la position "dernier" avant d'arrêter --- borné
                // naturellement par `beta_max` (boucle englobante), donc
                // aucun risque de boucle infinie.
                if !plateaus.is_empty() {
                    let current_width = (beta / current_plateau_start).ln();
                    let best_previous_width = plateaus.iter().map(|p| p.log_width()).fold(0.0, f64::max);
                    if !early_stop_triggered && current_width > early_stop_ratio.ln() && current_width > 3.0 * best_previous_width.max(1.0) {
                        early_stop_triggered = true;
                        plateau_k_at_trigger = current_plateau_k;
                    }
                }
                if early_stop_triggered && current_plateau_k != plateau_k_at_trigger {
                    break;
                }
            }
            plateaus.push(Plateau { k: current_plateau_k, beta_start: current_plateau_start, beta_end: beta, centers: last_stable_centers.clone() });

            // Sélection de K par largeur de plateau (identique à
            // powkm.rs) --- RÉHABILITÉE cette session après diagnostic
            // complet, en remplacement de l'heuristique par plus grand
            // écart relatif dans les gains d'énergie libre triés
            // (elle-même adoptée après un premier rejet de la sélection
            // par plateau, cf. historique ci-dessous).
            //
            // **Diagnostic complet.** Le rejet initial de la sélection
            // par plateau reposait sur une sur-scission observée sur
            // blobs bien séparés (K=5 au lieu de K=3). Deux causes
            // distinctes ont été identifiées et corrigées, l'une après
            // l'autre :
            // (1) Le bug β_c déjà documenté en tête de ce module (facteur
            //     2 manquant entre seuil prescrit et seuil libre) —
            //     déclenchait des scissions deux fois trop tôt.
            // (2) Un bug plus profond, non lié aux poids prescrits et
            //     donc PARTAGÉ avec `powkm.rs` (libre) : l'arrêt anticipé
            //     du recuit (`early_stop_plateau_ratio`) se déclenche
            //     précisément quand un plateau est déjà nettement le plus
            //     large — mais l'interrompt alors immédiatement, ce qui
            //     en fait structurellement "le dernier plateau observé",
            //     que la règle d'exclusion anti-troncature (premier et
            //     dernier plateau exclus, cf. papier Algorithme 1) rejette
            //     aussitôt au profit de plateaux transitoires bien plus
            //     étroits. Les deux mécanismes se neutralisaient
            //     mutuellement : l'arrêt anticipé désignait le vainqueur,
            //     puis la règle d'exclusion l'éliminait automatiquement.
            //     Confirmé par instrumentation directe (`POWKM_DEBUG_PLATEAUS=1`)
            //     sur un cas K=4 synthétique dégénéré (4 centres en carré
            //     parfait --- `cluster_data::make_blobs` place les
            //     centres régulièrement sur un cercle) : plateau K=4 de
            //     largeur log(β) = 3.35 (de loin le plus large) exclu au
            //     profit de K=3 à largeur 0.14. Corrigé en repoussant
            //     l'arrêt effectif jusqu'à l'observation d'AU MOINS une
            //     transition de K supplémentaire après le déclenchement
            //     (`early_stop_triggered`/`plateau_k_at_trigger`
            //     ci-dessus) --- le plateau dominant n'est alors plus
            //     jamais structurellement "le dernier", et la borne
            //     `beta_max` de la boucle englobante garantit l'absence
            //     de risque de boucle infinie. Correction appliquée
            //     identiquement dans `powkm.rs`.
            //
            // **Validation avant real-world.** Stress-test synthétique
            // (`examples/stress_test_plateau_selection.rs`, 100
            // configurations : K∈{2..6} × séparation∈{0.4..1.0} × 5
            // graines) : 60/100 → 73/100 récupérations exactes de K après
            // correctif (2), tous les échecs K=4 éliminés. Les échecs
            // résiduels (K=3, K=6, configurations à symétrie circulaire
            // parfaite du générateur de blobs) correspondent exactement à
            // la dégénérescence de symétrie caractérisée théoriquement
            // dans le papier (Section 5.4-5.5 : ensemble dégénéré de
            // codimension 2, mesure nulle, non générique) --- pas un bug
            // résiduel à corriger, une limitation déjà documentée et
            // scopée.
            //
            // **Historique (sélecteurs rejetés).** Deux approches
            // essayées et écartées avant la présente réhabilitation, pour
            // mémoire : la sélection par persistance en β seule (ne
            // distingue pas une vraie bifurcation d'une scission
            // marginale qui survit simplement faute d'avoir eu l'occasion
            // de mourir) ; et la sélection par plus grand écart relatif
            // dans les gains d'énergie libre triés par scission (ne
            // dépend pas de β_max, contournait donc le symptôme, mais pas
            // la cause racine (2) ci-dessus, découverte seulement après
            // coup en creusant pourquoi *cette même* pathologie de
            // sur-scission persistait sur les 15 jeux UCI réels malgré le
            // changement de sélecteur).
            if std::env::var("POWKM_DEBUG_PLATEAUS").is_ok() {
                for p in &plateaus {
                    eprintln!("PLATEAU: k={} beta=[{:.5},{:.5}] log_width={:.4}", p.k, p.beta_start, p.beta_end, p.log_width());
                }
            }
            let candidates: Vec<&Plateau> = if plateaus.len() >= 3 { plateaus[1..plateaus.len() - 1].iter().collect() } else { plateaus.iter().collect() };
            let best_plateau = candidates.iter().max_by(|a, b| a.log_width().partial_cmp(&b.log_width()).unwrap()).expect("au moins un plateau doit exister");

            let final_centers = &best_plateau.centers;
            let labels: Vec<i32> = points
                .iter()
                .map(|x| final_centers.iter().enumerate().map(|(k, c)| (k, euclidean(x, c))).fold((0usize, f64::INFINITY), |acc, item| if item.1 < acc.1 { item } else { acc }).0 as i32)
                .collect();
            // K rapporté = nombre de labels RÉELLEMENT distincts après
            // assignation au plus proche centre, pas centers.len()
            // aveuglément — un centre peut avoir une masse prescrite non
            // nulle sans jamais être le plus proche voisin d'aucun point
            // (position quasi coïncidente avec un autre centre, cf.
            // diagnostics de session sur la règle de partage). Le
            // rapporter comme faisant partie de K serait trompeur.
            let final_k = labels.iter().collect::<std::collections::HashSet<_>>().len();

            (labels, final_k)
        });

        self.last_fit_stats = stats;
        result
    }
}

fn merge_close_centers_prescribed(
    centers: Vec<Vec<f64>>,
    weights: Vec<f64>,
    birth_beta: Vec<f64>,
    current_beta: f64,
    tol: f64,
    persistence_events: &mut Vec<(f64, f64)>,
) -> (Vec<Vec<f64>>, Vec<f64>, Vec<f64>) {
    let mut merged_centers: Vec<Vec<f64>> = Vec::new();
    let mut merged_weights: Vec<f64> = Vec::new();
    let mut merged_birth: Vec<f64> = Vec::new();
    for ((c, w), b) in centers.into_iter().zip(weights.into_iter()).zip(birth_beta.into_iter()) {
        if let Some(idx) = merged_centers.iter().position(|m| euclidean(m, &c) < tol) {
            merged_weights[idx] += w;
            // La branche la plus jeune (née le plus tard) meurt à ce β —
            // enregistrée comme paire (naissance, mort) pour la sélection
            // de K par écart de persistance (cf. doc plus haut). La plus
            // ancienne survit, sa naissance ne change pas.
            let elder_birth = merged_birth[idx].min(b);
            let younger_birth = merged_birth[idx].max(b);
            if younger_birth > elder_birth {
                persistence_events.push((younger_birth, current_beta));
            }
            merged_birth[idx] = elder_birth;
        } else {
            merged_centers.push(c);
            merged_weights.push(w);
            merged_birth.push(b);
        }
    }
    (merged_centers, merged_weights, merged_birth)
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_data::make_blobs;
    use cluster_metrics::adjusted_rand_index;

    #[test]
    fn entropic_free_energy_matches_python_reference() {
        // Cas de référence calculé indépendamment en Python (session,
        // solveur par descente de gradient naïve — pas le même code que
        // Newton) : X 20 points seed=0, Y 3 centres fixés, a uniforme,
        // b=[0.5,0.3,0.2], epsilon=0.7. Vérifie ici que Newton + la
        // formule S() reproduisent les mêmes marges et une valeur de S
        // cohérente (pas la valeur exacte du script, qui utilisait un
        // seed numpy différent du générateur Rust — mais la propriété
        // structurelle : marges exactement respectées).
        let mut rng = ChaCha8Rng::seed_from_u64(0);
        let points: Vec<Vec<f64>> = (0..20).map(|_| vec![rng.gen::<f64>() * 4.0 - 2.0, rng.gen::<f64>() * 4.0 - 2.0]).collect();
        let centers = vec![vec![0.5, 0.5], vec![-0.5, 1.0], vec![1.0, -0.3]];
        let a = vec![1.0 / 20.0; 20];
        let b = vec![0.5, 0.3, 0.2];
        let epsilon = 0.7;
        let cost = cost_matrix(&points, &centers);
        let (r, g, _, _) = solve_and_responsibilities(&cost, &a, &b, epsilon, vec![0.0; 3], 200, 1e-12);
        let marginals: Vec<f64> = (0..3).map(|j| (0..20).map(|i| a[i] * r[i][j]).sum()).collect();
        for (m, bj) in marginals.iter().zip(b.iter()) {
            assert!((m - bj).abs() < 1e-8, "marge {m} != cible {bj}");
        }
        let s = entropic_free_energy(&cost, &a, &b, epsilon, &g);
        assert!(s.is_finite());
    }

    #[test]
    fn gradient_matches_finite_difference_of_entropic_free_energy() {
        // Vérification indépendante (Rust cette fois, la version Python
        // avait déjà confirmé un écart de 2.7e-11 avant portage) : le
        // gradient enveloppe-théorème doit matcher les différences finies
        // de S(g*(Y),Y) — pas juste de S à g fixé.
        let mut rng = ChaCha8Rng::seed_from_u64(5);
        let points: Vec<Vec<f64>> = (0..15).map(|_| vec![rng.gen::<f64>() * 3.0, rng.gen::<f64>() * 3.0]).collect();
        let centers = vec![vec![1.0, 1.0], vec![2.0, 0.5]];
        let a = vec![1.0 / 15.0; 15];
        let b = vec![0.6, 0.4];
        let epsilon = 0.5;

        let (grad, _g) = gradient_wrt_centers(&points, &centers, &a, &b, epsilon, vec![0.0; 2], 400, 1e-7);

        let h = 1e-5;
        let s_at = |c: &[Vec<f64>]| -> f64 {
            let cost = cost_matrix(&points, c);
            let (_, g, _, _) = solve_and_responsibilities(&cost, &a, &b, epsilon, vec![0.0; 2], 400, 1e-7);
            entropic_free_energy(&cost, &a, &b, epsilon, &g)
        };
        for kk in 0..2 {
            for d in 0..2 {
                let mut cp = centers.clone();
                cp[kk][d] += h;
                let mut cm = centers.clone();
                cm[kk][d] -= h;
                let fd = (s_at(&cp) - s_at(&cm)) / (2.0 * h);
                assert!((fd - grad[kk][d]).abs() < 1e-4, "K={kk} d={d}: analytique={} differences finies={fd}", grad[kk][d]);
            }
        }
    }

    #[test]
    fn entropic_free_energy_decreases_with_more_clusters_prescribed_split_rule() {
        // Analogue prescrit du test libre
        // `free_energy_is_finite_and_decreases_with_more_clusters_at_fixed_beta`
        // — vérifié numériquement en Python avant portage (1.73 -> 1.01 ->
        // 0.77 sur un cas synthétique) ; reproduit ici indépendamment
        // avec le vrai code Rust.
        let data = make_blobs(60, 3, 1.0, 3);
        let a = vec![1.0 / 60.0; 60];
        let epsilon = 0.3;
        let mut stats = NewtonUsageStats::default();

        let mean: Vec<f64> = (0..2).map(|d| data.points.iter().map(|p| p[d]).sum::<f64>() / 60.0).collect();
        let (c1, g1) = em_converge_prescribed(&data.points, vec![mean.clone()], &a, &[1.0], epsilon, vec![0.0], 30, 200, 1e-7, 1e-8, &mut stats, false);
        let s1 = entropic_free_energy(&cost_matrix(&data.points, &c1), &a, &[1.0], epsilon, &g1);

        let c2_init = vec![(0..2).map(|d| mean[d] + 0.3).collect(), (0..2).map(|d| mean[d] - 0.3).collect()];
        let (c2, g2) = em_converge_prescribed(&data.points, c2_init, &a, &[0.5, 0.5], epsilon, vec![g1[0], g1[0]], 30, 200, 1e-7, 1e-8, &mut stats, false);
        let s2 = entropic_free_energy(&cost_matrix(&data.points, &c2), &a, &[0.5, 0.5], epsilon, &g2);

        assert!(s2 <= s1 + 1e-6, "plus de centres ne devrait jamais augmenter S: s1={s1}, s2={s2}");
    }

    #[test]
    fn rose_bifurcation_point_matches_free_weight_derivation() {
        // Ce test a d'abord révélé une prédiction FAUSSE de ma part, pas
        // un bug de code — corrigé ici, pas caché. J'avais supposé
        // (commentaire original) que le hessien prescrit et le hessien
        // libre coïncidaient exactement au point symétrique de scission
        // puisque les poids valent [0.5,0.5] dans les deux cas à ce point
        // précis. C'est vrai pour la VALEUR des poids, faux pour la
        // STABILITÉ : la formulation libre linéarise sur (position ET
        // poids) conjointement — le poids est un degré de liberté
        // supplémentaire qui peut déstabiliser le système plus tôt. En
        // fixant le poids à exactement [0.5,0.5] (poids prescrits), ce
        // degré de liberté disparaît, retardant la bifurcation.
        //
        // Vérifié numériquement (Python indépendant, avant correction du
        // test Rust) sur le cas hand-verified de `powkm.rs` (points 1D
        // {-3,-1,1,3}, variance=5, β_c^libre=1/(2·5)=0.1) : le mode de
        // séparation du hessien prescrit change de signe exactement à
        // β_c^prescrit=0.2 — le double, pas la même valeur. Confirmé sur
        // un balayage complet (β=0.1→0.5, pas de 0.05), passage par zéro
        // net à β=0.2, pas approximatif.
        let points: Vec<Vec<f64>> = vec![-3.0, -1.0, 1.0, 3.0].into_iter().map(|x| vec![x]).collect();
        let beta_c_free = 0.1; // = 1/(2*5), variance=5, cf. dérivation dans powkm.rs
        let beta_c_prescribed = 2.0 * beta_c_free; // = 0.2, découverte de cette session (voir ci-dessus)

        for (beta, expect_negative) in [(beta_c_prescribed * 0.8, false), (beta_c_prescribed * 1.2, true)] {
            let eps = 1.0 / beta;
            let centers = vec![vec![0.0], vec![0.0]];
            let weights = vec![0.5, 0.5];
            let lambda = local_stability_prescribed(&points, &centers, &weights, eps, 7);
            if expect_negative {
                assert!(lambda < 0.0, "beta={beta} > beta_c_prescribed={beta_c_prescribed}: la paire dédoublée devrait être instable (λ<0), λ={lambda}");
            } else {
                assert!(lambda > 0.0, "beta={beta} < beta_c_prescribed={beta_c_prescribed}: la paire dédoublée devrait être stable (λ>0), λ={lambda}");
            }
        }
    }

    #[test]
    fn discovers_plausible_number_of_clusters_on_blobs() {
        let data = make_blobs(90, 3, 0.6, 42);
        let mut model = PoWKMPrescribed::new(7);
        model.beta_max = 5.0;
        let result = model.fit(&data);
        assert!(result.n_clusters >= 2 && result.n_clusters <= 6, "n_clusters={}", result.n_clusters);
        assert_eq!(result.labels.len(), data.n_samples());
    }

    #[test]
    fn deterministic_across_runs() {
        let data = make_blobs(60, 2, 0.5, 5);
        let mut p1 = PoWKMPrescribed::new(7);
        let mut p2 = PoWKMPrescribed::new(7);
        p1.beta_max = 5.0;
        p2.beta_max = 5.0;
        assert_eq!(p1.fit(&data).labels, p2.fit(&data).labels);
    }

    #[test]
    fn warm_start_reduces_total_newton_iterations() {
        // LE test qui justifie l'existence de ce module : sur un vrai fit
        // complet, le warm-start réellement utilisé doit consommer moins
        // d'itérations Newton au total que l'équivalent à froid mesuré en
        // parallèle.
        let data = make_blobs(90, 3, 0.7, 11);
        let mut model = PoWKMPrescribed::new(3);
        model.beta_max = 6.0;
        model.track_cold_start_comparison = true;
        let _ = model.fit(&data);
        let stats = &model.last_fit_stats;
        let cold = stats.total_iterations_cold.expect("cold tracking activé");
        assert!(
            stats.total_iterations_warm < cold,
            "warm-start ({} itérations) devrait battre le froid ({} itérations)",
            stats.total_iterations_warm,
            cold
        );
        println!("warm={} cold={} reduction={:.1}%", stats.total_iterations_warm, cold, 100.0 * (1.0 - stats.total_iterations_warm as f64 / cold as f64));
    }

    #[test]
    fn plateau_centers_always_match_plateau_k() {
        for seed in [1u64, 2, 3] {
            let data = make_blobs(90, 3, 0.9, seed);
            let mut model = PoWKMPrescribed::new(seed);
            model.beta_max = 5.0;
            let result = model.fit(&data);
            let n_distinct = result.labels.iter().collect::<std::collections::HashSet<_>>().len();
            assert_eq!(n_distinct, result.n_clusters, "seed={seed}: n_clusters annoncé={} mais {n_distinct} labels distincts", result.n_clusters);
        }
    }

    #[test]
    fn recovers_k_on_well_separated_blobs() {
        let data = make_blobs(90, 3, 0.5, 42);
        let mut model = PoWKMPrescribed::new(7);
        model.beta_max = 5.0;
        let result = model.fit(&data);
        assert_eq!(result.n_clusters, 3, "K trouvé={}", result.n_clusters);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.8, "ARI={ari}");
    }

    #[test]
    #[should_panic(expected = "au moins 2 points")]
    fn panics_on_too_few_points() {
        let data = Dataset::new(vec![vec![0.0]], None, "toy");
        let mut model = PoWKMPrescribed::new(0);
        model.fit(&data);
    }
}

