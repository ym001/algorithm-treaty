//! Utilitaires d'algèbre linéaire partagés : valeurs **et vecteurs**
//! propres d'une matrice symétrique (méthode de Jacobi cyclique), et
//! blanchiment PCA qui s'en sert.
//!
//! ## Blanchiment complet vs. rang effectif — un résultat négatif établi cette session
//!
//! Sur German Credit, le blanchiment complet (`pca_whiten`) corrige un
//! vrai spike de covariance isolé (λ_max=2.52 sans direction quasi
//! nulle, condition number sain ≈16) et améliore la découverte de K.
//! **Ce n'est PAS généralisable** : sur Wine, Seeds et Breast Cancer
//! (forte redondance de variables — triplets mean/se/worst pour Breast
//! Cancer, mesures géométriques corrélées pour Seeds), le blanchiment
//! complet fait système effondrer à K=1, quelle que soit la
//! régularisation appliquée à l'inversion des valeurs propres :
//! - Blanchiment brut (division directe par √λ) : amplification
//!   1/√λ_min jusqu'à 87× sur Breast Cancer — collapse.
//! - Shrinkage Ledoit-Wolf (`pca_whiten_shrunk`, cf. plus bas) : δ
//!   optimal au sens Frobenius global, ~2-5% seulement — insuffisant,
//!   amplification encore 2.6-9.3× — collapse persiste sur Wine/BC.
//! - Shrinkage Ledoit-Wolf + plancher Marchenko-Pastur
//!   (`pca_whiten_mp_floor`, cf. plus bas) : amplification ramenée à
//!   1.2-1.4× — quasi le régime sain de German Credit — **collapse
//!   persiste identiquement sur Wine/BC**.
//!
//! Ce dernier résultat est le plus informatif : il élimine
//! définitivement l'hypothèse "amplification numérique 1/√λ" comme
//! cause du collapse sur ces jeux, puisque la corriger presque
//! totalement ne change rien à K. La cause est donc structurelle, pas
//! numérique : le blanchiment complet remet **toutes** les directions à
//! variance 1, y compris les directions de bruit/redondance qui
//! pesaient jusque-là peu dans la distance. Si la vraie séparation entre
//! classes est concentrée dans une poignée de directions à variance
//! originellement élevée (rang effectif ≪ d — cas typique d'un jeu
//! fortement redondant), le blanchiment dilue ce signal en le mettant à
//! égalité avec toutes les directions de bruit, au lieu de le renforcer.
//! Aucun plancher sur les valeurs propres ne peut réparer une dilution
//! du rapport signal/bruit — ce n'est pas ce qui est cassé.
//!
//! **Conclusion pratique** : le blanchiment (sous toutes ses formes
//! implémentées ici) n'est PAS un préconditionnement à appliquer
//! uniformément. Il doit rester conditionnel à un diagnostic spectral
//! préalable — un spike isolé sans direction quasi nulle (comme German
//! Credit) en bénéficie ; une redondance diffuse sur de nombreuses
//! directions (Wine, Seeds, Breast Cancer) en pâtit, quelle que soit la
//! régularisation. Piste structurelle non encore testée à ce stade :
//! réduction de rang (ne blanchir QUE le sous-espace des directions
//! statistiquement significatives, cf. `pca_whiten_rank_reduced`
//! ci-dessous) plutôt que blanchiment complet régularisé.
//!
//!
//! `powkm_prescribed.rs` sur-scinde radicalement sur données réelles
//! corrélées : K=17 (German Credit, K_vrai=2) et K=21 (Ionosphere,
//! K_vrai=2), contre un comportement propre sur données synthétiques
//! isotropes (blobs gaussiens). Diagnostiqué précisément avant de
//! corriger quoi que ce soit : sur German Credit standardisé (z-score),
//! `λ_max(Σ)=2.52` (vérifié via ce module, cf. tests), alors qu'une
//! porte de stabilité isotrope l'attendrait proche de 1. Le `β_c` d'une
//! seule composante réelle (pas de vraie sous-structure) tombe donc à
//! `1/2.52≈0.40` — bien en-dessous de tout `beta_max` raisonnable, donc
//! la porte de stabilité de Rose (`β·λ_max(Σ_k)>1`, dérivée pour un bruit
//! intra-cluster à peu près isotrope) se déclenche sur la corrélation
//! entre variables, pas sur une vraie sous-structure multimodale.
//!
//! Le blanchiment PCA (décorréler puis remettre chaque composante
//! principale à variance 1) est le correctif standard de la littérature
//! pour ce problème précis — pas spécifique à PoWKM, c'est une étape de
//! prétraitement établie pour tout clustering à distance euclidienne sur
//! données corrélées. Après blanchiment, `λ_max(Σ)=1` exactement par
//! construction pour le nuage entier (vérifié, `pca_whiten_removes_correlation`),
//! rétablissant l'hypothèse sous laquelle le critère de Rose a été dérivé.

#![allow(clippy::needless_range_loop)]

use cluster_core::Dataset;

/// Valeurs propres (triées croissant) et vecteurs propres (colonnes,
/// même ordre) d'une matrice symétrique, par la méthode de Jacobi
/// cyclique. Cross-validé contre `numpy.linalg.eigh` avant tout usage
/// (voir tests) — mêmes garanties que le solveur valeurs-propres-seules
/// déjà utilisé dans `warm_start_bound.rs`, étendu ici pour accumuler la
/// rotation (nécessaire pour les vecteurs propres, pas seulement les
/// valeurs).
pub(crate) fn jacobi_eigen(matrix: &[Vec<f64>], max_sweeps: usize, tol: f64) -> (Vec<f64>, Vec<Vec<f64>>) {
    let n = matrix.len();
    let mut a: Vec<Vec<f64>> = matrix.to_vec();
    let mut v: Vec<Vec<f64>> = (0..n).map(|i| (0..n).map(|j| if i == j { 1.0 } else { 0.0 }).collect()).collect();

    for _ in 0..max_sweeps {
        let off_diag_sq: f64 = (0..n).map(|p| ((p + 1)..n).map(|q| a[p][q] * a[p][q]).sum::<f64>()).sum();
        if off_diag_sq.sqrt() < tol {
            break;
        }
        for p in 0..n {
            for q in (p + 1)..n {
                if a[p][q].abs() < 1e-300 {
                    continue;
                }
                let theta = (a[q][q] - a[p][p]) / (2.0 * a[p][q]);
                let t = if theta == 0.0 { 1.0 } else { theta.signum() / (theta.abs() + (theta * theta + 1.0).sqrt()) };
                let c = 1.0 / (t * t + 1.0).sqrt();
                let s = t * c;
                let app = a[p][p];
                let aqq = a[q][q];
                let apq = a[p][q];
                a[p][p] = c * c * app - 2.0 * s * c * apq + s * s * aqq;
                a[q][q] = s * s * app + 2.0 * s * c * apq + c * c * aqq;
                a[p][q] = 0.0;
                a[q][p] = 0.0;
                for i in 0..n {
                    if i != p && i != q {
                        let aip = a[i][p];
                        let aiq = a[i][q];
                        a[i][p] = c * aip - s * aiq;
                        a[p][i] = a[i][p];
                        a[i][q] = s * aip + c * aiq;
                        a[q][i] = a[i][q];
                    }
                    let vip = v[i][p];
                    let viq = v[i][q];
                    v[i][p] = c * vip - s * viq;
                    v[i][q] = s * vip + c * viq;
                }
            }
        }
    }

    let mut idx: Vec<usize> = (0..n).collect();
    idx.sort_by(|&i, &j| a[i][i].partial_cmp(&a[j][j]).unwrap());
    let eigenvalues: Vec<f64> = idx.iter().map(|&i| a[i][i]).collect();
    let eigenvectors: Vec<Vec<f64>> = (0..n).map(|row| idx.iter().map(|&i| v[row][i]).collect()).collect();
    (eigenvalues, eigenvectors)
}

/// Blanchiment PCA : centre, décorrèle, remet chaque composante
/// principale à variance 1 (`y = D^{-1/2} V^T (x-μ)`). Valeurs propres
/// quasi nulles (colonnes constantes ou parfaitement corrélées)
/// laissées inchangées (variance 1 forcée, comme `standardize` gère déjà
/// les colonnes à variance nulle dans `real_world_finance_defense.rs`)
/// plutôt qu'amplifiées par une division par un nombre proche de 0.
pub fn pca_whiten(dataset: &Dataset) -> Dataset {
    let n = dataset.points.len();
    let d = dataset.points[0].len();
    let mut mean = vec![0.0; d];
    for p in &dataset.points {
        for j in 0..d {
            mean[j] += p[j] / n as f64;
        }
    }
    let mut cov = vec![vec![0.0; d]; d];
    for p in &dataset.points {
        let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
        for i in 0..d {
            for j in 0..d {
                cov[i][j] += centered[i] * centered[j] / n as f64;
            }
        }
    }
    let (eigenvalues, eigenvectors) = jacobi_eigen(&cov, 200, 1e-12);
    let inv_sqrt: Vec<f64> = eigenvalues.iter().map(|&l| if l > 1e-10 { 1.0 / l.sqrt() } else { 1.0 }).collect();

    let points: Vec<Vec<f64>> = dataset
        .points
        .iter()
        .map(|p| {
            let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
            (0..d)
                .map(|k| {
                    let proj: f64 = (0..d).map(|j| eigenvectors[j][k] * centered[j]).sum();
                    proj * inv_sqrt[k]
                })
                .collect()
        })
        .collect();
    Dataset::new(points, dataset.labels_true.clone(), dataset.name.clone())
}

/// Intensité de shrinkage de Ledoit & Wolf (2004, *A well-conditioned
/// estimator for large-dimensional covariance matrices*, JMVA 88(2),
/// 365-411), cible = matrice identité mise à l'échelle μI avec
/// μ=tr(Σ̂)/d. Formule reconstruite depuis le papier et **validée à la
/// précision machine (diff ~1e-15 à 1e-17) contre
/// `sklearn.covariance.ledoit_wolf_shrinkage`** sur 5 cas aléatoires
/// (n,d variés) plus deux cas limites pertinents pour ce projet : une
/// colonne à variance nulle (comme la colonne toujours nulle
/// d'Ionosphere) et une covariance quasi-singulière par colinéarité
/// forte (comme les triplets mean/se/worst de Breast Cancer) — vérifié
/// avant tout portage Rust, cf. session.
///
/// Retourne un coefficient dans \[0,1\] : 0 = covariance brute (aucun
/// shrinkage), 1 = cible isotrope pure μI.
fn ledoit_wolf_shrinkage_intensity(points: &[Vec<f64>], mean: &[f64], cov: &[Vec<f64>]) -> f64 {
    let n = points.len() as f64;
    let d = mean.len();
    let mu = (0..d).map(|i| cov[i][i]).sum::<f64>() / d as f64;

    // γ̂ normalisé : ||Σ̂ - μI||²_F / d
    let mut gamma_hat = 0.0;
    for i in 0..d {
        for j in 0..d {
            let delta_ij = cov[i][j] - if i == j { mu } else { 0.0 };
            gamma_hat += delta_ij * delta_ij;
        }
    }
    gamma_hat /= d as f64;

    // β̂ normalisé : (1/(d·n)) Σ_{i,j} [ (1/n)Σ_k x_k,i² x_k,j² - Σ̂_ij² ]
    // — variance asymptotique des entrées de Σ̂, estimée directement sur
    // l'échantillon (pas de forme close supposant la normalité).
    let mut beta_hat = 0.0;
    for i in 0..d {
        for j in 0..d {
            let mut term: f64 = 0.0;
            for p in points {
                let ci = p[i] - mean[i];
                let cj = p[j] - mean[j];
                term += ci * ci * cj * cj;
            }
            term /= n;
            beta_hat += term - cov[i][j] * cov[i][j];
        }
    }
    beta_hat /= d as f64 * n;

    let beta = beta_hat.min(gamma_hat).max(0.0);
    if gamma_hat <= 1e-15 {
        0.0
    } else {
        beta / gamma_hat
    }
}

/// Covariance de Ledoit-Wolf : Σ̂_shrink = (1-δ)·Σ̂ + δ·μ·I, δ = intensité
/// optimale ci-dessus. Corrige le défaut diagnostiqué du blanchiment PCA
/// brut : diviser par √λ pour une valeur propre proche de zéro
/// (colinéarité quasi exacte entre variables, ex. Breast Cancer, Wine,
/// Seeds — cf. doc de `pca_whiten`) amplifie massivement le bruit
/// numérique dans cette direction. Le shrinkage relève ce plancher AVANT
/// la décomposition propre, sans jamais toucher la direction de
/// variance dominante si elle porte un vrai signal (le shrinkage réduit
/// TOUTES les valeurs propres vers μ proportionnellement à leur écart à
/// μ, donc une valeur propre déjà proche de μ — cas typique d'une
/// direction de bruit — bouge peu en absolu, alors qu'une valeur propre
/// très petite se retrouve remontée d'une fraction fixe δ de l'écart).
fn ledoit_wolf_covariance(points: &[Vec<f64>]) -> (Vec<f64>, Vec<Vec<f64>>) {
    let n = points.len();
    let d = points[0].len();
    let mean: Vec<f64> = (0..d).map(|j| points.iter().map(|p| p[j]).sum::<f64>() / n as f64).collect();
    let mut cov = vec![vec![0.0; d]; d];
    for p in points {
        let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
        for i in 0..d {
            for j in 0..d {
                cov[i][j] += centered[i] * centered[j] / n as f64;
            }
        }
    }
    let delta = ledoit_wolf_shrinkage_intensity(points, &mean, &cov);
    let mu = (0..d).map(|i| cov[i][i]).sum::<f64>() / d as f64;
    let mut shrunk = cov.clone();
    for i in 0..d {
        for j in 0..d {
            shrunk[i][j] *= 1.0 - delta;
        }
        shrunk[i][i] += delta * mu;
    }
    (mean, shrunk)
}

/// Variante de [`pca_whiten`] utilisant la covariance de Ledoit-Wolf
/// plutôt que la covariance brute avant décomposition propre — cf.
/// `ledoit_wolf_covariance`. Fonction séparée plutôt que modification de
/// `pca_whiten` : préserve le comportement déjà testé et documenté de
/// `pca_whiten` (`pca_whiten_removes_correlation`), qui reste correct
/// pour son cas d'usage d'origine (German Credit, spike isolé sans
/// direction quasi-singulière).
pub fn pca_whiten_shrunk(dataset: &Dataset) -> Dataset {
    let d = dataset.points[0].len();
    let (mean, cov) = ledoit_wolf_covariance(&dataset.points);
    let (eigenvalues, eigenvectors) = jacobi_eigen(&cov, 200, 1e-12);
    let inv_sqrt: Vec<f64> = eigenvalues.iter().map(|&l| if l > 1e-10 { 1.0 / l.sqrt() } else { 1.0 }).collect();

    let points: Vec<Vec<f64>> = dataset
        .points
        .iter()
        .map(|p| {
            let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
            (0..d)
                .map(|k| {
                    let proj: f64 = (0..d).map(|j| eigenvectors[j][k] * centered[j]).sum();
                    proj * inv_sqrt[k]
                })
                .collect()
        })
        .collect();
    Dataset::new(points, dataset.labels_true.clone(), dataset.name.clone())
}

/// Blanchiment à double correctif : shrinkage Ledoit-Wolf (cf.
/// `pca_whiten_shrunk`) PUIS plancher explicite de Marchenko-Pastur sur
/// chaque valeur propre restante. Diagnostiqué nécessaire cette session
/// après vérification numérique : le δ de Ledoit-Wolf, optimal pour la
/// perte de Frobenius **globale** (moyennée sur toute la matrice), reste
/// insuffisant pour empêcher l'explosion 1/√λ sur les jeux à forte
/// redondance de variables (Wine, Breast Cancer) — le δ optimal global
/// est tiré vers le bas par les nombreuses directions déjà bien
/// estimées, sacrifiant la correction des quelques directions
/// quasi-nulles qui posent le problème.
///
/// Le bord inférieur de Marchenko-Pastur, λ₋ = μ·(1-√c)² avec c=d/n et
/// μ=tr(Σ)/d, est le plus petit valeur propre qu'une matrice de
/// covariance de bruit purement isotrope produirait à cette taille
/// d'échantillon — une valeur propre observée en dessous n'est pas
/// distinguable du bruit d'échantillonnage pur, donc n'est pas fiable
/// telle quelle. C'est une formule fermée fonction de (n,d)
/// **uniquement** : aucun paramètre réglé sur un jeu de données
/// particulier, elle s'adapte automatiquement à chaque jeu via son
/// propre n et d — cf. Marchenko & Pastur (1967), Bai & Silverstein
/// (2010) pour la théorie ; usage comme plancher de confiance déjà
/// courant en débruitage de covariance par RMT (ex. sélection de rang
/// automatique en PCA).
///
/// Avertissement honnête : la dérivation exacte du bord MP suppose un
/// modèle de bruit i.i.d. isotrope, une hypothèse approximative pour des
/// données réelles non i.i.d. — traité ici comme une heuristique de
/// plancher bien établie, pas comme un théorème appliqué à la lettre.
/// Vérifié numériquement avant portage (cf. session) : ramène
/// l'amplification 1/√λ_min de 2.6-87× (LW seul) à 1.2-1.4× sur
/// Wine/Seeds/Breast Cancer, proche du régime sans pathologie observé
/// sur German Credit (~2.5×).
pub fn pca_whiten_mp_floor(dataset: &Dataset) -> Dataset {
    let n = dataset.points.len();
    let d = dataset.points[0].len();
    let (mean, cov) = ledoit_wolf_covariance(&dataset.points);
    let (eigenvalues, eigenvectors) = jacobi_eigen(&cov, 200, 1e-12);

    let mu = (0..d).map(|i| cov[i][i]).sum::<f64>() / d as f64;
    let c = d as f64 / n as f64;
    let mp_floor = mu * (1.0 - c.sqrt()).powi(2);

    let inv_sqrt: Vec<f64> = eigenvalues
        .iter()
        .map(|&l| {
            let floored = l.max(mp_floor);
            if floored > 1e-10 {
                1.0 / floored.sqrt()
            } else {
                1.0
            }
        })
        .collect();

    let points: Vec<Vec<f64>> = dataset
        .points
        .iter()
        .map(|p| {
            let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
            (0..d)
                .map(|k| {
                    let proj: f64 = (0..d).map(|j| eigenvectors[j][k] * centered[j]).sum();
                    proj * inv_sqrt[k]
                })
                .collect()
        })
        .collect();
    Dataset::new(points, dataset.labels_true.clone(), dataset.name.clone())
}

/// Blanchiment à **rang réduit** : ne projette et ne blanchit QUE le
/// sous-espace des directions statistiquement significatives (valeur
/// propre au-dessus du bord SUPÉRIEUR de Marchenko-Pastur,
/// λ₊=μ(1+√c)², c=d/n), au lieu de blanchir les d dimensions complètes.
/// Adresse directement le mécanisme de dilution diagnostiqué cette
/// session (cf. doc du module) : `pca_whiten_mp_floor` corrige
/// l'amplification numérique sur les valeurs propres quasi nulles mais
/// laisse ces directions dans l'espace blanchi à un poids comparable aux
/// directions signal — diluant la séparation si celle-ci est concentrée
/// dans une poignée de directions à variance originellement élevée
/// (rang effectif ≪ d, cas typique d'un jeu à fortes redondances). La
/// réduction de rang **retire** ces directions plutôt que de leur
/// donner un poids artificiellement égal.
///
/// Les valeurs propres retenues sont, par construction, au-dessus du
/// bord de bruit — pas besoin du shrinkage Ledoit-Wolf dessus (déjà
/// fiables). λ₊ est, comme λ₋ dans `pca_whiten_mp_floor`, une formule
/// fermée fonction de (n,d) uniquement — aucun paramètre réglé par jeu
/// de données.
///
/// Change la dimensionnalité du jeu retourné (r ≤ d, pas d) —
/// contrairement aux autres variantes de blanchiment de ce module.
///
/// Avertissement honnête : comme pour `pca_whiten_mp_floor`, le bord MP
/// suppose un modèle de bruit i.i.d. isotrope — approximation pour des
/// données réelles non i.i.d., traitée comme heuristique de sélection
/// de rang établie (usage courant en débruitage PCA par RMT), pas comme
/// théorème appliqué à la lettre. Pas encore vérifié empiriquement sur
/// K — à faire avant d'en tirer une conclusion, cf. session.
pub fn pca_whiten_rank_reduced(dataset: &Dataset) -> Dataset {
    let n = dataset.points.len();
    let d = dataset.points[0].len();
    let mut mean = vec![0.0; d];
    for p in &dataset.points {
        for j in 0..d {
            mean[j] += p[j] / n as f64;
        }
    }
    let mut cov = vec![vec![0.0; d]; d];
    for p in &dataset.points {
        let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
        for i in 0..d {
            for j in 0..d {
                cov[i][j] += centered[i] * centered[j] / n as f64;
            }
        }
    }
    let (eigenvalues, eigenvectors) = jacobi_eigen(&cov, 200, 1e-12);
    let mu = (0..d).map(|i| cov[i][i]).sum::<f64>() / d as f64;
    let c = d as f64 / n as f64;
    let mp_upper = mu * (1.0 + c.sqrt()).powi(2);

    // Indices triés par valeur propre décroissante, ne garder que celles
    // au-dessus du bord de bruit. Filet de sécurité : au moins 1
    // dimension conservée (la plus grande valeur propre), même si aucune
    // ne dépasse formellement λ₊ (cas dégénéré, ne devrait pas arriver
    // sur des données réelles avec une structure quelconque).
    let mut order: Vec<usize> = (0..d).collect();
    order.sort_by(|&a, &b| eigenvalues[b].partial_cmp(&eigenvalues[a]).unwrap());
    let mut kept: Vec<usize> = order.iter().copied().filter(|&i| eigenvalues[i] > mp_upper).collect();
    if kept.is_empty() {
        kept.push(order[0]);
    }
    let r = kept.len();

    let points: Vec<Vec<f64>> = dataset
        .points
        .iter()
        .map(|p| {
            let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
            kept.iter()
                .map(|&k| {
                    let proj: f64 = (0..d).map(|j| eigenvectors[j][k] * centered[j]).sum();
                    proj / eigenvalues[k].max(1e-12).sqrt()
                })
                .collect()
        })
        .collect();
    debug_assert!(points.iter().all(|p| p.len() == r));
    Dataset::new(points, dataset.labels_true.clone(), dataset.name.clone())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ledoit_wolf_shrinkage_matches_sklearn_reference() {
        // Référence externe : sklearn.covariance.ledoit_wolf_shrinkage,
        // seed=0, n=40, d=5, covariance corrélée aléatoire — même niveau
        // de rigueur que `jacobi_eigen_matches_numpy_reference`. La
        // formule elle-même (reconstruite depuis Ledoit & Wolf 2004,
        // Journal of Multivariate Analysis 88(2), 365-411) a été validée
        // séparément en Python contre 5 cas aléatoires (n,d variés) plus
        // deux cas limites (colonne à variance nulle, covariance
        // quasi-singulière) avant ce portage — diff machine ~1e-15 dans
        // tous les cas, cf. session.
        let points: Vec<Vec<f64>> = vec![
            vec![0.4898, -1.017, 0.1033, 0.3988, -2.319],
            vec![-0.6679, 0.7398, -0.1094, 0.7777, -0.0048],
            vec![-1.723, -0.3082, -1.264, -0.9528, -0.0882],
            vec![2.25, -0.2484, 1.795, 1.409, -1.316],
            vec![2.328, -0.0924, -0.2381, -0.3497, -0.1624],
            vec![-0.1777, -0.0845, -0.346, 0.6813, -1.629],
            vec![-0.2146, 0.2463, -0.2384, -0.2918, 0.6793],
            vec![0.8352, 0.2727, 0.0907, 0.92, -1.03],
            vec![2.79, -0.09, 0.2622, -0.1593, 0.0105],
            vec![-0.2774, 0.2142, -0.7882, -0.9367, 1.23],
            vec![1.567, -0.0491, 0.5174, 0.6419, -0.8279],
            vec![-0.6496, -0.5479, -1.253, 0.0542, -2.127],
            vec![-2.636, 1.137, -0.3485, -0.2182, 2.567],
            vec![-1.691, -0.5438, -0.5651, -0.153, -1.062],
            vec![-0.0668, -0.2654, -0.7795, -1.527, 1.315],
            vec![0.8976, 1.308, 1.899, 0.4512, 3.351],
            vec![-0.5166, 0.8576, 1.358, 0.0123, 3.199],
            vec![-2.503, 0.8275, 0.7955, 0.0521, 2.551],
            vec![-1.873, 0.2636, -0.097, -0.1107, 0.9252],
            vec![1.457, -0.0773, 0.739, -0.4141, 1.037],
            vec![0.9863, -0.8027, -0.648, -1.409, 0.1287],
            vec![-0.569, -0.1915, -0.0381, 0.6663, -1.505],
            vec![-1.25, 0.334, 0.0663, -0.0659, 0.8264],
            vec![0.0236, -1.029, -0.4841, 0.2214, -2.479],
            vec![1.201, 0.4316, -0.2419, -0.9658, 1.944],
            vec![-2.635, 0.2717, -0.6194, 0.6143, -0.8299],
            vec![-1.502, 0.1834, -0.3438, 1.036, -1.601],
            vec![-2.548, -0.6668, -1.477, -0.6785, -1.426],
            vec![0.8019, 0.7658, 1.7, 0.9154, 1.563],
            vec![-0.7387, 0.3208, -0.5466, -0.8487, 1.418],
            vec![0.8168, 0.711, 0.7773, 0.4166, 1.307],
            vec![2.284, 0.5227, 0.4348, 0.7835, -0.1248],
            vec![2.481, -0.6706, 0.0071, 0.4474, -2.115],
            vec![0.2658, -0.4538, -0.6176, 0.4289, -2.159],
            vec![-1.088, -0.856, -0.3847, -0.7355, -0.4401],
            vec![0.6733, -0.6813, -0.3996, -0.7831, -0.369],
            vec![0.6574, -0.6322, 0.1457, 0.9163, -2.64],
            vec![-0.7538, 0.301, -0.4726, -0.8044, 1.396],
            vec![0.1402, -0.7663, 0.2192, -0.3676, -0.5927],
            vec![0.865, -0.3664, 0.3491, 0.5085, -1.46],
        ];
        let n = points.len();
        let d = points[0].len();
        let mean: Vec<f64> = (0..d).map(|j| points.iter().map(|p| p[j]).sum::<f64>() / n as f64).collect();
        let mut cov = vec![vec![0.0; d]; d];
        for p in &points {
            let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
            for i in 0..d {
                for j in 0..d {
                    cov[i][j] += centered[i] * centered[j] / n as f64;
                }
            }
        }
        let shrinkage = ledoit_wolf_shrinkage_intensity(&points, &mean, &cov);
        let expected = 0.13629094424320404;
        assert!((shrinkage - expected).abs() < 1e-9, "shrinkage={shrinkage}, attendu={expected}");
    }

    #[test]
    fn ledoit_wolf_shrinkage_handles_zero_variance_column() {
        // Cas limite critique pour ce projet : une colonne à variance
        // nulle (comme la colonne toujours nulle d'Ionosphere, déjà
        // documentée ailleurs) ne doit produire ni NaN ni panique — le
        // shrinkage doit rester un nombre fini dans [0,1].
        let mut rng_state = 42u64;
        let mut next = || {
            rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1);
            ((rng_state >> 33) as f64) / (1u64 << 31) as f64 - 1.0
        };
        let points: Vec<Vec<f64>> = (0..100).map(|_| vec![next(), next(), 0.0, next()]).collect();
        let n = points.len();
        let d = points[0].len();
        let mean: Vec<f64> = (0..d).map(|j| points.iter().map(|p| p[j]).sum::<f64>() / n as f64).collect();
        let mut cov = vec![vec![0.0; d]; d];
        for p in &points {
            let centered: Vec<f64> = (0..d).map(|j| p[j] - mean[j]).collect();
            for i in 0..d {
                for j in 0..d {
                    cov[i][j] += centered[i] * centered[j] / n as f64;
                }
            }
        }
        let shrinkage = ledoit_wolf_shrinkage_intensity(&points, &mean, &cov);
        assert!(shrinkage.is_finite(), "shrinkage non fini : {shrinkage}");
        assert!((0.0..=1.0).contains(&shrinkage), "shrinkage hors [0,1] : {shrinkage}");
    }

    #[test]
    fn pca_whiten_rank_reduced_drops_pure_noise_dimensions() {
        // 2 vraies directions de signal (variance élevée), 8 directions
        // de bruit pur isotrope de faible variance — le rang réduit doit
        // ne garder que les 2 significatives, pas les 10.
        let mut rng_state = 99u64;
        let mut next = || {
            rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1);
            ((rng_state >> 33) as f64) / (1u64 << 31) as f64 - 1.0
        };
        let n = 400;
        let points: Vec<Vec<f64>> = (0..n)
            .map(|_| {
                let mut row = vec![next() * 5.0, next() * 4.0];
                for _ in 0..8 {
                    row.push(next() * 0.05);
                }
                row
            })
            .collect();
        let dataset = Dataset::new(points, None, "test");
        let reduced = pca_whiten_rank_reduced(&dataset);
        assert!(reduced.points[0].len() <= 3, "rang retenu trop élevé : {} (attendu ~2)", reduced.points[0].len());
        assert!(!reduced.points[0].is_empty());
        assert!(reduced.points.iter().flatten().all(|v| v.is_finite()));
    }

    #[test]
    fn pca_whiten_mp_floor_bounds_amplification_on_redundant_features() {
        // Reproduit la structure de Breast Cancer (fortes redondances
        // type triplets mean/se/worst) : 30 variables mais seulement 3
        // véritables degrés de liberté, chacun dupliqué 10 fois avec un
        // bruit minuscule. `pca_whiten_shrunk` seul (Ledoit-Wolf, pas de
        // plancher MP) blowup encore visiblement sur ce cas — vérifié
        // avant d'écrire ce test (cf. session) ; `pca_whiten_mp_floor`
        // doit rester borné.
        let mut rng_state = 2024u64;
        let mut next = || {
            rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1);
            ((rng_state >> 33) as f64) / (1u64 << 31) as f64 - 1.0
        };
        let n = 300;
        let points: Vec<Vec<f64>> = (0..n)
            .map(|_| {
                let base: Vec<f64> = (0..3).map(|_| next() * 2.0).collect();
                (0..30).map(|j| base[j % 3] + next() * 1e-4).collect()
            })
            .collect();
        let dataset = Dataset::new(points, None, "test");
        let whitened = pca_whiten_mp_floor(&dataset);
        let max_abs = whitened.points.iter().flatten().fold(0.0_f64, |acc, &v| acc.max(v.abs()));
        assert!(max_abs < 50.0, "valeur blanchie anormalement grande avec plancher MP : {max_abs}");
        assert!(whitened.points.iter().flatten().all(|v| v.is_finite()), "valeurs non finies");
    }

    #[test]
    fn pca_whiten_shrunk_removes_correlation_and_floors_near_zero_eigenvalues() {
        // Propriété double : (1) même propriété que pca_whiten standard
        // (décorrélation), (2) NE DOIT PAS produire de valeurs
        // explosives sur une direction quasi-colinéaire — c'est
        // précisément le défaut diagnostiqué du blanchiment brut que
        // cette variante corrige (cf. doc du module).
        let mut rng_state = 777u64;
        let mut next = || {
            rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1);
            ((rng_state >> 33) as f64) / (1u64 << 31) as f64 - 1.0
        };
        let n = 300;
        let points: Vec<Vec<f64>> = (0..n)
            .map(|_| {
                let x1 = next() * 3.0;
                // x2 quasi identique à x1 (colinéarité quasi exacte,
                // comme les triplets mean/se/worst de Breast Cancer) —
                // bruit minuscule pour éviter une covariance
                // EXACTEMENT singulière.
                let x2 = x1 + next() * 1e-4;
                let x3 = next() * 1.5;
                vec![x1, x2, x3]
            })
            .collect();
        let dataset = Dataset::new(points, None, "test");
        let whitened = pca_whiten_shrunk(&dataset);

        // (1) Aucune valeur explosive : sur blanchiment brut, la
        // direction quasi-colinéaire produirait des valeurs de l'ordre
        // de 1/1e-4=10000x le bruit — ici tout doit rester borné à une
        // échelle raisonnable (quelques dizaines au plus).
        let max_abs = whitened.points.iter().flatten().fold(0.0_f64, |acc, &v| acc.max(v.abs()));
        assert!(max_abs < 100.0, "valeur blanchie anormalement grande : {max_abs} (shrinkage n'a pas empêché l'explosion)");

        // (2) Toujours fini partout.
        assert!(whitened.points.iter().flatten().all(|v| v.is_finite()), "valeurs non finies après blanchiment");
    }

    #[test]
    fn jacobi_eigen_matches_numpy_reference() {
        // 2 matrices de référence (seed=0, numpy.linalg.eigh) avec
        // valeurs ET vecteurs propres — cross-validation externe avant
        // tout usage, même niveau de rigueur que le solveur
        // valeurs-propres-seules de `warm_start_bound.rs`.
        type Case = (Vec<Vec<f64>>, Vec<f64>, Vec<Vec<f64>>);
        let cases: Vec<Case> = vec![(
            vec![
                vec![1.764052345967664, 1.1338575992585953, 0.4377595661560907, 1.5009654621742257],
                vec![1.1338575992585953, -0.977277879876411, 0.6803434597319808, -0.014841095902434737],
                vec![0.4377595661560907, 0.6803434597319808, 0.144043571160878, 0.9490683698542004],
                vec![1.5009654621742257, -0.014841095902434737, 0.9490683698542004, 0.33367432737426683],
            ],
            vec![-1.8641095023450251, -0.3714359009200855, 0.2253873030452761, 3.274650464846232],
            vec![
                vec![-0.36010163489284935, -0.0787746791879184, 0.5190823131543697, -0.7711516806936536],
                vec![0.7512990372332728, -0.6069453091066446, 0.05185479955445366, -0.25392563511580357],
                vec![-0.3702158919653291, -0.3942410025514343, -0.7809288928126497, -0.31251286311760773],
                vec![0.4108731708644044, 0.6855552301452595, -0.34353267137768057, -0.49313544547155064],
            ],
        )];

        for (matrix, expected_eigenvalues, expected_eigenvectors) in cases {
            let (eigenvalues, eigenvectors) = jacobi_eigen(&matrix, 200, 1e-14);
            for (computed, wanted) in eigenvalues.iter().zip(expected_eigenvalues.iter()) {
                assert!((computed - wanted).abs() < 1e-8, "valeur propre: {computed} vs {wanted}");
            }
            // Signe arbitraire par colonne (convention numpy vs. la
            // nôtre peuvent différer d'un signe global par vecteur
            // propre — les deux sont mathématiquement corrects) :
            // comparer |v| composante à composante après alignement du
            // signe sur la première composante non nulle.
            let n = matrix.len();
            for col in 0..n {
                let sign = if eigenvectors[0][col].signum() == expected_eigenvectors[0][col].signum() { 1.0 } else { -1.0 };
                for row in 0..n {
                    let got = sign * eigenvectors[row][col];
                    let want = expected_eigenvectors[row][col];
                    assert!((got - want).abs() < 1e-6, "vecteur propre col={col} row={row}: {got} vs {want}");
                }
            }
        }
    }

    #[test]
    fn eigenvectors_are_orthonormal() {
        // Propriété structurelle indépendante de toute référence externe
        // : V^T V = I pour toute matrice symétrique, pas seulement les
        // cas de test ci-dessus.
        let matrix = vec![vec![2.0, 1.0, 0.5], vec![1.0, 3.0, -0.5], vec![0.5, -0.5, 1.5]];
        let (_, v) = jacobi_eigen(&matrix, 200, 1e-14);
        let n = v.len();
        for i in 0..n {
            for j in 0..n {
                let dot: f64 = (0..n).map(|k| v[k][i] * v[k][j]).sum();
                let expected = if i == j { 1.0 } else { 0.0 };
                assert!((dot - expected).abs() < 1e-9, "V^T V [{i}][{j}] = {dot}, attendu {expected}");
            }
        }
    }

    #[test]
    fn reconstructs_original_matrix() {
        // A = V Λ V^T doit redonner la matrice de départ — vérifie
        // conjointement valeurs ET vecteurs propres ensemble (pas
        // seulement chacun isolément contre la référence numpy).
        let matrix = vec![vec![4.0, 1.0, -1.0], vec![1.0, 3.0, 0.5], vec![-1.0, 0.5, 2.0]];
        let (eigenvalues, v) = jacobi_eigen(&matrix, 200, 1e-14);
        let n = matrix.len();
        for i in 0..n {
            for j in 0..n {
                let reconstructed: f64 = (0..n).map(|k| v[i][k] * eigenvalues[k] * v[j][k]).sum();
                assert!((reconstructed - matrix[i][j]).abs() < 1e-9, "[{i}][{j}]: reconstruit={reconstructed}, original={}", matrix[i][j]);
            }
        }
    }

    #[test]
    fn pca_whiten_removes_correlation() {
        // Propriété centrale utilisée pour corriger la sur-scission :
        // après blanchiment, la covariance du nuage entier est
        // exactement l'identité (λ_max=1, pas de corrélation résiduelle)
        // — vérifié directement, pas supposé.
        let mut rng_state = 12345u64;
        let mut next = || {
            rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1);
            ((rng_state >> 33) as f64) / (1u64 << 31) as f64 - 1.0
        };
        // Nuage corrélé : x2 = 2*x1 + bruit, x3 = independant.
        let n = 500;
        let points: Vec<Vec<f64>> = (0..n)
            .map(|_| {
                let x1 = next() * 3.0;
                let x2 = 2.0 * x1 + next() * 0.3;
                let x3 = next() * 1.5;
                vec![x1, x2, x3]
            })
            .collect();
        let dataset = Dataset::new(points, None, "test");
        let whitened = pca_whiten(&dataset);

        let d = 3;
        let n_f = n as f64;
        let mean: Vec<f64> = (0..d).map(|j| whitened.points.iter().map(|p| p[j]).sum::<f64>() / n_f).collect();
        let mut cov = vec![vec![0.0; d]; d];
        for p in &whitened.points {
            for i in 0..d {
                for j in 0..d {
                    cov[i][j] += (p[i] - mean[i]) * (p[j] - mean[j]) / n_f;
                }
            }
        }
        let (eigenvalues, _) = jacobi_eigen(&cov, 200, 1e-12);
        for lambda in eigenvalues {
            assert!((lambda - 1.0).abs() < 0.15, "valeur propre post-blanchiment = {lambda}, attendu ~1.0 (échantillon fini, tolérance large)");
        }
    }
}
