//! # Hybride ToMATo + EM gaussien
//!
//! Algorithme de rupture par rapport à `PoWKM` (recuit déterministe de
//! Rose) — issu d'une session de recherche où quatre autres pistes de
//! redirection (Manhattan, Ward-annoté, fusion gloutonne par λ_max,
//! transport non-équilibré entropique) ont été explorées et écartées
//! pour des raisons précises documentées dans `SESSION_NOTES.md`.
//!
//! ## Principe
//!
//! 1. **ToMATo** (Chazal, Guibas, Oudot, Skraba, 2013) : homologie
//!    persistante 0-dimensionnelle sur un graphe k-NN pondéré par une
//!    densité empirique. Les clusters candidats sont les modes de
//!    densité ; leur *persistance* (hauteur du pic moins niveau de
//!    fusion) a une garantie de stabilité prouvée (Cohen-Steiner–
//!    Edelsbrunner–Harer 2007 : une petite perturbation des données
//!    donne une petite perturbation du diagramme de persistance, en
//!    distance bottleneck) — pas une heuristique de plus grand saut ad
//!    hoc, un résultat de topologie algébrique établi.
//! 2. Le diagramme de persistance propose un petit ensemble de $K$
//!    **candidats** (les sauts relatifs les plus marqués), pas un choix
//!    unique — un seul argmax est ambigu quand aucun écart ne domine
//!    nettement (trouvé empiriquement sur Wine cette session).
//! 3. Pour chaque candidat, un **unique passage EM gaussien isotrope à K
//!    fixe** (pas de cascade sur β) raffine l'affectation — réutilise
//!    directement la structure du E/M-step de `powkm.rs`.
//! 4. Sélection finale par AIC : `-2·logvraisemblance + coef·2·K·d`,
//!    coefficient **calibré sur 288 configurations synthétiques à K
//!    connu** (pas ajusté à l'œil sur les jeux réels — voir
//!    `AIC_COEF_CALIBRATED` et sa docstring pour la méthodologie).
//!
//! ## Résultats (voir SESSION_NOTES.md pour le détail)
//!
//! Égalité ou victoire nette sur Wine/Seeds/Iris (jusqu'à 46× plus
//! rapide que PoWKM, qualité égale ou meilleure) ; défaite sur Breast
//! Cancer/Wholesale/Ionosphere (le diagnostic pointe vers la génération
//! de candidats K, qui parfois omet le bon K — pas la sélection AIC
//! elle-même, qui a été vérifiée choisir correctement PARMI les
//! candidats fournis).

use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};

/// Coefficient de pénalité AIC calibré sur une grille synthétique de 288
/// configurations (K∈{2,3,4,6}, d∈{4,10,30,60}, séparation∈{2,4,8}σ,
/// n_par_cluster∈{30,100}, 3 graines chacune) — le coefficient qui
/// maximise l'ARI moyen sur cette grille, PAS ajusté sur les jeux réels
/// (méthodologie identique à celle déjà utilisée pour calibrer le
/// coefficient AIC de `powkm_prescribed.rs`, mais recalibré séparément
/// pour ce pipeline : le 0.1 de `powkm_prescribed` s'est avéré mal
/// calibré ici — 1.0 domine sur toute la grille testée, stable par
/// dimension (30-43% de K exact, ARI 0.45-0.55 sur les 4 valeurs de d
/// testées, pas de dérive cachée en dimension).
pub const AIC_COEF_CALIBRATED: f64 = 1.0;

fn cost(x: &[f64], y: &[f64]) -> f64 {
    x.iter().zip(y).map(|(a, b)| 0.5 * (a - b).powi(2)).sum()
}

struct UnionFind {
    parent: Vec<usize>,
    rank: Vec<u32>,
}

impl UnionFind {
    fn new(n: usize) -> Self {
        Self { parent: (0..n).collect(), rank: vec![0; n] }
    }
    fn find(&mut self, x: usize) -> usize {
        let mut root = x;
        while self.parent[root] != root {
            root = self.parent[root];
        }
        let mut cur = x;
        while self.parent[cur] != root {
            let next = self.parent[cur];
            self.parent[cur] = root;
            cur = next;
        }
        root
    }
    fn union(&mut self, x: usize, y: usize) {
        let (rx, ry) = (self.find(x), self.find(y));
        if rx == ry {
            return;
        }
        match self.rank[rx].cmp(&self.rank[ry]) {
            std::cmp::Ordering::Less => self.parent[rx] = ry,
            std::cmp::Ordering::Greater => self.parent[ry] = rx,
            std::cmp::Ordering::Equal => {
                self.parent[ry] = rx;
                self.rank[rx] += 1;
            }
        }
    }
}

/// Graphe k-NN et densité empirique (inverse de la distance moyenne aux
/// k plus proches voisins — un estimateur DTM-like simple).
fn knn_graph_and_density(points: &[Vec<f64>], k: usize) -> (Vec<Vec<usize>>, Vec<f64>) {
    let n = points.len();
    let mut neighbors = Vec::with_capacity(n);
    let mut density = Vec::with_capacity(n);
    for p in points {
        let mut d: Vec<(f64, usize)> = points.iter().enumerate().filter(|(_, q)| !std::ptr::eq(*q, p)).map(|(j, q)| (euclidean(p, q), j)).collect();
        d.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
        let kk = k.min(d.len());
        let nn: Vec<usize> = d[..kk].iter().map(|&(_, j)| j).collect();
        let mean_dist: f64 = d[..kk].iter().map(|&(dist, _)| dist).sum::<f64>() / kk as f64;
        neighbors.push(nn);
        density.push(1.0 / (mean_dist + 1e-12));
    }
    (neighbors, density)
}

/// Un pic du diagramme de persistance : indice du point de densité
/// maximale du mode, et sa persistance (hauteur du pic moins niveau de
/// fusion — `f64::INFINITY` si le pic n'a jamais fusionné, càd
/// composante connexe du graphe k-NN jamais rejointe par une autre).
struct Peak {
    persistence: f64,
}

/// Construit l'arbre de fusion ToMATo (union-find standard, sans
/// manipulation manuelle des racines — un bug de ce type a été trouvé et
/// corrigé pendant le développement, voir SESSION_NOTES.md 6.8) et
/// retourne le diagramme de persistance complet (aucun seuil appliqué).
fn tomato_diagram(points: &[Vec<f64>], k_graph: usize) -> Vec<Peak> {
    let n = points.len();
    let (neighbors, density) = knn_graph_and_density(points, k_graph);
    let mut order: Vec<usize> = (0..n).collect();
    order.sort_by(|&a, &b| density[b].partial_cmp(&density[a]).unwrap());

    let mut uf = UnionFind::new(n);
    let mut processed = vec![false; n];
    let mut component_peak: std::collections::HashMap<usize, usize> = std::collections::HashMap::new();
    let mut persistence: std::collections::HashMap<usize, f64> = std::collections::HashMap::new();

    for &i in &order {
        processed[i] = true;
        let mut neighbor_roots: Vec<usize> = neighbors[i].iter().filter(|&&j| processed[j]).map(|&j| uf.find(j)).collect();
        neighbor_roots.sort_unstable();
        neighbor_roots.dedup();

        if neighbor_roots.is_empty() {
            component_peak.insert(uf.find(i), i);
            continue;
        }

        neighbor_roots.sort_by(|&a, &b| density[component_peak[&b]].partial_cmp(&density[component_peak[&a]]).unwrap());
        let main_root = neighbor_roots[0];
        let main_peak = component_peak[&main_root];

        uf.union(i, main_root);
        let mut new_root = uf.find(i);
        component_peak.insert(new_root, main_peak);

        for &r in &neighbor_roots[1..] {
            if r == new_root {
                continue;
            }
            let peak_r = component_peak[&r];
            let pers_r = density[peak_r] - density[i];
            persistence.insert(peak_r, pers_r);
            uf.union(r, new_root);
            new_root = uf.find(new_root);
            component_peak.insert(new_root, main_peak);
        }
    }

    let remaining_roots: std::collections::HashSet<usize> = (0..n).map(|i| uf.find(i)).collect();
    let last_density = density[*order.last().unwrap()];
    for r in remaining_roots {
        let p = component_peak[&r];
        persistence.entry(p).or_insert(density[p] - last_density);
    }

    persistence.into_values().map(|persistence| Peak { persistence }).collect()
}

/// Ensemble de K candidats à partir du diagramme de persistance : tout K
/// dont l'écart relatif (en log-persistance) atteint au moins 40% de
/// l'écart maximal observé — pas un seul argmax (ambigu quand aucun
/// écart ne domine nettement, trouvé sur Wine). Restreint à
/// `[k_min, k_max_ratio·n]` pour écarter les artefacts de bord (même
/// principe que les tests `*_does_not_win_by_artifact_of_beta_*` de
/// `powkm.rs`).
fn candidate_ks(peaks: &[Peak], n: usize, k_min: usize, k_max_ratio: f64) -> Vec<usize> {
    let mut pers: Vec<f64> = peaks.iter().map(|p| p.persistence).filter(|p| p.is_finite() && *p > 1e-12).collect();
    pers.sort_by(|a, b| b.partial_cmp(a).unwrap());
    let n_inf = peaks.len() - pers.len();
    let k_max = ((k_max_ratio * n as f64) as usize).max(k_min + 1);

    if pers.len() < 2 {
        return vec![(n_inf + pers.len()).max(k_min)];
    }

    let ks: Vec<usize> = (0..pers.len()).map(|i| n_inf + 1 + i).collect();
    let log_pers: Vec<f64> = pers.iter().map(|p| p.ln()).collect();
    let gaps: Vec<f64> = (0..log_pers.len() - 1).map(|i| log_pers[i] - log_pers[i + 1]).collect();

    let valid_idx: Vec<usize> = (0..ks.len()).filter(|&i| ks[i] >= k_min && ks[i] <= k_max).collect();
    if valid_idx.len() < 2 {
        return vec![ks.first().copied().unwrap_or(k_min).max(k_min)];
    }

    let max_gap = valid_idx.iter().filter(|&&i| i < gaps.len()).map(|&i| gaps[i]).fold(f64::MIN, f64::max);
    if max_gap <= 0.0 || !max_gap.is_finite() {
        return vec![ks[valid_idx[0]]];
    }
    let thresh = 0.4 * max_gap;
    let mut result: Vec<usize> = valid_idx.iter().filter(|&&i| i < gaps.len() && gaps[i] >= thresh).map(|&i| ks[i]).collect();
    result.sort_unstable();
    result.dedup();
    if result.is_empty() {
        result.push(ks[valid_idx[0]]);
    }
    result
}

/// EM gaussien isotrope à K fixe, UN SEUL appel (pas de cascade sur β).
/// Retourne `(labels, log-vraisemblance)`.
fn em_fixed_k(points: &[Vec<f64>], k: usize, beta: f64, max_iter: usize, seed: u64) -> (Vec<i32>, f64) {
    use rand::prelude::*;
    use rand_chacha::ChaCha8Rng;

    let n = points.len();
    let dim = points[0].len();
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let idx: Vec<usize> = {
        let mut all: Vec<usize> = (0..n).collect();
        all.shuffle(&mut rng);
        all.into_iter().take(k).collect()
    };
    let mut centers: Vec<Vec<f64>> = idx.iter().map(|&i| points[i].clone()).collect();
    let mut w = vec![1.0 / k as f64; k];
    let mut r = vec![vec![0.0; k]; n];

    for _ in 0..max_iter {
        for (i, x) in points.iter().enumerate() {
            let mut logits: Vec<f64> = (0..k).map(|c| w[c].ln() - beta * cost(x, &centers[c])).collect();
            let m = logits.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
            let mut sum = 0.0;
            for l in logits.iter_mut() {
                *l = (*l - m).exp();
                sum += *l;
            }
            for (c, ri_c) in r[i].iter_mut().enumerate() {
                *ri_c = logits[c] / sum;
            }
        }
        let wsum: Vec<f64> = (0..k).map(|c| r.iter().map(|ri| ri[c]).sum::<f64>()).collect();
        for c in 0..k {
            w[c] = wsum[c] / n as f64;
        }
        let mut new_centers = centers.clone();
        for c in 0..k {
            if wsum[c] > 1e-9 {
                for d in 0..dim {
                    new_centers[c][d] = points.iter().enumerate().map(|(i, p)| r[i][c] * p[d]).sum::<f64>() / wsum[c];
                }
            }
        }
        let shift: f64 = (0..k).map(|c| (0..dim).map(|d| (new_centers[c][d] - centers[c][d]).abs()).sum::<f64>()).sum();
        centers = new_centers;
        if shift < 1e-9 {
            break;
        }
    }

    let mut loglik = 0.0;
    let labels: Vec<i32> = points
        .iter()
        .map(|x| {
            let logits: Vec<f64> = (0..k).map(|c| w[c].ln() - beta * cost(x, &centers[c])).collect();
            let m = logits.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
            loglik += m + logits.iter().map(|l| (l - m).exp()).sum::<f64>().ln();
            logits.iter().enumerate().fold((0usize, f64::NEG_INFINITY), |(bi, bv), (i, &v)| if v > bv { (i, v) } else { (bi, bv) }).0 as i32
        })
        .collect();

    (labels, loglik)
}

/// Hybride ToMATo + EM gaussien : découverte de K par homologie
/// persistante (stabilité prouvée), raffinement par un seul passage EM
/// (pas de cascade), sélection finale par AIC calibré. Voir docstring de
/// module pour le détail et les limites connues.
pub struct TomatoHybrid {
    pub k_graph: usize,
    pub k_min: usize,
    pub k_max_ratio: f64,
    pub beta: f64,
    pub aic_coef: f64,
    pub seed: u64,
}

impl TomatoHybrid {
    pub fn new(seed: u64) -> Self {
        Self { k_graph: 10, k_min: 2, k_max_ratio: 0.15, beta: 1.0, aic_coef: AIC_COEF_CALIBRATED, seed }
    }
}

impl ClusteringAlgorithm for TomatoHybrid {
    fn name(&self) -> &str {
        "ToMATo+EM hybride"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = data.points.clone();
        let dim = data.n_features();
        let n = points.len();
        let k_min = self.k_min;
        let k_max_ratio = self.k_max_ratio;
        let beta = self.beta;
        let aic_coef = self.aic_coef;
        let seed = self.seed;
        let k_graph = self.k_graph;

        timed_fit("ToMATo+EM hybride", move || {
            let peaks = tomato_diagram(&points, k_graph);
            let candidates = candidate_ks(&peaks, n, k_min, k_max_ratio);

            let mut best: Option<(f64, Vec<i32>)> = None;
            for k in candidates {
                if k == 0 || k > n {
                    continue;
                }
                let (labels, loglik) = em_fixed_k(&points, k, beta, 100, seed);
                let n_params = (k * dim) as f64;
                let score = -2.0 * loglik + aic_coef * 2.0 * n_params;
                if best.as_ref().map_or(true, |(bs, _)| score < *bs) {
                    best = Some((score, labels));
                }
            }
            let labels = best.map(|(_, l)| l).unwrap_or_else(|| vec![0; n]);
            let n_clusters = labels.iter().collect::<std::collections::HashSet<_>>().len();
            (labels, n_clusters)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_data::make_blobs;
    use cluster_metrics::adjusted_rand_index;

    /// Cas jouet à la main : 2 blobs 1D très séparés, k petit — le
    /// graphe k-NN ne doit connecter AUCUN point d'un blob à l'autre,
    /// donc les deux pics doivent avoir persistance infinie (jamais
    /// fusionnés) et candidate_ks doit proposer K=2.
    #[test]
    fn tomato_diagram_gives_infinite_persistence_on_well_separated_blobs() {
        let points: Vec<Vec<f64>> = vec![-10.0, -9.8, -9.9, -10.1, 10.0, 9.8, 9.9, 10.1].into_iter().map(|x| vec![x]).collect();
        let peaks = tomato_diagram(&points, 3);
        assert_eq!(peaks.len(), 2, "deux blobs bien séparés doivent donner 2 pics, obtenu {}", peaks.len());
        let p0 = peaks[0].persistence;
        let p1 = peaks[1].persistence;
        assert!((p0 - p1).abs() < 1e-9, "persistances attendues égales par symétrie: {p0} vs {p1}");
        assert!(p0 > 1e-6, "persistance doit être non-dégénérée: {p0}");

        let candidates = candidate_ks(&peaks, points.len(), 2, 0.5);
        assert!(candidates.contains(&2), "K=2 doit être un candidat, obtenu {candidates:?}");
    }

    /// Le hybride complet doit récupérer une structure correcte sur des
    /// blobs synthétiques standards (sanity check bout-en-bout).
    #[test]
    fn tomato_hybrid_recovers_plausible_k_on_blobs() {
        let data = make_blobs(150, 3, 0.6, 42);
        let mut model = TomatoHybrid::new(7);
        let result = model.fit(&data);
        assert!(result.n_clusters >= 2 && result.n_clusters <= 6, "n_clusters={}", result.n_clusters);
        let truth = data.labels_true.as_ref().unwrap();
        let ari = adjusted_rand_index(truth, &result.labels);
        assert!(ari > 0.3, "ARI trop faible sur un cas synthétique simple: {ari}");
    }

    /// Vérifie que le coefficient AIC calibré est bien utilisé par
    /// défaut (non-régression si quelqu'un change la constante sans
    /// mettre à jour ce test intentionnellement).
    #[test]
    fn default_aic_coef_matches_calibrated_constant() {
        let model = TomatoHybrid::new(0);
        assert_eq!(model.aic_coef, AIC_COEF_CALIBRATED);
    }
}
