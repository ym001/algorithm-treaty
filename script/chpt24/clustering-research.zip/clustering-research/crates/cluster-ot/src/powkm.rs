//! PoWKM (Potential-warm-started Wasserstein K-Means) : clustering par
//! recuit déterministe sur l'énergie libre entropique (Rose, Gurewitz &
//! Fox, 1990 ; Rose, 1998), reformulé dans le langage du transport
//! optimal entropique. Le nombre de classes n'est **pas** un paramètre
//! d'entrée : il émerge d'une cascade de transitions de phase à mesure
//! que la température inverse β augmente, et se stabilise en fin de
//! recuit.
//!
//! ## Cadre mathématique
//!
//! Responsabilités de Gibbs à poids auto-cohérents (formulation libre,
//! Rose 1990 — proche du transport entropique de Sinkhorn mais sans
//! contrainte de marge cible fixée) :
//! ```text
//! r_ik = w_k·exp(-β·c(x_i,y_k)) / Σ_l w_l·exp(-β·c(x_i,y_l))    (E-step)
//! w_k  = (1/n)·Σ_i r_ik                                          (poids)
//! y_k  = (Σ_i r_ik·x_i) / (Σ_i r_ik)                             (M-step, forme close)
//! ```
//!
//! Énergie libre (log-partition, forme robuste, évite de calculer
//! séparément le terme d'entropie) :
//! ```text
//! F_β(Y,w) = -(1/(nβ))·Σ_i log( Σ_k w_k·exp(-β·c(x_i,y_k)) )
//! ```
//! dont le gradient (théorème de l'enveloppe, prouvé dans le README) est
//! `∂F/∂y_k = (1/n)·Σ_i r_ik·(y_k - x_i)`.
//!
//! ## Critère de scission (global, pas local)
//!
//! Pour chaque centre `y_k`, on construit un système augmenté à K+1
//! centres où `y_k` est dédoublé en `y_k ± ε·v` (poids partagé), `v` étant
//! la direction principale de la covariance locale pondérée. On relaxe ce
//! système augmenté par EM complet (tous les centres, pas seulement la
//! paire dédoublée, sont libres de bouger — c'est ce qui rend le critère
//! global et non local : la décision dépend de la vraie énergie couplée,
//! pas d'une approximation découplée par cluster) puis on compare
//! l'énergie libre convergée à celle du système non scindé. La scission
//! est acceptée ssi elle est strictement meilleure.
//!
//! Cas particulier vérifiable à la main (K=1, voir tests) : la condition
//! de bifurcation exacte est `(I - 2βΣ)v = 0`, Σ = covariance des données,
//! soit un premier `β_c = 1/(2λ_max(Σ))` — résultat de Rose (1990),
//! reproduit ici comme garde-fou de correction avant tout usage sur données
//! réelles.

#![allow(clippy::needless_range_loop, clippy::too_many_arguments)]

use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;

fn logsumexp(values: &[f64]) -> f64 {
    let max = values.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    if !max.is_finite() {
        return max;
    }
    let sum: f64 = values.iter().map(|&v| (v - max).exp()).sum();
    max + sum.ln()
}

fn cost(x: &[f64], y: &[f64]) -> f64 {
    0.5 * euclidean(x, y).powi(2)
}

/// E-step : responsabilités de Gibbs pour des centres/poids fixés.
fn responsibilities(points: &[Vec<f64>], centers: &[Vec<f64>], weights: &[f64], beta: f64) -> Vec<Vec<f64>> {
    let k = centers.len();
    points
        .iter()
        .map(|x| {
            let log_terms: Vec<f64> = (0..k).map(|j| weights[j].ln() - beta * cost(x, &centers[j])).collect();
            let lse = logsumexp(&log_terms);
            log_terms.iter().map(|&t| (t - lse).exp()).collect()
        })
        .collect()
}

/// Point fixe interne (E-step + mise à jour des poids), **centres fixés**.
/// Nécessaire pour que la formule du gradient (théorème de l'enveloppe)
/// soit valide : elle suppose r et w à leur optimum conditionnel pour Y
/// donné.
fn inner_fixed_point(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, max_iter: usize, tol: f64) -> (Vec<Vec<f64>>, Vec<f64>) {
    let k = centers.len();
    let n = points.len();
    let mut weights = vec![1.0 / k as f64; k];
    let mut r = responsibilities(points, centers, &weights, beta);

    for _ in 0..max_iter {
        let new_weights: Vec<f64> = (0..k).map(|j| r.iter().map(|row| row[j]).sum::<f64>() / n as f64).collect();
        let shift: f64 = new_weights.iter().zip(weights.iter()).map(|(a, b)| (a - b).abs()).sum();
        weights = new_weights;
        r = responsibilities(points, centers, &weights, beta);
        if shift < tol {
            break;
        }
    }
    (r, weights)
}

/// Énergie libre (log-partition), forme robuste. Ne nécessite pas de
/// calculer séparément le terme d'entropie.
fn free_energy(points: &[Vec<f64>], centers: &[Vec<f64>], weights: &[f64], beta: f64) -> f64 {
    let n = points.len() as f64;
    let total: f64 = points
        .iter()
        .map(|x| {
            let log_terms: Vec<f64> = weights.iter().zip(centers.iter()).map(|(w, c)| w.ln() - beta * cost(x, c)).collect();
            logsumexp(&log_terms)
        })
        .sum();
    -total / (n * beta)
}

/// Gradient de l'énergie libre par rapport aux centres (K×d), à
/// (centres, β) donnés — utilise `inner_fixed_point` pour obtenir r à son
/// optimum conditionnel (théorème de l'enveloppe : le terme de variation
/// de r s'annule au premier ordre).
fn gradient_wrt_centers(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, max_iter: usize, tol: f64) -> Vec<Vec<f64>> {
    let (r, _weights) = inner_fixed_point(points, centers, beta, max_iter, tol);
    let n = points.len() as f64;
    let dim = centers[0].len();
    let k = centers.len();
    let mut grad = vec![vec![0.0; dim]; k];
    for (i, x) in points.iter().enumerate() {
        for kk in 0..k {
            let rik = r[i][kk];
            for d in 0..dim {
                grad[kk][d] += rik * (centers[kk][d] - x[d]);
            }
        }
    }
    for row in grad.iter_mut() {
        for v in row.iter_mut() {
            *v /= n;
        }
    }
    grad
}

/// EM complet à β fixé : alterne E-step, mise à jour des poids, et M-step
/// (forme close) sur les centres, jusqu'à convergence des centres.
pub(crate) fn em_converge(points: &[Vec<f64>], init_centers: Vec<Vec<f64>>, beta: f64, max_outer: usize, max_inner: usize, tol: f64) -> (Vec<Vec<f64>>, Vec<f64>) {
    let dim = points[0].len();
    let k = init_centers.len();
    let mut centers = init_centers;

    let mut weights = vec![1.0 / k as f64; k];
    for _ in 0..max_outer {
        let r = responsibilities(points, &centers, &weights, beta);
        let n = points.len() as f64;
        let new_weights: Vec<f64> = (0..k).map(|j| r.iter().map(|row| row[j]).sum::<f64>() / n).collect();

        let mut new_centers = vec![vec![0.0; dim]; k];
        for kk in 0..k {
            let denom: f64 = r.iter().map(|row| row[kk]).sum();
            if denom > 1e-12 {
                for (i, x) in points.iter().enumerate() {
                    for d in 0..dim {
                        new_centers[kk][d] += r[i][kk] * x[d];
                    }
                }
                for d in 0..dim {
                    new_centers[kk][d] /= denom;
                }
            } else {
                new_centers[kk] = centers[kk].clone();
            }
        }

        let shift: f64 = centers
            .iter()
            .zip(new_centers.iter())
            .map(|(a, b)| euclidean(a, b))
            .sum();
        centers = new_centers;
        weights = new_weights;
        if shift < tol {
            break;
        }
    }
    // dernier E-step pour renvoyer des poids cohérents avec les centres finaux
    let r = responsibilities(points, &centers, &weights, beta);
    let n = points.len() as f64;
    weights = (0..k).map(|j| r.iter().map(|row| row[j]).sum::<f64>() / n).collect();
    let _ = max_inner; // inner fixed point n'est utilisé que pour le gradient/hessien, pas ici
    (centers, weights)
}

/// Produit hessien-vecteur par différences finies centrées de la formule
/// **exacte** du gradient (pas de différentiation finie du gradient
/// lui-même en dehors de cette étape). `v` est un vecteur aplati K×d.
fn hessian_vector_product(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, v: &[f64], h: f64, max_iter: usize, tol: f64) -> Vec<f64> {
    let dim = centers[0].len();
    let k = centers.len();

    let perturb = |sign: f64| -> Vec<Vec<f64>> {
        (0..k)
            .map(|kk| (0..dim).map(|d| centers[kk][d] + sign * h * v[kk * dim + d]).collect())
            .collect()
    };

    let grad_plus = gradient_wrt_centers(points, &perturb(1.0), beta, max_iter, tol);
    let grad_minus = gradient_wrt_centers(points, &perturb(-1.0), beta, max_iter, tol);

    let mut result = vec![0.0; k * dim];
    for kk in 0..k {
        for d in 0..dim {
            result[kk * dim + d] = (grad_plus[kk][d] - grad_minus[kk][d]) / (2.0 * h);
        }
    }
    result
}

/// Matérialise le hessien complet (K·dim)×(K·dim) par différences finies
/// de la formule **exacte** du gradient (une colonne = une évaluation en
/// perturbant un unique degré de liberté). Coûteux mais robuste pour les
/// petites dimensions K·dim en jeu ici — voir la note ci-dessous sur
/// pourquoi le matrix-free (produit hessien-vecteur seul + itération de
/// puissance simple) s'est révélé **incorrect** en pratique.
fn materialize_hessian(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, h: f64, max_iter: usize, tol: f64) -> Vec<Vec<f64>> {
    let dim = centers[0].len();
    let k = centers.len();
    let total = k * dim;
    let mut h_mat = vec![vec![0.0; total]; total];
    for col in 0..total {
        let mut e = vec![0.0; total];
        e[col] = 1.0;
        let hv = hessian_vector_product(points, centers, beta, &e, h, max_iter, tol);
        for row in 0..total {
            h_mat[row][col] = hv[row];
        }
    }
    // Symétrisation (le hessien est théoriquement symétrique ; la
    // différence finie introduit une asymétrie numérique de l'ordre de h).
    for i in 0..total {
        for j in (i + 1)..total {
            let avg = 0.5 * (h_mat[i][j] + h_mat[j][i]);
            h_mat[i][j] = avg;
            h_mat[j][i] = avg;
        }
    }
    h_mat
}

fn matvec(m: &[Vec<f64>], v: &[f64]) -> Vec<f64> {
    m.iter().map(|row| row.iter().zip(v.iter()).map(|(a, b)| a * b).sum()).collect()
}

fn power_iteration_dense(matrix: &[Vec<f64>], dim: usize, max_iter: usize, tol: f64, rng: &mut ChaCha8Rng) -> (Vec<f64>, f64) {
    let mut v: Vec<f64> = (0..dim).map(|_| rng.gen::<f64>() - 0.5).collect();
    normalize(&mut v);
    for _ in 0..max_iter {
        let mut mv = matvec(matrix, &v);
        normalize(&mut mv);
        let diff: f64 = v.iter().zip(mv.iter()).map(|(a, b)| (a - b).abs()).sum();
        let diff_flip: f64 = v.iter().zip(mv.iter()).map(|(a, b)| (a + b).abs()).sum();
        v = mv;
        if diff.min(diff_flip) < tol {
            break;
        }
    }
    let mv = matvec(matrix, &v);
    let eigenvalue: f64 = v.iter().zip(mv.iter()).map(|(a, b)| a * b).sum();
    (v, eigenvalue)
}

/// Point méthodologique important (bug corrigé après premier essai raté,
/// voir tests) : une itération de puissance *simple* sur `-H` ne trouve
/// pas nécessairement la plus petite valeur propre de `H` — elle converge
/// vers le mode de plus grande magnitude, qui peut très bien être un mode
/// trivial sans rapport avec l'instabilité de scission cherchée (c'est
/// exactement ce qui se produit ici : un mode « tous les centres bougent
/// ensemble » de valeur propre constante domine en magnitude un mode de
/// séparation dont la valeur propre est proche de 0 près du point critique).
/// Solution robuste : matérialiser le hessien complet et **déflater tout
/// le spectre** (comme dans `spectral::top_k_eigenvectors`), puis prendre
/// le minimum sur l'ensemble des valeurs propres retrouvées — la
/// déflation élimine chaque mode trouvé indépendamment de son signe, donc
/// aucun mode ne peut « cacher » un autre indéfiniment.
fn smallest_eigenvalue(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, h: f64, power_iter: usize, inner_max_iter: usize, inner_tol: f64, seed: u64) -> (f64, Vec<f64>) {
    let dim = centers[0].len();
    let k = centers.len();
    let total = k * dim;
    let mut rng = ChaCha8Rng::seed_from_u64(seed);

    let h_mat = materialize_hessian(points, centers, beta, h, inner_max_iter, inner_tol);
    let mut working = h_mat;
    let mut best_eigenvalue = f64::INFINITY;
    let mut best_vector = vec![0.0; total];

    for _ in 0..total {
        let (v, lambda) = power_iteration_dense(&working, total, power_iter, 1e-12, &mut rng);
        if lambda < best_eigenvalue {
            best_eigenvalue = lambda;
            best_vector = v.clone();
        }
        for a in 0..total {
            for b in 0..total {
                working[a][b] -= lambda * v[a] * v[b];
            }
        }
    }
    (best_eigenvalue, best_vector)
}

/// Analyse de stabilité locale (outil de diagnostic/certification, séparé
/// du critère opérationnel de scission utilisé par `fit`) : matérialise le
/// hessien de l'énergie libre au point `centers` donné et retourne sa plus
/// petite valeur propre. Négative ⟹ au moins une direction de séparation
/// fait strictement décroître l'énergie libre localement — signal
/// d'instabilité. C'est la machinerie validée contre le point de
/// bifurcation exact de Rose (1990) dans les tests de ce module ; exposée
/// publiquement pour permettre de certifier a posteriori qu'une
/// configuration retenue par `fit` (dont le critère opérationnel est une
/// comparaison directe d'énergie libre après relaxation complète, plus
/// robuste en pratique que ce test local) est bien localement stable.
pub fn local_stability(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, seed: u64) -> f64 {
    let (lambda, _) = smallest_eigenvalue(points, centers, beta, 1e-4, 300, 300, 1e-10, seed);
    lambda
}

/// Covariance pondérée du cluster `k_idx`, sous les responsabilités `r`
/// du système **complet** à K clusters (pas un système isolé à 2
/// centres) — c'est `Σ_{k*}` de la dérivation générale ci-dessous.
/// Extrait de la boucle de scission de `fit()` (même calcul, factorisé
/// ici pour être réutilisable par les fonctions d'analyse/test).
fn weighted_covariance(points: &[Vec<f64>], r: &[Vec<f64>], centers: &[Vec<f64>], k_idx: usize) -> (Vec<Vec<f64>>, f64) {
    let dim = points[0].len();
    let mut cov = vec![vec![0.0; dim]; dim];
    let wsum: f64 = r.iter().map(|row| row[k_idx]).sum();
    if wsum < 1e-9 {
        return (cov, wsum);
    }
    for (i, x) in points.iter().enumerate() {
        let rik = r[i][k_idx];
        if rik <= 0.0 {
            continue;
        }
        for a in 0..dim {
            for b in 0..dim {
                cov[a][b] += rik * (x[a] - centers[k_idx][a]) * (x[b] - centers[k_idx][b]);
            }
        }
    }
    for row in cov.iter_mut() {
        for v in row.iter_mut() {
            *v /= wsum;
        }
    }
    (cov, wsum)
}

/// ## Formule généralisée du point de bifurcation, K quelconque
///
/// Généralisation du cas hand-vérifié `K=1` (voir
/// `rose_bifurcation_point_duplicated_pair_hand_verified`) à un cluster
/// `k_idx` quelconque au sein d'un système à K clusters déjà convergé,
/// **les autres centres étant gelés** pendant la sonde (même hypothèse
/// que le test `K=1`, juste plus de clusters autour).
///
/// Dérivation (à la main, cf. session de recherche — développement à
/// l'ordre 2 en ε de `F_β(y_k*+εv, y_k*-εv ; reste fixé)`, poids
/// dédoublé, coût `c(x,y)=½‖x-y‖²`) :
/// ```text
/// d²F/dε²|_{ε=0} = w_k* · [1 - β·vᵀΣ_k*v]
/// ```
/// où `w_k*` est le poids du cluster et `Σ_k*` sa covariance pondérée
/// dans le système complet (calculée par `weighted_covariance`, sous les
/// responsabilités du système à K clusters — c'est la SEULE façon dont
/// les autres clusters entrent dans la formule : via la forme de `Σ_k*`,
/// pas via un terme de couplage additionnel). Minimisée sur `v` unitaire
/// (vecteur propre dominant de `Σ_k*`) :
/// ```text
/// β_c = 1 / λ_max(Σ_k*)
/// ```
/// **Résultat notable** : `w_k*` ne change que l'amplitude du mode, jamais
/// l'emplacement du zéro — donc la formule ne dépend pas de K sous cette
/// forme, seulement de la covariance locale du cluster candidat à la
/// scission. Ceci transforme la porte opérationnelle `β·λ_max(Σ_k)>1`
/// (jusqu'ici utilisée comme heuristique, cf. note dans `linalg.rs`) en
/// critère de stabilité locale **prouvé**, pas seulement plausible par
/// analogie avec le cas K=1.
///
/// Validé numériquement en Python (différences finies, accord à 1e-5 ou
/// mieux) avant ce portage, y compris sur un cas K=2→3 réellement couplé
/// (deux clusters de variances très différentes) — voir
/// `generalized_beta_c_matches_finite_difference_coupled_k2` ci-dessous
/// pour la même vérification en Rust.
///
/// Retourne `(β_c prédit, λ_max, vecteur propre dominant, w_k*)`.
pub fn predicted_beta_c(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, k_idx: usize) -> (f64, f64, Vec<f64>, f64) {
    let (r, _w) = inner_fixed_point(points, centers, beta, 300, 1e-11);
    let (cov, wsum) = weighted_covariance(points, &r, centers, k_idx);
    let n = points.len() as f64;
    let w_k_star = wsum / n;
    let (eigenvalues, eigenvectors) = crate::linalg::jacobi_eigen(&cov, 200, 1e-12);
    let dim = cov.len();
    let last = eigenvalues.len() - 1;
    let lambda_max = eigenvalues[last];
    let v: Vec<f64> = (0..dim).map(|d| eigenvectors[d][last]).collect();
    (1.0 / lambda_max, lambda_max, v, w_k_star)
}

/// Second membre analytique `w_k*·[1-β·λ_max(Σ_k*)]` (formule ci-dessus),
/// utile pour comparer directement à une différence finie plutôt que de
/// ne comparer que l'emplacement du zéro.
pub fn predicted_second_derivative(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, k_idx: usize) -> f64 {
    let (_beta_c, lambda_max, _v, w_k_star) = predicted_beta_c(points, centers, beta, k_idx);
    w_k_star * (1.0 - beta * lambda_max)
}

/// Différence finie centrée de `d²F/dε²|_0` pour la même sonde
/// (dédoublement de `y_k*` le long de `v`, **autres centres gelés**, pas
/// de relaxation complète) — vérification indépendante de la formule
/// analytique ci-dessus, même esprit que
/// `free_energy_and_gradient_are_consistent_via_finite_difference`.
pub fn finite_diff_second_derivative(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64, k_idx: usize, v: &[f64], eps: f64) -> f64 {
    let dim = centers[0].len();
    let (r0, w0) = inner_fixed_point(points, centers, beta, 300, 1e-11);
    let _ = r0;

    let eval_at = |e: f64| -> f64 {
        let mut trial_centers = centers.to_vec();
        let y0 = &centers[k_idx];
        trial_centers[k_idx] = (0..dim).map(|d| y0[d] + e * v[d]).collect();
        trial_centers.push((0..dim).map(|d| y0[d] - e * v[d]).collect());
        let mut trial_weights = w0.clone();
        trial_weights[k_idx] /= 2.0;
        trial_weights.push(trial_weights[k_idx]);
        free_energy(points, &trial_centers, &trial_weights, beta)
    };

    let f0 = eval_at(0.0);
    let fp = eval_at(eps);
    let fm = eval_at(-eps);
    (fp - 2.0 * f0 + fm) / (eps * eps)
}

/// ## Seuil de significativité statistique pour λ_max(Σ_k*)
///
/// **Piste de correction pour l'emballement de K en haute dimension**
/// (diagnostiqué cette session sur Sonar : d=60, K passe de 1 à 88+ sur
/// une plage étroite de β). Hypothèse : ce n'est pas un bug de calcul
/// mais un artefact statistique — `weighted_covariance` estime Σ_k* à
/// partir d'un échantillon EFFECTIF de taille `wsum` (le poids
/// pondéré du cluster, pas n) en `d` dimensions. Une fois `wsum`
/// comparable à `d` (ce qui arrive vite : `wsum≈n/K` décroît à mesure
/// que K croît), même un cluster réellement isotrope produit par pur
/// bruit d'échantillonnage un λ_max(Σ_k*) largement supérieur à la
/// vraie variance — c'est exactement la théorie de Marchenko-Pastur déjà
/// utilisée pour `pca_whiten_rank_reduced` dans `linalg.rs` (bord
/// supérieur `λ₊=μ(1+√c)²`, c=d/n), simplement appliquée ici à
/// l'échantillon effectif d'UN cluster candidat plutôt qu'au jeu de
/// données entier.
///
/// Retourne `λ₊`. Un `λ_max(Σ_k*)` observé en dessous de ce seuil est
/// statistiquement indiscernable d'un cluster isotrope sans structure —
/// la scission ne doit pas être tentée, quelle que soit la valeur de β.
///
/// **Avertissement honnête**, comme pour `pca_whiten_rank_reduced` :
/// Marchenko-Pastur est un résultat ASYMPTOTIQUE (n,d→∞, d/n→c fixé).
/// Invalide littéralement pour de petits échantillons jouets (ex. le
/// test hand-vérifié K=1 à 4 points — voir
/// `mp_significance_floor_is_inert_on_well_sampled_clusters` pour où la
/// limite se situe concrètement). Traité comme heuristique de
/// significativité établie (usage courant en débruitage par RMT), pas
/// comme théorème appliqué à la lettre — pas encore vérifié comme
/// améliorant les métriques de découverte de K sur les jeux réels, à
/// faire avant de l'activer par défaut dans `fit()` (actuellement
/// **non câblé**, diagnostic pur).
pub fn mp_significance_floor(cov: &[Vec<f64>], wsum: f64) -> f64 {
    let d = cov.len();
    let mu = (0..d).map(|i| cov[i][i]).sum::<f64>() / d as f64;
    let c = d as f64 / wsum.max(1e-9);
    mu * (1.0 + c.sqrt()).powi(2)
}

/// ## D(β), distorsion moyenne pondérée sous les responsabilités
/// courantes — `D(β) = (1/n)ΣᵢΣₖ r_ik·c(xᵢ,yₖ)`.
///
/// Par le théorème de l'enveloppe appliqué à `βF*(β) = min_D[βD+R(D)]`
/// (dualité débit-distorsion, Rose 1994), `D(β) = d(βF*(β))/dβ` — et
/// comme `βF*(β)` est CONCAVE en β (établi la session précédente : c'est
/// un inf de fonctions affines en β, une pour chaque niveau de
/// distorsion D), `D(β)` doit être **non-croissante**. Résultat
/// indépendant de toute hypothèse de log-concavité — validé
/// numériquement (Python, 175 points, 0 violation) avant ce portage. Ne
/// prouve PAS la log-concavité de la suite des gains/largeurs de
/// plateau (résultat négatif documenté dans `powkm_prescribed.rs`) —
/// c'est une propriété distincte, plus faible mais plus solide.
pub fn distortion(points: &[Vec<f64>], centers: &[Vec<f64>], beta: f64) -> f64 {
    let (r, _w) = inner_fixed_point(points, centers, beta, 300, 1e-11);
    let n = points.len() as f64;
    let mut total = 0.0;
    for (i, x) in points.iter().enumerate() {
        for (k, y) in centers.iter().enumerate() {
            total += r[i][k] * cost(x, y);
        }
    }
    total / n
}

#[derive(Debug, Clone)]
pub struct PoWKM {
    pub beta_min: f64,
    pub beta_max: f64,
    pub beta_growth: f64,
    pub merge_tol: f64,
    /// Seuil **relatif** d'amélioration de l'énergie libre pour accepter
    /// une scission (`f_after < f_before·(1-tol)`). Un seuil absolu s'est
    /// révélé accepter des scissions relevant du bruit numérique de
    /// convergence de l'EM plutôt que d'une vraie structure (voir
    /// historique : diagnostic ayant montré des scissions acceptées pour
    /// une amélioration de 10⁻⁵ sur une énergie de l'ordre de 1, soit
    /// ~0.001 % — non significatif).
    pub split_improvement_rel_tol: f64,
    /// Arrêt anticipé du recuit si le plateau courant (même K depuis
    /// combien de multiplications de β) dépasse ce facteur — évite de
    /// payer le coût du régime de sur-segmentation (K→n quand β→∞, un
    /// comportement mathématiquement attendu, pas un bug, mais inutile
    /// une fois le plateau stable clairement établi).
    pub early_stop_plateau_ratio: f64,
    /// **Opt-in, désactivé par défaut** — n'affecte aucun test existant
    /// tant qu'il n'est pas mis à `true` explicitement. Filtre une
    /// scission candidate AVANT la relaxation complète coûteuse si
    /// `λ_max(Σ_k*)` ne dépasse pas le bord de bruit de Marchenko-Pastur
    /// (`mp_significance_floor`) — piste de correction pour l'emballement
    /// de K en haute dimension (diagnostiqué sur Sonar, d=60 : K passe de
    /// 1 à 88+ sur une plage étroite de β). Voir docstring de
    /// `mp_significance_floor` pour les limites (résultat asymptotique,
    /// pas encore vérifié comme améliorant les métriques de découverte de
    /// K sur les jeux réels — traité comme piste à valider, pas comme
    /// correctif acquis).
    pub mp_significance_gate: bool,
    /// **Opt-in, désactivé par défaut** (`0.0` = pas de plancher). Interdit
    /// toute scission qui laisserait le cluster candidat sous
    /// `wsum < min_samples_per_dim * d` — pas un test de significativité
    /// statistique comme `mp_significance_gate` (qui reste sujet aux faux
    /// positifs répétés sur beaucoup d'essais successifs), un plafond DUR :
    /// plafonne K par construction à environ `n/(min_samples_per_dim*d)`,
    /// au lieu de simplement ralentir sa croissance. Motivé par
    /// l'échec du gate MP seul à empêcher l'emballement de K sur Sonar
    /// (section 6.4/6.6 de SESSION_NOTES.md) — cf. tests
    /// `min_samples_per_dim_caps_k_hard` et suite empirique jeux réels.
    pub min_samples_per_dim: f64,
    pub seed: u64,
}

impl PoWKM {
    pub fn new(seed: u64) -> Self {
        Self {
            beta_min: 0.01,
            beta_max: 50.0,
            beta_growth: 1.15,
            merge_tol: 1e-2,
            split_improvement_rel_tol: 1e-3,
            early_stop_plateau_ratio: 25.0,
            mp_significance_gate: false,
            min_samples_per_dim: 0.0,
            seed,
        }
    }
}

/// Un segment du recuil pendant lequel K est resté constant.
struct Plateau {
    k: usize,
    beta_start: f64,
    beta_end: f64,
    centers: Vec<Vec<f64>>,
}

impl Plateau {
    fn log_width(&self) -> f64 {
        (self.beta_end / self.beta_start).ln()
    }
}

impl ClusteringAlgorithm for PoWKM {
    fn name(&self) -> &str {
        "PoWKM"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        assert!(points.len() >= 2, "PoWKM requiert au moins 2 points");
        let dim = points[0].len();
        let n = points.len();

        let beta_min = self.beta_min;
        let beta_max = self.beta_max;
        let beta_growth = self.beta_growth;
        let merge_tol = self.merge_tol;
        let rel_tol = self.split_improvement_rel_tol;
        let early_stop_ratio = self.early_stop_plateau_ratio;

        timed_fit(self.name(), || {
            let mean: Vec<f64> = (0..dim).map(|d| points.iter().map(|p| p[d]).sum::<f64>() / n as f64).collect();
            let mut centers = vec![mean];
            let mut beta = beta_min;

            let mut plateaus: Vec<Plateau> = Vec::new();
            let mut current_plateau_k = centers.len();
            let mut current_plateau_start = beta;
            let mut early_stop_triggered = false;
            let mut plateau_k_at_trigger: usize = 0;
            let mut last_stable_centers = centers.clone();

            while beta < beta_max {
                let (converged, _w) = em_converge(points, centers.clone(), beta, 60, 100, 1e-6);
                centers = converged;

                let k_cap = if self.min_samples_per_dim > 0.0 {
                    ((n as f64) / (self.min_samples_per_dim * dim as f64)).floor().max(1.0) as usize
                } else {
                    usize::MAX
                };

                let mut k_idx = 0;
                let mut dirty = true;
                let mut r = Vec::new();
                let mut f_before = 0.0;
                while k_idx < centers.len() {
                    if centers.len() >= k_cap {
                        break;
                    }
                    if dirty {
                        let (r_new, w_new) = inner_fixed_point(points, &centers, beta, 100, 1e-7);
                        f_before = free_energy(points, &centers, &w_new, beta);
                        r = r_new;
                        dirty = false;
                    }

                    let (cov, wsum) = weighted_covariance(points, &r, &centers, k_idx);
                    if wsum < 1e-9 {
                        k_idx += 1;
                        continue;
                    }
                    if self.min_samples_per_dim > 0.0 && wsum < self.min_samples_per_dim * dim as f64 {
                        k_idx += 1;
                        continue;
                    }
                    let (eigenvalues, eigenvectors) = crate::linalg::jacobi_eigen(&cov, 100, 1e-12);
                    let last = eigenvalues.len() - 1;
                    let dir: Vec<f64> = (0..dim).map(|d| eigenvectors[d][last]).collect();

                    if self.mp_significance_gate {
                        let mp_floor = mp_significance_floor(&cov, wsum);
                        if eigenvalues[last] <= mp_floor {
                            k_idx += 1;
                            continue;
                        }
                    }

                    let eps_probe = 0.05 * cov.iter().enumerate().map(|(a, row)| row[a]).sum::<f64>().sqrt().max(1e-6);
                    let mut trial_centers = centers.clone();
                    let y_k = centers[k_idx].clone();
                    trial_centers[k_idx] = (0..dim).map(|d| y_k[d] + eps_probe * dir[d]).collect();
                    trial_centers.push((0..dim).map(|d| y_k[d] - eps_probe * dir[d]).collect());

                    let (relaxed, w_relaxed) = em_converge(points, trial_centers, beta, 50, 100, 1e-6);
                    let f_after = free_energy(points, &relaxed, &w_relaxed, beta);

                    if f_after < f_before * (1.0 - rel_tol) {
                        centers = relaxed;
                        dirty = true;
                    } else {
                        k_idx += 1;
                    }
                }

                centers = merge_close_centers(centers, merge_tol);

                if std::env::var("POWKM_DEBUG_PROGRESS").is_ok() {
                    eprintln!("β={beta:.5}  K={}", centers.len());
                }

                if centers.len() != current_plateau_k {
                    plateaus.push(Plateau {
                        k: current_plateau_k,
                        beta_start: current_plateau_start,
                        beta_end: beta,
                        centers: last_stable_centers.clone(),
                    });
                    current_plateau_k = centers.len();
                    current_plateau_start = beta;
                }
                last_stable_centers = centers.clone();

                beta *= beta_growth;

                // Correctif (diagnostiqué sur powkm_prescribed.rs, même
                // logique partagée ici : conflit entre arrêt anticipé et
                // exclusion du dernier plateau) : ne jamais interrompre
                // tant que le plateau qui a déclenché l'arrêt anticipé est
                // encore le plateau courant --- sinon il devient
                // structurellement "le dernier" et se fait exclure par la
                // règle anti-troncature, au profit de plateaux transitoires
                // parasites bien plus étroits. On continue donc jusqu'à
                // observer au moins une transition de K après le
                // déclenchement --- borné naturellement par `beta_max`
                // (boucle englobante), aucun risque de boucle infinie.
                if !plateaus.is_empty() {
                    let current_width = (beta / current_plateau_start).ln();
                    let best_previous_width = plateaus.iter().map(|p| p.log_width()).fold(0.0, f64::max);
                    if !early_stop_triggered && current_width > early_stop_ratio.ln() && current_width > 3.0 * best_previous_width.max(1.0) {
                        early_stop_triggered = true;
                        plateau_k_at_trigger = current_plateau_k;
                    }
                }
                if early_stop_triggered && current_plateau_k != plateau_k_at_trigger {
                    break;
                }
            }
            plateaus.push(Plateau {
                k: current_plateau_k,
                beta_start: current_plateau_start,
                beta_end: beta,
                centers: last_stable_centers.clone(),
            });

            if std::env::var("POWKM_DEBUG_PLATEAUS").is_ok() {
                for p in &plateaus {
                    eprintln!("PLATEAU: k={} beta=[{:.5},{:.5}] log_width={:.4}", p.k, p.beta_start, p.beta_end, p.log_width());
                }
            }
            let candidates: Vec<&Plateau> = if plateaus.len() >= 3 {
                plateaus[1..plateaus.len() - 1].iter().collect()
            } else {
                plateaus.iter().collect()
            };
            let best_plateau = candidates
                .iter()
                .max_by(|a, b| a.log_width().partial_cmp(&b.log_width()).unwrap())
                .expect("au moins un plateau doit exister");

            let final_centers = &best_plateau.centers;
            let final_k = best_plateau.k;
            assert_eq!(final_k, final_centers.len(), "incohérence interne plateau/centres — ne devrait jamais arriver");
            let labels: Vec<i32> = points
                .iter()
                .map(|x| {
                    final_centers
                        .iter()
                        .enumerate()
                        .map(|(k, c)| (k, euclidean(x, c)))
                        .fold((0usize, f64::INFINITY), |acc, item| if item.1 < acc.1 { item } else { acc })
                        .0 as i32
                })
                .collect();

            (labels, final_k)
        })
    }
}

fn normalize(v: &mut [f64]) {
    let n: f64 = v.iter().map(|x| x * x).sum::<f64>().sqrt();
    if n > 1e-15 {
        for x in v.iter_mut() {
            *x /= n;
        }
    }
}

pub(crate) fn merge_close_centers(centers: Vec<Vec<f64>>, tol: f64) -> Vec<Vec<f64>> {
    let mut merged: Vec<Vec<f64>> = Vec::new();
    for c in centers {
        if !merged.iter().any(|m| euclidean(m, &c) < tol) {
            merged.push(c);
        }
    }
    merged
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_core::Dataset;
    use cluster_data::make_blobs;
    use cluster_metrics::adjusted_rand_index;
    use rand_distr::{Distribution, Normal};

    #[test]
    fn mp_significance_floor_matches_hand_computed_toy_case() {
        let cov = vec![vec![2.0, 0.0, 0.0], vec![0.0, 2.0, 0.0], vec![0.0, 0.0, 2.0]];
        let floor = mp_significance_floor(&cov, 3.0);
        assert!((floor - 8.0).abs() < 1e-10, "attendu 8.0, obtenu {floor}");
    }

    #[test]
    fn mp_significance_floor_tracks_pure_noise_in_both_regimes() {
        let mut rng = ChaCha8Rng::seed_from_u64(123);
        let normal = Normal::new(0.0, 1.0).unwrap();
        let n_trials = 300;

        let mut check_regime = |d: usize, m: usize, label: &str| {
            let mut lambda_max_sum = 0.0;
            for _ in 0..n_trials {
                let points: Vec<Vec<f64>> = (0..m).map(|_| (0..d).map(|_| normal.sample(&mut rng)).collect()).collect();
                let mean: Vec<f64> = (0..d).map(|j| points.iter().map(|p| p[j]).sum::<f64>() / m as f64).collect();
                let mut cov = vec![vec![0.0; d]; d];
                for p in &points {
                    for a in 0..d {
                        for b in 0..d {
                            cov[a][b] += (p[a] - mean[a]) * (p[b] - mean[b]) / m as f64;
                        }
                    }
                }
                let (eigenvalues, _) = crate::linalg::jacobi_eigen(&cov, 100, 1e-12);
                lambda_max_sum += eigenvalues[eigenvalues.len() - 1];
            }
            let observed_mean_lambda_max = lambda_max_sum / n_trials as f64;
            let c = d as f64 / m as f64;
            let predicted = (1.0 + c.sqrt()).powi(2);
            println!("[{label}] d={d} m={m}: λ_max moyen observé={observed_mean_lambda_max:.3}  λ₊ prédit={predicted:.3}");
            (observed_mean_lambda_max, predicted)
        };

        let (obs_under, pred_under) = check_regime(20, 15, "sous-échantillonné");
        assert!(
            obs_under > 1.5,
            "en régime sous-échantillonné, λ_max doit être nettement gonflé par le pur bruit (observé={obs_under:.3}), sinon le mécanisme d'emballement K n'a pas cette cause"
        );
        assert!(
            (obs_under - pred_under).abs() / pred_under < 0.35,
            "λ₊ prédit={pred_under:.3} doit être dans le bon ordre de grandeur de l'observé={obs_under:.3} (asymptotique, pas exact — tolérance 35%)"
        );

        let (obs_over, pred_over) = check_regime(4, 300, "bien échantillonné");
        assert!(
            obs_over < 1.5,
            "en régime bien échantillonné, λ_max ne doit PAS être gonflé (observé={obs_over:.3}) — sinon le seuil gênerait aussi les jeux à faible dimension bien peuplés"
        );
        assert!((obs_over - pred_over).abs() / pred_over < 0.35, "λ₊ prédit={pred_over:.3} vs observé={obs_over:.3}");
    }

    #[test]
    fn mp_significance_floor_would_incorrectly_gate_the_tiny_hand_verified_case() {
        let cov = vec![vec![5.0]];
        let floor = mp_significance_floor(&cov, 4.0);
        assert!(floor > 5.0, "à n=4,d=1, le bord MP ({floor:.3}) dépasse la vraie variance (5.0) — hors du régime asymptotique valide, gate à ne pas activer ici");
    }

    #[test]
    fn rose_bifurcation_point_duplicated_pair_hand_verified() {
        let points = vec![vec![-3.0], vec![-1.0], vec![1.0], vec![3.0]];
        let duplicated = vec![vec![0.0], vec![0.0]];

        let (lambda_stable, _) = smallest_eigenvalue(&points, &duplicated, 0.1, 1e-4, 300, 300, 1e-11, 0);
        assert!(lambda_stable > -1e-6, "à β=0.1 (< β_c=0.2), le mode de séparation devrait être stable (>=0): λ={lambda_stable}");

        let (lambda_unstable, _) = smallest_eigenvalue(&points, &duplicated, 0.4, 1e-4, 300, 300, 1e-11, 0);
        assert!(lambda_unstable < -1e-6, "à β=0.4 (> β_c=0.2), le mode de séparation devrait être instable (<0): λ={lambda_unstable}");
    }

    #[test]
    fn rose_bifurcation_crossing_is_near_predicted_beta_c() {
        let points = vec![vec![-3.0], vec![-1.0], vec![1.0], vec![3.0]];
        let duplicated = vec![vec![0.0], vec![0.0]];
        let beta_c = 0.2;

        let (just_below, _) = smallest_eigenvalue(&points, &duplicated, beta_c * 0.9, 1e-4, 300, 300, 1e-11, 0);
        let (just_above, _) = smallest_eigenvalue(&points, &duplicated, beta_c * 1.1, 1e-4, 300, 300, 1e-11, 0);
        assert!(just_below > 0.0, "juste sous β_c=0.2: λ={just_below} devrait être > 0");
        assert!(just_above < 0.0, "juste au-dessus de β_c=0.2: λ={just_above} devrait être < 0");

        assert!((just_below - 0.05).abs() < 1e-3, "λ prédit=0.05, obtenu={just_below}");
        let (near_crossing, _) = smallest_eigenvalue(&points, &duplicated, 0.22, 1e-4, 300, 300, 1e-11, 0);
        assert!((near_crossing - (-0.05)).abs() < 1e-3, "λ prédit=-0.05, obtenu={near_crossing}");
    }

    #[test]
    fn generalized_beta_c_matches_hand_verified_k1() {
        let points = vec![vec![-3.0], vec![-1.0], vec![1.0], vec![3.0]];
        let centers = vec![vec![0.0]];

        let (beta_c, lambda_max, _v, w_k_star) = predicted_beta_c(&points, &centers, 0.1, 0);
        assert!((lambda_max - 5.0).abs() < 1e-8, "λ_max attendu=5.0, obtenu={lambda_max}");
        assert!((beta_c - 0.2).abs() < 1e-8, "β_c attendu=0.2, obtenu={beta_c}");
        assert!((w_k_star - 1.0).abs() < 1e-8, "w_k* attendu=1.0 (un seul cluster), obtenu={w_k_star}");

        for beta in [0.1, 0.18, 0.2, 0.22, 0.4] {
            let analytic = predicted_second_derivative(&points, &centers, beta, 0);
            let expected = 1.0 - 5.0 * beta;
            assert!((analytic - expected).abs() < 1e-8, "β={beta}: analytique={analytic}, attendu={expected}");
        }
    }

    #[test]
    fn generalized_beta_c_matches_finite_difference_coupled_k2() {
        let points: Vec<Vec<f64>> = vec![-9.0, -7.0, -5.0, -3.0, 5.7, 5.9, 6.1, 6.3].into_iter().map(|x| vec![x]).collect();
        let init_centers = vec![vec![-6.0], vec![6.0]];

        for k_idx in [0usize, 1usize] {
            for &beta in &[0.02, 0.05, 0.1, 0.15, 0.2, 0.3] {
                let (centers, _w) = em_converge(&points, init_centers.clone(), beta, 300, 300, 1e-11);
                let (_beta_c, lambda_max, v, _w_k_star) = predicted_beta_c(&points, &centers, beta, k_idx);
                let analytic = predicted_second_derivative(&points, &centers, beta, k_idx);
                let fd = finite_diff_second_derivative(&points, &centers, beta, k_idx, &v, 1e-3);
                assert!(
                    (analytic - fd).abs() < 5e-4,
                    "k*={k_idx} β={beta}: analytique={analytic:.6}, différence-finie={fd:.6}, λ_max={lambda_max:.4}"
                );
            }
        }
    }

    #[test]
    fn distortion_is_nonincreasing_along_annealing_trajectory() {
        let data = make_blobs(150, 3, 0.6, 7);
        let mut centers = data.points[0..3].to_vec();
        let mut beta = 0.001;
        let mut prev_d = f64::INFINITY;
        let mut n_checked = 0;

        while beta < 20.0 {
            let (converged, _w) = em_converge(&data.points, centers.clone(), beta, 200, 200, 1e-9);
            centers = converged;
            let d = distortion(&data.points, &centers, beta);
            assert!(d <= prev_d + 1e-9, "violation de monotonie à β={beta}: D={d} > D_précédent={prev_d}");
            prev_d = d;
            n_checked += 1;
            beta *= 1.08;
        }
        assert!(n_checked > 50, "trajectoire trop courte pour être un test significatif: {n_checked} points");
    }

    #[test]
    fn free_energy_and_gradient_are_consistent_via_finite_difference() {
        let points = vec![vec![0.0, 0.0], vec![1.0, 0.5], vec![-0.5, 1.0], vec![2.0, -1.0]];
        let centers = vec![vec![0.3, 0.2], vec![1.0, -0.3]];
        let beta = 0.8;
        let h = 1e-5;

        let (_, w) = inner_fixed_point(&points, &centers, beta, 200, 1e-12);
        let grad = gradient_wrt_centers(&points, &centers, beta, 200, 1e-12);

        for kk in 0..2 {
            for d in 0..2 {
                let mut c_plus = centers.clone();
                c_plus[kk][d] += h;
                let (_, w_plus) = inner_fixed_point(&points, &c_plus, beta, 200, 1e-12);
                let f_plus = free_energy(&points, &c_plus, &w_plus, beta);

                let mut c_minus = centers.clone();
                c_minus[kk][d] -= h;
                let (_, w_minus) = inner_fixed_point(&points, &c_minus, beta, 200, 1e-12);
                let f_minus = free_energy(&points, &c_minus, &w_minus, beta);

                let numeric = (f_plus - f_minus) / (2.0 * h);
                assert!(
                    (numeric - grad[kk][d]).abs() < 1e-4,
                    "centre {kk} dim {d}: gradient analytique={}, numérique={numeric}",
                    grad[kk][d]
                );
            }
        }
        let _ = w;
    }

    #[test]
    fn em_converges_to_global_mean_at_low_beta() {
        let data = make_blobs(100, 3, 0.5, 42);
        let global_mean: Vec<f64> = (0..2).map(|d| data.points.iter().map(|p| p[d]).sum::<f64>() / data.points.len() as f64).collect();

        let init = vec![vec![5.0, 5.0], vec![-5.0, -5.0], vec![5.0, -5.0]];
        let (converged, _w) = em_converge(&data.points, init, 0.001, 200, 100, 1e-9);

        for c in &converged {
            assert!(euclidean(c, &global_mean) < 0.5, "centre {c:?} devrait être proche de la moyenne globale {global_mean:?}");
        }
    }

    #[test]
    fn deterministic_across_runs() {
        let data = make_blobs(60, 2, 0.5, 5);
        let mut p1 = PoWKM::new(7);
        let mut p2 = PoWKM::new(7);
        p1.beta_max = 5.0;
        p2.beta_max = 5.0;
        assert_eq!(p1.fit(&data).labels, p2.fit(&data).labels);
    }

    #[test]
    fn discovers_plausible_number_of_clusters_on_blobs() {
        let data = make_blobs(150, 3, 0.6, 42);
        let mut model = PoWKM::new(7);
        model.beta_max = 8.0;
        let result = model.fit(&data);
        assert!(result.n_clusters >= 2 && result.n_clusters <= 6, "n_clusters={}", result.n_clusters);
        assert_eq!(result.labels.len(), data.n_samples());
    }

    #[test]
    fn min_samples_per_dim_caps_k_hard() {
        let mut rng = ChaCha8Rng::seed_from_u64(11);
        let normal = rand_distr::Normal::new(0.0, 1.0).unwrap();
        let points: Vec<Vec<f64>> = (0..150).map(|_| (0..10).map(|_| Distribution::sample(&normal, &mut rng)).collect()).collect();
        let data = Dataset::new(points, None, "bruit isotrope d=10 (test plafond n/d)");

        let mut model = PoWKM::new(3);
        model.beta_max = 50.0;
        model.min_samples_per_dim = 5.0;
        let result = model.fit(&data);
        assert!(result.n_clusters <= 3, "plafond n/d violé : K={} devrait être ≤ 150/(5*10)=3", result.n_clusters);
    }

    #[test]
    fn free_energy_is_finite_and_decreases_with_more_clusters_at_fixed_beta() {
        let data = make_blobs(80, 2, 0.5, 3);
        let beta = 2.0;
        let (c1, w1) = em_converge(&data.points, vec![data.points[0].clone()], beta, 200, 100, 1e-9);
        let f1 = free_energy(&data.points, &c1, &w1, beta);
        let init2 = vec![data.points[0].clone(), data.points[40].clone()];
        let (c2, w2) = em_converge(&data.points, init2, beta, 200, 100, 1e-9);
        let f2 = free_energy(&data.points, &c2, &w2, beta);
        assert!(f1.is_finite() && f2.is_finite());
        assert!(f2 <= f1 + 1e-6, "plus de centres ne devrait jamais augmenter l'énergie libre: f1={f1}, f2={f2}");
    }

    #[test]
    fn selected_plateau_is_locally_stable() {
        let data = make_blobs(150, 3, 0.6, 42);
        let mut model = PoWKM::new(7);
        let result = model.fit(&data);

        let mut centers = vec![vec![0.0; data.points[0].len()]; result.n_clusters];
        let mut counts = vec![0usize; result.n_clusters];
        for (p, &l) in data.points.iter().zip(result.labels.iter()) {
            let l = l as usize;
            counts[l] += 1;
            for (d, &v) in p.iter().enumerate() {
                centers[l][d] += v;
            }
        }
        for (c, &cnt) in centers.iter_mut().zip(counts.iter()) {
            if cnt > 0 {
                for v in c.iter_mut() {
                    *v /= cnt as f64;
                }
            }
        }

        let lambda = local_stability(&data.points, &centers, 1.0, 7);
        assert!(lambda > -0.5, "le plateau retenu devrait être proche de la stabilité locale: λ={lambda}");
    }

    fn make_blobs_at_separation(n_per_cluster: usize, k: usize, std: f64, separation_in_stds: f64, seed: u64) -> Dataset {
        use std::f64::consts::PI;

        let mut rng = ChaCha8Rng::seed_from_u64(seed);
        let chord_target = separation_in_stds * std;
        let radius = chord_target / (2.0 * (PI / k as f64).sin());
        let centers: Vec<(f64, f64)> = (0..k)
            .map(|i| {
                let theta = 2.0 * PI * i as f64 / k as f64;
                (radius * theta.cos(), radius * theta.sin())
            })
            .collect();
        let normal = Normal::new(0.0, std).unwrap();
        let mut points = Vec::new();
        let mut labels = Vec::new();
        for (ci, &(cx, cy)) in centers.iter().enumerate() {
            for _ in 0..n_per_cluster {
                points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
                labels.push(ci as i32);
            }
        }
        Dataset::new(points, Some(labels), format!("sep{separation_in_stds}"))
    }

    #[test]
    fn initial_plateau_does_not_win_by_artifact_of_beta_min() {
        let data = make_blobs_at_separation(60, 3, 1.0, 6.0, 42);
        let mut model = PoWKM::new(7);
        let result = model.fit(&data);
        assert!(result.n_clusters > 1, "K=1 ne devrait pas gagner par artefact de beta_min: K trouvé={}", result.n_clusters);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.5, "ARI trop bas, la scission a dû mal se passer: ARI={ari}");
    }

    #[test]
    fn final_plateau_does_not_win_by_artifact_of_beta_max() {
        let data = make_blobs_at_separation(60, 3, 1.0, 4.0, 42);
        let mut model = PoWKM::new(7);
        let result = model.fit(&data);
        assert_eq!(result.n_clusters, 3, "devrait retrouver K=3, pas un plateau dégénéré aux extrémités: K trouvé={}", result.n_clusters);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.7, "ARI trop bas: ARI={ari}");
    }

    #[test]
    fn plateau_centers_always_match_plateau_k() {
        for seed in [1u64, 2, 3] {
            let data = make_blobs(90, 3, 0.9, seed);
            let mut model = PoWKM::new(seed);
            let result = model.fit(&data);
            let n_distinct = result.labels.iter().collect::<std::collections::HashSet<_>>().len();
            assert_eq!(
                n_distinct, result.n_clusters,
                "seed={seed}: n_clusters annoncé={} mais {n_distinct} labels distincts trouvés",
                result.n_clusters
            );
        }
    }

    #[test]
    #[should_panic(expected = "au moins 2 points")]
    fn panics_on_too_few_points() {
        let data = Dataset::new(vec![vec![0.0]], None, "toy");
        let mut model = PoWKM::new(0);
        model.fit(&data);
    }
}
