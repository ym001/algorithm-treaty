//! Transport optimal entropique (Sinkhorn, 1967 ; Cuturi, 2013), résolu en
//! domaine logarithmique pour la stabilité numérique.
//!
//! Problème résolu : `min_π ⟨π,C⟩ + ε·Σ π_ij(log π_ij - 1)` sous contrainte
//! que `π` ait pour marges `a` (source) et `b` (cible). Solution de la
//! forme `π*_ij = exp((f_i+g_j-C_ij)/ε)`, potentiels duaux `(f,g)`
//! obtenus par point fixe (itération de Sinkhorn), ici en log-domaine :
//!
//! ```text
//! f_i = ε·log(a_i) - ε·logsumexp_j((g_j - C_ij)/ε)
//! g_j = ε·log(b_j) - ε·logsumexp_i((f_i - C_ij)/ε)
//! ```
//!
//! C'est la brique de base (Phase 4) réutilisée par `powkm` (Phase 5) pour
//! le calcul des responsabilités souples.

#![allow(clippy::needless_range_loop)]

/// `logsumexp` stabilisé (soustraction du maximum), pour éviter les
/// dépassements de capacité numérique dans les exponentielles.
pub fn logsumexp(values: &[f64]) -> f64 {
    let max = values.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    if !max.is_finite() {
        return max; // tout est -infini (ou vide) : logsumexp = -infini
    }
    let sum: f64 = values.iter().map(|&v| (v - max).exp()).sum();
    max + sum.ln()
}

/// Résultat d'un appel à `sinkhorn` : potentiels duaux et plan de transport.
#[derive(Debug, Clone)]
pub struct SinkhornResult {
    pub f: Vec<f64>,
    pub g: Vec<f64>,
    pub plan: Vec<Vec<f64>>,
}

/// Résout le problème de transport optimal entropique entre les poids
/// source `a` (taille n) et cible `b` (taille m), pour une matrice de coût
/// `cost` (n×m) et une régularisation `epsilon` (= 1/β).
///
/// # Panics
/// Si `a` ou `b` ne somment pas approximativement à 1, ou si `epsilon <= 0`.
pub fn sinkhorn(cost: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, max_iter: usize, tol: f64) -> SinkhornResult {
    assert!(epsilon > 0.0, "epsilon doit être > 0");
    let n = a.len();
    let m = b.len();
    assert_eq!(cost.len(), n, "cost doit avoir n lignes");
    assert!(cost.iter().all(|row| row.len() == m), "cost doit avoir m colonnes");
    debug_assert!((a.iter().sum::<f64>() - 1.0).abs() < 1e-6, "a doit sommer à 1");
    debug_assert!((b.iter().sum::<f64>() - 1.0).abs() < 1e-6, "b doit sommer à 1");

    let mut f = vec![0.0; n];
    let mut g = vec![0.0; m];

    for _ in 0..max_iter.max(1) {
        let f_old = f.clone();

        for i in 0..n {
            let terms: Vec<f64> = (0..m).map(|j| (g[j] - cost[i][j]) / epsilon).collect();
            f[i] = epsilon * a[i].ln() - epsilon * logsumexp(&terms);
        }
        for j in 0..m {
            let terms: Vec<f64> = (0..n).map(|i| (f[i] - cost[i][j]) / epsilon).collect();
            g[j] = epsilon * b[j].ln() - epsilon * logsumexp(&terms);
        }

        let shift: f64 = f.iter().zip(f_old.iter()).map(|(x, y)| (x - y).abs()).sum();
        if shift < tol {
            break;
        }
    }

    let mut plan = vec![vec![0.0; m]; n];
    for i in 0..n {
        for j in 0..m {
            plan[i][j] = ((f[i] + g[j] - cost[i][j]) / epsilon).exp();
        }
    }
    SinkhornResult { f, g, plan }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn logsumexp_hand_computed() {
        // logsumexp([0,0]) = log(2) (deux termes égaux à exp(0)=1)
        let v = logsumexp(&[0.0, 0.0]);
        assert!((v - 2.0_f64.ln()).abs() < 1e-12, "v={v}");
    }

    #[test]
    fn marginals_are_satisfied() {
        // Propriété fondamentale d'un plan de transport valide : ses
        // marges doivent correspondre EXACTEMENT (à tolérance numérique
        // près) à a et b, quelle que soit la structure du coût.
        let cost = vec![vec![0.0, 1.0, 2.0], vec![1.0, 0.0, 1.0], vec![2.0, 1.0, 0.0]];
        let a = vec![0.2, 0.5, 0.3];
        let b = vec![0.3, 0.3, 0.4];
        let result = sinkhorn(&cost, &a, &b, 0.5, 1000, 1e-12);

        for i in 0..3 {
            let row_sum: f64 = result.plan[i].iter().sum();
            assert!((row_sum - a[i]).abs() < 1e-6, "ligne {i}: somme={row_sum}, attendu={}", a[i]);
        }
        for j in 0..3 {
            let col_sum: f64 = result.plan.iter().map(|row| row[j]).sum();
            assert!((col_sum - b[j]).abs() < 1e-6, "colonne {j}: somme={col_sum}, attendu={}", b[j]);
        }
    }

    #[test]
    fn large_epsilon_converges_to_independent_coupling() {
        // Quand epsilon -> infini, la régularisation entropique domine
        // totalement le coût : le plan optimal tend vers le couplage
        // indépendant a⊗b, indépendamment du coût.
        let cost = vec![vec![0.0, 10.0], vec![10.0, 0.0]];
        let a = vec![0.5, 0.5];
        let b = vec![0.5, 0.5];
        let result = sinkhorn(&cost, &a, &b, 1000.0, 2000, 1e-14);
        for i in 0..2 {
            for j in 0..2 {
                let expected = a[i] * b[j];
                assert!((result.plan[i][j] - expected).abs() < 5e-3, "plan[{i}][{j}]={}, attendu~{expected}", result.plan[i][j]);
            }
        }
    }

    #[test]
    fn small_epsilon_concentrates_on_optimal_matching() {
        // Quand epsilon -> 0, le plan entropique converge vers le plan de
        // transport optimal non régularisé. Ici, le coût favorise
        // clairement l'appariement diagonal (0 vs 10) : le plan doit se
        // concentrer sur la diagonale.
        let cost = vec![vec![0.0, 10.0], vec![10.0, 0.0]];
        let a = vec![0.5, 0.5];
        let b = vec![0.5, 0.5];
        let result = sinkhorn(&cost, &a, &b, 0.05, 5000, 1e-14);
        assert!(result.plan[0][0] > 0.49, "plan[0][0]={}", result.plan[0][0]);
        assert!(result.plan[1][1] > 0.49, "plan[1][1]={}", result.plan[1][1]);
        assert!(result.plan[0][1] < 0.01, "plan[0][1]={}", result.plan[0][1]);
        assert!(result.plan[1][0] < 0.01, "plan[1][0]={}", result.plan[1][0]);
    }

    #[test]
    fn deterministic_across_runs() {
        let cost = vec![vec![0.0, 1.0], vec![1.0, 0.0]];
        let a = vec![0.5, 0.5];
        let b = vec![0.5, 0.5];
        let r1 = sinkhorn(&cost, &a, &b, 0.5, 500, 1e-10);
        let r2 = sinkhorn(&cost, &a, &b, 0.5, 500, 1e-10);
        assert_eq!(r1.plan, r2.plan);
    }
}
