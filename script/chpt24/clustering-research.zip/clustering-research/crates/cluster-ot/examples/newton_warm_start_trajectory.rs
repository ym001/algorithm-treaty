//! Démonstration réaliste du bénéfice de warm-start : simule une
//! trajectoire de centroïdes qui se déplacent progressivement (comme dans
//! la boucle externe d'un algorithme de type PoWKM), et compare le nombre
//! d'itérations de Newton nécessaires en repartant à froid vs. en
//! réchauffant depuis la solution de l'étape précédente.
//!
//! Jeu synthétique à chevauchement modéré et contrôlé (pas des blobs
//! triviaux à séparation large, où l'affectation dure ne bouge jamais et
//! le gradient est nul dès le départ) : 3 groupes à distance 2.5σ, assez
//! proches pour qu'un déplacement de centre change réellement
//! l'affectation souple d'un pas à l'autre.

use cluster_ot::newton_semidiscrete_ot;
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use rand_distr::Normal;

fn cost_matrix(points: &[Vec<f64>], centers: &[Vec<f64>]) -> Vec<Vec<f64>> {
    points
        .iter()
        .map(|p| {
            centers
                .iter()
                .map(|c| 0.5 * p.iter().zip(c.iter()).map(|(a, b)| (a - b).powi(2)).sum::<f64>())
                .collect()
        })
        .collect()
}

fn main() {
    let mut gen_rng = ChaCha8Rng::seed_from_u64(1);
    let normal = Normal::new(0.0, 1.0).unwrap();
    let true_centers = [[0.0, 0.0], [2.5, 0.0], [1.25, 2.165]]; // triangle équilatéral, côté 2.5σ
    let mut points = Vec::new();
    for c in &true_centers {
        for _ in 0..50 {
            points.push(vec![c[0] + normal.sample(&mut gen_rng), c[1] + normal.sample(&mut gen_rng)]);
        }
    }

    let n = points.len();
    let k = 3;
    let a = vec![1.0 / n as f64; n];
    let b = vec![1.0 / k as f64; k];
    let epsilon = 1.0; // comparable à l'échelle des coûts (σ=1, coûts ~O(1))

    let n_steps = 8;
    let mut rng = ChaCha8Rng::seed_from_u64(0);
    let mut current_centers: Vec<Vec<f64>> = true_centers.iter().map(|c| vec![c[0], c[1]]).collect();
    let mut g_prev: Option<Vec<f64>> = None;
    let mut total_cold_iters = 0usize;
    let mut total_warm_iters = 0usize;

    println!("{:<6} {:>18} {:>18}", "étape", "itérations (froid)", "itérations (chaud)");
    for step in 0..=n_steps {
        for center in current_centers.iter_mut() {
            for d in center.iter_mut() {
                *d += 0.5 * (rng.gen::<f64>() - 0.5);
            }
        }
        let cost = cost_matrix(&points, &current_centers);

        let cold = newton_semidiscrete_ot(&cost, &a, &b, epsilon, vec![0.0; k], 200, 1e-10);
        let warm_init = g_prev.clone().unwrap_or_else(|| vec![0.0; k]);
        let warm = newton_semidiscrete_ot(&cost, &a, &b, epsilon, warm_init, 200, 1e-10);

        println!("{:<6} {:>18} {:>18}", step, cold.iterations, warm.iterations);
        total_cold_iters += cold.iterations;
        total_warm_iters += warm.iterations;
        g_prev = Some(warm.g);
    }

    println!("\nTotal itérations (froid à chaque étape) : {total_cold_iters}");
    println!("Total itérations (réchauffé d'une étape à l'autre) : {total_warm_iters}");
    println!(
        "Réduction : {:.1}%",
        100.0 * (1.0 - total_warm_iters as f64 / total_cold_iters.max(1) as f64)
    );
}
