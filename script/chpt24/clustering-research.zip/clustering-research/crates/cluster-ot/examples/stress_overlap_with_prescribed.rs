//! Extension de `stress_overlap.rs` (protocole strictement identique,
//! même générateur dupliqué à l'identique) : ajoute PoWKM-prescribed au
//! comparatif, pour vérifier s'il maintient l'avantage déjà prouvé de
//! PoWKM (libre) dans le régime où l'annealing entropique a un avantage
//! structurel légitime — chevauchement croissant entre populations à peu
//! près gaussiennes (pas le régime de `real_world_finance_defense.rs`,
//! où DBSCAN/OPTICS gagnent grâce à une structure de densité que les
//! méthodes à centroïdes, PoWKM inclus, ne capturent pas).
//!
//! `cargo run --release --example stress_overlap_with_prescribed -p cluster-ot`

use cluster_algos::{Dbscan, Hdbscan, MeanShift, Optics};
use cluster_core::{euclidean, ClusteringAlgorithm, Dataset};
use cluster_metrics::{adjusted_rand_index, normalized_mutual_info};
use cluster_ot::{PoWKMPrescribed, PoWKM};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use rand_distr::Normal;
use std::f64::consts::PI;

/// Dupliqué à l'identique depuis `stress_overlap.rs` — même protocole,
/// pas une variante.
fn make_blobs_at_separation(n_per_cluster: usize, k: usize, std: f64, separation_in_stds: f64, seed: u64) -> Dataset {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let chord_target = separation_in_stds * std;
    let radius = chord_target / (2.0 * (PI / k as f64).sin());
    let centers: Vec<(f64, f64)> = (0..k)
        .map(|i| {
            let theta = 2.0 * PI * i as f64 / k as f64;
            (radius * theta.cos(), radius * theta.sin())
        })
        .collect();
    let normal = Normal::new(0.0, std).unwrap();
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for (ci, &(cx, cy)) in centers.iter().enumerate() {
        for _ in 0..n_per_cluster {
            points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
            labels.push(ci as i32);
        }
    }
    Dataset::new(points, Some(labels), format!("sep{separation_in_stds}"))
}

fn kth_nn_distances(points: &[Vec<f64>], k: usize) -> Vec<f64> {
    points
        .iter()
        .map(|p| {
            let mut d: Vec<f64> = points.iter().filter(|q| !std::ptr::eq(*q, p)).map(|q| euclidean(p, q)).collect();
            d.sort_by(|a, b| a.partial_cmp(b).unwrap());
            d[(k - 1).min(d.len() - 1)]
        })
        .collect()
}

fn median(mut v: Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = v.len();
    if n % 2 == 0 {
        0.5 * (v[n / 2 - 1] + v[n / 2])
    } else {
        v[n / 2]
    }
}

fn suggest_eps(points: &[Vec<f64>], min_samples: usize) -> f64 {
    median(kth_nn_distances(points, min_samples))
}

fn suggest_bandwidth(points: &[Vec<f64>], quantile: f64) -> f64 {
    let n = points.len();
    let k = ((quantile * n as f64).ceil() as usize).max(1);
    median(kth_nn_distances(points, k))
}

fn main() {
    let separations = [6.0, 5.0, 4.0, 3.0, 2.5, 2.0];
    let k_true = 3;
    let n_per_cluster = 60;
    let std = 1.0;
    let seed = 42;
    let min_samples = 5;

    println!("{:<6} | {:>16} | {:>16} | {:>16} | {:>16} | {:>16} | {:>16}", "sep(σ)", "DBSCAN", "HDBSCAN", "OPTICS", "Mean-Shift", "PoWKM (libre)", "PoWKM-prescribed");

    for &sep in &separations {
        let data = make_blobs_at_separation(n_per_cluster, k_true, std, sep, seed);
        let truth = data.labels_true.as_ref().unwrap();

        let eps = suggest_eps(&data.points, min_samples);
        let bandwidth = suggest_bandwidth(&data.points, 0.3).max(1e-3);

        let mut db = Dbscan::new(eps, min_samples);
        let r_db = db.fit(&data);
        let mut hdb = Hdbscan::new(min_samples, min_samples);
        let r_hdb = hdb.fit(&data);
        let mut optics = Optics::new(eps, min_samples, eps);
        let r_optics = optics.fit(&data);
        let mut ms = MeanShift::new(bandwidth);
        let r_ms = ms.fit(&data);
        let mut powkm = PoWKM::new(7);
        let r_powkm = powkm.fit(&data);
        let mut prescribed = PoWKMPrescribed::new(7);
        let r_prescribed = prescribed.fit(&data);

        let cell = |r: &cluster_core::ClusterResult| {
            let ari = adjusted_rand_index(truth, &r.labels);
            let nmi = normalized_mutual_info(truth, &r.labels);
            format!("K={:<3} ARI={ari:.2} NMI={nmi:.2}", r.n_clusters)
        };

        println!("{:<6} | {:>16} | {:>16} | {:>16} | {:>16} | {:>16} | {:>16}", sep, cell(&r_db), cell(&r_hdb), cell(&r_optics), cell(&r_ms), cell(&r_powkm), cell(&r_prescribed));
    }
    println!("\n(K vrai=3 partout ; hyperparamètres génériques, aucun accès aux labels ;");
    println!("protocole strictement identique à stress_overlap.rs, PoWKM-prescribed ajouté)");
}
