//! Étude approfondie de la découverte automatique de K, sur une plage de
//! complexité (K vrai = 2,3,4,6,8), avec 4 métriques :
//! - ARI, NMI (externes, nécessitent la vérité terrain)
//! - Silhouette, Davies-Bouldin (internes, calculées hors points de bruit)
//!
//! Même discipline méthodologique que la comparaison précédente : aucun
//! hyperparamètre n'est choisi en regardant les labels.

use cluster_algos::{Dbscan, Hdbscan, MeanShift, Optics};
use cluster_core::{euclidean, ClusteringAlgorithm};
use cluster_data::make_blobs;
use cluster_metrics::{adjusted_rand_index, davies_bouldin_index, normalized_mutual_info, silhouette_score};
use cluster_ot::PoWKM;
use std::collections::HashSet;

fn kth_nn_distances(points: &[Vec<f64>], k: usize) -> Vec<f64> {
    points
        .iter()
        .map(|p| {
            let mut d: Vec<f64> = points.iter().filter(|q| !std::ptr::eq(*q, p)).map(|q| euclidean(p, q)).collect();
            d.sort_by(|a, b| a.partial_cmp(b).unwrap());
            d[(k - 1).min(d.len() - 1)]
        })
        .collect()
}

fn median(mut v: Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = v.len();
    if n % 2 == 0 {
        0.5 * (v[n / 2 - 1] + v[n / 2])
    } else {
        v[n / 2]
    }
}

fn suggest_eps(points: &[Vec<f64>], min_samples: usize) -> f64 {
    median(kth_nn_distances(points, min_samples))
}

fn suggest_bandwidth(points: &[Vec<f64>], quantile: f64) -> f64 {
    let n = points.len();
    let k = ((quantile * n as f64).ceil() as usize).max(1);
    median(kth_nn_distances(points, k))
}

struct Metrics {
    k_found: usize,
    ari: f64,
    nmi: f64,
    silhouette: Option<f64>,
    davies_bouldin: Option<f64>,
    runtime: std::time::Duration,
}

fn compute_metrics(points: &[Vec<f64>], truth: &[i32], labels: &[i32], k_found: usize, runtime: std::time::Duration) -> Metrics {
    let ari = adjusted_rand_index(truth, labels);
    let nmi = normalized_mutual_info(truth, labels);

    let filtered_idx: Vec<usize> = (0..labels.len()).filter(|&i| labels[i] != -1).collect();
    let distinct: HashSet<i32> = filtered_idx.iter().map(|&i| labels[i]).collect();

    let (silhouette, davies_bouldin) = if distinct.len() >= 2 && filtered_idx.len() > distinct.len() {
        let sub_points: Vec<Vec<f64>> = filtered_idx.iter().map(|&i| points[i].clone()).collect();
        let sub_labels: Vec<i32> = filtered_idx.iter().map(|&i| labels[i]).collect();
        (Some(silhouette_score(&sub_points, &sub_labels)), Some(davies_bouldin_index(&sub_points, &sub_labels)))
    } else {
        (None, None)
    };

    Metrics { k_found, ari, nmi, silhouette, davies_bouldin, runtime }
}

fn fmt_opt(v: Option<f64>) -> String {
    match v {
        Some(x) => format!("{x:.3}"),
        None => "n/a".to_string(),
    }
}

fn print_table(name: &str, k_true_values: &[usize], rows: &[Metrics]) {
    println!("\n=== {name} ===");
    println!("{:<8} {:<8} {:>7} {:>7} {:>11} {:>15} {:>10}", "K_vrai", "K_trouvé", "ARI", "NMI", "Silhouette", "Davies-Bouldin", "temps");
    for (k_true, m) in k_true_values.iter().zip(rows.iter()) {
        println!(
            "{:<8} {:<8} {:>7.3} {:>7.3} {:>11} {:>15} {:>10?}",
            k_true,
            m.k_found,
            m.ari,
            m.nmi,
            fmt_opt(m.silhouette),
            fmt_opt(m.davies_bouldin),
            m.runtime
        );
    }
}

fn main() {
    let k_true_values = [2usize, 3, 4, 6, 8];
    let n_per_cluster = 50;
    let cluster_std = 0.8;
    let seed = 42;
    let min_samples = 5;

    let mut dbscan_rows = Vec::new();
    let mut hdbscan_rows = Vec::new();
    let mut optics_rows = Vec::new();
    let mut meanshift_rows = Vec::new();
    let mut powkm_rows = Vec::new();

    for &k_true in &k_true_values {
        let data = make_blobs(n_per_cluster * k_true, k_true, cluster_std, seed);
        let truth = data.labels_true.as_ref().unwrap();

        let eps = suggest_eps(&data.points, min_samples);
        let bandwidth = suggest_bandwidth(&data.points, 0.3).max(1e-3);

        let mut db = Dbscan::new(eps, min_samples);
        let r = db.fit(&data);
        dbscan_rows.push(compute_metrics(&data.points, truth, &r.labels, r.n_clusters, r.runtime));

        let mut hdb = Hdbscan::new(min_samples, min_samples);
        let r = hdb.fit(&data);
        hdbscan_rows.push(compute_metrics(&data.points, truth, &r.labels, r.n_clusters, r.runtime));

        let mut optics = Optics::new(eps, min_samples, eps);
        let r = optics.fit(&data);
        optics_rows.push(compute_metrics(&data.points, truth, &r.labels, r.n_clusters, r.runtime));

        let mut ms = MeanShift::new(bandwidth);
        let r = ms.fit(&data);
        meanshift_rows.push(compute_metrics(&data.points, truth, &r.labels, r.n_clusters, r.runtime));

        let mut powkm = PoWKM::new(7);
        let r = powkm.fit(&data);
        powkm_rows.push(compute_metrics(&data.points, truth, &r.labels, r.n_clusters, r.runtime));

        eprintln!("K_vrai={k_true} termine (n={})", n_per_cluster * k_true);
    }

    print_table("DBSCAN", &k_true_values, &dbscan_rows);
    print_table("HDBSCAN", &k_true_values, &hdbscan_rows);
    print_table("OPTICS", &k_true_values, &optics_rows);
    print_table("Mean-Shift", &k_true_values, &meanshift_rows);
    print_table("PoWKM", &k_true_values, &powkm_rows);

    println!("\n(hyperparametres generiques : min_samples=5, eps=mediane distance au 5e ppv,");
    println!(" bandwidth façon sklearn.estimate_bandwidth(quantile=0.3) -- aucun reglage par K, aucun acces aux labels)");
}
