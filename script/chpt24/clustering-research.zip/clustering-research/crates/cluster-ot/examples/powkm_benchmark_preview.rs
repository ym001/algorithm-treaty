use cluster_core::ClusteringAlgorithm;
use cluster_data::standard_benchmark_suite;
use cluster_metrics::adjusted_rand_index;
use cluster_ot::PoWKM;

fn main() {
    let n = 200; // plus petit que 300 pour un temps d'exécution raisonnable (recuit + tests de scission)
    let seed = 42;
    let suite = standard_benchmark_suite(n, seed);

    for dataset in &suite {
        if dataset.labels_true.is_none() {
            continue;
        }
        let true_k = dataset.labels_true.as_ref().unwrap().iter().collect::<std::collections::HashSet<_>>().len();
        let mut model = PoWKM::new(7);
        let result = model.fit(dataset);
        let ari = adjusted_rand_index(dataset.labels_true.as_ref().unwrap(), &result.labels);
        println!(
            "{:<20} K_vrai={true_k}  K_emergent={:<3} ARI={ari:.3}  temps={:?}",
            dataset.name, result.n_clusters, result.runtime
        );
    }
}
