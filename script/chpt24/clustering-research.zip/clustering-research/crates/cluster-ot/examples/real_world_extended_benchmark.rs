//! Comparaison de PoWKM (libre et prescrit) contre tous les algorithmes de
//! la littérature déjà implémentés dans ce workspace, **augmentés de deux
//! algorithmes récents (post-2020) de découverte automatique de K** ---
//! cf. section "Algorithmes récents" ci-dessous --- sur l'ensemble des
//! jeux de données **réels** disponibles dans
//! `/home/yves/Nextcloud/book/traité_d_algorithmique/article/data_cluster/`
//! (chemin en dur, cf. `main()`) ---
//! fusion de `real_world_finance_defense.rs` et `real_world_extended_benchmark.rs`
//! (8 jeux) avec **7 nouveaux jeux UCI** téléchargés pour étendre la
//! couverture expérimentale du papier (objectif JMLR : 20-30 jeux réels).
//!
//! ## Algorithmes récents (post-2020) de découverte automatique de K
//!
//! Choisis après recherche bibliographique (pas inventés, pas de détail
//! d'algorithme deviné) parmi les méthodes post-2020 les mieux établies :
//!
//! - **DynMSC** (Dynamic Medoid Silhouette Clustering ; Lenssen &
//!   Schubert, version étendue de *Clustering by Direct Optimization of
//!   the Medoid Silhouette*, SISAP 2022, LNCS 13590 ; arXiv:2309.03751,
//!   2023 --- Erich Schubert est également l'auteur de FastPAM et de
//!   "DBSCAN revisited, revisited", référence bien établie du domaine).
//!   Principe : optimise directement l'Average Medoid Silhouette (AMS,
//!   une variante médoïde de l'indice de silhouette classique, caractérisée
//!   axiomatiquement dans le papier comme mesure de qualité valide) pour
//!   chaque K candidat, retient le K qui maximise l'AMS obtenue.
//!   Approche entièrement **déterministe** (pas de rééchantillonnage
//!   Monte-Carlo), ce qui élimine par construction la classe de fragilité
//!   rencontrée avec CNAK (voir ci-dessous). Simplification assumée et
//!   documentée par rapport à l'algorithme complet du papier : nous
//!   utilisons une optimisation par médoïdes alternée (Maranzana 1963,
//!   citée dans le papier comme alternative légitime plus simple à PAM
//!   SWAP) plutôt que FasterMSC, la variante à recherche incrémentale par
//!   échange que proposent les auteurs --- les deux méthodes optimisent
//!   le **même objectif** (AMS), FasterMSC n'apportant qu'un gain de
//!   vitesse (jusqu'à O(k²) plus rapide dans leurs mesures), non critique
//!   pour nos tailles de jeux (n≤625). Par construction, l'AMS n'est pas
//!   définie pour K=1 (pas de "second plus proche médoïde"), donc K=1
//!   n'est jamais retourné --- cohérent avec la boucle `while k > 2` de
//!   l'algorithme 5 (DynMSC) du papier original, qui exclut K=1 pour la
//!   même raison structurelle, pas une limite que nous introduisons.
//!   **Remplace un essai initial avec CNAK** (Cluster Number Assisted
//!   K-means ; Saha & Mukherjee, *Pattern Recognition* 110:107625, 2021),
//!   abandonné après diagnostic honnête : une première implémentation
//!   trouvait systématiquement K=1 sur les 15 jeux réels, y compris Iris
//!   où le papier original rapporte explicitement trouver K=3
//!   correctement --- signal clair d'un défaut d'implémentation. Après
//!   comparaison avec `CNAK.py`, l'implémentation de référence des
//!   auteurs (github.com/Jayasree-Saha/CNAK, récupérée et lue en
//!   intégralité), un bug précis a été identifié et corrigé
//!   (`sklearn.cluster.KMeans(n_init=20)` dans la référence contre un
//!   seul essai K-means++ dans notre première version, biaisant
//!   systématiquement vers K=1) et validé sur données synthétiques (K=3
//!   exact au lieu de K=1 systématique). Malgré cette amélioration
//!   démontrée en synthétique, le problème persistait sur les 15 jeux
//!   réels après correctif (K=1 encore trouvé partout) --- plutôt que de
//!   continuer à corriger un algorithme dont l'implémentation restait
//!   fragile sur données réelles malgré un diagnostic sérieux, CNAK a été
//!   abandonné au profit de DynMSC.
//! - **DenMune** (Abbas, El-Zoghabi & Shoukry, *Pattern Recognition*
//!   109:107589, 2021). Principe : voisinage mutuel de taille K (un seul
//!   paramètre) ; les points dont le nombre de "votes" reçus (taille de
//!   la liste de référence) excède K sont des points forts (graines) qui
//!   forment le squelette des clusters par fusion des ensembles de plus
//!   proches voisins mutuels qui se recoupent (implémenté ici par
//!   union-find, équivalent aux Algorithmes 1-2 du papier, section 3) ;
//!   les points faibles restants sont assignés au cluster avec lequel ils
//!   partagent le plus de voisins mutuels, ou classés bruit s'ils n'en
//!   partagent aucun (Algorithme 3). Implémentation directement dans
//!   l'espace des variables standardisées d'origine plutôt qu'après
//!   réduction t-SNE en 2D : le papier utilise t-SNE comme choix
//!   d'expérimentation pour comparer équitablement plusieurs méthodes en
//!   2D (section 4.1), pas comme exigence mathématique de l'algorithme
//!   (Algorithmes 1-3, section 3, opèrent sur la matrice de distances
//!   quelle que soit la dimension) ; cette déviation assumée est
//!   cohérente avec le traitement du reste de ce fichier, où toutes les
//!   méthodes tournent sur les mêmes variables standardisées, sans
//!   réduction de dimension spécifique à une méthode.
//!
//! Les deux implémentations ont été vérifiées sur des jeux synthétiques
//! (mélanges gaussiens à 3 et 5 clusters bien séparés, structure à la
//! Iris avec chevauchement partiel) avant d'être exécutées sur les
//! données réelles : DynMSC retrouve K=3 et ARI=1.00 sur les blobs bien
//! séparés, et K=2 (ARI=0.568) sur la structure à chevauchement partiel
//! --- identique au résultat de Mean-Shift sur le vrai Iris ; DenMune
//! retrouve K exactement avec ARI≥0.92 sur les cas synthétiques séparés.
//!
//! ## Jeux de données (18 au total)
//!
//! **Déjà présents (8)** : Iris, Wine, Seeds, Breast Cancer, Sonar,
//! Wholesale, German Credit, Ionosphere --- cf. la documentation des
//! fichiers d'origine pour le détail de chacun.
//!
//! **Nouveaux (7)**, tous UCI, format vérifié à partir d'extraits fournis
//! par l'utilisateur (pas deviné) avant écriture des parseurs :
//!
//! - **Abalone** (Nash et al. 1994, UCI), ormeaux. `Sex` (M/F/I, 3
//!   modalités) sert de vérité terrain, par analogie avec le traitement de
//!   `Channel` pour Wholesale ; les 7 mesures physiques continues (Length,
//!   Diameter, Height, Whole/Shucked/Viscera/Shell weight) sont les
//!   variables de clustering. `Rings` (dernière colonne) est **exclu** ---
//!   c'est la cible de la tâche de régression d'origine (âge), pas une
//!   variable de clustering, même logique que l'exclusion de `Region` pour
//!   Wholesale.
//! - **Balance Scale** (Siegler 1976, UCI), 625 configurations d'une
//!   balance à 2 bras. Classe en 1ère colonne (L/B/R : bras gauche plus
//!   lourd / équilibré / bras droit plus lourd, 3 modalités), 4 variables
//!   entières (poids et distance de chaque côté).
//! - **Ecoli** (Nakai/Horton, UCI), localisation de protéines. 1ère colonne
//!   = nom de séquence (ignoré), 7 variables continues, dernière colonne =
//!   classe textuelle (site de localisation : `cp`, `im`, `pp`, etc.).
//! - **Glass Identification** (Evett & Spiegelman 1987, UCI). 1ère colonne
//!   = Id (ignoré), 9 variables continues (indice de réfraction +
//!   composition chimique), dernière colonne = type de verre (entier,
//!   6 classes présentes sur 7 possibles : la classe 4 est absente de ce
//!   jeu, phénomène documenté dans la littérature UCI, pas une erreur de
//!   chargement).
//! - **Heart Disease (Cleveland)** (Detrano et al. 1989, UCI). 13 variables
//!   cliniques, dernière colonne = `num` (sévérité, 0=absence à 4=sévère,
//!   utilisé tel quel comme vérité terrain multi-classe, cohérent avec le
//!   traitement des autres jeux du fichier). Quelques lignes contiennent
//!   des valeurs manquantes encodées `?` (colonnes `ca`/`thal`) --- ces
//!   lignes sont éliminées, pratique standard pour ce jeu.
//! - **Yeast** (Nakai/Horton, UCI), même famille qu'Ecoli. 1ère colonne =
//!   nom de séquence (ignoré), 8 variables continues, dernière colonne =
//!   classe textuelle (localisation subcellulaire, jusqu'à 10 modalités).
//! - **Zoo** (Forsyth 1990, UCI). 1ère colonne = nom d'animal (ignoré),
//!   variables intermédiaires (attributs binaires + nombre de pattes),
//!   **dernière** colonne = type d'animal (entier, 7 classes). Le nombre
//!   exact de colonnes intermédiaires n'est pas fixé en dur dans le
//!   parseur (seules la position `première`/`dernière` comptent), pour ne
//!   pas dépendre d'un comptage de colonnes qui pourrait varier selon la
//!   source de téléchargement.
//!
//! **3 nouveaux jeux médicaux**, choisis délibérément pour leur ratio
//! n/d faible --- le régime où le rétrécissement Ledoit-Wolf conditionnel
//! de `PoWKMPrescribed::use_shrinkage_split_test` a démontré un gain net
//! sur les 15 jeux précédents (Sonar, Zoo), permettant une comparaison
//! ciblée et honnête plutôt qu'une moyenne diluée sur des jeux où ce
//! mécanisme n'a structurellement aucune raison de jouer :
//!
//! - **SPECTF Heart** (Cios, Kurgan & Goodenday 2001, UCI). Imagerie
//!   cardiaque SPECT, 267 patients (fusion de `SPECTF.train`, 80 lignes,
//!   et `SPECTF.test`, 187 lignes), 44 variables continues entières
//!   [0,100], classe en 1ère colonne (0=normal, 1=anormal). n/d≈6.1,
//!   comparable à Zoo.
//! - **Arrhythmia** (Guvenir et al. 1998, UCI). ECG, 452 patients, 279
//!   variables (206 continues, le reste nominal), classe en dernière
//!   colonne (16 modalités : 1=normal, 2-15=types d'arythmie, 16=non
//!   classifiés ; plusieurs classes ne comptent que 2-3 patients). Valeurs
//!   manquantes `?` (colonnes clairsemées) --- lignes éliminées, comme
//!   pour Heart. n/d≈1.6, le ratio le plus extrême de tous les jeux de ce
//!   fichier --- un vrai test de stress plutôt qu'une victoire garantie.
//! - **Parkinsons** (Little et al. 2008, UCI). Mesures vocales, 195
//!   enregistrements (31 sujets, ~6 enregistrements chacun), 22 variables
//!   continues, classe (`status`, 0=sain/1=Parkinson) en position **18
//!   sur 23** --- ni première ni dernière, vérifié explicitement sur
//!   l'en-tête officiel UCI avant d'écrire le parseur plutôt que supposé
//!   par défaut comme les autres jeux de ce fichier. En-tête présent
//!   (`name,MDVP:Fo(Hz),...`), cas particulier géré par détection
//!   générique de ligne non numérique. n/d≈8.9.
//!
//! ## Méthodologie
//!
//! Identique aux fichiers d'origine : standardisation z-score, aucun
//! hyperparamètre choisi en regardant les labels pour les méthodes à
//! découverte de K, K vrai fourni aux méthodes qui l'exigent. PoWKM libre
//! reste désactivé par défaut sur tous les jeux (cf. justification dans
//! `real_world_finance_defense.rs` : le recuit complet sur β n'est pas
//! encore optimisé au-delà de n~300 en dimension modérée) ; seul PoWKM
//! prescrit (K vrai en entrée) est testé pour la comparaison ARI/NMI à K
//! fixé, comme dans les fichiers existants. Le blanchiment PCA a été
//! testé puis retiré : sur les 15 jeux, il aidait nettement sur 2
//! d'entre eux et nuisait sur 9 (souvent fortement, ex. Breast Cancer
//! −0.46 ARI) --- signal net et cohérent, pas la peine de l'encombrer le
//! pipeline pour un correctif qui ne généralise pas. Les jeux les plus
//! grands (Abalone n=4177, Yeast n=1484, German Credit n=1000) sont
//! sous-échantillonnés pour rester dans un temps d'exécution raisonnable
//! pour l'ensemble des 11 méthodes comparées --- limite honnête et
//! documentée, pas un artefact caché (même principe que le
//! sous-échantillonnage déjà appliqué à German Credit dans
//! `real_world_finance_defense.rs`).
//!
//! Les tailles (`expected_n`) indiquées dans les parseurs sont les tailles
//! canoniques UCI connues ; un écart n'entraîne qu'un **avertissement**
//! (pas un arrêt), pour ne pas bloquer l'exécution des autres jeux si un
//! fichier téléchargé diffère légèrement (ligne d'en-tête ajoutée, mirroir
//! différent, etc.) --- si un avertissement apparaît, vérifier le fichier
//! correspondant avant d'interpréter les résultats de ce jeu.
//!
//! Exécuter depuis la racine du dépôt :
//! ```text
//! cargo run --release --example real_world_full_benchmark -p cluster-ot
//! ```

use cluster_algos::{Birch, Dbscan, Hdbscan, HierarchicalClustering, KMeans, Linkage, MeanShift, Optics, SpectralClustering};
use cluster_core::{euclidean, ClusterResult, ClusteringAlgorithm, Dataset};
use cluster_metrics::{adjusted_rand_index, normalized_mutual_info};
use cluster_ot::{PoWKMPrescribed, PoWKM};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use std::collections::{HashMap, HashSet};
use std::fs;

// ============================================================================
// Utilitaires génériques de parsing
// ============================================================================

/// Découpe une ligne sur virgule OU espace(s) (un ou plusieurs), et retire
/// les guillemets éventuels --- gère indifféremment les variantes
/// "vrai CSV" et "colonnes alignées par espaces" sans avoir à deviner
/// laquelle a été téléchargée.
fn tokenize(line: &str) -> Vec<String> {
    line.split(|c: char| c == ',' || c.is_whitespace())
        .map(|s| s.trim_matches('"').trim())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .collect()
}

/// Convertit un vecteur d'étiquettes textuelles (ex. `"cp"`, `"M"`, `"3"`)
/// en entiers `0..k`, par ordre alphabétique des chaînes distinctes ---
/// déterministe, indépendant de l'ordre d'apparition dans le fichier.
fn label_to_int_map(raw: &[String]) -> Vec<i32> {
    let mut distinct: Vec<String> = raw.to_vec();
    distinct.sort();
    distinct.dedup();
    let map: HashMap<&str, i32> = distinct.iter().enumerate().map(|(i, s)| (s.as_str(), i as i32)).collect();
    raw.iter().map(|s| map[s.as_str()]).collect()
}

/// Avertit (sans arrêter le programme) si le nombre de lignes/colonnes
/// parsées diffère de la valeur canonique UCI attendue.
fn check_shape(name: &str, path: &str, n: usize, d: usize, expected_n: usize, expected_d: usize) {
    if n != expected_n {
        eprintln!("ATTENTION [{name}] {path} : {expected_n} lignes attendues (taille UCI canonique), {n} trouvées --- vérifier le fichier avant d'interpréter les résultats de ce jeu.");
    }
    if d != expected_d {
        eprintln!("ATTENTION [{name}] {path} : {expected_d} variables attendues, {d} trouvées --- vérifier le fichier avant d'interpréter les résultats de ce jeu.");
    }
}

/// Chargeur générique robuste pour les jeux "features + classe en 1ère ou
/// dernière colonne" dont le format exact n'est pas garanti d'avance : ni
/// la position de la classe (Iris/Seeds/Sonar/Ionosphere l'ont en
/// dernière colonne, mais le format UCI canonique de Wine l'a en
/// **première** colonne --- diagnostiqué après coup sur le run réel de
/// l'utilisateur : la version qui supposait toujours "dernière colonne"
/// prenait par erreur une variable continue pour la classe, produisant
/// ~121 "classes" distinctes sur 178 lignes au lieu de 3), ni le
/// caractère déjà-numérique ou textuel de la classe, ni la présence d'une
/// ligne d'en-tête/métadonnées. Stratégie : essayer les deux positions,
/// et retenir celle qui donne le plus petit nombre de modalités
/// distinctes --- une vraie colonne de classe a toujours un petit nombre
/// de modalités, à la différence d'une variable continue prise à tort
/// pour la classe, qui en produit presque autant que de lignes. Le choix
/// retenu est toujours affiché (`colonne détectée : ...`) pour permettre
/// une vérification visuelle. Ne devine jamais silencieusement au-delà de
/// cette heuristique explicite : un échec de parsing des deux côtés
/// provoque un arrêt explicite plutôt qu'une corruption silencieuse.
fn load_labelled_csv(path: &str, dataset_name: &str, expected_n: usize, expected_d: usize) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let rows: Vec<Vec<String>> = content.lines().map(tokenize).filter(|t| t.len() >= 2).collect();
    if rows.is_empty() {
        panic!("{dataset_name} ({path}) : aucune ligne exploitable (>=2 champs) trouvée.");
    }

    let try_position = |label_last: bool| -> Option<(Vec<Vec<f64>>, Vec<String>, usize)> {
        let mut points = Vec::new();
        let mut raw_labels = Vec::new();
        let mut skipped_header = false;
        for (i, tok) in rows.iter().enumerate() {
            let (feat_tok, label_tok): (&[String], String) = if label_last {
                let (f, l) = tok.split_at(tok.len() - 1);
                (f, l[0].clone())
            } else {
                (&tok[1..], tok[0].clone())
            };
            let parsed: Result<Vec<f64>, _> = feat_tok.iter().map(|s| s.parse::<f64>()).collect();
            match parsed {
                Ok(feats) => {
                    points.push(feats);
                    raw_labels.push(label_tok);
                }
                Err(_) if i < 2 && !skipped_header => skipped_header = true,
                Err(_) => return None,
            }
        }
        if points.is_empty() {
            return None;
        }
        let mut distinct: Vec<&String> = raw_labels.iter().collect();
        distinct.sort();
        distinct.dedup();
        let n_distinct = distinct.len();
        Some((points, raw_labels, n_distinct))
    };

    let (points, raw_labels, chosen_col, n_distinct) = match (try_position(true), try_position(false)) {
        (Some((p_l, r_l, d_l)), Some((p_f, r_f, d_f))) => {
            if d_f < d_l {
                (p_f, r_f, "première", d_f)
            } else {
                (p_l, r_l, "dernière", d_l)
            }
        }
        (Some((p_l, r_l, d_l)), None) => (p_l, r_l, "dernière", d_l),
        (None, Some((p_f, r_f, d_f))) => (p_f, r_f, "première", d_f),
        (None, None) => panic!("{dataset_name} ({path}) : échec de parsing avec la classe en première ET en dernière colonne --- format inattendu, à inspecter manuellement."),
    };

    if (n_distinct as f64) > 0.2 * points.len() as f64 {
        eprintln!(
            "ATTENTION [{dataset_name}] {path} : {n_distinct} modalités distinctes détectées en colonne {chosen_col} sur {} lignes --- ressemble à une variable continue prise à tort pour la classe, vérifier le fichier.",
            points.len()
        );
    } else {
        eprintln!("{dataset_name} ({path}) : classe détectée en colonne {chosen_col} ({n_distinct} modalités).");
    }

    let all_numeric_int = raw_labels.iter().all(|s| s.parse::<i32>().is_ok());
    let labels: Vec<i32> = if all_numeric_int {
        raw_labels.iter().map(|s| s.parse::<i32>().unwrap()).collect()
    } else {
        label_to_int_map(&raw_labels)
    };
    check_shape(dataset_name, path, points.len(), points[0].len(), expected_n, expected_d);
    Dataset::new(points, Some(labels), dataset_name)
}

// ============================================================================
// DynMSC (Lenssen & Schubert ; version etendue de "Clustering by Direct
// Optimization of the Medoid Silhouette", SISAP 2022, LNCS 13590 ;
// arXiv:2309.03751, 2023) --- cf. doc du module pour le detail complet.
// ============================================================================

/// K-medoides par alternance (Maranzana 1963, alternative simple a PAM
/// SWAP citee dans Lenssen & Schubert) : assigne au medoide le plus
/// proche, puis pour chaque cluster choisit comme nouveau medoide le
/// point qui minimise la somme des distances aux autres points du
/// cluster. Simplification assumee par rapport a DynMSC/FasterMSC (qui
/// utilisent une recherche SWAP incrementale bien plus rapide pour le
/// meme objectif AMS) --- la vitesse n'etant pas critique pour nos
/// tailles de jeux (n<=625), on privilegie ici la simplicite.
fn kmedoids_alternating(points: &[Vec<f64>], k: usize, rng: &mut ChaCha8Rng, max_iter: usize) -> Vec<usize> {
    let n = points.len();
    let k = k.min(n);
    let mut medoids: Vec<usize> = Vec::with_capacity(k);
    medoids.push(rng.gen_range(0..n));
    let mut dist2 = vec![f64::INFINITY; n];
    for _ in 1..k {
        for i in 0..n {
            let d2 = euclidean(&points[i], &points[*medoids.last().unwrap()]).powi(2);
            if d2 < dist2[i] {
                dist2[i] = d2;
            }
        }
        let total: f64 = dist2.iter().sum();
        if total <= 0.0 {
            medoids.push(rng.gen_range(0..n));
            continue;
        }
        let target = rng.gen::<f64>() * total;
        let mut acc = 0.0;
        let mut chosen = n - 1;
        for i in 0..n {
            acc += dist2[i];
            if acc >= target {
                chosen = i;
                break;
            }
        }
        medoids.push(chosen);
    }

    for _ in 0..max_iter {
        let mut assign = vec![0usize; n];
        for i in 0..n {
            let mut best = 0;
            let mut best_d = f64::INFINITY;
            for (c, &m) in medoids.iter().enumerate() {
                let dd = euclidean(&points[i], &points[m]);
                if dd < best_d {
                    best_d = dd;
                    best = c;
                }
            }
            assign[i] = best;
        }
        let mut changed = false;
        for c in 0..k {
            let members: Vec<usize> = (0..n).filter(|&i| assign[i] == c).collect();
            if members.is_empty() {
                continue;
            }
            let mut best_member = members[0];
            let mut best_cost = f64::INFINITY;
            for &cand in &members {
                let cost: f64 = members.iter().map(|&j| euclidean(&points[cand], &points[j])).sum();
                if cost < best_cost {
                    best_cost = cost;
                    best_member = cand;
                }
            }
            if best_member != medoids[c] {
                medoids[c] = best_member;
                changed = true;
            }
        }
        if !changed {
            break;
        }
    }
    medoids
}

/// Average Medoid Silhouette (Lenssen & Schubert) : AMS = moyenne sur
/// tous les points de 1 - d1(i)/d2(i), ou d1 = distance au medoide le
/// plus proche, d2 = distance au second plus proche --- non defini pour
/// K=1 (pas de "second plus proche"), d'ou k_min=2 dans dynmsc()
/// ci-dessous, cohérent avec la boucle "while k > 2" de l'algorithme 5
/// (DynMSC) du papier, qui exclut structurellement K=1 de la comparaison
/// pour la meme raison.
fn average_medoid_silhouette(points: &[Vec<f64>], medoids: &[usize]) -> f64 {
    let n = points.len();
    if medoids.len() < 2 {
        return 0.0;
    }
    let mut total = 0.0;
    for i in 0..n {
        let mut dists: Vec<f64> = medoids.iter().map(|&m| euclidean(&points[i], &points[m])).collect();
        dists.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let d1 = dists[0];
        let d2 = dists[1];
        let s = if d2 > 0.0 { 1.0 - d1 / d2 } else { 1.0 };
        total += s;
    }
    total / n as f64
}

/// DynMSC --- pour chaque K de k_min a k_max, optimise les medoides pour
/// maximiser l'Average Medoid Silhouette (AMS), retient le K avec l'AMS
/// la plus elevee. Remplace un essai initial avec CNAK (Saha & Mukherjee
/// 2021), abandonne apres diagnostic : une premiere version (sans
/// redemarrages K-means++) trouvait systematiquement K=1 sur les 15 jeux
/// reels ; corrigee (n_init=10, comparaison avec l'implementation de
/// reference CNAK.py des auteurs, recuperee et lue en integralite sur
/// github.com/Jayasree-Saha/CNAK) mais le probleme persistait sur
/// donnees reelles malgre une nette amelioration sur donnees synthetiques
/// --- feuille de route abandonnee au profit de DynMSC, dont la nature
/// deterministe (pas de rééchantillonnage Monte-Carlo) élimine cette
/// classe de fragilité par construction.
fn dynmsc(points: &[Vec<f64>], k_min: usize, k_max: usize, seed: u64) -> Vec<i32> {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let mut best_ams = f64::NEG_INFINITY;
    let mut best_medoids: Vec<usize> = Vec::new();
    for k in k_min..=k_max.min(points.len()) {
        let medoids = kmedoids_alternating(points, k, &mut rng, 100);
        let ams = average_medoid_silhouette(points, &medoids);
        if ams > best_ams {
            best_ams = ams;
            best_medoids = medoids;
        }
    }
    points
        .iter()
        .map(|p| {
            best_medoids
                .iter()
                .enumerate()
                .min_by(|(_, &a), (_, &b)| euclidean(p, &points[a]).partial_cmp(&euclidean(p, &points[b])).unwrap())
                .map(|(i, _)| i as i32)
                .unwrap_or(0)
        })
        .collect()
}


/// Structure union-find minimale pour la construction du squelette de
/// clusters de DenMune (fusion des ensembles seed∪MNN qui se recoupent).
struct UnionFind {
    parent: Vec<usize>,
}
impl UnionFind {
    fn new(n: usize) -> Self {
        Self { parent: (0..n).collect() }
    }
    fn find(&mut self, x: usize) -> usize {
        if self.parent[x] != x {
            self.parent[x] = self.find(self.parent[x]);
        }
        self.parent[x]
    }
    fn union(&mut self, a: usize, b: usize) {
        let (ra, rb) = (self.find(a), self.find(b));
        if ra != rb {
            self.parent[ra] = rb;
        }
    }
}

/// DenMune (Abbas, El-Zoghabi & Shoukry, Pattern Recognition 2021) --- cf.
/// doc du module pour les détails et la déviation assumée (pas de t-SNE).
fn denmune(points: &[Vec<f64>], k: usize) -> Vec<i32> {
    let n = points.len();
    let k = k.min(n.saturating_sub(1)).max(1);

    let mut knn_forward: Vec<Vec<usize>> = Vec::with_capacity(n);
    for i in 0..n {
        let mut d: Vec<(f64, usize)> = (0..n).filter(|&j| j != i).map(|j| (euclidean(&points[i], &points[j]), j)).collect();
        d.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
        knn_forward.push(d.into_iter().take(k).map(|(_, j)| j).collect());
    }
    let mut knn_backward: Vec<Vec<usize>> = vec![Vec::new(); n];
    for i in 0..n {
        for &j in &knn_forward[i] {
            knn_backward[j].push(i);
        }
    }
    let mnn: Vec<Vec<usize>> = (0..n)
        .map(|i| {
            let back: HashSet<usize> = knn_backward[i].iter().copied().collect();
            knn_forward[i].iter().copied().filter(|j| back.contains(j)).collect()
        })
        .collect();

    let noise1: Vec<bool> = (0..n).map(|i| mnn[i].is_empty()).collect();
    let is_seed: Vec<bool> = (0..n).map(|i| !noise1[i] && knn_backward[i].len() >= k).collect();

    let mut uf = UnionFind::new(n);
    for i in 0..n {
        if is_seed[i] {
            for &m in &mnn[i] {
                if is_seed[m] {
                    uf.union(i, m);
                }
            }
        }
    }

    let mut cluster_id: HashMap<usize, i32> = HashMap::new();
    let mut next_id = 0i32;
    for i in 0..n {
        if is_seed[i] {
            let root = uf.find(i);
            cluster_id.entry(root).or_insert_with(|| {
                let id = next_id;
                next_id += 1;
                id
            });
        }
    }

    let mut labels = vec![-1i32; n];
    for i in 0..n {
        if is_seed[i] {
            let root = uf.find(i);
            labels[i] = cluster_id[&root];
        }
    }

    for i in 0..n {
        if !is_seed[i] && !noise1[i] {
            let mut overlap: HashMap<i32, usize> = HashMap::new();
            let mut candidates: Vec<usize> = mnn[i].clone();
            candidates.push(i);
            for &m in &candidates {
                if is_seed[m] {
                    let root = uf.find(m);
                    if let Some(&cid) = cluster_id.get(&root) {
                        *overlap.entry(cid).or_insert(0) += 1;
                    }
                }
            }
            if let Some((&best_cid, _)) = overlap.iter().max_by_key(|(_, &c)| c) {
                labels[i] = best_cid;
            }
        }
    }
    labels
}

// ============================================================================
// Parseurs --- jeux déjà présents (inchangés par rapport aux fichiers d'origine)
// ============================================================================

/// Iris/Wine : `d` variables + classe, position auto-détectée --- cf.
/// `load_labelled_csv`.
fn load_sklearn_csv(path: &str, name: &str, expected_n: usize, expected_d: usize) -> Dataset {
    load_labelled_csv(path, name, expected_n, expected_d)
}

/// Seeds : `7` variables puis la classe (variété de blé, 1/2/3) en
/// dernière colonne --- cf. `load_labelled_csv`.
fn load_seeds(path: &str) -> Dataset {
    load_labelled_csv(path, "Seeds (blé)", 210, 7)
}

/// Sonar : `60` variables puis la classe (`R`/`M`, roche/mine, ou déjà
/// numérique selon la source) en dernière colonne --- cf.
/// `load_labelled_csv`.
fn load_sonar(path: &str) -> Dataset {
    load_labelled_csv(path, "Sonar (défense/mines vs. roches)", 208, 60)
}

/// Wholesale : `Channel` (classe, 1ère colonne), `Region` (exclu), puis 6
/// variables de dépense. Tokenisation générique + en-tête auto-détecté ;
/// `Channel` est toujours numérique dans toutes les sources UCI connues,
/// donc pas de fallback texte ici (à la différence des autres jeux).
fn load_wholesale(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut labels = Vec::new();
    let mut skipped_header = false;
    for (i, line) in content.lines().enumerate() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        let parsed: Result<Vec<f64>, _> = tok.iter().map(|s| s.parse::<f64>()).collect();
        match parsed {
            Ok(fields) => {
                labels.push(fields[0] as i32);
                points.push(fields[2..].to_vec());
            }
            Err(_) if i < 2 && !skipped_header => {
                skipped_header = true;
                eprintln!("Wholesale ({path}) : ligne {} ignorée (en-tête détecté).", i + 1);
            }
            Err(e) => panic!("valeur non numérique dans Wholesale ({path}), ligne {} : {e} --- champs bruts : {:?}", i + 1, tok),
        }
    }
    check_shape("Wholesale", path, points.len(), points[0].len(), 440, 6);
    Dataset::new(points, Some(labels), "Wholesale Customers (finance/business)")
}

/// German Credit (variante numérique) : `24` variables puis la classe
/// (1/2, bon/mauvais risque) en dernière colonne. Tokenisation générique +
/// en-tête auto-détecté (le fichier `.numeric` original n'en a pas, mais
/// on ne suppose plus rien).
fn load_german_credit(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut labels = Vec::new();
    let mut skipped_header = false;
    for (i, line) in content.lines().enumerate() {
        let tok = tokenize(line);
        if tok.len() < 2 {
            continue;
        }
        let parsed: Result<Vec<f64>, _> = tok.iter().map(|s| s.parse::<f64>()).collect();
        match parsed {
            Ok(fields) => {
                let (feats, class) = fields.split_at(fields.len() - 1);
                points.push(feats.to_vec());
                labels.push(class[0] as i32);
            }
            Err(_) if i < 2 && !skipped_header => {
                skipped_header = true;
                eprintln!("German Credit ({path}) : ligne {} ignorée (en-tête détecté).", i + 1);
            }
            Err(e) => panic!("valeur non numérique dans German Credit ({path}), ligne {} : {e} --- champs bruts : {:?}", i + 1, tok),
        }
    }
    check_shape("German Credit", path, points.len(), points[0].len(), 1000, 24);
    Dataset::new(points, Some(labels), "German Credit (finance)")
}

/// Ionosphere : `34` variables puis la classe (`g`/`b`, textuelle dans la
/// source UCI brute, ou déjà numérique selon la source) en dernière
/// colonne --- cf. `load_labelled_csv`.
fn load_ionosphere(path: &str) -> Dataset {
    load_labelled_csv(path, "Ionosphere (défense/radar)", 351, 34)
}

// ============================================================================
// Parseurs --- 7 nouveaux jeux
// ============================================================================

/// Abalone : `Sexe(M/F/I), 7 mesures continues, Rings`. Vérité terrain =
/// Sexe (K=3) ; `Rings` (dernier champ) est parsé pour valider la ligne
/// puis explicitement écarté des variables (cf. doc du module).
fn load_abalone(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.is_empty() {
            continue;
        }
        raw_labels.push(tok[0].clone());
        let feats: Vec<f64> = tok[1..8]
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans {path} : {s} ({e})")))
            .collect();
        let _rings: f64 = tok[8].parse().unwrap_or_else(|e| panic!("Rings non numérique dans {path} : {} ({e})", tok[8]));
        points.push(feats);
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Abalone", path, points.len(), points[0].len(), 4177, 7);
    Dataset::new(points, Some(labels), "Abalone (biologie, Sexe=vérité terrain)")
}

/// Balance Scale : `Classe(L/B/R), 4 variables entières`.
fn load_balance(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.is_empty() {
            continue;
        }
        raw_labels.push(tok[0].clone());
        let feats: Vec<f64> = tok[1..]
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans {path} : {s} ({e})")))
            .collect();
        points.push(feats);
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Balance Scale", path, points.len(), points[0].len(), 625, 4);
    Dataset::new(points, Some(labels), "Balance Scale (psychologie cognitive)")
}

/// Ecoli / Yeast partagent le même format : `Nom(ignoré), variables
/// continues, Classe(texte)`. Facteur commun extrait ici.
fn load_named_continuous_lastclass(path: &str, name: &str) -> (Vec<Vec<f64>>, Vec<String>) {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        let (mid, class) = tok[1..].split_at(tok.len() - 2);
        let feats: Vec<f64> = mid
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans {name} ({path}) : {s} ({e})")))
            .collect();
        points.push(feats);
        raw_labels.push(class[0].clone());
    }
    (points, raw_labels)
}

fn load_ecoli(path: &str) -> Dataset {
    let (points, raw_labels) = load_named_continuous_lastclass(path, "Ecoli");
    let labels = label_to_int_map(&raw_labels);
    check_shape("Ecoli", path, points.len(), points[0].len(), 336, 7);
    Dataset::new(points, Some(labels), "Ecoli (biologie, localisation protéine)")
}

fn load_yeast(path: &str) -> Dataset {
    let (points, raw_labels) = load_named_continuous_lastclass(path, "Yeast");
    let labels = label_to_int_map(&raw_labels);
    check_shape("Yeast", path, points.len(), points[0].len(), 1484, 8);
    Dataset::new(points, Some(labels), "Yeast (biologie, localisation subcellulaire)")
}

/// Glass : `Id(ignoré), 9 variables continues, Type(entier, dernière colonne)`.
fn load_glass(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        let (mid, class) = tok[1..].split_at(tok.len() - 2);
        let feats: Vec<f64> = mid
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans Glass ({path}) : {s} ({e})")))
            .collect();
        points.push(feats);
        raw_labels.push(class[0].clone());
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Glass", path, points.len(), points[0].len(), 214, 9);
    Dataset::new(points, Some(labels), "Glass Identification (criminalistique)")
}

/// Heart Disease (Cleveland) : 13 variables + `num` (sévérité 0-4) en
/// dernière colonne. Lignes contenant `?` (valeurs manquantes ca/thal)
/// éliminées.
fn load_heart(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    let mut n_dropped = 0usize;
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.is_empty() {
            continue;
        }
        if tok.iter().any(|t| t == "?") {
            n_dropped += 1;
            continue;
        }
        let (feats_s, class) = tok.split_at(tok.len() - 1);
        let feats: Vec<f64> = feats_s
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans Heart ({path}) : {s} ({e})")))
            .collect();
        points.push(feats);
        raw_labels.push(class[0].clone());
    }
    if n_dropped > 0 {
        eprintln!("Heart ({path}) : {n_dropped} ligne(s) avec valeur(s) manquante(s) '?' éliminée(s).");
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Heart", path, points.len(), points[0].len(), 297, 13);
    Dataset::new(points, Some(labels), "Heart Disease Cleveland (médecine)")
}

/// Zoo : `Nom(ignoré), variables intermédiaires, Type(dernière colonne)`.
/// Le nombre exact de variables intermédiaires n'est pas fixé en dur ---
/// seule la position (1ère colonne = nom, dernière = classe) l'est.
fn load_zoo(path: &str) -> Dataset {
    let (points, raw_labels) = load_named_continuous_lastclass(path, "Zoo");
    let labels = label_to_int_map(&raw_labels);
    check_shape("Zoo", path, points.len(), points[0].len(), 101, 16);
    Dataset::new(points, Some(labels), "Zoo (biologie, taxonomie)")
}

/// SPECTF Heart : `Classe(1ère colonne, 0/1), 44 variables entières
/// [0,100]`. Deux fichiers UCI distincts (`SPECTF.train`, 80 lignes,
/// `SPECTF.test`, 187 lignes) à fusionner --- format confirmé via le code
/// R de référence des auteurs (`y.train <- train[,1]`,
/// `x.train <- as.matrix(train[,-1])`) et la description officielle UCI
/// (44 attributs continus F1R..F22S, valeurs entières 0-100), pas deviné.
fn load_spectf(train_path: &str, test_path: &str) -> Dataset {
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for path in [train_path, test_path] {
        let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
        for line in content.lines() {
            let tok = tokenize(line);
            if tok.len() < 3 {
                continue;
            }
            let (class, feats_s) = tok.split_at(1);
            let feats: Vec<f64> = feats_s
                .iter()
                .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans SPECTF ({path}) : {s} ({e})")))
                .collect();
            points.push(feats);
            raw_labels.push(class[0].clone());
        }
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("SPECTF Heart", train_path, points.len(), points[0].len(), 267, 44);
    Dataset::new(points, Some(labels), "SPECTF Heart (médecine, imagerie cardiaque SPECT)")
}

/// Arrhythmia : `279 variables, Classe(dernière colonne, 280e, 16
/// modalités)`. Valeurs manquantes `?` (quelques colonnes clairsemées) ---
/// lignes éliminées comme pour Heart. Format (classe en dernière colonne)
/// confirmé via la description officielle UCI/futurehealth.uci.edu
/// ("class 01 refers to 'normal'... class 16 refers to the rest of
/// unclassified ones", énumérées dans l'ordre des attributs, la classe
/// suivant les 279 attributs).
/// Arrhythmia : `279 variables, Classe(dernière colonne, 280e, 16
/// modalités)`. **Correctif** : une première version éliminait les
/// LIGNES contenant au moins une valeur manquante `?`, ce qui effondrait
/// n de 452 à 68 --- les valeurs manquantes sont éparpillées sur de
/// nombreuses colonnes différentes, si bien que presque chaque ligne en
/// contient au moins une quelque part parmi 279 variables. Confirmé
/// incorrect par recoupement de plusieurs sources indépendantes citant
/// ce jeu (Islam et al. 2023 ; Jadhav et al., IJITKM) : la pratique
/// standard élimine les COLONNES contenant des valeurs manquantes (279
/// → 252 colonnes rapporté dans la littérature), conservant toutes les
/// lignes. Reproduit ici : une colonne est éliminée dès qu'elle contient
/// au moins un `?` sur l'ensemble des lignes, les 452 lignes sont
/// conservées.
fn load_arrhythmia(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let rows: Vec<Vec<String>> = content.lines().map(tokenize).filter(|t| !t.is_empty()).collect();
    if rows.is_empty() {
        panic!("Arrhythmia ({path}) : aucune ligne exploitable.");
    }
    let n_cols = rows[0].len();
    // colonnes 0..n_cols-2 = variables, derniere colonne (n_cols-1) = classe
    let n_feat_cols = n_cols - 1;
    let col_has_missing: Vec<bool> = (0..n_feat_cols).map(|c| rows.iter().any(|r| r[c] == "?")).collect();
    let n_dropped_cols = col_has_missing.iter().filter(|&&b| b).count();

    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for r in &rows {
        let feats: Vec<f64> = (0..n_feat_cols)
            .filter(|&c| !col_has_missing[c])
            .map(|c| r[c].parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans Arrhythmia ({path}) : {} ({e})", r[c])))
            .collect();
        points.push(feats);
        raw_labels.push(r[n_cols - 1].clone());
    }
    eprintln!("Arrhythmia ({path}) : {n_dropped_cols} colonne(s) avec valeur(s) manquante(s) éliminée(s) ({n_feat_cols} → {} variables), 0 ligne éliminée.", n_feat_cols - n_dropped_cols);
    let labels = label_to_int_map(&raw_labels);
    check_shape("Arrhythmia", path, points.len(), points[0].len(), 452, 252);
    Dataset::new(points, Some(labels), "Arrhythmia (médecine, ECG)")
}

/// Parkinsons : `Nom(1ère colonne, ignoré), 16 variables, status(18e
/// colonne, 0/1), 6 variables supplémentaires`. Cas particulier parmi
/// tous les jeux de ce fichier : la classe n'est NI en première NI en
/// dernière position --- vérifié explicitement via l'en-tête officiel UCI
/// avant d'écrire ce parseur (`name,MDVP:Fo(Hz),...,HNR,status,RPDE,DFA,
/// spread1,spread2,D2,PPE`), pas supposé par défaut comme les autres
/// jeux. Une ligne d'en-tête est présente (contrairement à la plupart des
/// fichiers `.data` UCI), gérée par la détection générique déjà en place
/// dans `tokenize`+ligne non numérique.
fn load_parkinsons(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    let mut skipped_header = false;
    for (i, line) in content.lines().enumerate() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        // colonne 0 = name (ignorée), colonne 17 (index 17, la 18e) = status
        let status_idx = 17;
        if status_idx >= tok.len() {
            continue;
        }
        let mut feat_tokens: Vec<&String> = Vec::new();
        for (j, t) in tok.iter().enumerate() {
            if j == 0 || j == status_idx {
                continue;
            }
            feat_tokens.push(t);
        }
        let parsed: Result<Vec<f64>, _> = feat_tokens.iter().map(|s| s.parse::<f64>()).collect();
        match parsed {
            Ok(feats) => {
                points.push(feats);
                raw_labels.push(tok[status_idx].clone());
            }
            Err(_) if i == 0 && !skipped_header => {
                skipped_header = true;
                eprintln!("Parkinsons ({path}) : ligne 1 ignorée (en-tête détecté).");
            }
            Err(e) => panic!("valeur non numérique dans Parkinsons ({path}), ligne {} : {e} --- champs bruts : {:?}", i + 1, tok),
        }
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Parkinsons", path, points.len(), points[0].len(), 195, 22);
    Dataset::new(points, Some(labels), "Parkinsons (médecine, mesures vocales)")
}

// ============================================================================
// Prétraitement et harnais d'exécution (inchangés par rapport aux fichiers d'origine)
// ============================================================================

fn standardize(dataset: &Dataset) -> Dataset {
    let n = dataset.points.len();
    let d = dataset.points[0].len();
    let mut mean = vec![0.0; d];
    for p in &dataset.points {
        for j in 0..d {
            mean[j] += p[j] / n as f64;
        }
    }
    let mut std = vec![0.0; d];
    for p in &dataset.points {
        for j in 0..d {
            std[j] += (p[j] - mean[j]).powi(2) / n as f64;
        }
    }
    for s in std.iter_mut() {
        *s = s.sqrt();
        if *s < 1e-12 {
            *s = 1.0;
        }
    }
    let points: Vec<Vec<f64>> = dataset.points.iter().map(|p| (0..d).map(|j| (p[j] - mean[j]) / std[j]).collect()).collect();
    Dataset::new(points, dataset.labels_true.clone(), dataset.name.clone())
}

/// Cf. `real_world_finance_defense.rs` pour la justification (PoWKM libre
/// non optimisé au-delà de n~300 en dimension modérée).
fn subsample(dataset: &Dataset, n_target: usize, seed: u64) -> Dataset {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let mut idx: Vec<usize> = (0..dataset.points.len()).collect();
    idx.shuffle(&mut rng);
    idx.truncate(n_target.min(idx.len()));
    let points = idx.iter().map(|&i| dataset.points[i].clone()).collect();
    let labels = dataset.labels_true.as_ref().map(|l| idx.iter().map(|&i| l[i]).collect());
    Dataset::new(points, labels, dataset.name.clone())
}

fn kth_nn_distances(points: &[Vec<f64>], k: usize) -> Vec<f64> {
    points
        .iter()
        .map(|p| {
            let mut d: Vec<f64> = points.iter().filter(|q| !std::ptr::eq(*q, p)).map(|q| euclidean(p, q)).collect();
            d.sort_by(|a, b| a.partial_cmp(b).unwrap());
            d[(k - 1).min(d.len() - 1)]
        })
        .collect()
}

fn median(mut v: Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = v.len();
    if n % 2 == 0 {
        0.5 * (v[n / 2 - 1] + v[n / 2])
    } else {
        v[n / 2]
    }
}

fn suggest_eps(points: &[Vec<f64>], min_samples: usize) -> f64 {
    median(kth_nn_distances(points, min_samples))
}

fn suggest_bandwidth(points: &[Vec<f64>], quantile: f64) -> f64 {
    let n = points.len();
    let k = ((quantile * n as f64).ceil() as usize).max(1);
    median(kth_nn_distances(points, k))
}

fn cell(r: &ClusterResult, truth: &[i32]) -> String {
    let ari = adjusted_rand_index(truth, &r.labels);
    let nmi = normalized_mutual_info(truth, &r.labels);
    format!("K={:<2} ARI={ari:>6.3} NMI={nmi:>6.3} {:>7.1}ms", r.n_clusters, r.runtime.as_secs_f64() * 1000.0)
}

fn run_all(dataset: &Dataset, true_k: usize, seed: u64, run_free_powkm: bool) -> Vec<(&'static str, ClusterResult)> {
    let truth = dataset.labels_true.as_ref().unwrap();
    let points = &dataset.points;

    let min_samples = 5;
    let eps = suggest_eps(points, min_samples);
    let bandwidth = suggest_bandwidth(points, 0.3).max(1e-3);

    println!("--- K connu fourni en entrée (ne concourent pas sur la découverte de K) ---");
    let mut km = KMeans::new(true_k, seed);
    println!("{:<24} {}", "K-Means", cell(&km.fit(dataset), truth));
    let mut hc = HierarchicalClustering::new(true_k, Linkage::Ward);
    println!("{:<24} {}", "Hiérarchique/Ward", cell(&hc.fit(dataset), truth));
    let mut birch = Birch::new(0.5, 50, true_k);
    println!("{:<24} {}", "BIRCH", cell(&birch.fit(dataset), truth));
    let mut spectral = SpectralClustering::new(true_k, 1.0 / points[0].len() as f64, seed);
    println!("{:<24} {}", "Spectral", cell(&spectral.fit(dataset), truth));

    // Résultats à K découvert automatiquement uniquement --- c'est cette
    // catégorie qui constitue la comparaison honnête pour l'article
    // (aucune de ces méthodes ne reçoit K_vrai), d'où le tracking séparé
    // pour en extraire le meilleur (K, ARI) ci-dessous.
    let mut discovered: Vec<(&'static str, ClusterResult)> = Vec::new();

    println!("--- K découvert automatiquement (hyperparamètres génériques, aucun accès aux labels) ---");
    let mut db = Dbscan::new(eps, min_samples);
    let r = db.fit(dataset);
    println!("{:<24} {}", "DBSCAN", cell(&r, truth));
    discovered.push(("DBSCAN", r));
    let mut hdb = Hdbscan::new(min_samples, min_samples);
    let r = hdb.fit(dataset);
    println!("{:<24} {}", "HDBSCAN", cell(&r, truth));
    discovered.push(("HDBSCAN", r));
    let mut optics = Optics::new(eps, min_samples, eps);
    let r = optics.fit(dataset);
    println!("{:<24} {}", "OPTICS", cell(&r, truth));
    discovered.push(("OPTICS", r));
    let mut ms = MeanShift::new(bandwidth);
    let r = ms.fit(dataset);
    println!("{:<24} {}", "Mean-Shift", cell(&r, truth));
    discovered.push(("Mean-Shift", r));
    if run_free_powkm {
        let mut powkm = PoWKM::new(seed);
        powkm.beta_max = 6.0;
        let r = powkm.fit(dataset);
        println!("{:<24} {}", "PoWKM (libre)", cell(&r, truth));
        discovered.push(("PoWKM (libre)", r));
    } else {
        println!("{:<24} désactivé — cf. doc du module", "PoWKM (libre)");
    }
    let mut prescribed = PoWKMPrescribed::new(seed);
    prescribed.beta_max = 6.0;
    let r = prescribed.fit(dataset);
    println!("{:<24} {}", "PoWKM-prescribed", cell(&r, truth));
    discovered.push(("PoWKM-prescribed", r));

    // Deux algorithmes récents (post-2020) de la littérature --- cf. doc
    // du module pour les citations complètes et les détails d'implémentation.
    let t0 = std::time::Instant::now();
    let labels_dynmsc = dynmsc(points, 2, 15, seed);
    let n_clusters_dynmsc = labels_dynmsc.iter().collect::<HashSet<_>>().len();
    let r = ClusterResult { labels: labels_dynmsc, n_clusters: n_clusters_dynmsc, runtime: t0.elapsed(), algorithm: "DynMSC".into() };
    println!("{:<24} {}", "DynMSC (2023)", cell(&r, truth));
    discovered.push(("DynMSC", r));

    let t0 = std::time::Instant::now();
    let labels_dm = denmune(points, 10);
    let n_clusters_dm = labels_dm.iter().filter(|&&l| l >= 0).collect::<HashSet<_>>().len();
    let r = ClusterResult { labels: labels_dm, n_clusters: n_clusters_dm, runtime: t0.elapsed(), algorithm: "DenMune".into() };
    println!("{:<24} {}", "DenMune (2021)", cell(&r, truth));
    discovered.push(("DenMune", r));

    discovered
}

/// Statistiques accumulées pour un algorithme à K découvert automatiquement,
/// sur l'ensemble des jeux traités --- alimente le classement final.
#[derive(Default)]
struct AlgoStats {
    ari_sum: f64,
    nmi_sum: f64,
    time_ms_sum: f64,
    k_abs_diff_sum: f64,
    n_datasets: usize,
    n_wins: usize,
}

/// Affiche le meilleur résultat par ARI pour la catégorie "K découvert
/// automatiquement" (seule comparaison honnête entre PoWKM et les
/// baselines K-agnostiques de la littérature --- cf. rappel méthodologique
/// en fin de run), et accumule ARI/NMI/temps/|K_trouvé-K_vrai|/victoires
/// dans `stats` pour le classement final imprimé par `main()`.
fn print_best_and_accumulate(dataset_name: &str, results: &[(&'static str, ClusterResult)], truth: &[i32], true_k: usize, stats: &mut HashMap<&'static str, AlgoStats>) {
    let mut best_name = "";
    let mut best_ari = f64::NEG_INFINITY;
    let mut best_nmi = 0.0;
    let mut best_k = 0usize;
    for (name, r) in results {
        let ari = adjusted_rand_index(truth, &r.labels);
        let nmi = normalized_mutual_info(truth, &r.labels);
        let time_ms = r.runtime.as_secs_f64() * 1000.0;
        let k_abs_diff = (r.n_clusters as f64 - true_k as f64).abs();
        let entry = stats.entry(name).or_default();
        entry.ari_sum += ari;
        entry.nmi_sum += nmi;
        entry.time_ms_sum += time_ms;
        entry.k_abs_diff_sum += k_abs_diff;
        entry.n_datasets += 1;
        if ari > best_ari {
            best_ari = ari;
            best_nmi = nmi;
            best_k = r.n_clusters;
            best_name = name;
        }
    }
    if !best_name.is_empty() {
        stats.get_mut(best_name).unwrap().n_wins += 1;
        let tag = if best_name == "PoWKM-prescribed" { " <-- PoWKM gagne" } else { "" };
        println!("  => MEILLEUR (K découvert) [{dataset_name}] : {best_name} K={best_k} ARI={best_ari:.3} NMI={best_nmi:.3}{tag}");
    }
}

fn run_group(title: &str, datasets: &[&Dataset], seed: u64, stats: &mut HashMap<&'static str, AlgoStats>) {
    println!("\n### {title} ###");
    for dataset in datasets {
        let truth = dataset.labels_true.as_ref().unwrap();
        let true_k = truth.iter().collect::<HashSet<_>>().len();
        println!("\n=== {} — n={}, d={}, K_vrai={true_k} ===\n", dataset.name, dataset.points.len(), dataset.points[0].len());
        let discovered = run_all(dataset, true_k, seed, false);
        print_best_and_accumulate(&dataset.name, &discovered, truth, true_k, stats);
    }
}

/// Classement final des algorithmes à K découvert automatiquement, moyenné
/// sur tous les jeux traités --- trié par ARI moyen décroissant.
fn print_final_ranking(stats: &HashMap<&'static str, AlgoStats>) {
    println!("\n### Classement moyen --- algorithmes à K découvert automatiquement ###\n");
    let mut rows: Vec<(&&str, &AlgoStats)> = stats.iter().collect();
    rows.sort_by(|a, b| {
        let ari_a = a.1.ari_sum / a.1.n_datasets as f64;
        let ari_b = b.1.ari_sum / b.1.n_datasets as f64;
        ari_b.partial_cmp(&ari_a).unwrap()
    });
    println!(
        "{:<20} {:>10} {:>10} {:>12} {:>16} {:>12}",
        "Algorithme", "ARI moy.", "NMI moy.", "Temps moy.", "|K_trouvé-K_vrai|", "Victoires"
    );
    for (name, s) in &rows {
        let n = s.n_datasets as f64;
        println!(
            "{:<20} {:>10.3} {:>10.3} {:>10.1}ms {:>14.2} {:>9}/{}",
            name,
            s.ari_sum / n,
            s.nmi_sum / n,
            s.time_ms_sum / n,
            s.k_abs_diff_sum / n,
            s.n_wins,
            s.n_datasets
        );
    }
    println!("\n(moyennes calculées sur les mêmes {} jeux pour chaque algorithme ;", rows.first().map(|(_, s)| s.n_datasets).unwrap_or(0));
    println!("« victoires » = nombre de jeux où l'algorithme obtient le meilleur ARI");
    println!("parmi les méthodes à K découvert automatiquement, cf. MEILLEUR ci-dessus.)");
}

fn main() {
    let seed = 42;
    let data_dir = "/home/yves/Nextcloud/book/traité_d_algorithmique/article/data_cluster";

    // --- 8 jeux déjà présents ---
    let iris = standardize(&load_sklearn_csv(&format!("{data_dir}/iris.csv"), "Iris", 150, 4));
    let wine = standardize(&load_sklearn_csv(&format!("{data_dir}/wine.csv"), "Wine", 178, 13));
    let seeds = standardize(&load_seeds(&format!("{data_dir}/seeds.csv")));
    let breast_cancer = standardize(&load_sklearn_csv(&format!("{data_dir}/breast_cancer.csv"), "Breast Cancer", 569, 30));
    let sonar = standardize(&load_sonar(&format!("{data_dir}/sonar.csv")));
    let wholesale = standardize(&load_wholesale(&format!("{data_dir}/wholesale.csv")));
    let german_raw = load_german_credit(&format!("{data_dir}/german_credit_numeric.txt"));
    let german = standardize(&subsample(&german_raw, 300, seed));
    let ionosphere = standardize(&load_ionosphere(&format!("{data_dir}/ionosphere.csv")));

    // --- 7 nouveaux jeux ---
    let abalone_raw = load_abalone(&format!("{data_dir}/abalone.csv"));
    let abalone = standardize(&subsample(&abalone_raw, 600, seed));
    let balance = standardize(&load_balance(&format!("{data_dir}/balance.csv")));
    let ecoli = standardize(&load_ecoli(&format!("{data_dir}/ecoli.csv")));
    let glass = standardize(&load_glass(&format!("{data_dir}/glass.csv")));
    let heart = standardize(&load_heart(&format!("{data_dir}/heart.csv")));
    let yeast_raw = load_yeast(&format!("{data_dir}/yeast.csv"));
    let yeast = standardize(&subsample(&yeast_raw, 500, seed));
    let zoo = standardize(&load_zoo(&format!("{data_dir}/zoo.csv")));

    // --- 3 nouveaux jeux médicaux (n/d faible, régime cible du
    // rétrécissement Ledoit-Wolf de PoWKM-prescribed --- cf. doc du
    // module `powkm_prescribed.rs`) ---
    let spectf = standardize(&load_spectf(&format!("{data_dir}/SPECTF.train"), &format!("{data_dir}/SPECTF.test")));
    let arrhythmia = standardize(&load_arrhythmia(&format!("{data_dir}/arrhythmia.data")));
    let parkinsons = standardize(&load_parkinsons(&format!("{data_dir}/parkinsons.data")));

    let mut stats: HashMap<&'static str, AlgoStats> = HashMap::new();
    run_group("Jeux bien séparés (classiques du clustering)", &[&iris, &wine, &seeds, &breast_cancer], seed, &mut stats);
    run_group("Jeux finance/business", &[&wholesale, &balance], seed, &mut stats);
    run_group("Jeux finance/défense (haute dimension ou n plus grand)", &[&german, &ionosphere, &sonar], seed, &mut stats);
    run_group("Jeux biologie (protéines/organismes)", &[&ecoli, &yeast, &zoo, &abalone], seed, &mut stats);
    run_group("Jeux physique/médecine", &[&glass, &heart], seed, &mut stats);
    run_group("Jeux médicaux n/d faible (régime cible du rétrécissement)", &[&spectf, &arrhythmia, &parkinsons], seed, &mut stats);

    print_final_ranking(&stats);

    println!("\nRappel méthodologique : DBSCAN/HDBSCAN/OPTICS/Mean-Shift/PoWKM/PoWKM-prescribed/DynMSC/DenMune");
    println!("découvrent K eux-mêmes (hyperparamètres génériques, aucun accès aux labels) ;");
    println!("K-Means/Hiérarchique/BIRCH/Spectral reçoivent K_vrai en entrée (ne peuvent pas");
    println!("fonctionner sans). Ce ne sont pas deux catégories à comparer terme à terme sur");
    println!("l'ARI seul — la comparaison honnête porte sur K trouvé pour la première catégorie,");
    println!("et sur ARI/NMI à K fixé pour la seconde. PoWKM libre reste désactivé partout dans");
    println!("ce fichier ; Abalone/Yeast/German Credit sont sous-échantillonnés (cf. doc du");
    println!("module) pour un temps d'exécution raisonnable sur l'ensemble des 18 jeux.");
}
