//! Comparaison de la capacité à découvrir K automatiquement, entre PoWKM
//! et les algorithmes de la littérature qui ne prennent pas K en
//! paramètre (DBSCAN, HDBSCAN, OPTICS, Mean-Shift).
//!
//! Point méthodologique central : pour que la comparaison soit honnête,
//! AUCUN hyperparamètre n'est choisi en regardant les labels de vérité
//! terrain. Les heuristiques utilisées ci-dessous (distance au k-ième
//! plus proche voisin, estimation de bandwidth façon scikit-learn) sont
//! des règles standard de la littérature, appliquées uniformément à tous
//! les jeux de données — exactement comme PoWKM, qui tourne avec les
//! mêmes hyperparamètres par défaut partout.

use cluster_algos::{Dbscan, Hdbscan, MeanShift, Optics};
use cluster_core::{euclidean, ClusteringAlgorithm};
use cluster_data::standard_benchmark_suite;
use cluster_metrics::adjusted_rand_index;
use cluster_ot::PoWKM;
use std::collections::HashSet;

/// Distance de chaque point à son k-ième plus proche voisin (lui-même
/// exclu), triée. Primitive partagée par les heuristiques ci-dessous.
fn kth_nn_distances(points: &[Vec<f64>], k: usize) -> Vec<f64> {
    points
        .iter()
        .map(|p| {
            let mut d: Vec<f64> = points.iter().filter(|q| !std::ptr::eq(*q, p)).map(|q| euclidean(p, q)).collect();
            d.sort_by(|a, b| a.partial_cmp(b).unwrap());
            d[(k - 1).min(d.len() - 1)]
        })
        .collect()
}

fn median(mut v: Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = v.len();
    if n % 2 == 0 {
        0.5 * (v[n / 2 - 1] + v[n / 2])
    } else {
        v[n / 2]
    }
}

/// Heuristique standard (issue de l'article original de DBSCAN, Ester et
/// al. 1996) : eps = médiane des distances au k-ième plus proche voisin.
/// Aucun accès aux labels.
fn suggest_eps(points: &[Vec<f64>], min_samples: usize) -> f64 {
    median(kth_nn_distances(points, min_samples))
}

/// Réplique la logique de `sklearn.cluster.estimate_bandwidth` (quantile
/// des distances aux plus proches voisins, quantile par défaut 0.3).
/// Aucun accès aux labels.
fn suggest_bandwidth(points: &[Vec<f64>], quantile: f64) -> f64 {
    let n = points.len();
    let k = ((quantile * n as f64).ceil() as usize).max(1);
    median(kth_nn_distances(points, k))
}

fn main() {
    let n = 200;
    let seed = 42;
    let suite = standard_benchmark_suite(n, seed);

    println!("{:<20} {:>7} | {:>28} | {:>28} | {:>28} | {:>28} | {:>28}", "jeu", "K_vrai", "DBSCAN", "HDBSCAN", "OPTICS", "Mean-Shift", "PoWKM");

    for dataset in &suite {
        if dataset.labels_true.is_none() {
            continue;
        }
        let truth = dataset.labels_true.as_ref().unwrap();
        let true_k = truth.iter().collect::<HashSet<_>>().len();

        // --- Hyperparamètres génériques, calculés SANS accès aux labels ---
        let min_samples = 5;
        let eps = suggest_eps(&dataset.points, min_samples);
        let bandwidth = suggest_bandwidth(&dataset.points, 0.3).max(1e-3);

        let mut db = Dbscan::new(eps, min_samples);
        let r_db = db.fit(dataset);
        let ari_db = adjusted_rand_index(truth, &r_db.labels);

        let mut hdb = Hdbscan::new(min_samples, min_samples);
        let r_hdb = hdb.fit(dataset);
        let ari_hdb = adjusted_rand_index(truth, &r_hdb.labels);

        let mut optics = Optics::new(eps, min_samples, eps);
        let r_optics = optics.fit(dataset);
        let ari_optics = adjusted_rand_index(truth, &r_optics.labels);

        let mut ms = MeanShift::new(bandwidth);
        let r_ms = ms.fit(dataset);
        let ari_ms = adjusted_rand_index(truth, &r_ms.labels);

        let mut powkm = PoWKM::new(7);
        let r_powkm = powkm.fit(dataset);
        let ari_powkm = adjusted_rand_index(truth, &r_powkm.labels);

        let cell = |k: usize, ari: f64| format!("K={k:<3} ARI={ari:.3}");

        println!(
            "{:<20} {:>7} | {:>28} | {:>28} | {:>28} | {:>28} | {:>28}",
            dataset.name,
            true_k,
            cell(r_db.n_clusters, ari_db),
            cell(r_hdb.n_clusters, ari_hdb),
            cell(r_optics.n_clusters, ari_optics),
            cell(r_ms.n_clusters, ari_ms),
            cell(r_powkm.n_clusters, ari_powkm),
        );
    }
    println!("\n(hyperparamètres génériques : min_samples=5, eps=médiane des distances au 5e plus proche voisin,");
    println!(" bandwidth façon sklearn.estimate_bandwidth(quantile=0.3) — aucun réglage par jeu de données, aucun accès aux labels)");
}
