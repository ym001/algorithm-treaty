//! Comparaison de PoWKM (libre et prescrit) contre tous les algorithmes de
//! la littérature déjà implémentés dans ce workspace, sur deux jeux de
//! données **réels** (pas synthétiques) :
//!
//! - **Finance** : German Credit (Statlog, Hofmann 1994), 1000 clients,
//!   24 variables numériques, 2 classes (bon/mauvais risque de crédit).
//!   Source : `zergtant/pytorch-handbook` (GitHub), qui redistribue le
//!   fichier `german.data-numeric` officiel de Strathclyde University.
//! - **Défense / radar** : Ionosphere (Sigillito et al. 1989, Johns
//!   Hopkins APL), 351 retours radar collectés par le système à réseau
//!   phasé de Goose Bay (Labrador), 34 variables numériques, 2 classes
//!   (retour radar "bon" = structure ionosphérique détectée, "mauvais" =
//!   signal traversant sans structure). Source : `selva86/datasets`
//!   (GitHub), qui redistribue le jeu de données UCI original.
//!
//! Les deux sont des jeux **de classification**, pas nativement conçus
//! pour le clustering — pratique standard et largement établie dans la
//! littérature du clustering (Xu & Wunsch 2005, entre autres) : la classe
//! sert de vérité terrain pour évaluer si le clustering, non supervisé,
//! retrouve une structure qui coïncide avec une catégorisation réelle et
//! indépendante.
//!
//! ## Méthodologie
//!
//! - **Standardisation z-score** sur chaque colonne avant tout algorithme
//!   à base de distance euclidienne — les échelles brutes diffèrent
//!   radicalement (ex. montant de crédit en milliers vs indicatrices
//!   0/1), sans quoi la distance serait dominée par les colonnes de plus
//!   grande échelle.
//! - **Aucun hyperparamètre choisi en regardant les labels** pour DBSCAN,
//!   HDBSCAN, OPTICS, Mean-Shift, PoWKM, PoWKM-prescribed — heuristiques
//!   génériques identiques à `k_discovery_comparison.rs` (distance au
//!   k-ième plus proche voisin, quantile façon `sklearn.estimate_bandwidth`).
//! - **K vrai fourni** à KMeans, Hiérarchique (Ward), BIRCH, Spectral —
//!   ces méthodes ne fonctionnent pas sans K en entrée ; leur rôle ici
//!   est de montrer la qualité atteignable *si* K est déjà connu, pas de
//!   concourir sur la découverte de K.
//!
//! Exécuter depuis la racine du dépôt (chemins relatifs vers `data/real/`) :
//! ```text
//! cargo run --release --example real_world_finance_defense -p cluster-ot
//! ```

use cluster_algos::{Birch, Dbscan, Hdbscan, HierarchicalClustering, KMeans, Linkage, MeanShift, Optics, SpectralClustering};
use cluster_core::{euclidean, ClusterResult, ClusteringAlgorithm, Dataset};
use cluster_metrics::{adjusted_rand_index, normalized_mutual_info};
use cluster_ot::{pca_whiten, PoWKMPrescribed, PoWKM};
use std::collections::HashSet;
use std::fs;

/// German Credit (`german.data-numeric`) : 24 colonnes numériques par
/// ligne, séparateur espace(s) multiples, dernière colonne = classe
/// (1=bon risque, 2=mauvais), pas d'en-tête.
fn load_german_credit(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for line in content.lines() {
        let fields: Vec<f64> = line.split_whitespace().map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans {path} : {s} ({e})"))).collect();
        if fields.is_empty() {
            continue;
        }
        let (feats, class) = fields.split_at(fields.len() - 1);
        points.push(feats.to_vec());
        labels.push(class[0] as i32);
    }
    assert_eq!(points.len(), 1000, "German Credit : 1000 lignes attendues, {} trouvées", points.len());
    assert_eq!(points[0].len(), 24, "German Credit : 24 variables attendues, {} trouvées", points[0].len());
    Dataset::new(points, Some(labels), "German Credit (finance)")
}

/// Ionosphere (`Ionosphere.csv`) : en-tête `V1..V34,Class`, séparateur
/// virgule, valeurs entre guillemets, classe déjà encodée 0/1 en dernière
/// colonne.
fn load_ionosphere(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut lines = content.lines();
    lines.next(); // en-tête
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for line in lines {
        if line.trim().is_empty() {
            continue;
        }
        let fields: Vec<f64> = line.split(',').map(|s| s.trim_matches('"').parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans {path} : {s} ({e})"))).collect();
        let (feats, class) = fields.split_at(fields.len() - 1);
        points.push(feats.to_vec());
        labels.push(class[0] as i32);
    }
    assert_eq!(points.len(), 351, "Ionosphere : 351 lignes attendues, {} trouvées", points.len());
    assert_eq!(points[0].len(), 34, "Ionosphere : 34 variables attendues, {} trouvées", points[0].len());
    Dataset::new(points, Some(labels), "Ionosphere (défense/radar)")
}

/// Standardisation z-score colonne par colonne (moyenne 0, écart-type 1).
/// Colonnes à variance nulle laissées à 0 (évite une division par 0 — la
/// colonne 2 d'Ionosphere, toujours nulle d'après la documentation UCI,
/// en est un exemple réel, pas hypothétique).
fn standardize(dataset: &Dataset) -> Dataset {
    let n = dataset.points.len();
    let d = dataset.points[0].len();
    let mut mean = vec![0.0; d];
    for p in &dataset.points {
        for j in 0..d {
            mean[j] += p[j] / n as f64;
        }
    }
    let mut std = vec![0.0; d];
    for p in &dataset.points {
        for j in 0..d {
            std[j] += (p[j] - mean[j]).powi(2) / n as f64;
        }
    }
    for s in std.iter_mut() {
        *s = s.sqrt();
        if *s < 1e-12 {
            *s = 1.0;
        }
    }
    let points: Vec<Vec<f64>> = dataset.points.iter().map(|p| (0..d).map(|j| (p[j] - mean[j]) / std[j]).collect()).collect();
    Dataset::new(points, dataset.labels_true.clone(), dataset.name.clone())
}

/// Tire un sous-échantillon aléatoire (indices fixés par graine, pas de
/// tri par label) — nécessaire en pratique : PoWKM avec `beta_max=50`
/// (valeur par défaut) sur German Credit en entier (n=1000, d=24) a été
/// mesuré à plus de 9 minutes sans terminer (diagnostiqué directement,
/// tué manuellement, pas un choix de confort). PoWKM explore par
/// construction un recuit complet sur β à chaque run ; ce n'est pas
/// (encore) optimisé pour n~1000 en dimension >2. Sous-échantillonner
/// est une limite honnête à documenter, pas un artefact caché — la
/// comparaison porte sur un sous-ensemble représentatif, pas le jeu
/// complet.
fn subsample(dataset: &Dataset, n_target: usize, seed: u64) -> Dataset {
    use rand::prelude::*;
    use rand_chacha::ChaCha8Rng;
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let mut idx: Vec<usize> = (0..dataset.points.len()).collect();
    idx.shuffle(&mut rng);
    idx.truncate(n_target.min(idx.len()));
    let points = idx.iter().map(|&i| dataset.points[i].clone()).collect();
    let labels = dataset.labels_true.as_ref().map(|l| idx.iter().map(|&i| l[i]).collect());
    Dataset::new(points, labels, dataset.name.clone())
}

fn kth_nn_distances(points: &[Vec<f64>], k: usize) -> Vec<f64> {
    points
        .iter()
        .map(|p| {
            let mut d: Vec<f64> = points.iter().filter(|q| !std::ptr::eq(*q, p)).map(|q| euclidean(p, q)).collect();
            d.sort_by(|a, b| a.partial_cmp(b).unwrap());
            d[(k - 1).min(d.len() - 1)]
        })
        .collect()
}

fn median(mut v: Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = v.len();
    if n % 2 == 0 {
        0.5 * (v[n / 2 - 1] + v[n / 2])
    } else {
        v[n / 2]
    }
}

fn suggest_eps(points: &[Vec<f64>], min_samples: usize) -> f64 {
    median(kth_nn_distances(points, min_samples))
}

fn suggest_bandwidth(points: &[Vec<f64>], quantile: f64) -> f64 {
    let n = points.len();
    let k = ((quantile * n as f64).ceil() as usize).max(1);
    median(kth_nn_distances(points, k))
}

fn cell(r: &ClusterResult, truth: &[i32]) -> String {
    let ari = adjusted_rand_index(truth, &r.labels);
    let nmi = normalized_mutual_info(truth, &r.labels);
    format!("K={:<2} ARI={ari:>6.3} NMI={nmi:>6.3} {:>7.1}ms", r.n_clusters, r.runtime.as_secs_f64() * 1000.0)
}

fn run_all(dataset: &Dataset, whitened: &Dataset, true_k: usize, seed: u64, run_free_powkm: bool) {
    let truth = dataset.labels_true.as_ref().unwrap();
    let points = &dataset.points;

    let min_samples = 5;
    let eps = suggest_eps(points, min_samples);
    let bandwidth = suggest_bandwidth(points, 0.3).max(1e-3);

    println!("--- K connu fourni en entrée (ne concourent pas sur la découverte de K) ---");
    let mut km = KMeans::new(true_k, seed);
    println!("{:<24} {}", "K-Means", cell(&km.fit(dataset), truth));
    let mut hc = HierarchicalClustering::new(true_k, Linkage::Ward);
    println!("{:<24} {}", "Hiérarchique/Ward", cell(&hc.fit(dataset), truth));
    let mut birch = Birch::new(0.5, 50, true_k);
    println!("{:<24} {}", "BIRCH", cell(&birch.fit(dataset), truth));
    let mut spectral = SpectralClustering::new(true_k, 1.0 / points[0].len() as f64, seed);
    println!("{:<24} {}", "Spectral", cell(&spectral.fit(dataset), truth));

    println!("--- K découvert automatiquement (hyperparamètres génériques, aucun accès aux labels) ---");
    let mut db = Dbscan::new(eps, min_samples);
    println!("{:<24} {}", "DBSCAN", cell(&db.fit(dataset), truth));
    let mut hdb = Hdbscan::new(min_samples, min_samples);
    println!("{:<24} {}", "HDBSCAN", cell(&hdb.fit(dataset), truth));
    let mut optics = Optics::new(eps, min_samples, eps);
    println!("{:<24} {}", "OPTICS", cell(&optics.fit(dataset), truth));
    let mut ms = MeanShift::new(bandwidth);
    println!("{:<24} {}", "Mean-Shift", cell(&ms.fit(dataset), truth));
    if run_free_powkm {
        let mut powkm = PoWKM::new(seed);
        powkm.beta_max = 6.0;
        println!("{:<24} {}", "PoWKM (libre, standard.)", cell(&powkm.fit(dataset), truth));
    } else {
        println!("{:<24} désactivé — cf. doc du module", "PoWKM (libre, standard.)");
    }
    let mut prescribed = PoWKMPrescribed::new(seed);
    prescribed.beta_max = 6.0;
    println!("{:<24} {}", "PoWKM-pres. (standard.)", cell(&prescribed.fit(dataset), truth));

    println!("--- Variantes blanchies PCA (correctif diagnostiqué — cf. linalg.rs) ---");
    if run_free_powkm {
        let mut powkm_w = PoWKM::new(seed);
        powkm_w.beta_max = 6.0;
        println!("{:<24} {}", "PoWKM (libre, blanchi)", cell(&powkm_w.fit(whitened), truth));
    } else {
        println!("{:<24} désactivé — cf. doc du module (pas encore vérifié séparément)", "PoWKM (libre, blanchi)");
    }
    let mut prescribed_w = PoWKMPrescribed::new(seed);
    prescribed_w.beta_max = 6.0;
    println!("{:<24} {}", "PoWKM-pres. (blanchi)", cell(&prescribed_w.fit(whitened), truth));
}

fn main() {
    let seed = 42;

    let german_raw = load_german_credit("data/real/german_credit_numeric.txt");
    let ionosphere_raw = load_ionosphere("data/real/ionosphere.csv");
    let german_sub = subsample(&german_raw, 300, seed);
    let german = standardize(&german_sub);
    let ionosphere = standardize(&ionosphere_raw);

    for dataset in [&german, &ionosphere] {
        let truth = dataset.labels_true.as_ref().unwrap();
        let true_k = truth.iter().collect::<HashSet<_>>().len();
        let whitened = pca_whiten(dataset);
        println!("\n=== {} — n={}, d={}, K_vrai={true_k} ===\n", dataset.name, dataset.points.len(), dataset.points[0].len());
        run_all(dataset, &whitened, true_k, seed, false);
    }

    println!("\nRappel méthodologique : DBSCAN/HDBSCAN/OPTICS/Mean-Shift/PoWKM/PoWKM-prescribed");
    println!("découvrent K eux-mêmes (hyperparamètres génériques, aucun accès aux labels) ;");
    println!("K-Means/Hiérarchique/BIRCH/Spectral reçoivent K_vrai en entrée (ne peuvent pas");
    println!("fonctionner sans). Ce ne sont pas deux catégories à comparer terme à terme sur");
    println!("l'ARI seul — la comparaison honnête porte sur K trouvé pour la première catégorie,");
    println!("et sur ARI/NMI à K fixé pour la seconde.");
}
