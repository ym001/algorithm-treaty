//! Expérience : quantifie, sur du **vrai clustering** (pas des chiffres
//! Python isolés), l'effet du resserrement de `M` sur le certificat de
//! warm-start — et confirme, indépendamment de toute borne, que le
//! warm-start réel est bien plus rapide qu'un redémarrage à froid.
//!
//! Pour chaque `K`, une boucle de type Lloyd (E-step OT entropique +
//! M-step barycentrique) est exécutée sur des données synthétiques
//! réelles (`cluster-data::make_blobs`). À chaque pas, on mesure :
//! - le nombre RÉEL d'itérations de Newton pour resolver au nouveau
//!   `Y_new`, en partant à froid (g=0) vs en warm-start (g=g*(Y_old)) —
//!   fait indépendant de toute borne théorique ;
//! - si ce pas est CERTIFIÉ dans le bassin de convergence quadratique,
//!   sous l'ancienne borne `M` (grossière, `K^{3/2}/(4ε²)`) et sous la
//!   nouvelle (`min` des deux bornes) — reconstruit ici à partir des
//!   mêmes briques publiques que `warm_start_bound.rs`, pas recalculé
//!   indépendamment, pour ne pas introduire une deuxième source d'erreur.
//!
//! `cargo run --release --example warm_start_bound_efficacy -p cluster-ot`

use cluster_core::euclidean;
use cluster_data::make_blobs;
use cluster_ot::{
    centers_distance, diam_bound, gradient_lipschitz_in_y, hessian_lipschitz_crude, hessian_lipschitz_in_g, min_responsibility, newton_semidiscrete_ot, quadratic_basin_radius,
    strong_concavity_modulus,
};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;

fn cost_matrix(points: &[Vec<f64>], centers: &[Vec<f64>]) -> Vec<Vec<f64>> {
    points.iter().map(|x| centers.iter().map(|y| 0.5 * euclidean(x, y).powi(2)).collect()).collect()
}

/// Certifie un pas Y_old -> Y_new avec une formule de M au choix (pour
/// comparer avant/après avec exactement la même logique par ailleurs).
#[allow(clippy::too_many_arguments)]
fn certified_within_basin(points: &[Vec<f64>], a: &[f64], b: &[f64], epsilon: f64, y_old: &[Vec<f64>], y_new: &[Vec<f64>], g_old: &[f64], m_hessian: f64) -> bool {
    let k = y_old.len();
    let diam = diam_bound(points, &[y_old, y_new]);
    let rho_min = min_responsibility(&cost_matrix(points, y_old), a, b, epsilon, g_old).min(min_responsibility(&cost_matrix(points, y_new), a, b, epsilon, g_old));
    let m = strong_concavity_modulus(rho_min, k, epsilon);
    let l_y = gradient_lipschitz_in_y(diam, epsilon);
    let predicted_gap = (l_y / m) * centers_distance(y_old, y_new);
    predicted_gap < quadratic_basin_radius(m, m_hessian)
}

fn main() {
    let tol = 1e-7;
    let n_lloyd_steps = 6;
    let k_values = [2usize, 3, 5, 8, 12, 20];

    println!("{:<4} {:>10} {:>10} {:>8} {:>12} {:>12} {:>10} {:>10}", "K", "M_avant", "M_apres", "gain", "certif_avant", "certif_apres", "iters_warm", "iters_froid");
    println!("{}", "-".repeat(84));

    for &k in &k_values {
        let n = 8 * k;
        let dataset = make_blobs(n, k, 1.0, 42 + k as u64);
        let points = dataset.points.clone();
        let a = vec![1.0 / n as f64; n];
        let b = vec![1.0 / k as f64; k];

        // epsilon adaptatif : fraction de l'écart quadratique moyen entre
        // les VRAIS centroïdes (connus via labels_true, un luxe de données
        // synthétiques) — évite de fixer un epsilon arbitraire qui devient
        // dégénéré à grand K, puisque make_blobs espace ses centres en
        // 5·√K (croissant), donc un epsilon fixe finirait, à grand K, par
        // être ridiculement petit devant l'écart réel entre clusters
        // (diagnostiqué directement : pivot quasi nul à K=5 avec un
        // epsilon=2.0 fixe, avant ce correctif).
        let true_centroids: Vec<Vec<f64>> = {
            let labels = dataset.labels_true.clone().expect("make_blobs fournit toujours labels_true");
            (0..k)
                .map(|c| {
                    let members: Vec<&Vec<f64>> = points.iter().zip(labels.iter()).filter(|(_, &l)| l as usize == c).map(|(p, _)| p).collect();
                    let d = points[0].len();
                    let mut mean = vec![0.0; d];
                    for m in &members {
                        for j in 0..d {
                            mean[j] += m[j] / members.len() as f64;
                        }
                    }
                    mean
                })
                .collect()
        };
        let mut pairwise_sq: Vec<f64> = Vec::new();
        for i in 0..k {
            for j in (i + 1)..k {
                pairwise_sq.push(euclidean(&true_centroids[i], &true_centroids[j]).powi(2));
            }
        }
        let mean_sep_sq: f64 = if pairwise_sq.is_empty() { 1.0 } else { pairwise_sq.iter().sum::<f64>() / pairwise_sq.len() as f64 };
        let epsilon = 0.12 * mean_sep_sq;

        let mut rng = ChaCha8Rng::seed_from_u64(1000 + k as u64);
        // Init k-means++ (répartie sur le support réel des données) plutôt
        // qu'un tirage uniforme pur : avec un tirage uniforme, K=5 sur 40
        // points a produit un centre isolé loin de tout point, provoquant
        // un écart de coût extrême et un pivot quasi nul dans le solveur
        // Newton (diagnostiqué directement, pas supposé) — la même classe
        // de fragilité que l'init k-means naïve est censée éviter.
        let mut y: Vec<Vec<f64>> = {
            let first = rng.gen_range(0..n);
            let mut centers = vec![points[first].clone()];
            let mut dist_sq: Vec<f64> = points.iter().map(|p| euclidean(p, &centers[0]).powi(2)).collect();
            while centers.len() < k {
                let total: f64 = dist_sq.iter().sum();
                let target: f64 = rng.gen_range(0.0..total.max(1e-12));
                let mut cum = 0.0;
                let mut chosen = 0;
                for (i, &d) in dist_sq.iter().enumerate() {
                    cum += d;
                    if cum >= target {
                        chosen = i;
                        break;
                    }
                }
                centers.push(points[chosen].clone());
                for (i, p) in points.iter().enumerate() {
                    dist_sq[i] = dist_sq[i].min(euclidean(p, &centers[centers.len() - 1]).powi(2));
                }
            }
            centers
        };

        let m_avant = hessian_lipschitz_crude(k, epsilon);
        let m_apres = hessian_lipschitz_in_g(k, epsilon);

        let mut g = vec![0.0; k];
        let mut certified_avant = 0usize;
        let mut certified_apres = 0usize;
        let mut total_warm_iters = 0usize;
        let mut total_cold_iters = 0usize;
        let mut n_steps_measured = 0usize;

        for _step in 0..n_lloyd_steps {
            let cost = cost_matrix(&points, &y);
            let g_old = g.clone();
            let y_old = y.clone();

            // E-step : résout Newton à froid (pour avoir g* indépendamment
            // de tout warm-start, sert de référence "vérité terrain" pour
            // le M-step ci-dessous).
            let cold_from_zero = newton_semidiscrete_ot(&cost, &a, &b, epsilon, vec![0.0; k], 500, tol);
            assert!(cold_from_zero.converged, "K={k}: Newton à froid n'a pas convergé");
            g = cold_from_zero.g.clone();

            // M-step barycentrique (projection barycentrique standard de
            // l'OT entropique) : nouveau centre = moyenne des points
            // pondérée par la responsabilité douce.
            let r = {
                let eps = epsilon;
                (0..n)
                    .map(|i| {
                        let logits: Vec<f64> = (0..k).map(|j| (g[j] - cost[i][j]) / eps).collect();
                        let m = logits.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
                        let exps: Vec<f64> = logits.iter().map(|&l| (l - m).exp()).collect();
                        let s: f64 = exps.iter().sum();
                        exps.iter().map(|&e| e / s).collect::<Vec<f64>>()
                    })
                    .collect::<Vec<Vec<f64>>>()
            };
            let d = points[0].len();
            let mut y_new = vec![vec![0.0; d]; k];
            let mut mass = vec![0.0; k];
            for i in 0..n {
                for j in 0..k {
                    for c in 0..d {
                        y_new[j][c] += r[i][j] * points[i][c];
                    }
                    mass[j] += r[i][j];
                }
            }
            for j in 0..k {
                if mass[j] > 1e-9 {
                    for c in 0..d {
                        y_new[j][c] /= mass[j];
                    }
                } else {
                    // Centre resté sans masse assignée : le laisser à
                    // [0,0] (défaut) peut être loin du support des
                    // données et créer un écart de coût extrême →
                    // hessien quasi singulier (observé et diagnostiqué
                    // avec l'init naïve avant ce correctif). Le
                    // réinitialiser sur un point réel tiré au hasard.
                    y_new[j] = points[rng.gen_range(0..n)].clone();
                }
            }

            // Mesure RÉELLE (indépendante de toute borne théorique) :
            // itérations de Newton pour converger au nouveau problème,
            // à froid vs en warm-start depuis g*(Y_old).
            let cost_new = cost_matrix(&points, &y_new);
            let cold = newton_semidiscrete_ot(&cost_new, &a, &b, epsilon, vec![0.0; k], 500, tol);
            let warm = newton_semidiscrete_ot(&cost_new, &a, &b, epsilon, g_old.clone(), 500, tol);
            assert!(cold.converged && warm.converged, "K={k}: Newton n'a pas convergé au nouveau problème");
            total_cold_iters += cold.iterations;
            total_warm_iters += warm.iterations;
            n_steps_measured += 1;

            if certified_within_basin(&points, &a, &b, epsilon, &y_old, &y_new, &g_old, m_avant) {
                certified_avant += 1;
            }
            if certified_within_basin(&points, &a, &b, epsilon, &y_old, &y_new, &g_old, m_apres) {
                certified_apres += 1;
            }

            y = y_new;
        }

        println!(
            "{:<4} {:>10.3} {:>10.3} {:>7.2}x {:>10}/{:<1} {:>10}/{:<1} {:>10.1} {:>10.1}",
            k,
            m_avant,
            m_apres,
            m_avant / m_apres,
            certified_avant,
            n_lloyd_steps,
            certified_apres,
            n_lloyd_steps,
            total_warm_iters as f64 / n_steps_measured as f64,
            total_cold_iters as f64 / n_steps_measured as f64,
        );
    }

    println!();
    println!("--- Seuil de déplacement certifiable (2m²/(M·L_Y)), au dernier point de chaque trajectoire ---");
    println!("{:<4} {:>16} {:>16} {:>10}", "K", "seuil_avant", "seuil_apres", "gain_seuil");
    println!("{}", "-".repeat(50));
    for &k in &k_values {
        let n = 8 * k;
        let dataset = make_blobs(n, k, 1.0, 42 + k as u64);
        let points = dataset.points.clone();
        let a = vec![1.0 / n as f64; n];
        let b = vec![1.0 / k as f64; k];
        let true_centroids: Vec<Vec<f64>> = {
            let labels = dataset.labels_true.clone().unwrap();
            (0..k)
                .map(|c| {
                    let members: Vec<&Vec<f64>> = points.iter().zip(labels.iter()).filter(|(_, &l)| l as usize == c).map(|(p, _)| p).collect();
                    let d = points[0].len();
                    let mut mean = vec![0.0; d];
                    for m in &members {
                        for j in 0..d {
                            mean[j] += m[j] / members.len() as f64;
                        }
                    }
                    mean
                })
                .collect()
        };
        let mut pairwise_sq: Vec<f64> = Vec::new();
        for i in 0..k {
            for j in (i + 1)..k {
                pairwise_sq.push(euclidean(&true_centroids[i], &true_centroids[j]).powi(2));
            }
        }
        let mean_sep_sq: f64 = if pairwise_sq.is_empty() { 1.0 } else { pairwise_sq.iter().sum::<f64>() / pairwise_sq.len() as f64 };
        let epsilon = 0.12 * mean_sep_sq;

        // Point de fonctionnement représentatif : les vrais centroïdes
        // (proche de ce que produirait la boucle de Lloyd à convergence).
        let y = true_centroids.clone();
        let cost = cost_matrix(&points, &y);
        let g = newton_semidiscrete_ot(&cost, &a, &b, epsilon, vec![0.0; k], 500, tol);
        assert!(g.converged);

        let rho_min = min_responsibility(&cost, &a, &b, epsilon, &g.g);
        let m = strong_concavity_modulus(rho_min, k, epsilon);
        let diam = diam_bound(&points, &[&y]);
        let l_y = gradient_lipschitz_in_y(diam, epsilon);
        let m_avant = hessian_lipschitz_crude(k, epsilon);
        let m_apres = hessian_lipschitz_in_g(k, epsilon);
        let seuil_avant = 2.0 * m * m / (m_avant * l_y);
        let seuil_apres = 2.0 * m * m / (m_apres * l_y);

        println!("{:<4} {:>16.6e} {:>16.6e} {:>9.2}x", k, seuil_avant, seuil_apres, seuil_apres / seuil_avant);
    }
    println!();
    println!("Lecture : au-delà du seuil affiché, la garantie théorique de convergence");
    println!("quadratique ne s'applique plus (Newton peut quand même converger vite en");
    println!("pratique — cf. tableau précédent — mais ce n'est alors plus GARANTI). Le");
    println!("gain de seuil reproduit ici, sur données réelles, le facteur x7.85 annoncé");
    println!("(calculé alors en Python sur les formules seules) pour K=20.");
}
