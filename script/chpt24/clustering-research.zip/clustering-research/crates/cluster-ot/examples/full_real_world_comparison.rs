//! Tableau de comparaison complet, tous les algorithmes de la
//! littérature déjà implémentés + PoWKM (libre, config actuelle :
//! gate MP + plafond n/d) + PoWKM-prescribed + ToMATo+EM hybride, sur
//! les 8 jeux de données réels. Hyperparamètres label-blind (même
//! méthodologie que k_discovery_comparison.rs) pour les algorithmes qui
//! ne prennent pas K en entrée ; K_vrai fourni comme oracle pour ceux
//! qui le prennent (K-Means, Hiérarchique, BIRCH, Spectral — pratique
//! standard, ces méthodes ne DÉCOUVRENT pas K).
//!
//! ```text
//! cargo run --release --example full_real_world_comparison -p cluster-ot -- [--budget N] [--whiten-high-d]
//! ```
use cluster_algos::{Birch, Dbscan, Hdbscan, HierarchicalClustering, KMeans, Linkage, MeanShift, Optics, SpectralClustering};
use cluster_core::{euclidean, ClusterResult, ClusteringAlgorithm, Dataset};
use cluster_metrics::{adjusted_rand_index, normalized_mutual_info};
use cluster_ot::{pca_whiten, PoWKM, PoWKMPrescribed, TomatoHybrid};
use std::collections::HashSet;
use std::fs;
use std::time::{Duration, Instant};

// ---------- chargement des jeux ----------

fn load_sklearn_csv(path: &str, expected_n: usize, expected_d: usize) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut lines = content.lines();
    lines.next();
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for line in lines {
        if line.trim().is_empty() {
            continue;
        }
        let fields: Vec<f64> = line.split(',').map(|s| s.trim().parse::<f64>().unwrap()).collect();
        let (feats, class) = fields.split_at(fields.len() - 1);
        points.push(feats.to_vec());
        labels.push(class[0] as i32);
    }
    assert_eq!(points.len(), expected_n);
    assert_eq!(points[0].len(), expected_d);
    Dataset::new(points, Some(labels), path)
}

fn load_seeds(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap();
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for line in content.lines() {
        if line.trim().is_empty() {
            continue;
        }
        let fields: Vec<f64> = line.split(',').map(|s| s.trim().parse::<f64>().unwrap()).collect();
        let (feats, class) = fields.split_at(fields.len() - 1);
        points.push(feats.to_vec());
        labels.push(class[0] as i32);
    }
    Dataset::new(points, Some(labels), "Seeds (blé)")
}

fn load_sonar(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap();
    let mut lines = content.lines();
    lines.next();
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for line in lines {
        if line.trim().is_empty() {
            continue;
        }
        let fields: Vec<f64> = line.split(',').map(|s| s.trim_matches('"').parse::<f64>().unwrap()).collect();
        let (feats, class) = fields.split_at(fields.len() - 1);
        points.push(feats.to_vec());
        labels.push(class[0] as i32);
    }
    Dataset::new(points, Some(labels), "Sonar (défense/mines vs. roches)")
}

fn load_wholesale(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap();
    let mut lines = content.lines();
    lines.next();
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for line in lines {
        if line.trim().is_empty() {
            continue;
        }
        let fields: Vec<f64> = line.split(',').map(|s| s.trim().parse::<f64>().unwrap()).collect();
        labels.push(fields[0] as i32);
        points.push(fields[2..].to_vec());
    }
    Dataset::new(points, Some(labels), "Wholesale Customers (finance/business)")
}

fn load_german_credit(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap();
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for line in content.lines() {
        if line.trim().is_empty() {
            continue;
        }
        let fields: Vec<f64> = line.split_whitespace().map(|s| s.parse::<f64>().unwrap()).collect();
        let (feats, class) = fields.split_at(fields.len() - 1);
        points.push(feats.to_vec());
        labels.push(class[0] as i32);
    }
    Dataset::new(points, Some(labels), "German Credit")
}

fn load_ionosphere(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap();
    let mut lines = content.lines();
    lines.next();
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for line in lines {
        if line.trim().is_empty() {
            continue;
        }
        let fields: Vec<f64> = line.split(',').map(|s| s.trim_matches('"').parse::<f64>().unwrap()).collect();
        let (feats, class) = fields.split_at(fields.len() - 1);
        points.push(feats.to_vec());
        labels.push(class[0] as i32);
    }
    assert_eq!(points.len(), 351);
    assert_eq!(points[0].len(), 34);
    Dataset::new(points, Some(labels), "Ionosphere")
}

fn standardize(dataset: &Dataset) -> Dataset {
    let n = dataset.points.len();
    let d = dataset.points[0].len();
    let mean: Vec<f64> = (0..d).map(|j| dataset.points.iter().map(|p| p[j]).sum::<f64>() / n as f64).collect();
    let std: Vec<f64> = (0..d)
        .map(|j| {
            let v = dataset.points.iter().map(|p| (p[j] - mean[j]).powi(2)).sum::<f64>() / n as f64;
            v.sqrt().max(1e-12)
        })
        .collect();
    let points: Vec<Vec<f64>> = dataset.points.iter().map(|p| (0..d).map(|j| (p[j] - mean[j]) / std[j]).collect()).collect();
    Dataset::new(points, dataset.labels_true.clone(), dataset.name.clone())
}

// ---------- heuristiques label-blind ----------

fn kth_nn_distances(points: &[Vec<f64>], k: usize) -> Vec<f64> {
    points
        .iter()
        .map(|p| {
            let mut d: Vec<f64> = points.iter().filter(|q| !std::ptr::eq(*q, p)).map(|q| euclidean(p, q)).collect();
            d.sort_by(|a, b| a.partial_cmp(b).unwrap());
            d[(k - 1).min(d.len() - 1)]
        })
        .collect()
}

fn median(mut v: Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = v.len();
    if n % 2 == 0 {
        0.5 * (v[n / 2 - 1] + v[n / 2])
    } else {
        v[n / 2]
    }
}

fn suggest_eps(points: &[Vec<f64>], min_samples: usize) -> f64 {
    median(kth_nn_distances(points, min_samples))
}

fn suggest_bandwidth(points: &[Vec<f64>], quantile: f64) -> f64 {
    let n = points.len();
    let k = ((quantile * n as f64).ceil() as usize).max(1);
    median(kth_nn_distances(points, k))
}

// ---------- exécution avec budget de temps (thread + timeout) ----------

struct Row {
    algo: String,
    found_k: usize,
    ari: f64,
    nmi: f64,
    ms: f64,
    timed_out: bool,
}

fn run_with_budget<F>(name: &str, truth: &[i32], budget: Duration, run: F) -> Row
where
    F: FnOnce() -> ClusterResult + Send + 'static,
{
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let t0 = Instant::now();
        let result = run();
        let _ = tx.send((result, t0.elapsed()));
    });
    match rx.recv_timeout(budget) {
        Ok((result, elapsed)) => Row {
            algo: name.to_string(),
            found_k: result.n_clusters,
            ari: adjusted_rand_index(truth, &result.labels),
            nmi: normalized_mutual_info(truth, &result.labels),
            ms: elapsed.as_secs_f64() * 1000.0,
            timed_out: false,
        },
        Err(_) => Row { algo: name.to_string(), found_k: 0, ari: f64::NAN, nmi: f64::NAN, ms: budget.as_secs_f64() * 1000.0, timed_out: true },
    }
}

fn print_table(dataset_name: &str, true_k: usize, n: usize, d: usize, rows: &[Row]) {
    println!("\n=== {dataset_name} — n={n}, d={d}, K_vrai={true_k} ===");
    println!("{:-<70}", "");
    println!("{:<20} {:>6} {:>8} {:>8} {:>12}", "algorithme", "K", "ARI", "NMI", "temps");
    println!("{:-<70}", "");
    for r in rows {
        if r.timed_out {
            println!("{:<20} {:>6} {:>8} {:>8} {:>10}", r.algo, "—", "—", "—", "TIMEOUT");
        } else {
            println!("{:<20} {:>6} {:>8.3} {:>8.3} {:>10.0}ms", r.algo, r.found_k, r.ari, r.nmi, r.ms);
        }
    }
}

fn run_all_algos(dataset: &Dataset, true_k: usize, seed: u64, budget: Duration) -> Vec<Row> {
    let truth = dataset.labels_true.as_ref().unwrap().clone();
    let points = dataset.points.clone();
    let d = points[0].len();
    let min_samples = 5;
    let eps = suggest_eps(&points, min_samples);
    let bandwidth = suggest_bandwidth(&points, 0.3).max(1e-3);
    let gamma = 1.0 / d as f64;

    let mut rows = Vec::new();

    {
        let ds = dataset.clone();
        rows.push(run_with_budget("K-Means (K oracle)", &truth, budget, move || KMeans::new(true_k, seed).fit(&ds)));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("Ward (K oracle)", &truth, budget, move || HierarchicalClustering::new(true_k, Linkage::Ward).fit(&ds)));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("BIRCH (K oracle)", &truth, budget, move || Birch::new(0.5, 50, true_k).fit(&ds)));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("Spectral (K oracle)", &truth, budget, move || SpectralClustering::new(true_k, gamma, seed).fit(&ds)));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("DBSCAN", &truth, budget, move || Dbscan::new(eps, min_samples).fit(&ds)));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("HDBSCAN", &truth, budget, move || Hdbscan::new(min_samples, min_samples).fit(&ds)));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("OPTICS", &truth, budget, move || Optics::new(eps, min_samples, eps).fit(&ds)));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("Mean-Shift", &truth, budget, move || MeanShift::new(bandwidth).fit(&ds)));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("PoWKM libre (mp_gate+n/d=2)", &truth, budget, move || {
            let mut m = PoWKM::new(seed);
            m.beta_max = 6.0;
            m.mp_significance_gate = true;
            m.min_samples_per_dim = 2.0;
            m.fit(&ds)
        }));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("PoWKM-prescribed", &truth, budget, move || {
            let mut m = PoWKMPrescribed::new(seed);
            m.beta_max = 6.0;
            m.fit(&ds)
        }));
    }
    {
        let ds = dataset.clone();
        rows.push(run_with_budget("ToMATo+EM hybride", &truth, budget, move || TomatoHybrid::new(seed).fit(&ds)));
    }

    rows
}

fn main() {
    let seed = 244;
    let args: Vec<String> = std::env::args().collect();
    let budget_secs: u64 = args.iter().position(|a| a == "--budget").and_then(|i| args.get(i + 1)).and_then(|s| s.parse().ok()).unwrap_or(30);
    let budget = Duration::from_secs(budget_secs);
    let whiten_high_d = args.iter().any(|a| a == "--whiten-high-d");

    let all: Vec<Dataset> = vec![
        standardize(&load_sklearn_csv("data/real/iris.csv", 150, 4)),
        standardize(&load_sklearn_csv("data/real/wine.csv", 178, 13)),
        standardize(&load_seeds("data/real/seeds.csv")),
        standardize(&load_sklearn_csv("data/real/breast_cancer.csv", 569, 30)),
        standardize(&load_sonar("data/real/sonar.csv")),
        standardize(&load_wholesale("data/real/wholesale.csv")),
        standardize(&load_german_credit("data/real/german_credit_numeric.txt")),
        standardize(&load_ionosphere("data/real/ionosphere.csv")),
    ];

    for dataset in &all {
        let truth = dataset.labels_true.as_ref().unwrap();
        let true_k = truth.iter().collect::<HashSet<_>>().len();
        let d = dataset.points[0].len();
        let use_dataset = if whiten_high_d && d > 20 { pca_whiten(dataset) } else { dataset.clone() };
        eprintln!(">> {} (n={}, d={d})...", dataset.name, dataset.points.len());
        let rows = run_all_algos(&use_dataset, true_k, seed, budget);
        print_table(&dataset.name, true_k, dataset.points.len(), d, &rows);
    }
}
