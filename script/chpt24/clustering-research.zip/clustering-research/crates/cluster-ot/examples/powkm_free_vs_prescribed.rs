//! Comparaison directe des deux versions de PoWKM sur le même banc
//! d'essai que le résultat empirique principal (`stress_overlap.rs`) :
//! qualité du clustering (K, ARI, NMI) et temps d'exécution, plus — pour
//! la variante à poids prescrits — le détail de l'usage du solveur
//! Newton (itérations warm-start vs à froid, filet de sécurité Sinkhorn).
//!
//! Les deux variantes partagent le même squelette (recuit sur β, cascade
//! de bifurcations, sélection du plateau le plus stable) ; seul l'E-step
//! diffère (Gibbs à poids libres vs Newton à poids prescrits +
//! warm-start). Voir `powkm.rs` et `powkm_prescribed.rs` pour le détail.
//!
//! `cargo run --release --example powkm_free_vs_prescribed -p cluster-ot`

use cluster_core::{ClusterResult, ClusteringAlgorithm, Dataset};
use cluster_metrics::{adjusted_rand_index, normalized_mutual_info};
use cluster_ot::{PoWKMPrescribed, PoWKM};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use rand_distr::Normal;
use std::f64::consts::PI;

/// Même générateur que `stress_overlap.rs` (dupliqué à l'identique, pas
/// partagé — chaque exemple reste autonome dans ce workspace).
fn make_blobs_at_separation(n_per_cluster: usize, k: usize, std: f64, separation_in_stds: f64, seed: u64) -> Dataset {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let chord_target = separation_in_stds * std;
    let radius = chord_target / (2.0 * (PI / k as f64).sin());
    let centers: Vec<(f64, f64)> = (0..k)
        .map(|i| {
            let theta = 2.0 * PI * i as f64 / k as f64;
            (radius * theta.cos(), radius * theta.sin())
        })
        .collect();
    let normal = Normal::new(0.0, std).unwrap();
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for (ci, &(cx, cy)) in centers.iter().enumerate() {
        for _ in 0..n_per_cluster {
            points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
            labels.push(ci as i32);
        }
    }
    Dataset::new(points, Some(labels), format!("sep{separation_in_stds}"))
}

fn cell(r: &ClusterResult, truth: &[i32]) -> String {
    let ari = adjusted_rand_index(truth, &r.labels);
    let nmi = normalized_mutual_info(truth, &r.labels);
    format!("K={:<2} ARI={ari:.2} NMI={nmi:.2} {:>6.1}ms", r.n_clusters, r.runtime.as_secs_f64() * 1000.0)
}

fn main() {
    let separations = [6.0, 5.0, 4.0, 3.0, 2.5, 2.0];
    let k_true = 3;
    let n_per_cluster = 60;
    let std = 1.0;
    let seed = 42;
    let beta_max = 8.0;

    println!("=== Qualité du clustering : PoWKM (poids libres) vs PoWKM-prescribed (Newton + warm-start) ===\n");
    println!("{:<6} | {:>28} | {:>28}", "sep(σ)", "PoWKM (libre)", "PoWKM-prescribed");
    println!("{}", "-".repeat(70));

    let mut all_stats: Vec<(f64, cluster_ot::NewtonUsageStats)> = Vec::new();

    for &sep in &separations {
        let data = make_blobs_at_separation(n_per_cluster, k_true, std, sep, seed);
        let truth = data.labels_true.as_ref().unwrap();

        let mut free = PoWKM::new(7);
        free.beta_max = beta_max;
        let r_free = free.fit(&data);

        let mut prescribed = PoWKMPrescribed::new(7);
        prescribed.beta_max = beta_max;
        prescribed.track_cold_start_comparison = true;
        let r_prescribed = prescribed.fit(&data);

        println!("{:<6} | {:>28} | {:>28}", sep, cell(&r_free, truth), cell(&r_prescribed, truth));

        all_stats.push((sep, prescribed.last_fit_stats.clone()));
    }

    println!("\n(K vrai=3 partout ; hyperparamètres génériques par défaut des deux variantes)\n");

    println!("=== Usage du solveur Newton (PoWKM-prescribed uniquement) ===\n");
    println!("{:<6} | {:>12} | {:>12} | {:>10} | {:>10}", "sep(σ)", "warm (iters)", "froid (iters)", "réduction", "fallbacks");
    println!("{}", "-".repeat(60));
    for (sep, stats) in &all_stats {
        let cold = stats.total_iterations_cold.unwrap_or(0);
        let reduction = if cold > 0 { 100.0 * (1.0 - stats.total_iterations_warm as f64 / cold as f64) } else { 0.0 };
        println!("{:<6} | {:>12} | {:>12} | {:>9.1}% | {:>10}", sep, stats.total_iterations_warm, cold, reduction, stats.total_sinkhorn_fallbacks);
    }

    println!("\nLecture : \"warm\"/\"froid\" = itérations Newton totales sur tout le run");
    println!("(recuit + cascade de bifurcations), mesurées en parallèle sur la même");
    println!("trajectoire de centres (le froid ne pilote jamais l'algorithme, mesure");
    println!("seulement le compteur). \"fallbacks\" = nombre de fois où le hessien de");
    println!("Newton était numériquement singulier et où Sinkhorn a pris le relais");
    println!("(attendu : rare, uniquement à ε très petit en fin de recuit).");
}
