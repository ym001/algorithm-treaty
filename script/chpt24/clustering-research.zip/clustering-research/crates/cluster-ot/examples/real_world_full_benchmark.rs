//! Comparaison de PoWKM (libre et prescrit) contre tous les algorithmes de
//! la littérature déjà implémentés dans ce workspace, **augmentés de deux
//! algorithmes récents (post-2020) de découverte automatique de K** ---
//! cf. section "Algorithmes récents" ci-dessous --- sur l'ensemble des
//! jeux de données **réels** disponibles dans
//! `/home/yves/Nextcloud/book/traité_d_algorithmique/article/data_cluster/`
//! (chemin en dur, cf. `main()`) ---
//! fusion de `real_world_finance_defense.rs` et `real_world_extended_benchmark.rs`
//! (8 jeux) avec **7 nouveaux jeux UCI** téléchargés pour étendre la
//! couverture expérimentale du papier (objectif JMLR : 20-30 jeux réels).
//!
//! ## Algorithmes récents (post-2020) de découverte automatique de K
//!
//! Choisis après recherche bibliographique (pas inventés, pas de détail
//! d'algorithme deviné) parmi les méthodes post-2020 les mieux établies :
//!
//! - **DynMSC** (Dynamic Medoid Silhouette Clustering ; Lenssen &
//!   Schubert, version étendue de *Clustering by Direct Optimization of
//!   the Medoid Silhouette*, SISAP 2022, LNCS 13590 ; arXiv:2309.03751,
//!   2023 --- Erich Schubert est également l'auteur de FastPAM et de
//!   "DBSCAN revisited, revisited", référence bien établie du domaine).
//!   Principe : optimise directement l'Average Medoid Silhouette (AMS,
//!   une variante médoïde de l'indice de silhouette classique, caractérisée
//!   axiomatiquement dans le papier comme mesure de qualité valide) pour
//!   chaque K candidat, retient le K qui maximise l'AMS obtenue.
//!   Approche entièrement **déterministe** (pas de rééchantillonnage
//!   Monte-Carlo), ce qui élimine par construction la classe de fragilité
//!   rencontrée avec CNAK (voir ci-dessous). Simplification assumée et
//!   documentée par rapport à l'algorithme complet du papier : nous
//!   utilisons une optimisation par médoïdes alternée (Maranzana 1963,
//!   citée dans le papier comme alternative légitime plus simple à PAM
//!   SWAP) plutôt que FasterMSC, la variante à recherche incrémentale par
//!   échange que proposent les auteurs --- les deux méthodes optimisent
//!   le **même objectif** (AMS), FasterMSC n'apportant qu'un gain de
//!   vitesse (jusqu'à O(k²) plus rapide dans leurs mesures), non critique
//!   pour nos tailles de jeux (n≤625). Par construction, l'AMS n'est pas
//!   définie pour K=1 (pas de "second plus proche médoïde"), donc K=1
//!   n'est jamais retourné --- cohérent avec la boucle `while k > 2` de
//!   l'algorithme 5 (DynMSC) du papier original, qui exclut K=1 pour la
//!   même raison structurelle, pas une limite que nous introduisons.
//!   **Remplace un essai initial avec CNAK** (Cluster Number Assisted
//!   K-means ; Saha & Mukherjee, *Pattern Recognition* 110:107625, 2021),
//!   abandonné après diagnostic honnête : une première implémentation
//!   trouvait systématiquement K=1 sur les 15 jeux réels, y compris Iris
//!   où le papier original rapporte explicitement trouver K=3
//!   correctement --- signal clair d'un défaut d'implémentation. Après
//!   comparaison avec `CNAK.py`, l'implémentation de référence des
//!   auteurs (github.com/Jayasree-Saha/CNAK, récupérée et lue en
//!   intégralité), un bug précis a été identifié et corrigé
//!   (`sklearn.cluster.KMeans(n_init=20)` dans la référence contre un
//!   seul essai K-means++ dans notre première version, biaisant
//!   systématiquement vers K=1) et validé sur données synthétiques (K=3
//!   exact au lieu de K=1 systématique). Malgré cette amélioration
//!   démontrée en synthétique, le problème persistait sur les 15 jeux
//!   réels après correctif (K=1 encore trouvé partout) --- plutôt que de
//!   continuer à corriger un algorithme dont l'implémentation restait
//!   fragile sur données réelles malgré un diagnostic sérieux, CNAK a été
//!   abandonné au profit de DynMSC.
//! - **DenMune** (Abbas, El-Zoghabi & Shoukry, *Pattern Recognition*
//!   109:107589, 2021). Principe : voisinage mutuel de taille K (un seul
//!   paramètre) ; les points dont le nombre de "votes" reçus (taille de
//!   la liste de référence) excède K sont des points forts (graines) qui
//!   forment le squelette des clusters par fusion des ensembles de plus
//!   proches voisins mutuels qui se recoupent (implémenté ici par
//!   union-find, équivalent aux Algorithmes 1-2 du papier, section 3) ;
//!   les points faibles restants sont assignés au cluster avec lequel ils
//!   partagent le plus de voisins mutuels, ou classés bruit s'ils n'en
//!   partagent aucun (Algorithme 3). Implémentation directement dans
//!   l'espace des variables standardisées d'origine plutôt qu'après
//!   réduction t-SNE en 2D : le papier utilise t-SNE comme choix
//!   d'expérimentation pour comparer équitablement plusieurs méthodes en
//!   2D (section 4.1), pas comme exigence mathématique de l'algorithme
//!   (Algorithmes 1-3, section 3, opèrent sur la matrice de distances
//!   quelle que soit la dimension) ; cette déviation assumée est
//!   cohérente avec le traitement du reste de ce fichier, où toutes les
//!   méthodes tournent sur les mêmes variables standardisées, sans
//!   réduction de dimension spécifique à une méthode.
//!
//! Les deux implémentations ont été vérifiées sur des jeux synthétiques
//! (mélanges gaussiens à 3 et 5 clusters bien séparés, structure à la
//! Iris avec chevauchement partiel) avant d'être exécutées sur les
//! données réelles : DynMSC retrouve K=3 et ARI=1.00 sur les blobs bien
//! séparés, et K=2 (ARI=0.568) sur la structure à chevauchement partiel
//! --- identique au résultat de Mean-Shift sur le vrai Iris ; DenMune
//! retrouve K exactement avec ARI≥0.92 sur les cas synthétiques séparés.
//!
//! ## Jeux de données (18 au total)
//!
//! **Déjà présents (8)** : Iris, Wine, Seeds, Breast Cancer, Sonar,
//! Wholesale, German Credit, Ionosphere --- cf. la documentation des
//! fichiers d'origine pour le détail de chacun.
//!
//! **Nouveaux (7)**, tous UCI, format vérifié à partir d'extraits fournis
//! par l'utilisateur (pas deviné) avant écriture des parseurs :
//!
//! - **Abalone** (Nash et al. 1994, UCI), ormeaux. `Sex` (M/F/I, 3
//!   modalités) sert de vérité terrain, par analogie avec le traitement de
//!   `Channel` pour Wholesale ; les 7 mesures physiques continues (Length,
//!   Diameter, Height, Whole/Shucked/Viscera/Shell weight) sont les
//!   variables de clustering. `Rings` (dernière colonne) est **exclu** ---
//!   c'est la cible de la tâche de régression d'origine (âge), pas une
//!   variable de clustering, même logique que l'exclusion de `Region` pour
//!   Wholesale.
//! - **Balance Scale** (Siegler 1976, UCI), 625 configurations d'une
//!   balance à 2 bras. Classe en 1ère colonne (L/B/R : bras gauche plus
//!   lourd / équilibré / bras droit plus lourd, 3 modalités), 4 variables
//!   entières (poids et distance de chaque côté).
//! - **Ecoli** (Nakai/Horton, UCI), localisation de protéines. 1ère colonne
//!   = nom de séquence (ignoré), 7 variables continues, dernière colonne =
//!   classe textuelle (site de localisation : `cp`, `im`, `pp`, etc.).
//! - **Glass Identification** (Evett & Spiegelman 1987, UCI). 1ère colonne
//!   = Id (ignoré), 9 variables continues (indice de réfraction +
//!   composition chimique), dernière colonne = type de verre (entier,
//!   6 classes présentes sur 7 possibles : la classe 4 est absente de ce
//!   jeu, phénomène documenté dans la littérature UCI, pas une erreur de
//!   chargement).
//! - **Heart Disease (Cleveland)** (Detrano et al. 1989, UCI). 13 variables
//!   cliniques, dernière colonne = `num` (sévérité, 0=absence à 4=sévère,
//!   utilisé tel quel comme vérité terrain multi-classe, cohérent avec le
//!   traitement des autres jeux du fichier). Quelques lignes contiennent
//!   des valeurs manquantes encodées `?` (colonnes `ca`/`thal`) --- ces
//!   lignes sont éliminées, pratique standard pour ce jeu.
//! - **Yeast** (Nakai/Horton, UCI), même famille qu'Ecoli. 1ère colonne =
//!   nom de séquence (ignoré), 8 variables continues, dernière colonne =
//!   classe textuelle (localisation subcellulaire, jusqu'à 10 modalités).
//! - **Zoo** (Forsyth 1990, UCI). 1ère colonne = nom d'animal (ignoré),
//!   variables intermédiaires (attributs binaires + nombre de pattes),
//!   **dernière** colonne = type d'animal (entier, 7 classes). Le nombre
//!   exact de colonnes intermédiaires n'est pas fixé en dur dans le
//!   parseur (seules la position `première`/`dernière` comptent), pour ne
//!   pas dépendre d'un comptage de colonnes qui pourrait varier selon la
//!   source de téléchargement.
//!
//! **3 nouveaux jeux médicaux**, choisis délibérément pour leur ratio
//! n/d faible --- le régime où le rétrécissement Ledoit-Wolf conditionnel
//! de `PoWKMPrescribed::use_shrinkage_split_test` a démontré un gain net
//! sur les 15 jeux précédents (Sonar, Zoo), permettant une comparaison
//! ciblée et honnête plutôt qu'une moyenne diluée sur des jeux où ce
//! mécanisme n'a structurellement aucune raison de jouer. **SPECTF Heart
//! et Parkinsons, choisis dans une première version sur le seul critère
//! n/d, ont été retirés après un run réel** : les deux montraient un
//! échec uniforme de TOUTES les méthodes testées, y compris K-Means à K
//! vrai (ARI négatif) --- un signal de jeu intrinsèquement difficile pour
//! toute méthode euclidienne (confirmé a posteriori dans la littérature :
//! SPECTF est explicitement documenté comme résistant aux méthodes
//! conventionnelles même en classification *supervisée*), pas un signal
//! utile pour différencier des méthodes de clustering entre elles.
//! Remplacés par Breast Tissue et Dermatology, sélectionnés cette fois en
//! vérifiant des résultats de clustering *non supervisé* documentés dans
//! la littérature, pas seulement le ratio n/d :
//!
//! - **Arrhythmia** (Guvenir et al. 1998, UCI). ECG, 452 patients, 279
//!   variables, classe en dernière colonne (16 modalités : 1=normal,
//!   2-15=types d'arythmie, 16=non classifiés ; plusieurs classes ne
//!   comptent que 2-3 patients). Valeurs manquantes `?` --- **colonnes**
//!   éliminées (pas les lignes, cf. correctif documenté sur
//!   `load_arrhythmia` ci-dessous), 452 lignes conservées, 279→252
//!   variables. n/d≈1.8, le ratio le plus extrême de tous les jeux de ce
//!   fichier --- un vrai test de stress plutôt qu'une victoire garantie.
//! - **Breast Tissue** (Jossinet, UCI). Impédance électrique de tissu
//!   mammaire, 106 échantillons, 9 variables continues, classe (texte :
//!   car/fad/mas/gla/con/adi) en 2e colonne (1ère = numéro de cas,
//!   ignoré). ~92% de précision de classification rapportée dans l'étude
//!   originale, cité comme référence de clustering dans la littérature.
//!   **Fichier source natif `.xls`**, à convertir en CSV avant usage
//!   (onglet "Data" uniquement). n/d≈11.8.
//! - **Dermatology** (Ilter & Guvenir, UCI). 366 patients (358 après
//!   élimination des 8 lignes à valeur d'Age manquante, valeur citée
//!   explicitement dans la littérature), 34 variables (33 cliniques +
//!   Age), classe en dernière colonne (35e, 6 modalités). ARI jusqu'à
//!   0.73 rapporté avec FAMD dans la littérature récente (2024-2025) ---
//!   benchmark de clustering établi, pas seulement de classification.
//!   n/d≈10.5.
//!
//! **2 jeux supplémentaires (20 au total)**, sélectionnés sur un critère
//! **neutre et documenté avant tout run** --- combler un angle mort du
//! plan d'expérience (n, d, K, équilibre des classes) parmi les 16 jeux
//! actifs, indépendamment du résultat attendu pour PoWKM-prescribed. À
//! cette occasion, Wholesale et Ionosphere ont été retirés des groupes
//! actifs (`run_group`, cf. `main()`) ; les parseurs et données restent
//! présents dans ce fichier, non supprimés, pour ne pas effacer de trace :
//!
//! - **Image Segmentation** (Vision Group, Univ. of Massachusetts, UCI
//!   id=50). 2310 instances (fusion train 210 + test 2100), 19 variables
//!   continues (attributs de région d'image : centroïde, densité de
//!   lignes, contraste, couleur RGB dérivée), classe en 1ère colonne (7
//!   types de scène, **parfaitement équilibrés** : 330 par classe).
//!   Comble l'angle mort "n grand (>2000) + classes équilibrées",
//!   totalement absent des 16 jeux actifs.
//! - **HCV Data** (Hoffmann et al. 2018 ; Lichtinghagen et al. 2013, UCI
//!   id=571). 615 patients bruts, Age + Sexe (encodé 0/1) + 10 variables
//!   biologiques continues (ALB, ALP, ALT, AST, BIL, CHE, CHOL, CREA,
//!   GGT, PROT), classe = stade (donneur sain / suspect / hépatite /
//!   fibrose / cirrhose, 5 modalités). Valeurs manquantes éparses (`NA`,
//!   surtout colonne ALP) éliminées par ligne, n final < 615. Comble
//!   l'angle mort "déséquilibre de classes plus extrême que tout jeu
//!   médical déjà présent" (majorité écrasante de donneurs sains), dans
//!   un domaine médical distinct d'Arrhythmia/Breast Tissue/Dermatology.
//!
//! ## Méthodologie
//!
//! Identique aux fichiers d'origine : standardisation z-score, aucun
//! hyperparamètre choisi en regardant les labels pour les méthodes à
//! découverte de K, K vrai fourni aux méthodes qui l'exigent. PoWKM libre
//! reste désactivé par défaut sur tous les jeux (cf. justification dans
//! `real_world_finance_defense.rs` : le recuit complet sur β n'est pas
//! encore optimisé au-delà de n~300 en dimension modérée) ; seul PoWKM
//! prescrit (K vrai en entrée) est testé pour la comparaison ARI/NMI à K
//! fixé, comme dans les fichiers existants. Le blanchiment PCA a été
//! testé puis retiré : sur les 15 jeux, il aidait nettement sur 2
//! d'entre eux et nuisait sur 9 (souvent fortement, ex. Breast Cancer
//! −0.46 ARI) --- signal net et cohérent, pas la peine de l'encombrer le
//! pipeline pour un correctif qui ne généralise pas. Les jeux les plus
//! grands (Abalone n=4177, Yeast n=1484, German Credit n=1000) sont
//! sous-échantillonnés pour rester dans un temps d'exécution raisonnable
//! pour l'ensemble des 11 méthodes comparées --- limite honnête et
//! documentée, pas un artefact caché (même principe que le
//! sous-échantillonnage déjà appliqué à German Credit dans
//! `real_world_finance_defense.rs`).
//!
//! Les tailles (`expected_n`) indiquées dans les parseurs sont les tailles
//! canoniques UCI connues ; un écart n'entraîne qu'un **avertissement**
//! (pas un arrêt), pour ne pas bloquer l'exécution des autres jeux si un
//! fichier téléchargé diffère légèrement (ligne d'en-tête ajoutée, mirroir
//! différent, etc.) --- si un avertissement apparaît, vérifier le fichier
//! correspondant avant d'interpréter les résultats de ce jeu.
//!
//! Exécuter depuis la racine du dépôt :
//! ```text
//! cargo run --release --example real_world_full_benchmark -p cluster-ot
//! ```

use cluster_algos::{Birch, Dbscan, Hdbscan, HierarchicalClustering, KMeans, Linkage, MeanShift, Optics, SpectralClustering};
use cluster_core::{euclidean, ClusterResult, ClusteringAlgorithm, Dataset};
use cluster_metrics::{adjusted_rand_index, normalized_mutual_info};
use cluster_ot::PoWKMPrescribed;
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use std::collections::{HashMap, HashSet};
use std::fs;

// ============================================================================
// Utilitaires génériques de parsing
// ============================================================================

/// Découpe une ligne sur virgule OU espace(s) (un ou plusieurs), et retire
/// les guillemets éventuels --- gère indifféremment les variantes
/// "vrai CSV" et "colonnes alignées par espaces" sans avoir à deviner
/// laquelle a été téléchargée.
fn tokenize(line: &str) -> Vec<String> {
    line.split(|c: char| c == ',' || c.is_whitespace())
        .map(|s| s.trim_matches('"').trim())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .collect()
}

/// Convertit un vecteur d'étiquettes textuelles (ex. `"cp"`, `"M"`, `"3"`)
/// en entiers `0..k`, par ordre alphabétique des chaînes distinctes ---
/// déterministe, indépendant de l'ordre d'apparition dans le fichier.
fn label_to_int_map(raw: &[String]) -> Vec<i32> {
    let mut distinct: Vec<String> = raw.to_vec();
    distinct.sort();
    distinct.dedup();
    let map: HashMap<&str, i32> = distinct.iter().enumerate().map(|(i, s)| (s.as_str(), i as i32)).collect();
    raw.iter().map(|s| map[s.as_str()]).collect()
}

/// Avertit (sans arrêter le programme) si le nombre de lignes/colonnes
/// parsées diffère de la valeur canonique UCI attendue.
fn check_shape(name: &str, path: &str, n: usize, d: usize, expected_n: usize, expected_d: usize) {
    if n != expected_n {
        eprintln!("ATTENTION [{name}] {path} : {expected_n} lignes attendues (taille UCI canonique), {n} trouvées --- vérifier le fichier avant d'interpréter les résultats de ce jeu.");
    }
    if d != expected_d {
        eprintln!("ATTENTION [{name}] {path} : {expected_d} variables attendues, {d} trouvées --- vérifier le fichier avant d'interpréter les résultats de ce jeu.");
    }
}

/// Chargeur générique robuste pour les jeux "features + classe en 1ère ou
/// dernière colonne" dont le format exact n'est pas garanti d'avance : ni
/// la position de la classe (Iris/Seeds/Sonar/Ionosphere l'ont en
/// dernière colonne, mais le format UCI canonique de Wine l'a en
/// **première** colonne --- diagnostiqué après coup sur le run réel de
/// l'utilisateur : la version qui supposait toujours "dernière colonne"
/// prenait par erreur une variable continue pour la classe, produisant
/// ~121 "classes" distinctes sur 178 lignes au lieu de 3), ni le
/// caractère déjà-numérique ou textuel de la classe, ni la présence d'une
/// ligne d'en-tête/métadonnées. Stratégie : essayer les deux positions,
/// et retenir celle qui donne le plus petit nombre de modalités
/// distinctes --- une vraie colonne de classe a toujours un petit nombre
/// de modalités, à la différence d'une variable continue prise à tort
/// pour la classe, qui en produit presque autant que de lignes. Le choix
/// retenu est toujours affiché (`colonne détectée : ...`) pour permettre
/// une vérification visuelle. Ne devine jamais silencieusement au-delà de
/// cette heuristique explicite : un échec de parsing des deux côtés
/// provoque un arrêt explicite plutôt qu'une corruption silencieuse.
fn load_labelled_csv(path: &str, dataset_name: &str, expected_n: usize, expected_d: usize) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let rows: Vec<Vec<String>> = content.lines().map(tokenize).filter(|t| t.len() >= 2).collect();
    if rows.is_empty() {
        panic!("{dataset_name} ({path}) : aucune ligne exploitable (>=2 champs) trouvée.");
    }

    let try_position = |label_last: bool| -> Option<(Vec<Vec<f64>>, Vec<String>, usize)> {
        let mut points = Vec::new();
        let mut raw_labels = Vec::new();
        let mut skipped_header = false;
        for (i, tok) in rows.iter().enumerate() {
            let (feat_tok, label_tok): (&[String], String) = if label_last {
                let (f, l) = tok.split_at(tok.len() - 1);
                (f, l[0].clone())
            } else {
                (&tok[1..], tok[0].clone())
            };
            let parsed: Result<Vec<f64>, _> = feat_tok.iter().map(|s| s.parse::<f64>()).collect();
            match parsed {
                Ok(feats) => {
                    points.push(feats);
                    raw_labels.push(label_tok);
                }
                Err(_) if i < 2 && !skipped_header => skipped_header = true,
                Err(_) => return None,
            }
        }
        if points.is_empty() {
            return None;
        }
        let mut distinct: Vec<&String> = raw_labels.iter().collect();
        distinct.sort();
        distinct.dedup();
        let n_distinct = distinct.len();
        Some((points, raw_labels, n_distinct))
    };

    let (points, raw_labels, chosen_col, n_distinct) = match (try_position(true), try_position(false)) {
        (Some((p_l, r_l, d_l)), Some((p_f, r_f, d_f))) => {
            if d_f < d_l {
                (p_f, r_f, "première", d_f)
            } else {
                (p_l, r_l, "dernière", d_l)
            }
        }
        (Some((p_l, r_l, d_l)), None) => (p_l, r_l, "dernière", d_l),
        (None, Some((p_f, r_f, d_f))) => (p_f, r_f, "première", d_f),
        (None, None) => panic!("{dataset_name} ({path}) : échec de parsing avec la classe en première ET en dernière colonne --- format inattendu, à inspecter manuellement."),
    };

    if (n_distinct as f64) > 0.2 * points.len() as f64 {
        eprintln!(
            "ATTENTION [{dataset_name}] {path} : {n_distinct} modalités distinctes détectées en colonne {chosen_col} sur {} lignes --- ressemble à une variable continue prise à tort pour la classe, vérifier le fichier.",
            points.len()
        );
    } else {
        eprintln!("{dataset_name} ({path}) : classe détectée en colonne {chosen_col} ({n_distinct} modalités).");
    }

    let all_numeric_int = raw_labels.iter().all(|s| s.parse::<i32>().is_ok());
    let labels: Vec<i32> = if all_numeric_int {
        raw_labels.iter().map(|s| s.parse::<i32>().unwrap()).collect()
    } else {
        label_to_int_map(&raw_labels)
    };
    check_shape(dataset_name, path, points.len(), points[0].len(), expected_n, expected_d);
    Dataset::new(points, Some(labels), dataset_name)
}

// ============================================================================
// DynMSC (Lenssen & Schubert ; version etendue de "Clustering by Direct
// Optimization of the Medoid Silhouette", SISAP 2022, LNCS 13590 ;
// arXiv:2309.03751, 2023) --- cf. doc du module pour le detail complet.
// ============================================================================

/// K-medoides par alternance (Maranzana 1963, alternative simple a PAM
/// SWAP citee dans Lenssen & Schubert) : assigne au medoide le plus
/// proche, puis pour chaque cluster choisit comme nouveau medoide le
/// point qui minimise la somme des distances aux autres points du
/// cluster. Simplification assumee par rapport a DynMSC/FasterMSC (qui
/// utilisent une recherche SWAP incrementale bien plus rapide pour le
/// meme objectif AMS) --- la vitesse n'etant pas critique pour nos
/// tailles de jeux (n<=625), on privilegie ici la simplicite.
fn kmedoids_alternating(points: &[Vec<f64>], k: usize, rng: &mut ChaCha8Rng, max_iter: usize) -> Vec<usize> {
    let n = points.len();
    let k = k.min(n);
    let mut medoids: Vec<usize> = Vec::with_capacity(k);
    medoids.push(rng.gen_range(0..n));
    let mut dist2 = vec![f64::INFINITY; n];
    for _ in 1..k {
        for i in 0..n {
            let d2 = euclidean(&points[i], &points[*medoids.last().unwrap()]).powi(2);
            if d2 < dist2[i] {
                dist2[i] = d2;
            }
        }
        let total: f64 = dist2.iter().sum();
        if total <= 0.0 {
            medoids.push(rng.gen_range(0..n));
            continue;
        }
        let target = rng.gen::<f64>() * total;
        let mut acc = 0.0;
        let mut chosen = n - 1;
        for i in 0..n {
            acc += dist2[i];
            if acc >= target {
                chosen = i;
                break;
            }
        }
        medoids.push(chosen);
    }

    for _ in 0..max_iter {
        let mut assign = vec![0usize; n];
        for i in 0..n {
            let mut best = 0;
            let mut best_d = f64::INFINITY;
            for (c, &m) in medoids.iter().enumerate() {
                let dd = euclidean(&points[i], &points[m]);
                if dd < best_d {
                    best_d = dd;
                    best = c;
                }
            }
            assign[i] = best;
        }
        let mut changed = false;
        for c in 0..k {
            let members: Vec<usize> = (0..n).filter(|&i| assign[i] == c).collect();
            if members.is_empty() {
                continue;
            }
            let mut best_member = members[0];
            let mut best_cost = f64::INFINITY;
            for &cand in &members {
                let cost: f64 = members.iter().map(|&j| euclidean(&points[cand], &points[j])).sum();
                if cost < best_cost {
                    best_cost = cost;
                    best_member = cand;
                }
            }
            if best_member != medoids[c] {
                medoids[c] = best_member;
                changed = true;
            }
        }
        if !changed {
            break;
        }
    }
    medoids
}

/// Average Medoid Silhouette (Lenssen & Schubert) : AMS = moyenne sur
/// tous les points de 1 - d1(i)/d2(i), ou d1 = distance au medoide le
/// plus proche, d2 = distance au second plus proche --- non defini pour
/// K=1 (pas de "second plus proche"), d'ou k_min=2 dans dynmsc()
/// ci-dessous, cohérent avec la boucle "while k > 2" de l'algorithme 5
/// (DynMSC) du papier, qui exclut structurellement K=1 de la comparaison
/// pour la meme raison.
fn average_medoid_silhouette(points: &[Vec<f64>], medoids: &[usize]) -> f64 {
    let n = points.len();
    if medoids.len() < 2 {
        return 0.0;
    }
    let mut total = 0.0;
    for i in 0..n {
        let mut dists: Vec<f64> = medoids.iter().map(|&m| euclidean(&points[i], &points[m])).collect();
        dists.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let d1 = dists[0];
        let d2 = dists[1];
        let s = if d2 > 0.0 { 1.0 - d1 / d2 } else { 1.0 };
        total += s;
    }
    total / n as f64
}

/// DynMSC --- pour chaque K de k_min a k_max, optimise les medoides pour
/// maximiser l'Average Medoid Silhouette (AMS), retient le K avec l'AMS
/// la plus elevee. Remplace un essai initial avec CNAK (Saha & Mukherjee
/// 2021), abandonne apres diagnostic : une premiere version (sans
/// redemarrages K-means++) trouvait systematiquement K=1 sur les 15 jeux
/// reels ; corrigee (n_init=10, comparaison avec l'implementation de
/// reference CNAK.py des auteurs, recuperee et lue en integralite sur
/// github.com/Jayasree-Saha/CNAK) mais le probleme persistait sur
/// donnees reelles malgre une nette amelioration sur donnees synthetiques
/// --- feuille de route abandonnee au profit de DynMSC, dont la nature
/// deterministe (pas de rééchantillonnage Monte-Carlo) élimine cette
/// classe de fragilité par construction.
fn dynmsc(points: &[Vec<f64>], k_min: usize, k_max: usize, seed: u64) -> Vec<i32> {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let mut best_ams = f64::NEG_INFINITY;
    let mut best_medoids: Vec<usize> = Vec::new();
    for k in k_min..=k_max.min(points.len()) {
        let medoids = kmedoids_alternating(points, k, &mut rng, 100);
        let ams = average_medoid_silhouette(points, &medoids);
        if ams > best_ams {
            best_ams = ams;
            best_medoids = medoids;
        }
    }
    points
        .iter()
        .map(|p| {
            best_medoids
                .iter()
                .enumerate()
                .min_by(|(_, &a), (_, &b)| euclidean(p, &points[a]).partial_cmp(&euclidean(p, &points[b])).unwrap())
                .map(|(i, _)| i as i32)
                .unwrap_or(0)
        })
        .collect()
}


/// Structure union-find minimale pour la construction du squelette de
/// clusters de DenMune (fusion des ensembles seed∪MNN qui se recoupent).
struct UnionFind {
    parent: Vec<usize>,
}
impl UnionFind {
    fn new(n: usize) -> Self {
        Self { parent: (0..n).collect() }
    }
    fn find(&mut self, x: usize) -> usize {
        if self.parent[x] != x {
            self.parent[x] = self.find(self.parent[x]);
        }
        self.parent[x]
    }
    fn union(&mut self, a: usize, b: usize) {
        let (ra, rb) = (self.find(a), self.find(b));
        if ra != rb {
            self.parent[ra] = rb;
        }
    }
}

/// DenMune (Abbas, El-Zoghabi & Shoukry, Pattern Recognition 2021) --- cf.
/// doc du module pour les détails et la déviation assumée (pas de t-SNE).
fn denmune(points: &[Vec<f64>], k: usize) -> Vec<i32> {
    let n = points.len();
    let k = k.min(n.saturating_sub(1)).max(1);

    let mut knn_forward: Vec<Vec<usize>> = Vec::with_capacity(n);
    for i in 0..n {
        let mut d: Vec<(f64, usize)> = (0..n).filter(|&j| j != i).map(|j| (euclidean(&points[i], &points[j]), j)).collect();
        d.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
        knn_forward.push(d.into_iter().take(k).map(|(_, j)| j).collect());
    }
    let mut knn_backward: Vec<Vec<usize>> = vec![Vec::new(); n];
    for i in 0..n {
        for &j in &knn_forward[i] {
            knn_backward[j].push(i);
        }
    }
    let mnn: Vec<Vec<usize>> = (0..n)
        .map(|i| {
            let back: HashSet<usize> = knn_backward[i].iter().copied().collect();
            knn_forward[i].iter().copied().filter(|j| back.contains(j)).collect()
        })
        .collect();

    let noise1: Vec<bool> = (0..n).map(|i| mnn[i].is_empty()).collect();
    let is_seed: Vec<bool> = (0..n).map(|i| !noise1[i] && knn_backward[i].len() >= k).collect();

    let mut uf = UnionFind::new(n);
    for i in 0..n {
        if is_seed[i] {
            for &m in &mnn[i] {
                if is_seed[m] {
                    uf.union(i, m);
                }
            }
        }
    }

    let mut cluster_id: HashMap<usize, i32> = HashMap::new();
    let mut next_id = 0i32;
    for i in 0..n {
        if is_seed[i] {
            let root = uf.find(i);
            cluster_id.entry(root).or_insert_with(|| {
                let id = next_id;
                next_id += 1;
                id
            });
        }
    }

    let mut labels = vec![-1i32; n];
    for i in 0..n {
        if is_seed[i] {
            let root = uf.find(i);
            labels[i] = cluster_id[&root];
        }
    }

    for i in 0..n {
        if !is_seed[i] && !noise1[i] {
            let mut overlap: HashMap<i32, usize> = HashMap::new();
            let mut candidates: Vec<usize> = mnn[i].clone();
            candidates.push(i);
            for &m in &candidates {
                if is_seed[m] {
                    let root = uf.find(m);
                    if let Some(&cid) = cluster_id.get(&root) {
                        *overlap.entry(cid).or_insert(0) += 1;
                    }
                }
            }
            if let Some((&best_cid, _)) = overlap.iter().max_by_key(|(_, &c)| c) {
                labels[i] = best_cid;
            }
        }
    }
    labels
}

// ============================================================================
// Parseurs --- jeux déjà présents (inchangés par rapport aux fichiers d'origine)
// ============================================================================

/// Iris/Wine : `d` variables + classe, position auto-détectée --- cf.
/// `load_labelled_csv`.
fn load_sklearn_csv(path: &str, name: &str, expected_n: usize, expected_d: usize) -> Dataset {
    load_labelled_csv(path, name, expected_n, expected_d)
}

/// Seeds : `7` variables puis la classe (variété de blé, 1/2/3) en
/// dernière colonne --- cf. `load_labelled_csv`.
fn load_seeds(path: &str) -> Dataset {
    load_labelled_csv(path, "Seeds (blé)", 210, 7)
}

/// Sonar : `60` variables puis la classe (`R`/`M`, roche/mine, ou déjà
/// numérique selon la source) en dernière colonne --- cf.
/// `load_labelled_csv`.
fn load_sonar(path: &str) -> Dataset {
    load_labelled_csv(path, "Sonar (défense/mines vs. roches)", 208, 60)
}

/// Wholesale : `Channel` (classe, 1ère colonne), `Region` (exclu), puis 6
/// variables de dépense. Tokenisation générique + en-tête auto-détecté ;
/// `Channel` est toujours numérique dans toutes les sources UCI connues,
/// donc pas de fallback texte ici (à la différence des autres jeux).
fn load_wholesale(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut labels = Vec::new();
    let mut skipped_header = false;
    for (i, line) in content.lines().enumerate() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        let parsed: Result<Vec<f64>, _> = tok.iter().map(|s| s.parse::<f64>()).collect();
        match parsed {
            Ok(fields) => {
                labels.push(fields[0] as i32);
                points.push(fields[2..].to_vec());
            }
            Err(_) if i < 2 && !skipped_header => {
                skipped_header = true;
                eprintln!("Wholesale ({path}) : ligne {} ignorée (en-tête détecté).", i + 1);
            }
            Err(e) => panic!("valeur non numérique dans Wholesale ({path}), ligne {} : {e} --- champs bruts : {:?}", i + 1, tok),
        }
    }
    check_shape("Wholesale", path, points.len(), points[0].len(), 440, 6);
    Dataset::new(points, Some(labels), "Wholesale Customers (finance/business)")
}

/// German Credit (variante numérique) : `24` variables puis la classe
/// (1/2, bon/mauvais risque) en dernière colonne. Tokenisation générique +
/// en-tête auto-détecté (le fichier `.numeric` original n'en a pas, mais
/// on ne suppose plus rien).
fn load_german_credit(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut labels = Vec::new();
    let mut skipped_header = false;
    for (i, line) in content.lines().enumerate() {
        let tok = tokenize(line);
        if tok.len() < 2 {
            continue;
        }
        let parsed: Result<Vec<f64>, _> = tok.iter().map(|s| s.parse::<f64>()).collect();
        match parsed {
            Ok(fields) => {
                let (feats, class) = fields.split_at(fields.len() - 1);
                points.push(feats.to_vec());
                labels.push(class[0] as i32);
            }
            Err(_) if i < 2 && !skipped_header => {
                skipped_header = true;
                eprintln!("German Credit ({path}) : ligne {} ignorée (en-tête détecté).", i + 1);
            }
            Err(e) => panic!("valeur non numérique dans German Credit ({path}), ligne {} : {e} --- champs bruts : {:?}", i + 1, tok),
        }
    }
    check_shape("German Credit", path, points.len(), points[0].len(), 1000, 24);
    Dataset::new(points, Some(labels), "German Credit (finance)")
}

/// Ionosphere : `34` variables puis la classe (`g`/`b`, textuelle dans la
/// source UCI brute, ou déjà numérique selon la source) en dernière
/// colonne --- cf. `load_labelled_csv`.
fn load_ionosphere(path: &str) -> Dataset {
    load_labelled_csv(path, "Ionosphere (défense/radar)", 351, 34)
}

// ============================================================================
// Parseurs --- 7 nouveaux jeux
// ============================================================================

/// Abalone : `Sexe(M/F/I), 7 mesures continues, Rings`. Vérité terrain =
/// Sexe (K=3) ; `Rings` (dernier champ) est parsé pour valider la ligne
/// puis explicitement écarté des variables (cf. doc du module).
fn load_abalone(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.is_empty() {
            continue;
        }
        raw_labels.push(tok[0].clone());
        let feats: Vec<f64> = tok[1..8]
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans {path} : {s} ({e})")))
            .collect();
        let _rings: f64 = tok[8].parse().unwrap_or_else(|e| panic!("Rings non numérique dans {path} : {} ({e})", tok[8]));
        points.push(feats);
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Abalone", path, points.len(), points[0].len(), 4177, 7);
    Dataset::new(points, Some(labels), "Abalone (biologie, Sexe=vérité terrain)")
}

/// Balance Scale : `Classe(L/B/R), 4 variables entières`.
fn load_balance(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.is_empty() {
            continue;
        }
        raw_labels.push(tok[0].clone());
        let feats: Vec<f64> = tok[1..]
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans {path} : {s} ({e})")))
            .collect();
        points.push(feats);
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Balance Scale", path, points.len(), points[0].len(), 625, 4);
    Dataset::new(points, Some(labels), "Balance Scale (psychologie cognitive)")
}

/// Ecoli / Yeast partagent le même format : `Nom(ignoré), variables
/// continues, Classe(texte)`. Facteur commun extrait ici.
fn load_named_continuous_lastclass(path: &str, name: &str) -> (Vec<Vec<f64>>, Vec<String>) {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        let (mid, class) = tok[1..].split_at(tok.len() - 2);
        let feats: Vec<f64> = mid
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans {name} ({path}) : {s} ({e})")))
            .collect();
        points.push(feats);
        raw_labels.push(class[0].clone());
    }
    (points, raw_labels)
}

fn load_ecoli(path: &str) -> Dataset {
    let (points, raw_labels) = load_named_continuous_lastclass(path, "Ecoli");
    let labels = label_to_int_map(&raw_labels);
    check_shape("Ecoli", path, points.len(), points[0].len(), 336, 7);
    Dataset::new(points, Some(labels), "Ecoli (biologie, localisation protéine)")
}

fn load_yeast(path: &str) -> Dataset {
    let (points, raw_labels) = load_named_continuous_lastclass(path, "Yeast");
    let labels = label_to_int_map(&raw_labels);
    check_shape("Yeast", path, points.len(), points[0].len(), 1484, 8);
    Dataset::new(points, Some(labels), "Yeast (biologie, localisation subcellulaire)")
}

/// Glass : `Id(ignoré), 9 variables continues, Type(entier, dernière colonne)`.
fn load_glass(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        let (mid, class) = tok[1..].split_at(tok.len() - 2);
        let feats: Vec<f64> = mid
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans Glass ({path}) : {s} ({e})")))
            .collect();
        points.push(feats);
        raw_labels.push(class[0].clone());
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Glass", path, points.len(), points[0].len(), 214, 9);
    Dataset::new(points, Some(labels), "Glass Identification (criminalistique)")
}

/// Heart Disease (Cleveland) : 13 variables + `num` (sévérité 0-4) en
/// dernière colonne. Lignes contenant `?` (valeurs manquantes ca/thal)
/// éliminées.
fn load_heart(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    let mut n_dropped = 0usize;
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.is_empty() {
            continue;
        }
        if tok.iter().any(|t| t == "?") {
            n_dropped += 1;
            continue;
        }
        let (feats_s, class) = tok.split_at(tok.len() - 1);
        let feats: Vec<f64> = feats_s
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans Heart ({path}) : {s} ({e})")))
            .collect();
        points.push(feats);
        raw_labels.push(class[0].clone());
    }
    if n_dropped > 0 {
        eprintln!("Heart ({path}) : {n_dropped} ligne(s) avec valeur(s) manquante(s) '?' éliminée(s).");
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Heart", path, points.len(), points[0].len(), 297, 13);
    Dataset::new(points, Some(labels), "Heart Disease Cleveland (médecine)")
}

/// Zoo : `Nom(ignoré), variables intermédiaires, Type(dernière colonne)`.
/// Le nombre exact de variables intermédiaires n'est pas fixé en dur ---
/// seule la position (1ère colonne = nom, dernière = classe) l'est.
fn load_zoo(path: &str) -> Dataset {
    let (points, raw_labels) = load_named_continuous_lastclass(path, "Zoo");
    let labels = label_to_int_map(&raw_labels);
    check_shape("Zoo", path, points.len(), points[0].len(), 101, 16);
    Dataset::new(points, Some(labels), "Zoo (biologie, taxonomie)")
}

/// Arrhythmia : `279 variables, Classe(dernière colonne, 280e, 16
/// modalités)`. **Correctif** : une première version éliminait les
/// LIGNES contenant au moins une valeur manquante `?`, ce qui effondrait
/// n de 452 à 68 --- les valeurs manquantes sont éparpillées sur de
/// nombreuses colonnes différentes, si bien que presque chaque ligne en
/// contient au moins une quelque part parmi 279 variables. Confirmé
/// incorrect par recoupement de plusieurs sources indépendantes citant
/// ce jeu (Islam et al. 2023 ; Jadhav et al., IJITKM) : la pratique
/// standard élimine les COLONNES contenant des valeurs manquantes (279
/// → 252 colonnes rapporté dans la littérature), conservant toutes les
/// lignes. Reproduit ici : une colonne est éliminée dès qu'elle contient
/// au moins un `?` sur l'ensemble des lignes, les 452 lignes sont
/// conservées.
fn load_arrhythmia(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let rows: Vec<Vec<String>> = content.lines().map(tokenize).filter(|t| !t.is_empty()).collect();
    if rows.is_empty() {
        panic!("Arrhythmia ({path}) : aucune ligne exploitable.");
    }
    let n_cols = rows[0].len();
    // colonnes 0..n_cols-2 = variables, derniere colonne (n_cols-1) = classe
    let n_feat_cols = n_cols - 1;
    let col_has_missing: Vec<bool> = (0..n_feat_cols).map(|c| rows.iter().any(|r| r[c] == "?")).collect();
    let n_dropped_cols = col_has_missing.iter().filter(|&&b| b).count();

    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    for r in &rows {
        let feats: Vec<f64> = (0..n_feat_cols)
            .filter(|&c| !col_has_missing[c])
            .map(|c| r[c].parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans Arrhythmia ({path}) : {} ({e})", r[c])))
            .collect();
        points.push(feats);
        raw_labels.push(r[n_cols - 1].clone());
    }
    eprintln!("Arrhythmia ({path}) : {n_dropped_cols} colonne(s) avec valeur(s) manquante(s) éliminée(s) ({n_feat_cols} → {} variables), 0 ligne éliminée.", n_feat_cols - n_dropped_cols);
    let labels = label_to_int_map(&raw_labels);
    // Note : le nombre exact de colonnes éliminées (et donc de variables
    // restantes) peut varier légèrement selon la source/version du
    // fichier téléchargé et la définition précise de "valeur manquante"
    // utilisée par chaque étude ; 279→252 (27 colonnes) est la valeur
    // citée dans la littérature de référence, mais un téléchargement
    // réel a donné 279→274 (5 colonnes) --- écart mineur, sans
    // conséquence sur la validité du mécanisme (colonnes, pas lignes),
    // simplement une différence de version/traitement en amont. Valeur
    // attendue ajustée en conséquence pour éviter un faux avertissement.
    check_shape("Arrhythmia", path, points.len(), points[0].len(), 452, 274);
    Dataset::new(points, Some(labels), "Arrhythmia (médecine, ECG)")
}

/// Breast Tissue (Jossinet, UCI) : `Case#(1ère colonne, ignoré),
/// Classe(2e colonne, texte : car/fad/mas/gla/con/adi), 9 variables
/// continues (I0,PA500,HFS,DA,Area,A/DA,Max IP,DR,P)`. **Remplace
/// SPECTF Heart**, retiré après diagnostic : SPECTF est documenté dans
/// la littérature comme résistant aux méthodes conventionnelles même en
/// classification *supervisée*, expliquant l'échec uniforme de toutes
/// les méthodes (y compris K-Means à K vrai, ARI négatif) observé dans
/// un run précédent --- pas un signal utile pour comparer des méthodes
/// de clustering entre elles. Breast Tissue est au contraire cité comme
/// référence de clustering dans la littérature (~92% de précision de
/// classification rapportée dans l'étude originale, structure
/// géométriquement séparable). n/d≈11.8, dans la marge où le
/// rétrécissement conditionnel de PoWKM-prescribed a montré un effet
/// (positif à négatif selon le jeu, cf. doc de
/// `powkm_prescribed.rs::use_shrinkage_split_test`) plutôt que neutre.
/// **Fichier source natif au format `.xls`** (pas `.csv`/`.data` comme
/// les autres jeux de ce fichier) --- à convertir en CSV avant usage
/// (onglet "Data" uniquement, pas "Description"), ex. via LibreOffice
/// Calc ou `pandas.read_excel(...).to_csv(...)`.
fn load_breast_tissue(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    let mut skipped_header = false;
    for (i, line) in content.lines().enumerate() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        let feat_tokens = &tok[2..];
        let parsed: Result<Vec<f64>, _> = feat_tokens.iter().map(|s| s.parse::<f64>()).collect();
        match parsed {
            Ok(feats) => {
                points.push(feats);
                raw_labels.push(tok[1].clone());
            }
            Err(_) if i == 0 && !skipped_header => {
                skipped_header = true;
                eprintln!("Breast Tissue ({path}) : ligne 1 ignorée (en-tête détecté).");
            }
            Err(e) => panic!("valeur non numérique dans Breast Tissue ({path}), ligne {} : {e} --- champs bruts : {:?}", i + 1, tok),
        }
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Breast Tissue", path, points.len(), points[0].len(), 106, 9);
    Dataset::new(points, Some(labels), "Breast Tissue (médecine, impédance électrique)")
}

/// Dermatology (Ilter & Guvenir, UCI) : `34 variables (33 cliniques +
/// Age), Classe(dernière colonne, 35e, 6 modalités)`. **Remplace
/// Parkinsons**, retiré après diagnostic : déséquilibre de classes
/// 75/25 posant un problème structurel similaire à SPECTF pour du
/// clustering pur (échec uniforme de toutes les méthodes, y compris
/// K-Means à K vrai). Dermatology est au contraire un benchmark de
/// clustering établi (ARI jusqu'à 0.73 rapporté avec FAMD dans la
/// littérature récente 2024-2025). Valeurs manquantes `?` uniquement sur
/// la colonne Age (8 lignes) --- éliminées par ligne, cohérent avec la
/// pratique rapportée dans la littérature (n=366→358 après nettoyage,
/// valeur explicitement citée). n/d≈10.5.
fn load_dermatology(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    let mut n_dropped = 0usize;
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.is_empty() {
            continue;
        }
        if tok.iter().any(|t| t == "?") {
            n_dropped += 1;
            continue;
        }
        let (feats_s, class) = tok.split_at(tok.len() - 1);
        let feats: Vec<f64> = feats_s
            .iter()
            .map(|s| s.parse::<f64>().unwrap_or_else(|e| panic!("valeur non numérique dans Dermatology ({path}) : {s} ({e})")))
            .collect();
        points.push(feats);
        raw_labels.push(class[0].clone());
    }
    if n_dropped > 0 {
        eprintln!("Dermatology ({path}) : {n_dropped} ligne(s) avec valeur(s) manquante(s) '?' éliminée(s).");
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Dermatology", path, points.len(), points[0].len(), 358, 34);
    Dataset::new(points, Some(labels), "Dermatology (médecine, dermatologie)")
}

// ============================================================================
// Parseurs --- 2 nouveaux jeux (extension neutre, cf. doc du module)
// ============================================================================

/// Image Segmentation (Vision Group, Univ. of Massachusetts, UCI id=50).
/// `Classe(1ère colonne, texte : BRICKFACE/SKY/FOLIAGE/CEMENT/WINDOW/
/// PATH/GRASS), 19 variables continues`. Fichier source brut
/// (`segmentation.data` + `segmentation.test` fusionnés, ou fichier déjà
/// fusionné) précédé de quelques lignes d'en-tête non numériques
/// (noms de colonnes / commentaires) --- ignorées par détection d'échec
/// de parsing, même mécanisme que `load_breast_tissue`, pas de nombre de
/// lignes d'en-tête fixé en dur. n=2310 attendu (210 train + 2100 test,
/// 330 par classe, classes parfaitement équilibrées --- contrairement à
/// la plupart des autres jeux médicaux/biologie de ce fichier). Choisi
/// pour combler un angle mort du plan d'expérience actuel : aucun jeu
/// existant ne combine n grand (>2000) et classes équilibrées.
fn load_image_segmentation(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    let mut n_skipped_header = 0usize;
    for line in content.lines() {
        let tok = tokenize(line);
        if tok.len() < 3 {
            continue;
        }
        let feat_tokens = &tok[1..];
        let parsed: Result<Vec<f64>, _> = feat_tokens.iter().map(|s| s.parse::<f64>()).collect();
        match parsed {
            Ok(feats) => {
                points.push(feats);
                raw_labels.push(tok[0].to_uppercase());
            }
            Err(_) => {
                n_skipped_header += 1;
            }
        }
    }
    if n_skipped_header > 0 {
        eprintln!("Image Segmentation ({path}) : {n_skipped_header} ligne(s) d'en-tête/commentaire ignorée(s) (détection par échec de parsing numérique).");
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("Image Segmentation", path, points.len(), points[0].len(), 2310, 19);
    Dataset::new(points, Some(labels), "Image Segmentation (vision, 7 classes équilibrées)")
}

/// Découpe stricte sur virgule uniquement, en respectant les guillemets
/// (les champs entre guillemets peuvent contenir des virgules ou des
/// espaces sans être coupés). **Nécessaire pour HCV Data** : la fonction
/// générique `tokenize()` découpe aussi sur les espaces, ce qui casse à
/// tort les valeurs de catégorie multi-mots du fichier `hcvdat0.csv`
/// (`"0=Blood Donor"`, `"0s=suspect Blood Donor"`) --- cf. `load_hcv`
/// pour le récit complet du bug diagnostiqué à cause de cela.
fn tokenize_csv_strict(line: &str) -> Vec<String> {
    let mut fields = Vec::new();
    let mut cur = String::new();
    let mut in_quotes = false;
    for c in line.chars() {
        match c {
            '"' => in_quotes = !in_quotes,
            ',' if !in_quotes => {
                fields.push(cur.trim().to_string());
                cur.clear();
            }
            _ => cur.push(c),
        }
    }
    fields.push(cur.trim().to_string());
    fields
}

/// HCV Data (Hoffmann et al. 2018, Lichtinghagen et al. 2013, UCI id=571).
/// Colonnes (fichier `hcvdat0.csv`, avec en-tête) : `index(1ère,
/// ignoré), Category(classe texte : "0=Blood Donor"/"0s=suspect Blood
/// Donor"/"1=Hepatitis"/"2=Fibrosis"/"3=Cirrhosis"), Age, Sex(m/f,
/// catégoriel --- encodé 0/1 comme variable, pas comme vérité terrain),
/// puis 10 variables biologiques continues (ALB, ALP, ALT, AST, BIL,
/// CHE, CHOL, CREA, GGT, PROT)`. Valeurs manquantes `NA`/`?` éparses
/// (principalement colonne ALP) --- lignes éliminées, même traitement
/// que Heart/Dermatology. n=615 brut attendu (valeur canonique UCI,
/// avant élimination des lignes à valeur manquante --- le n final après
/// nettoyage sera donc inférieur, cf. avertissement `check_shape` qui ne
/// bloque pas l'exécution). Choisi pour combler un second angle mort :
/// déséquilibre de classes plus extrême que tous les jeux médicaux déjà
/// présents (Arrhythmia/Breast Tissue/Dermatology), dans un domaine
/// médical distinct.
///
/// **Bug diagnostiqué et corrigé** : une première version utilisait le
/// tokenizer générique `tokenize()` (virgule OU espace), qui découpe à
/// tort la valeur de catégorie `"0=Blood Donor"` (contient un espace
/// interne) en plusieurs tokens --- rejetant silencieusement ~533 des
/// 615 lignes (toute la classe majoritaire "donneur sain") comme "ligne
/// non conforme" (nombre de champs ≠ 14). Le jeu obtenu (n=56) ne
/// contenait alors que les 3 classes pathologiques minoritaires (20+12+24
/// = 56, coïncidence exacte confirmant le diagnostic), sans la classe de
/// référence --- expliquant les résultats dégradés de **toutes** les
/// méthodes observés lors du premier run, pas un signal spécifique à
/// PoWKM. Corrigé par `tokenize_csv_strict` (virgule stricte, respecte
/// les guillemets), qui ne coupe plus les champs multi-mots.
fn load_hcv(path: &str) -> Dataset {
    let content = fs::read_to_string(path).unwrap_or_else(|e| panic!("lecture {path} impossible : {e}"));
    let mut points = Vec::new();
    let mut raw_labels = Vec::new();
    let mut n_dropped_missing = 0usize;
    let mut n_skipped_header = 0usize;
    for line in content.lines() {
        let tok = tokenize_csv_strict(line);
        if tok.len() < 13 {
            continue;

        }
        // colonnes attendues : index, Category, Age, Sex, ALB, ALP, ALT,
        // AST, BIL, CHE, CHOL, CREA, GGT, PROT (14 champs).
        if tok.len() != 14 {
            n_skipped_header += 1;
            continue;
        }
        if tok.iter().any(|t| t == "NA" || t == "?" || t.is_empty()) {
            n_dropped_missing += 1;
            continue;
        }
        let category = tok[1].clone();
        let age: f64 = match tok[2].parse() {
            Ok(v) => v,
            Err(_) => {
                n_skipped_header += 1;
                continue;
            }
        };
        let sex: f64 = match tok[3].to_lowercase().as_str() {
            "m" => 1.0,
            "f" => 0.0,
            _ => {
                n_skipped_header += 1;
                continue;
            }
        };
        let lab_parsed: Result<Vec<f64>, _> = tok[4..14].iter().map(|s| s.parse::<f64>()).collect();
        match lab_parsed {
            Ok(lab) => {
                let mut feats = vec![age, sex];
                feats.extend(lab);
                points.push(feats);
                raw_labels.push(category);
            }
            Err(_) => {
                n_skipped_header += 1;
            }
        }
    }
    if n_skipped_header > 0 {
        eprintln!("HCV Data ({path}) : {n_skipped_header} ligne(s) d'en-tête/non conforme(s) ignorée(s).");
    }
    if n_dropped_missing > 0 {
        eprintln!("HCV Data ({path}) : {n_dropped_missing} ligne(s) avec valeur(s) manquante(s) ('NA'/'?') éliminée(s).");
    }
    let labels = label_to_int_map(&raw_labels);
    check_shape("HCV Data", path, points.len(), points[0].len(), 615, 12);
    Dataset::new(points, Some(labels), "HCV Data (médecine, stades hépatite C)")
}

// ============================================================================
// Prétraitement et harnais d'exécution (inchangés par rapport aux fichiers d'origine)
// ============================================================================

fn standardize(dataset: &Dataset) -> Dataset {
    let n = dataset.points.len();
    let d = dataset.points[0].len();
    let mut mean = vec![0.0; d];
    for p in &dataset.points {
        for j in 0..d {
            mean[j] += p[j] / n as f64;
        }
    }
    let mut std = vec![0.0; d];
    for p in &dataset.points {
        for j in 0..d {
            std[j] += (p[j] - mean[j]).powi(2) / n as f64;
        }
    }
    for s in std.iter_mut() {
        *s = s.sqrt();
        if *s < 1e-12 {
            *s = 1.0;
        }
    }
    let points: Vec<Vec<f64>> = dataset.points.iter().map(|p| (0..d).map(|j| (p[j] - mean[j]) / std[j]).collect()).collect();
    Dataset::new(points, dataset.labels_true.clone(), dataset.name.clone())
}

/// Cf. `real_world_finance_defense.rs` pour la justification (PoWKM libre
/// non optimisé au-delà de n~300 en dimension modérée).
fn subsample(dataset: &Dataset, n_target: usize, seed: u64) -> Dataset {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let mut idx: Vec<usize> = (0..dataset.points.len()).collect();
    idx.shuffle(&mut rng);
    idx.truncate(n_target.min(idx.len()));
    let points = idx.iter().map(|&i| dataset.points[i].clone()).collect();
    let labels = dataset.labels_true.as_ref().map(|l| idx.iter().map(|&i| l[i]).collect());
    Dataset::new(points, labels, dataset.name.clone())
}

fn kth_nn_distances(points: &[Vec<f64>], k: usize) -> Vec<f64> {
    points
        .iter()
        .map(|p| {
            let mut d: Vec<f64> = points.iter().filter(|q| !std::ptr::eq(*q, p)).map(|q| euclidean(p, q)).collect();
            d.sort_by(|a, b| a.partial_cmp(b).unwrap());
            d[(k - 1).min(d.len() - 1)]
        })
        .collect()
}

fn median(mut v: Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = v.len();
    if n % 2 == 0 {
        0.5 * (v[n / 2 - 1] + v[n / 2])
    } else {
        v[n / 2]
    }
}

fn suggest_eps(points: &[Vec<f64>], min_samples: usize) -> f64 {
    median(kth_nn_distances(points, min_samples))
}

fn suggest_bandwidth(points: &[Vec<f64>], quantile: f64) -> f64 {
    let n = points.len();
    let k = ((quantile * n as f64).ceil() as usize).max(1);
    median(kth_nn_distances(points, k))
}

/// Nombre de répétitions par couple (algorithme, jeu) --- nécessaire car
/// plusieurs algorithmes ont une composante stochastique (K-Means : init
/// aléatoire ; Spectral : K-Means sur les vecteurs propres, même souci ;
/// Mean-Shift : l'estimation de bande passante peut dépendre d'un
/// sous-échantillonnage aléatoire) alors qu'un unique run (seed=42) était
/// utilisé jusqu'ici --- point faible identifié : un seul seed ne permet
/// pas de distinguer un bon résultat d'un coup de chance. Les jeux
/// sous-échantillonnés (Abalone/Yeast/German Credit) voient aussi leur
/// sous-échantillon varier à chaque run (variance totale, pas seulement
/// la stochasticité interne des algorithmes), cf. `DatasetSource::Resampled`.
/// Les algorithmes réellement déterministes (DBSCAN, OPTICS, DenMune,
/// PoWKM) produiront des valeurs quasi identiques d'un run à l'autre sur
/// les jeux non ré-échantillonnés --- pas un défaut, juste un fait
/// attendu compte tenu de leur nature.
const N_RUNS: usize = 10;

fn mean(v: &[f64]) -> f64 {
    v.iter().sum::<f64>() / v.len() as f64
}

fn std_dev(v: &[f64]) -> f64 {
    let m = mean(v);
    (v.iter().map(|x| (x - m).powi(2)).sum::<f64>() / v.len() as f64).sqrt()
}

fn median_ref(v: &[f64]) -> f64 {
    median(v.to_vec())
}

/// Source d'un jeu de données pour le harnais multi-run : soit fixe
/// (standardisé une fois, réutilisé identique à chaque run --- seule la
/// stochasticité interne des algorithmes varie), soit ré-échantillonnée
/// à chaque run avec un seed différent (variance totale, cf. doc de
/// `N_RUNS`) --- cas des 3 jeux volontairement sous-échantillonnés
/// (Abalone, Yeast, German Credit) pour temps d'exécution raisonnable.
enum DatasetSource {
    Fixed(Dataset),
    Resampled { raw: Dataset, n_target: usize },
}

impl DatasetSource {
    fn realize(&self, run_seed: u64) -> Dataset {
        match self {
            DatasetSource::Fixed(d) => d.clone(),
            DatasetSource::Resampled { raw, n_target } => standardize(&subsample(raw, *n_target, run_seed)),
        }
    }
}

/// Accumule ARI/NMI/temps/K_trouvé sur les `N_RUNS` répétitions d'un
/// couple (algorithme, jeu).
#[derive(Default)]
struct MultiRunStats {
    ari: Vec<f64>,
    nmi: Vec<f64>,
    time_ms: Vec<f64>,
    k_found: Vec<usize>,
}

impl MultiRunStats {
    fn push(&mut self, ari: f64, nmi: f64, time_ms: f64, k: usize) {
        self.ari.push(ari);
        self.nmi.push(nmi);
        self.time_ms.push(time_ms);
        self.k_found.push(k);
    }
    fn mean_ari(&self) -> f64 {
        mean(&self.ari)
    }
    fn std_ari(&self) -> f64 {
        std_dev(&self.ari)
    }
    fn median_ari(&self) -> f64 {
        median_ref(&self.ari)
    }
    fn mean_nmi(&self) -> f64 {
        mean(&self.nmi)
    }
    fn mean_time(&self) -> f64 {
        mean(&self.time_ms)
    }
    fn median_k(&self) -> usize {
        let mut ks = self.k_found.clone();
        ks.sort_unstable();
        ks[ks.len() / 2]
    }
    fn k_variable(&self) -> bool {
        self.k_found.iter().collect::<HashSet<_>>().len() > 1
    }
}

fn print_multi_run_line(name: &str, s: &MultiRunStats) {
    let k_label = if s.k_variable() { format!("K_méd={}*", s.median_k()) } else { format!("K={}", s.median_k()) };
    println!(
        "{:<24} {:<10} ARI={:>6.3}±{:<5.3} (méd={:>6.3}) NMI={:>6.3} {:>8.1}ms (moy.)",
        name,
        k_label,
        s.mean_ari(),
        s.std_ari(),
        s.median_ari(),
        s.mean_nmi(),
        s.mean_time()
    );
}

/// Exécute tous les algorithmes une fois sur `dataset` avec le `seed`
/// donné, sans impression (l'agrégation/l'affichage se font au niveau de
/// `run_group_multi` après les `N_RUNS` répétitions). Retourne
/// séparément les résultats "K connu fourni" et "K découvert
/// automatiquement", comme (nom, ARI, NMI, temps_ms, K_trouvé).
/// PoWKM libre reste désactivé (non inclus), inchangé par rapport à
/// l'ancien comportement par défaut.
fn run_all_silent(dataset: &Dataset, true_k: usize, seed: u64) -> (Vec<(&'static str, f64, f64, f64, usize)>, Vec<(&'static str, f64, f64, f64, usize)>) {
    let truth = dataset.labels_true.as_ref().unwrap();
    let points = &dataset.points;

    let min_samples = 5;
    let eps = suggest_eps(points, min_samples);
    let bandwidth = suggest_bandwidth(points, 0.3).max(1e-3);

    let mut known: Vec<(&'static str, f64, f64, f64, usize)> = Vec::new();
    let push_known = |name: &'static str, r: ClusterResult, known: &mut Vec<(&'static str, f64, f64, f64, usize)>| {
        known.push((name, adjusted_rand_index(truth, &r.labels), normalized_mutual_info(truth, &r.labels), r.runtime.as_secs_f64() * 1000.0, r.n_clusters));
    };
    let mut km = KMeans::new(true_k, seed);
    let r = km.fit(dataset);
    push_known("K-Means", r, &mut known);
    let mut hc = HierarchicalClustering::new(true_k, Linkage::Ward);
    let r = hc.fit(dataset);
    push_known("Hiérarchique/Ward", r, &mut known);
    let mut birch = Birch::new(0.5, 50, true_k);
    let r = birch.fit(dataset);
    push_known("BIRCH", r, &mut known);
    let mut spectral = SpectralClustering::new(true_k, 1.0 / points[0].len() as f64, seed);
    let r = spectral.fit(dataset);
    push_known("Spectral", r, &mut known);

    // Résultats à K découvert automatiquement uniquement --- c'est cette
    // catégorie qui constitue la comparaison honnête pour l'article
    // (aucune de ces méthodes ne reçoit K_vrai) ; c'est elle seule qui
    // alimente le classement par rang / Friedman / Nemenyi.
    let mut discovered: Vec<(&'static str, f64, f64, f64, usize)> = Vec::new();
    let push_disc = |name: &'static str, r: ClusterResult, discovered: &mut Vec<(&'static str, f64, f64, f64, usize)>| {
        discovered.push((name, adjusted_rand_index(truth, &r.labels), normalized_mutual_info(truth, &r.labels), r.runtime.as_secs_f64() * 1000.0, r.n_clusters));
    };

    let mut db = Dbscan::new(eps, min_samples);
    let r = db.fit(dataset);
    push_disc("DBSCAN", r, &mut discovered);
    let mut hdb = Hdbscan::new(min_samples, min_samples);
    let r = hdb.fit(dataset);
    push_disc("HDBSCAN", r, &mut discovered);
    let mut optics = Optics::new(eps, min_samples, eps);
    let r = optics.fit(dataset);
    push_disc("OPTICS", r, &mut discovered);
    let mut ms = MeanShift::new(bandwidth);
    let r = ms.fit(dataset);
    push_disc("Mean-Shift", r, &mut discovered);
    let mut prescribed = PoWKMPrescribed::new(seed);
    prescribed.beta_max = 6.0;
    let r = prescribed.fit(dataset);
    push_disc("PoWKM-prescribed", r, &mut discovered);

    // Deux algorithmes récents (post-2020) de la littérature --- cf. doc
    // du module pour les citations complètes et les détails d'implémentation.
    let t0 = std::time::Instant::now();
    let labels_dynmsc = dynmsc(points, 2, 15, seed);
    let n_clusters_dynmsc = labels_dynmsc.iter().collect::<HashSet<_>>().len();
    let time_ms = t0.elapsed().as_secs_f64() * 1000.0;
    discovered.push(("DynMSC", adjusted_rand_index(truth, &labels_dynmsc), normalized_mutual_info(truth, &labels_dynmsc), time_ms, n_clusters_dynmsc));

    let t0 = std::time::Instant::now();
    let labels_dm = denmune(points, 10);
    let n_clusters_dm = labels_dm.iter().filter(|&&l| l >= 0).collect::<HashSet<_>>().len();
    let time_ms = t0.elapsed().as_secs_f64() * 1000.0;
    discovered.push(("DenMune", adjusted_rand_index(truth, &labels_dm), normalized_mutual_info(truth, &labels_dm), time_ms, n_clusters_dm));

    (known, discovered)
}

/// Statistiques accumulées pour un algorithme à K découvert automatiquement,
/// sur l'ensemble des jeux traités --- alimente le classement final.
#[derive(Default)]
struct AlgoStats {
    ari_sum: f64,
    nmi_sum: f64,
    time_ms_sum: f64,
    k_abs_diff_sum: f64,
    n_datasets: usize,
    n_wins: usize,
}

// ============================================================================
// Statistiques inter-jeux : rang moyen, test de Friedman (correction
// Iman-Davenport) et post-hoc de Nemenyi --- protocole standard pour la
// comparaison de plusieurs algorithmes sur plusieurs jeux de données
// (Demšar, "Statistical Comparisons of Classifiers over Multiple Data
// Sets", JMLR 7:1-30, 2006 --- publié dans la revue cible de cet
// article). Fonctions de la loi F (bêta incomplète régularisée) et la
// table de Nemenyi vérifiées indépendamment contre
// `scipy.stats.f.sf`/`scipy.stats.studentized_range` (erreur max
// 4.6e-11) avant portage ici --- cf. `friedman_reference.py` et
// `test_betainc.rs` (scripts de validation, hors du crate).
// ============================================================================

fn ln_gamma(x: f64) -> f64 {
    const COF: [f64; 6] = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
    let mut y = x;
    let tmp = x + 5.5 - (x + 0.5) * (x + 5.5).ln();
    let mut ser = 1.000000000190015;
    for c in COF.iter() {
        y += 1.0;
        ser += c / y;
    }
    -tmp + (2.5066282746310005 * ser / x).ln()
}

/// Fraction continue de Lentz pour la bêta incomplète (Numerical
/// Recipes, ch. 6.4).
fn betacf(a: f64, b: f64, x: f64) -> f64 {
    let (max_iter, eps, fpmin) = (200, 3.0e-14, 1.0e-300);
    let (qab, qap, qam) = (a + b, a + 1.0, a - 1.0);
    let mut c = 1.0;
    let mut d = 1.0 - qab * x / qap;
    if d.abs() < fpmin {
        d = fpmin;
    }
    d = 1.0 / d;
    let mut h = d;
    for m in 1..=max_iter {
        let m_f = m as f64;
        let m2 = 2.0 * m_f;
        let aa1 = m_f * (b - m_f) * x / ((qam + m2) * (a + m2));
        d = 1.0 + aa1 * d;
        if d.abs() < fpmin {
            d = fpmin;
        }
        c = 1.0 + aa1 / c;
        if c.abs() < fpmin {
            c = fpmin;
        }
        d = 1.0 / d;
        h *= d * c;
        let aa2 = -(a + m_f) * (qab + m_f) * x / ((a + m2) * (qap + m2));
        d = 1.0 + aa2 * d;
        if d.abs() < fpmin {
            d = fpmin;
        }
        c = 1.0 + aa2 / c;
        if c.abs() < fpmin {
            c = fpmin;
        }
        d = 1.0 / d;
        let del = d * c;
        h *= del;
        if (del - 1.0).abs() < eps {
            break;
        }
    }
    h
}

fn betainc_reg(x: f64, a: f64, b: f64) -> f64 {
    if x <= 0.0 {
        return 0.0;
    }
    if x >= 1.0 {
        return 1.0;
    }
    let bt = (ln_gamma(a + b) - ln_gamma(a) - ln_gamma(b) + a * x.ln() + b * (1.0 - x).ln()).exp();
    if x < (a + 1.0) / (a + b + 2.0) {
        bt * betacf(a, b, x) / a
    } else {
        1.0 - bt * betacf(b, a, 1.0 - x) / b
    }
}

/// Fonction de survie (1-CDF) de la loi F(d1,d2), via la bêta incomplète
/// régularisée. Vérifiée contre `scipy.stats.f.sf` (5 valeurs de test,
/// erreur max 4.6e-11).
fn f_dist_sf(f_stat: f64, d1: f64, d2: f64) -> f64 {
    if f_stat <= 0.0 {
        return 1.0;
    }
    let x = d1 * f_stat / (d1 * f_stat + d2);
    1.0 - betainc_reg(x, d1 / 2.0, d2 / 2.0)
}

/// Table q_alpha (Nemenyi, alpha=0.05), issue de la loi "studentized
/// range" (Demšar 2006, Table 5(b)) --- vérifiée contre
/// `scipy.stats.studentized_range.ppf(0.95, k, inf)/sqrt(2)` pour
/// k=2..12 (cf. `friedman_reference.py`) ; correspond aux valeurs
/// canoniques bien connues de la littérature.
fn nemenyi_q_alpha(k: usize) -> f64 {
    match k {
        2 => 1.9600,
        3 => 2.3437,
        4 => 2.5690,
        5 => 2.7278,
        6 => 2.8497,
        7 => 2.9483,
        8 => 3.0309,
        9 => 3.1017,
        10 => 3.1637,
        11 => 3.2187,
        12 => 3.2680,
        _ => panic!("table de Nemenyi non couverte pour k={k} algorithmes (couvre 2..=12) --- étendre via scipy.stats.studentized_range avant d'utiliser un k plus grand, ne pas deviner la valeur."),
    }
}

fn nemenyi_cd(k: usize, n: usize) -> f64 {
    nemenyi_q_alpha(k) * ((k as f64 * (k as f64 + 1.0)) / (6.0 * n as f64)).sqrt()
}

/// Construit la matrice des rangs [jeu][algo] (1 = meilleur ARI moyen)
/// à partir des scores par jeu, avec gestion des ex æquo par rang moyen
/// (convention standard, cf. Demšar 2006 §3.1).
fn compute_ranks(rank_data: &[(String, HashMap<&'static str, f64>)], algos: &[&'static str]) -> Vec<Vec<f64>> {
    rank_data
        .iter()
        .map(|(_, scores)| {
            let mut vals: Vec<(usize, f64)> = algos.iter().enumerate().filter_map(|(i, a)| scores.get(a).map(|&v| (i, v))).collect();
            vals.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
            let mut ranks = vec![f64::NAN; algos.len()];
            let mut i = 0;
            while i < vals.len() {
                let mut j = i;
                while j + 1 < vals.len() && (vals[j + 1].1 - vals[i].1).abs() < 1e-12 {
                    j += 1;
                }
                let avg_rank = ((i + 1) + (j + 1)) as f64 / 2.0;
                for m in i..=j {
                    ranks[vals[m].0] = avg_rank;
                }
                i = j + 1;
            }
            ranks
        })
        .collect()
}

/// Statistique de Friedman avec correction d'Iman-Davenport (plus
/// puissante et moins conservatrice que le chi² de Friedman brut,
/// recommandée par Demšar 2006 §3.1) : suit une loi F(k-1, (k-1)(n-1))
/// sous H0 ("tous les algorithmes sont équivalents").
fn friedman_iman_davenport(ranks_matrix: &[Vec<f64>], k: usize) -> (f64, f64, f64, usize, usize) {
    let n = ranks_matrix.len();
    let mut avg_rank = vec![0.0; k];
    for ranks in ranks_matrix {
        for j in 0..k {
            avg_rank[j] += ranks[j] / n as f64;
        }
    }
    let sum_sq: f64 = avg_rank.iter().map(|r| r * r).sum();
    let chi2_f = (12.0 * n as f64) / (k as f64 * (k as f64 + 1.0)) * (sum_sq - k as f64 * (k as f64 + 1.0).powi(2) / 4.0);
    let f_f = (n as f64 - 1.0) * chi2_f / (n as f64 * (k as f64 - 1.0) - chi2_f);
    let (dfn, dfd) = (k - 1, (k - 1) * (n - 1));
    let p = f_dist_sf(f_f, dfn as f64, dfd as f64);
    (chi2_f, f_f, p, dfn, dfd)
}

fn run_group_multi(title: &str, sources: &[&DatasetSource], base_seed: u64, n_runs: usize, global_stats: &mut HashMap<&'static str, AlgoStats>, rank_data: &mut Vec<(String, HashMap<&'static str, f64>)>) {
    const DISCOVERED_ORDER: [&str; 7] = ["DBSCAN", "HDBSCAN", "OPTICS", "Mean-Shift", "PoWKM-prescribed", "DynMSC", "DenMune"];
    const KNOWN_ORDER: [&str; 4] = ["K-Means", "Hiérarchique/Ward", "BIRCH", "Spectral"];

    println!("\n### {title} ###");
    for source in sources {
        let probe = source.realize(base_seed);
        let true_k = probe.labels_true.as_ref().unwrap().iter().collect::<HashSet<_>>().len();
        let dataset_name = probe.name.clone();
        println!("\n=== {} — n={}, d={}, K_vrai={true_k} (moyenne/médiane sur {n_runs} runs) ===\n", dataset_name, probe.points.len(), probe.points[0].len());

        let mut known_acc: HashMap<&'static str, MultiRunStats> = HashMap::new();
        let mut disc_acc: HashMap<&'static str, MultiRunStats> = HashMap::new();

        for run_idx in 0..n_runs {
            let run_seed = base_seed.wrapping_mul(1_000_003).wrapping_add(run_idx as u64);
            let dataset = source.realize(run_seed);
            let (known, discovered) = run_all_silent(&dataset, true_k, run_seed);
            for (name, ari, nmi, t, k) in known {
                known_acc.entry(name).or_default().push(ari, nmi, t, k);
            }
            for (name, ari, nmi, t, k) in discovered {
                disc_acc.entry(name).or_default().push(ari, nmi, t, k);
            }
        }

        println!("--- K connu fourni en entrée (ne concourent pas sur la découverte de K) ---");
        for name in KNOWN_ORDER {
            if let Some(s) = known_acc.get(name) {
                print_multi_run_line(name, s);
            }
        }

        println!("--- K découvert automatiquement (hyperparamètres génériques, aucun accès aux labels) ---");
        let mut best_name = "";
        let mut best_mean_ari = f64::NEG_INFINITY;
        let mut algo_scores: HashMap<&'static str, f64> = HashMap::new();
        for name in DISCOVERED_ORDER {
            if let Some(s) = disc_acc.get(name) {
                print_multi_run_line(name, s);
                let m = s.mean_ari();
                algo_scores.insert(name, m);
                if m > best_mean_ari {
                    best_mean_ari = m;
                    best_name = name;
                }
                let entry = global_stats.entry(name).or_default();
                entry.ari_sum += m;
                entry.nmi_sum += s.mean_nmi();
                entry.time_ms_sum += s.mean_time();
                entry.k_abs_diff_sum += (s.median_k() as f64 - true_k as f64).abs();
                entry.n_datasets += 1;
            }
        }
        if !best_name.is_empty() {
            global_stats.get_mut(best_name).unwrap().n_wins += 1;
            let tag = if best_name == "PoWKM-prescribed" { " <-- PoWKM gagne" } else { "" };
            println!("  => MEILLEUR (K découvert, ARI moyen sur {n_runs} runs) [{dataset_name}] : {best_name} ARI_moy={best_mean_ari:.3}{tag}");
        }
        rank_data.push((dataset_name, algo_scores));
    }
}

/// Classement final des algorithmes à K découvert automatiquement (ARI
/// moyen des moyennes par jeu, sur `N_RUNS` répétitions par jeu), puis
/// rang moyen inter-jeux (protocole Demšar 2006) avec test de Friedman
/// (correction Iman-Davenport) et post-hoc de Nemenyi.
fn print_final_ranking(stats: &HashMap<&'static str, AlgoStats>, rank_data: &[(String, HashMap<&'static str, f64>)]) {
    println!("\n### Classement moyen --- algorithmes à K découvert automatiquement ###\n");
    let mut rows: Vec<(&&str, &AlgoStats)> = stats.iter().collect();
    rows.sort_by(|a, b| {
        let ari_a = a.1.ari_sum / a.1.n_datasets as f64;
        let ari_b = b.1.ari_sum / b.1.n_datasets as f64;
        ari_b.partial_cmp(&ari_a).unwrap()
    });
    println!("{:<20} {:>10} {:>10} {:>12} {:>16} {:>12}", "Algorithme", "ARI moy.", "NMI moy.", "Temps moy.", "|K_trouvé-K_vrai|", "Victoires");
    for (name, s) in &rows {
        let n = s.n_datasets as f64;
        println!("{:<20} {:>10.3} {:>10.3} {:>10.1}ms {:>14.2} {:>9}/{}", name, s.ari_sum / n, s.nmi_sum / n, s.time_ms_sum / n, s.k_abs_diff_sum / n, s.n_wins, s.n_datasets);
    }
    println!("\n(ARI moyen = moyenne, sur tous les jeux, de l'ARI moyen par jeu sur {} runs ;", N_RUNS);
    println!("« victoires » = nombre de jeux où l'algorithme obtient le meilleur ARI moyen");
    println!("parmi les méthodes à K découvert automatiquement.)");

    // --- Rang par jeu + rang moyen (Demšar 2006) ---
    const DISCOVERED_ORDER: [&str; 7] = ["DBSCAN", "HDBSCAN", "OPTICS", "Mean-Shift", "PoWKM-prescribed", "DynMSC", "DenMune"];
    let algos: Vec<&'static str> = DISCOVERED_ORDER.iter().filter(|a| stats.contains_key(*a)).copied().collect();
    let k = algos.len();
    let n = rank_data.len();

    println!("\n### Rang par jeu (1 = meilleur ARI moyen), algorithmes à K découvert ###\n");
    println!("{:<40} {}", "Jeu", algos.iter().map(|a| format!("{a:>18}")).collect::<String>());
    let ranks_matrix = compute_ranks(rank_data, &algos);
    for ((dataset_name, _), ranks) in rank_data.iter().zip(ranks_matrix.iter()) {
        let row: String = ranks.iter().map(|r| format!("{r:>18.1}")).collect();
        println!("{:<40} {row}", dataset_name);
    }

    let mut avg_rank = vec![0.0; k];
    for ranks in &ranks_matrix {
        for j in 0..k {
            avg_rank[j] += ranks[j] / n as f64;
        }
    }
    let mut rank_order: Vec<usize> = (0..k).collect();
    rank_order.sort_by(|&a, &b| avg_rank[a].partial_cmp(&avg_rank[b]).unwrap());
    println!("\n### Rang moyen inter-jeux (plus petit = meilleur) ###\n");
    for &i in &rank_order {
        println!("{:<20} rang moyen = {:.3}", algos[i], avg_rank[i]);
    }

    println!("\n### Test de Friedman (correction Iman-Davenport) ###\n");
    println!("H0 : tous les algorithmes sont équivalents (même rang moyen espéré).");
    if k >= 2 && n >= 2 {
        let (chi2_f, f_f, p_value, dfn, dfd) = friedman_iman_davenport(&ranks_matrix, k);
        println!("chi²_F = {chi2_f:.4}   F_F = {f_f:.4}   ddl=({dfn},{dfd})   p = {p_value:.5}");
        if p_value < 0.05 {
            println!("=> p < 0.05 : H0 rejetée, différences significatives entre au moins deux algorithmes.");
            println!("\n### Post-hoc de Nemenyi (alpha=0.05) ###\n");
            let cd = nemenyi_cd(k, n);
            println!("Différence critique (CD) = {cd:.4} (k={k} algorithmes, n={n} jeux)");
            println!("Paires dont |rang_moyen_i - rang_moyen_j| > CD (différence significative) :\n");
            let mut any_sig = false;
            for i in 0..k {
                for j in (i + 1)..k {
                    let diff = (avg_rank[i] - avg_rank[j]).abs();
                    if diff > cd {
                        any_sig = true;
                        println!("  {} vs {} : |diff rang| = {diff:.3}  (significatif)", algos[i], algos[j]);
                    }
                }
            }
            if !any_sig {
                println!("  Aucune paire individuelle ne dépasse CD malgré un test de Friedman significatif");
                println!("  (cas connu : le test omnibus peut être significatif sans qu'aucune paire ne le");
                println!("  soit individuellement après correction Nemenyi, plus conservatrice --- résultat");
                println!("  à documenter tel quel, pas un bug.)");
            }
        } else {
            println!("=> p ≥ 0.05 : H0 non rejetée --- pas de preuve statistique de différence globale");
            println!("   entre les algorithmes à ce niveau de signification (Nemenyi non calculé, sans");
            println!("   objet si le test omnibus n'est pas significatif, cf. Demšar 2006 §3.2).");
        }
    } else {
        println!("(k={k} algorithmes, n={n} jeux --- effectif insuffisant pour un test de Friedman informatif.)");
    }
}

fn main() {
    let seed = 42;
    let data_dir = "/home/yves/Nextcloud/book/traité_d_algorithmique/article/data_cluster";

    // --- 8 jeux déjà présents ---
    let iris = DatasetSource::Fixed(standardize(&load_sklearn_csv(&format!("{data_dir}/iris.csv"), "Iris", 150, 4)));
    let wine = DatasetSource::Fixed(standardize(&load_sklearn_csv(&format!("{data_dir}/wine.csv"), "Wine", 178, 13)));
    let seeds = DatasetSource::Fixed(standardize(&load_seeds(&format!("{data_dir}/seeds.csv"))));
    let breast_cancer = DatasetSource::Fixed(standardize(&load_sklearn_csv(&format!("{data_dir}/breast_cancer.csv"), "Breast Cancer", 569, 30)));
    let sonar = DatasetSource::Fixed(standardize(&load_sonar(&format!("{data_dir}/sonar.csv"))));
    let _wholesale = DatasetSource::Fixed(standardize(&load_wholesale(&format!("{data_dir}/wholesale.csv"))));
    // German Credit : ré-échantillonné à chaque run (variance totale),
    // cf. doc de `N_RUNS` --- le sous-échantillon lui-même varie, pas
    // seulement la stochasticité interne des algorithmes.
    let german_raw = load_german_credit(&format!("{data_dir}/german_credit_numeric.txt"));
    let german = DatasetSource::Resampled { raw: german_raw, n_target: 300 };
    let _ionosphere = DatasetSource::Fixed(standardize(&load_ionosphere(&format!("{data_dir}/ionosphere.csv"))));

    // --- 7 nouveaux jeux ---
    let abalone_raw = load_abalone(&format!("{data_dir}/abalone.csv"));
    let abalone = DatasetSource::Resampled { raw: abalone_raw, n_target: 600 };
    let balance = DatasetSource::Fixed(standardize(&load_balance(&format!("{data_dir}/balance.csv"))));
    let ecoli = DatasetSource::Fixed(standardize(&load_ecoli(&format!("{data_dir}/ecoli.csv"))));
    let glass = DatasetSource::Fixed(standardize(&load_glass(&format!("{data_dir}/glass.csv"))));
    let heart = DatasetSource::Fixed(standardize(&load_heart(&format!("{data_dir}/heart.csv"))));
    let yeast_raw = load_yeast(&format!("{data_dir}/yeast.csv"));
    let yeast = DatasetSource::Resampled { raw: yeast_raw, n_target: 500 };
    let zoo = DatasetSource::Fixed(standardize(&load_zoo(&format!("{data_dir}/zoo.csv"))));

    // --- 3 nouveaux jeux médicaux (n/d faible, régime cible du
    // rétrécissement Ledoit-Wolf de PoWKM-prescribed --- cf. doc du
    // module `powkm_prescribed.rs`). SPECTF et Parkinsons, essayés dans
    // une première version, ont été retirés après diagnostic : tous deux
    // documentés comme résistants aux méthodes conventionnelles /
    // déséquilibrés, échec uniforme de TOUTES les méthodes (y compris
    // K-Means à K vrai, ARI négatif) --- pas un signal utile pour
    // comparer des méthodes de clustering entre elles. Remplacés par
    // Breast Tissue et Dermatology, tous deux benchmarks de clustering
    // établis dans la littérature (pas seulement de classification).
    let arrhythmia = DatasetSource::Fixed(standardize(&load_arrhythmia(&format!("{data_dir}/arrhythmia.data"))));
    let breast_tissue = DatasetSource::Fixed(standardize(&load_breast_tissue(&format!("{data_dir}/BreastTissue.csv"))));
    let dermatology = DatasetSource::Fixed(standardize(&load_dermatology(&format!("{data_dir}/dermatology.data"))));

    // --- 2 nouveaux jeux (extension neutre du plan d'expérience, cf. doc
    // du module) : comblent deux angles morts identifiés dans les 16 jeux
    // actifs (Wholesale/Ionosphere restent désactivés ci-dessous, cf.
    // note), indépendamment du résultat attendu pour PoWKM ---
    // sélectionnés et documentés AVANT tout run, pas après coup.
    let image_segmentation = DatasetSource::Fixed(standardize(&load_image_segmentation(&format!("{data_dir}/segmentation.csv"))));
    let hcv = DatasetSource::Fixed(standardize(&load_hcv(&format!("{data_dir}/hcvdat0.csv"))));

    let mut stats: HashMap<&'static str, AlgoStats> = HashMap::new();
    let mut rank_data: Vec<(String, HashMap<&'static str, f64>)> = Vec::new();

    run_group_multi("Jeux bien séparés (classiques du clustering)", &[&iris, &wine, &seeds, &breast_cancer], seed, N_RUNS, &mut stats, &mut rank_data);
    run_group_multi("Jeux finance/business", &[&balance], seed, N_RUNS, &mut stats, &mut rank_data);
    run_group_multi("Jeux finance/défense (haute dimension ou n plus grand)", &[&german, &sonar], seed, N_RUNS, &mut stats, &mut rank_data);
    run_group_multi("Jeux biologie (protéines/organismes)", &[&ecoli, &yeast, &zoo, &abalone], seed, N_RUNS, &mut stats, &mut rank_data);
    run_group_multi("Jeux physique/médecine", &[&glass, &heart], seed, N_RUNS, &mut stats, &mut rank_data);
    run_group_multi("Jeux médicaux n/d faible (régime cible du rétrécissement)", &[&arrhythmia, &breast_tissue, &dermatology], seed, N_RUNS, &mut stats, &mut rank_data);
    run_group_multi("Jeux nouveaux (n grand + classes équilibrées ; déséquilibre extrême)", &[&image_segmentation, &hcv], seed, N_RUNS, &mut stats, &mut rank_data);

    print_final_ranking(&stats, &rank_data);

    println!("\nRappel méthodologique : DBSCAN/HDBSCAN/OPTICS/Mean-Shift/PoWKM/PoWKM-prescribed/DynMSC/DenMune");
    println!("découvrent K eux-mêmes (hyperparamètres génériques, aucun accès aux labels) ;");
    println!("K-Means/Hiérarchique/BIRCH/Spectral reçoivent K_vrai en entrée (ne peuvent pas");
    println!("fonctionner sans). Ce ne sont pas deux catégories à comparer terme à terme sur");
    println!("l'ARI seul — la comparaison honnête porte sur K trouvé pour la première catégorie,");
    println!("et sur ARI/NMI à K fixé pour la seconde. PoWKM libre reste désactivé partout dans");
    println!("ce fichier. Chaque couple (algorithme, jeu) est répété {N_RUNS} fois (seed variable,");
    println!("y compris le sous-échantillon lui-même pour Abalone/Yeast/German Credit) --- ARI");
    println!("moyen ± écart-type et médiane reportés ; rang par jeu, rang moyen inter-jeux, test");
    println!("de Friedman (Iman-Davenport) et post-hoc de Nemenyi en fin de sortie (protocole");
    println!("Demšar, JMLR 2006). Wholesale et Ionosphere restent chargés mais désactivés des");
    println!("groupes actifs (cf. doc du module en tête de fichier).");
}
