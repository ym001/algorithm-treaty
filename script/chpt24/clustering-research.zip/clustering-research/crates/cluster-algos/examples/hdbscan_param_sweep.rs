use cluster_algos::Hdbscan;
use cluster_core::ClusteringAlgorithm;
use cluster_data::make_adversarial_density;
use cluster_metrics::adjusted_rand_index;

fn main() {
    let data = make_adversarial_density(300, 42);
    let mut best = f64::NEG_INFINITY;
    let mut best_params = (0, 0);
    for &mcs in &[3, 5, 8, 10, 15, 20, 25, 30] {
        for &ms in &[1, 2, 3, 5, 8, 10, 15] {
            let mut hdb = Hdbscan::new(mcs, ms);
            let result = hdb.fit(&data);
            let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
            let n_noise = result.labels.iter().filter(|&&l| l == -1).count();
            println!("min_cluster_size={mcs:<3} min_samples={ms:<3} -> ARI={ari:.3} n_clusters={:<3} n_noise={n_noise}", result.n_clusters);
            if ari > best {
                best = ari;
                best_params = (mcs, ms);
            }
        }
    }
    println!("\nMeilleur: min_cluster_size={}, min_samples={} -> ARI={:.3}", best_params.0, best_params.1, best);
    println!("Rappel plafond DBSCAN sur ce même jeu: 0.713");
}
