//! Exporte un jeu de données, une initialisation explicite (sans aléa), et
//! le résultat de `KMeans::lloyd` au format CSV, pour validation croisée
//! numérique contre scikit-learn (voir `validation/compare_kmeans.py`).
//!
//! Le but n'est pas de mesurer un aléa d'initialisation partagé (Rust et
//! Python ont des générateurs différents) mais de vérifier que, à
//! initialisation strictement identique, l'algorithme de Lloyd converge
//! vers le même point fixe dans les deux implémentations — c'est la seule
//! comparaison numériquement fondée entre deux implémentations
//! indépendantes d'un algorithme itératif déterministe.

use cluster_algos::KMeans;
use cluster_data::make_blobs;
use std::fs::File;
use std::io::Write;

fn write_csv(path: &str, rows: &[Vec<f64>]) {
    let mut f = File::create(path).unwrap_or_else(|e| panic!("impossible de créer {path}: {e}"));
    for row in rows {
        let line: Vec<String> = row.iter().map(|v| format!("{v:.17}")).collect();
        writeln!(f, "{}", line.join(",")).unwrap();
    }
}

fn main() {
    let data = make_blobs(300, 3, 0.8, 42);
    let k = 3;
    // Initialisation explicite et déterministe : les k premiers points du
    // jeu de données. Aucun aléa, donc Rust et Python partent du point
    // exactement identique.
    let init: Vec<Vec<f64>> = data.points[0..k].to_vec();

    let max_iter = 300;
    // tol extrêmement petite : on force la convergence quasi complète au
    // point fixe, pour éliminer toute divergence due à des critères
    // d'arrêt différents entre implémentations (le tol de scikit-learn
    // est normalisé par la variance des données, le nôtre non).
    let tol = 1e-12;

    let (labels, centroids, inertia) = KMeans::lloyd(&data.points, init.clone(), max_iter, tol);

    write_csv("validation/points.csv", &data.points);
    write_csv("validation/init_centroids.csv", &init);
    write_csv("validation/rust_centroids.csv", &centroids);
    write_csv(
        "validation/rust_labels.csv",
        &labels.iter().map(|&l| vec![l as f64]).collect::<Vec<_>>(),
    );
    let mut f = File::create("validation/rust_inertia.txt").unwrap();
    writeln!(f, "{inertia:.17}").unwrap();

    println!("Export terminé : validation/*.csv (inertie Rust = {inertia:.10})");
}
