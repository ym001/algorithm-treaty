//! Balayage du seul hyperparamètre de Mean-Shift (bandwidth) sur la suite
//! standard de bancs d'essai, pour documenter honnêtement son comportement
//! plutôt que de figer une valeur choisie arbitrairement.

use cluster_algos::MeanShift;
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_data::standard_benchmark_suite;
use cluster_metrics::adjusted_rand_index;

fn main() {
    let n = 300;
    let seed = 42;
    let suite = standard_benchmark_suite(n, seed);
    let bandwidths = [0.3, 0.5, 0.8, 1.2, 1.8, 2.5, 3.5, 5.0];

    for dataset in &suite {
        println!("\n=== {} ===", dataset.name);
        let mut best: Option<(f64, f64, usize)> = None; // (bandwidth, ari, n_clusters)
        for &bw in &bandwidths {
            let data = Dataset::new(dataset.points.clone(), dataset.labels_true.clone(), &dataset.name);
            let mut ms = MeanShift::new(bw);
            let result = ms.fit(&data);
            let ari = dataset
                .labels_true
                .as_ref()
                .map(|truth| adjusted_rand_index(truth, &result.labels));
            match ari {
                Some(a) => println!("  bandwidth={bw:<5} n_clusters={:<4} ARI={a:.3}", result.n_clusters),
                None => println!("  bandwidth={bw:<5} n_clusters={:<4} ARI=n/a", result.n_clusters),
            }
            if let Some(a) = ari {
                if best.is_none() || a > best.unwrap().1 {
                    best = Some((bw, a, result.n_clusters));
                }
            }
        }
        if let Some((bw, ari, k)) = best {
            println!("  -> meilleur: bandwidth={bw}, ARI={ari:.3}, n_clusters={k}");
        }
    }
}
