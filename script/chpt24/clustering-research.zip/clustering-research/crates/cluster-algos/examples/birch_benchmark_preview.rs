use cluster_algos::Birch;
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_data::standard_benchmark_suite;
use cluster_metrics::adjusted_rand_index;

fn main() {
    let n = 300;
    let seed = 42;
    let suite = standard_benchmark_suite(n, seed);
    let k_for = |name: &str| -> usize {
        if name.starts_with("moons") || name.starts_with("circles") {
            2
        } else {
            3
        }
    };

    for dataset in &suite {
        let k = k_for(&dataset.name);
        let mut birch = Birch::new(1.0, 8, k);
        let data = Dataset::new(dataset.points.clone(), dataset.labels_true.clone(), &dataset.name);
        let result = birch.fit(&data);
        match &dataset.labels_true {
            Some(truth) => {
                let ari = adjusted_rand_index(truth, &result.labels);
                println!("{:<20} k={k}  ARI={ari:.3}  temps={:?}", dataset.name, result.runtime);
            }
            None => println!("{:<20} k={k}  ARI=n/a  temps={:?}", dataset.name, result.runtime),
        }
    }
}
