//! Balayage (eps, min_samples) pour DBSCAN sur la suite standard de bancs
//! d'essai, pour déterminer empiriquement de bons paramètres avant de les
//! figer dans les tests unitaires (plutôt que de deviner).

use cluster_algos::Dbscan;
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_data::standard_benchmark_suite;
use cluster_metrics::adjusted_rand_index;

fn main() {
    let n = 300;
    let seed = 42;
    let suite = standard_benchmark_suite(n, seed);
    let eps_values = [0.1, 0.15, 0.2, 0.25, 0.3, 0.5, 0.8, 1.0, 1.5, 2.0];
    let min_samples_values = [3, 5, 10];

    for dataset in &suite {
        println!("\n=== {} ===", dataset.name);
        let mut best: Option<(f64, usize, f64, usize, usize)> = None; // (eps, min_samples, ari, n_clusters, n_noise)
        for &eps in &eps_values {
            for &ms in &min_samples_values {
                let data = Dataset::new(dataset.points.clone(), dataset.labels_true.clone(), &dataset.name);
                let mut db = Dbscan::new(eps, ms);
                let result = db.fit(&data);
                let n_noise = result.labels.iter().filter(|&&l| l == -1).count();
                let ari = dataset.labels_true.as_ref().map(|truth| adjusted_rand_index(truth, &result.labels));
                if let Some(a) = ari {
                    if best.is_none() || a > best.unwrap().2 {
                        best = Some((eps, ms, a, result.n_clusters, n_noise));
                    }
                }
            }
        }
        if let Some((eps, ms, ari, k, noise)) = best {
            println!("  meilleur: eps={eps}, min_samples={ms} -> ARI={ari:.3}, n_clusters={k}, n_noise={noise}");
        }
    }
}
