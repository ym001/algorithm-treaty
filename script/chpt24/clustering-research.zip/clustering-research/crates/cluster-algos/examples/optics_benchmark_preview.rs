use cluster_algos::Optics;
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_data::standard_benchmark_suite;
use cluster_metrics::adjusted_rand_index;

fn main() {
    let n = 300;
    let seed = 42;
    let suite = standard_benchmark_suite(n, seed);
    // Réutilise les (eps, min_samples) déjà validés pour DBSCAN en Phase 2
    // (comportement attendu : identique à DBSCAN à eps_extract=eps).
    let params: [(&str, f64, usize); 7] = [
        ("blobs", 2.0, 3),
        ("anisotropic", 2.0, 3),
        ("varied_blobs", 2.0, 3),
        ("moons", 0.2, 10),
        ("circles", 0.2, 3),
        ("varied_density", 3.0, 3),
        ("uniform_noise", 0.1, 5),
    ];

    for (dataset, &(_, eps, ms)) in suite.iter().zip(params.iter()) {
        let mut optics = Optics::new(eps, ms, eps);
        let data = Dataset::new(dataset.points.clone(), dataset.labels_true.clone(), &dataset.name);
        let result = optics.fit(&data);
        match &dataset.labels_true {
            Some(truth) => {
                let ari = adjusted_rand_index(truth, &result.labels);
                println!("{:<20} eps={eps:<4} ms={ms:<3} ARI={ari:.3}  n_clusters={:<3} temps={:?}", dataset.name, result.n_clusters, result.runtime);
            }
            None => println!("{:<20} eps={eps:<4} ms={ms:<3} ARI=n/a  n_clusters={:<3} temps={:?}", dataset.name, result.n_clusters, result.runtime),
        }
    }
}
