use cluster_algos::Dbscan;
use cluster_core::ClusteringAlgorithm;
use cluster_data::{make_circles, make_moons, make_uniform_noise, make_varied_density};
use cluster_metrics::adjusted_rand_index;

fn main() {
    println!("=== grille complète varied_density (n=300, seed=42) ===");
    let data = make_varied_density(300, 42);
    for &eps in &[0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0] {
        for &ms in &[3, 5, 8, 10, 15] {
            let mut db = Dbscan::new(eps, ms);
            let result = db.fit(&data);
            let n_noise = result.labels.iter().filter(|&&l| l == -1).count();
            let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
            println!("  eps={eps:<4} min_samples={ms:<3} -> ARI={ari:.3}  n_clusters={:<3} n_noise={n_noise}", result.n_clusters);
        }
    }

    println!("\n=== valeur utilisée dans le test actuel : eps=1.0, min_samples=5 ===");
    let mut db = Dbscan::new(1.0, 5);
    let result = db.fit(&data);
    let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
    println!("ARI={ari:.3}  n_clusters={}  n_noise={}", result.n_clusters, result.labels.iter().filter(|&&l| l == -1).count());

    println!("\n=== moons: eps=0.25, min_samples=5 (valeur actuelle du test) ===");
    let moons = make_moons(300, 0.08, 42);
    let mut db = Dbscan::new(0.25, 5);
    let result = db.fit(&moons);
    let ari = adjusted_rand_index(moons.labels_true.as_ref().unwrap(), &result.labels);
    println!("ARI={ari:.3}  n_clusters={}", result.n_clusters);

    println!("\n=== circles: eps=0.2, min_samples=5 (valeur actuelle du test) ===");
    let circles = make_circles(300, 0.06, 0.5, 42);
    let mut db = Dbscan::new(0.2, 5);
    let result = db.fit(&circles);
    let ari = adjusted_rand_index(circles.labels_true.as_ref().unwrap(), &result.labels);
    println!("ARI={ari:.3}  n_clusters={}", result.n_clusters);

    println!("\n=== uniform_noise: fraction de bruit pour quelques (eps, min_samples) ===");
    let noise_data = make_uniform_noise(300, 3);
    for &(eps, ms) in &[(0.1, 5), (0.15, 5), (0.2, 5)] {
        let mut db = Dbscan::new(eps, ms);
        let result = db.fit(&noise_data);
        let n_noise = result.labels.iter().filter(|&&l| l == -1).count();
        println!("  eps={eps} min_samples={ms} -> n_clusters={} n_noise_fraction={:.2}", result.n_clusters, n_noise as f64 / 300.0);
    }
}
