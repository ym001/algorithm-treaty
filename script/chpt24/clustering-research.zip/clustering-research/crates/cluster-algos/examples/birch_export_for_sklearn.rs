//! Exporte le résultat de BIRCH (Rust) sur les blobs pour validation
//! croisée contre `sklearn.cluster.Birch` (voir
//! `validation/compare_birch.py`). Les détails internes de construction de
//! l'arbre CF peuvent différer légèrement entre implémentations
//! indépendantes (ex. critère de scission) : comparaison structurelle
//! (ARI, nombre de clusters), pas d'égalité numérique exacte attendue.

use cluster_algos::Birch;
use cluster_core::ClusteringAlgorithm;
use cluster_data::make_blobs;
use std::fs::File;
use std::io::Write;

fn write_csv(path: &str, rows: &[Vec<f64>]) {
    let mut f = File::create(path).unwrap_or_else(|e| panic!("impossible de créer {path}: {e}"));
    for row in rows {
        let line: Vec<String> = row.iter().map(|v| format!("{v:.17}")).collect();
        writeln!(f, "{}", line.join(",")).unwrap();
    }
}

fn write_labels(path: &str, labels: &[i32]) {
    let mut f = File::create(path).unwrap();
    for l in labels {
        writeln!(f, "{l}").unwrap();
    }
}

fn main() {
    let data = make_blobs(300, 3, 0.8, 42);
    let threshold = 1.0;
    let branching_factor = 8;
    let n_clusters = 3;

    let mut birch = Birch::new(threshold, branching_factor, n_clusters);
    let result = birch.fit(&data);

    write_csv("validation/birch_points.csv", &data.points);
    write_labels("validation/birch_rust_labels.csv", &result.labels);

    println!(
        "n_clusters Rust={}, threshold={threshold}, branching_factor={branching_factor}",
        result.n_clusters
    );
}
