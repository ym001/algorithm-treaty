use cluster_algos::Hdbscan;
use cluster_core::ClusteringAlgorithm;
use cluster_data::{make_adversarial_density, make_blobs};
use std::fs::File;
use std::io::Write;

fn write_csv(path: &str, rows: &[Vec<f64>]) {
    let mut f = File::create(path).unwrap_or_else(|e| panic!("impossible de créer {path}: {e}"));
    for row in rows {
        let line: Vec<String> = row.iter().map(|v| format!("{v:.17}")).collect();
        writeln!(f, "{}", line.join(",")).unwrap();
    }
}

fn write_labels(path: &str, labels: &[i32]) {
    let mut f = File::create(path).unwrap();
    for l in labels {
        writeln!(f, "{l}").unwrap();
    }
}

fn main() {
    let blobs = make_blobs(300, 3, 0.8, 42);
    let mut h_blobs = Hdbscan::new(15, 5);
    let r_blobs = h_blobs.fit(&blobs);
    write_csv("validation/hdbscan_blobs_points.csv", &blobs.points);
    write_labels("validation/hdbscan_blobs_rust_labels.csv", &r_blobs.labels);

    let adv = make_adversarial_density(300, 42);
    let mut h_adv = Hdbscan::new(8, 1);
    let r_adv = h_adv.fit(&adv);
    write_csv("validation/hdbscan_adv_points.csv", &adv.points);
    write_labels("validation/hdbscan_adv_rust_labels.csv", &r_adv.labels);

    println!("blobs: n_clusters={}, adv: n_clusters={}", r_blobs.n_clusters, r_adv.n_clusters);
}
