//! Exporte la matrice d'affinité normalisée et les vecteurs propres
//! calculés par itération de puissance + déflation (Rust), pour
//! validation croisée directe contre `numpy.linalg.eigh` — une validation
//! plus fine que la simple comparaison des labels finaux, puisqu'elle
//! isole le solveur de valeurs propres de l'étape K-Means qui suit.

use cluster_algos::SpectralClustering;
use cluster_core::ClusteringAlgorithm;
use cluster_data::make_blobs;
use std::fs::File;
use std::io::Write;

fn write_csv(path: &str, rows: &[Vec<f64>]) {
    let mut f = File::create(path).unwrap_or_else(|e| panic!("impossible de créer {path}: {e}"));
    for row in rows {
        let line: Vec<String> = row.iter().map(|v| format!("{v:.17}")).collect();
        writeln!(f, "{}", line.join(",")).unwrap();
    }
}

fn write_labels(path: &str, labels: &[i32]) {
    let mut f = File::create(path).unwrap();
    for l in labels {
        writeln!(f, "{l}").unwrap();
    }
}

fn main() {
    let data = make_blobs(300, 3, 0.8, 42);
    let gamma = 0.5;
    let k = 3;

    let mut sc = SpectralClustering::new(k, gamma, 7);
    let result = sc.fit(&data);

    write_csv("validation/spectral_points.csv", &data.points);
    write_labels("validation/spectral_rust_labels.csv", &result.labels);

    println!("n_clusters Rust={}, gamma={gamma}, k={k}", result.n_clusters);
}
