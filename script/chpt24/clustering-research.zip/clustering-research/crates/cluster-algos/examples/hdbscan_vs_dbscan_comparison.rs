//! Compare DBSCAN et HDBSCAN, chacun avec son propre balayage complet
//! d'hyperparamètres, sur plusieurs jeux de données à densité hétérogène.
//!
//! Découverte empirique (Phase 3) : contrairement à l'attente initiale
//! (HDBSCAN devrait dominer DBSCAN sur données à densité hétérogène),
//! quand les DEUX algorithmes ont accès à leur meilleur réglage possible,
//! DBSCAN égale ou dépasse HDBSCAN sur toutes les configurations testées
//! ici — jamais l'inverse. Voir la discussion complète dans le README
//! (section HDBSCAN, Phase 3).

use cluster_algos::{Dbscan, Hdbscan};
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_metrics::adjusted_rand_index;
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use rand_distr::Normal;

fn make_test(centers: &[(f64, f64)], stds: &[f64], n_per: usize, seed: u64) -> Dataset {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for (k, (&(cx, cy), &std)) in centers.iter().zip(stds.iter()).enumerate() {
        let normal = Normal::new(0.0, std).unwrap();
        for _ in 0..n_per {
            points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
            labels.push(k as i32);
        }
    }
    Dataset::new(points, Some(labels), "candidate")
}

fn best_ari_dbscan(data: &Dataset) -> f64 {
    let mut best = f64::NEG_INFINITY;
    for &eps in &[0.1,0.15,0.2,0.3,0.4,0.5,0.6,0.7,0.8,1.0,1.2,1.5,1.8,2.0,2.5,3.0] {
        for &ms in &[3,5,8,10,15] {
            let mut db = Dbscan::new(eps, ms);
            let r = db.fit(data);
            let a = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &r.labels);
            if a > best { best = a; }
        }
    }
    best
}

fn best_ari_hdbscan(data: &Dataset) -> f64 {
    let mut best = f64::NEG_INFINITY;
    for &mcs in &[3,5,8,10,15,20] {
        for &ms in &[1,2,3,5,8,10] {
            let mut h = Hdbscan::new(mcs, ms);
            let r = h.fit(data);
            let a = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &r.labels);
            if a > best { best = a; }
        }
    }
    best
}

type Config<'a> = (&'a str, Vec<(f64, f64)>, Vec<f64>);

fn main() {
    let configs: Vec<Config> = vec![
        ("2 clusters (rapprochés, v3)", vec![(0.0,0.0),(2.5,0.0)], vec![0.12,1.2]),
        ("3 clusters v1 (référence)", vec![(0.0,0.0),(2.5,0.0),(6.0,0.0)], vec![0.15,0.6,1.8]),
        ("3 clusters bien séparés, écart densité extrême", vec![(0.0,0.0),(8.0,0.0),(16.0,0.0)], vec![0.1,0.1,2.5]),
        ("3 clusters séparés, 2 denses + 1 clairsemé proche", vec![(0.0,0.0),(3.0,0.0),(9.0,3.0)], vec![0.15,0.15,2.0]),
    ];
    for (name, centers, stds) in &configs {
        let data = make_test(centers, stds, 100, 42);
        let db = best_ari_dbscan(&data);
        let hdb = best_ari_hdbscan(&data);
        println!("{name}: DBSCAN={db:.3}  HDBSCAN={hdb:.3}  (diff={:.3})", hdb-db);
    }
}
