use cluster_algos::SpectralClustering;
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_data::standard_benchmark_suite;
use cluster_metrics::adjusted_rand_index;

fn main() {
    let n = 300;
    let seed = 42;
    let suite = standard_benchmark_suite(n, seed);
    // (k, gamma) : meilleurs trouvés par examples/spectral_gamma_sweep.rs
    let params: [(&str, usize, f64); 6] = [
        ("blobs", 3, 0.05),
        ("anisotropic", 3, 0.05),
        ("varied_blobs", 3, 0.05),
        ("moons", 2, 25.0),
        ("circles", 2, 50.0),
        ("varied_density", 3, 0.05),
    ];

    for (dataset, &(_, k, gamma)) in suite.iter().zip(params.iter()) {
        let mut sc = SpectralClustering::new(k, gamma, 7);
        let data = Dataset::new(dataset.points.clone(), dataset.labels_true.clone(), &dataset.name);
        let result = sc.fit(&data);
        let ari = adjusted_rand_index(dataset.labels_true.as_ref().unwrap(), &result.labels);
        println!("{:<20} k={k} gamma={gamma:<6} ARI={ari:.3}  temps={:?}", dataset.name, result.runtime);
    }
}
