use cluster_algos::{HierarchicalClustering, Linkage};
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_data::make_moons;
use cluster_metrics::adjusted_rand_index;

fn main() {
    // --- Jeu "pont" ---
    let mut points = Vec::new();
    for i in 0..5 {
        points.push(vec![0.0 + 0.1 * i as f64, 0.0]);
    }
    for i in 0..5 {
        points.push(vec![20.0 + 0.1 * i as f64, 0.0]);
    }
    for i in 1..10 {
        points.push(vec![2.0 * i as f64, 0.0]);
    }
    let data = Dataset::new(points, None, "bridge");

    println!("=== jeu pont : répartition des labels selon k, pour single et complete ===");
    for k in [2, 3, 4, 5] {
        for linkage in [Linkage::Single, Linkage::Complete] {
            let mut hc = HierarchicalClustering::new(k, linkage);
            let result = hc.fit(&data);
            println!("  k={k} linkage={:?} labels={:?}", linkage, result.labels);
        }
    }

    // --- Moons : pourquoi single linkage donne ARI=0 ---
    println!("\n=== moons : détail single linkage k=2 ===");
    let moons = make_moons(300, 0.08, 42);
    let mut hc = HierarchicalClustering::new(2, Linkage::Single);
    let result = hc.fit(&moons);
    let mut counts = std::collections::HashMap::new();
    for &l in &result.labels {
        *counts.entry(l).or_insert(0) += 1;
    }
    println!("  tailles de cluster: {:?}", counts);
    let ari = adjusted_rand_index(moons.labels_true.as_ref().unwrap(), &result.labels);
    println!("  ARI={ari}");

    // Sweep de k pour voir à partir de quand single linkage sépare quelque chose de sensé
    println!("\n=== moons : ARI single linkage en fonction de k ===");
    for k in [2, 3, 5, 10, 20] {
        let mut hc = HierarchicalClustering::new(k, Linkage::Single);
        let result = hc.fit(&moons);
        let ari = adjusted_rand_index(moons.labels_true.as_ref().unwrap(), &result.labels);
        let mut counts = std::collections::HashMap::new();
        for &l in &result.labels {
            *counts.entry(l).or_insert(0) += 1;
        }
        let mut sizes: Vec<i32> = counts.values().copied().collect();
        sizes.sort_unstable_by(|a, b| b.cmp(a));
        println!("  k={k} ARI={ari:.3} tailles(top5)={:?}", &sizes[..sizes.len().min(5)]);
    }
}
