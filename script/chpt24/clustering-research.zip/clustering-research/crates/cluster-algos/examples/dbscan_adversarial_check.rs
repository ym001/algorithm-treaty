use cluster_algos::Dbscan;
use cluster_core::ClusteringAlgorithm;
use cluster_data::make_adversarial_density;
use cluster_metrics::adjusted_rand_index;

fn main() {
    let data = make_adversarial_density(300, 42);
    println!("=== balayage DBSCAN complet sur adversarial_density (n=300, seed=42) ===");
    let mut best_ari = f64::NEG_INFINITY;
    let mut best_params = (0.0, 0);
    for &eps in &[0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 1.0, 1.2, 1.5, 2.0] {
        for &ms in &[3, 5, 8, 10, 15] {
            let mut db = Dbscan::new(eps, ms);
            let result = db.fit(&data);
            let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
            let n_noise = result.labels.iter().filter(|&&l| l == -1).count();
            println!(
                "  eps={eps:<4} min_samples={ms:<3} -> ARI={ari:.3}  n_clusters={:<3} n_noise={n_noise}",
                result.n_clusters
            );
            if ari > best_ari {
                best_ari = ari;
                best_params = (eps, ms);
            }
        }
    }
    println!("\nMeilleur trouvé: eps={}, min_samples={} -> ARI={:.3}", best_params.0, best_params.1, best_ari);
    println!(
        "{}",
        if best_ari < 0.85 {
            "CONFIRMÉ adverse: aucun (eps, min_samples) testé ne dépasse ARI=0.85"
        } else {
            "PAS assez adverse: un réglage dépasse ARI=0.85, à durcir davantage"
        }
    );
}
