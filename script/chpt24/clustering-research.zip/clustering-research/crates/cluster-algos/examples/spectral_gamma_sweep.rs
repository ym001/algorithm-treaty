use cluster_algos::SpectralClustering;
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_data::standard_benchmark_suite;
use cluster_metrics::adjusted_rand_index;

fn main() {
    let n = 300;
    let seed = 42;
    let suite = standard_benchmark_suite(n, seed);
    let gammas = [0.05, 0.1, 0.3, 0.5, 1.0, 2.0, 5.0, 10.0, 15.0, 25.0, 50.0, 100.0];

    for dataset in &suite {
        if dataset.labels_true.is_none() {
            continue;
        }
        let k = dataset.labels_true.as_ref().unwrap().iter().collect::<std::collections::HashSet<_>>().len();
        println!("\n=== {} (k={k}) ===", dataset.name);
        let mut best_ari = f64::NEG_INFINITY;
        let mut best_gamma = 0.0;
        for &gamma in &gammas {
            let data = Dataset::new(dataset.points.clone(), dataset.labels_true.clone(), &dataset.name);
            let mut sc = SpectralClustering::new(k, gamma, 7);
            let result = sc.fit(&data);
            let ari = adjusted_rand_index(dataset.labels_true.as_ref().unwrap(), &result.labels);
            println!("  gamma={gamma:<6} ARI={ari:.3}");
            if ari > best_ari {
                best_ari = ari;
                best_gamma = gamma;
            }
        }
        println!("  -> meilleur: gamma={best_gamma}, ARI={best_ari:.3}");
    }
}
