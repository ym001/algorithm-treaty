use cluster_algos::Dbscan;
use cluster_core::{ClusteringAlgorithm, Dataset};
use cluster_metrics::adjusted_rand_index;
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use rand_distr::Normal;

fn make_test(centers: &[(f64, f64)], stds: &[f64], n_per: usize, seed: u64) -> Dataset {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let mut points = Vec::new();
    let mut labels = Vec::new();
    for (k, (&(cx, cy), &std)) in centers.iter().zip(stds.iter()).enumerate() {
        let normal = Normal::new(0.0, std).unwrap();
        for _ in 0..n_per {
            points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
            labels.push(k as i32);
        }
    }
    Dataset::new(points, Some(labels), "candidate")
}

fn best_ari(data: &Dataset) -> f64 {
    let mut best = f64::NEG_INFINITY;
    for &eps in &[0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 1.0, 1.2, 1.5, 1.8, 2.0, 2.5, 3.0] {
        for &ms in &[3, 5, 8, 10, 15] {
            let mut db = Dbscan::new(eps, ms);
            let result = db.fit(data);
            let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
            if ari > best {
                best = ari;
            }
        }
    }
    best
}

type Config<'a> = (&'a str, Vec<(f64, f64)>, Vec<f64>);

fn main() {
    let configs: Vec<Config> = vec![
        (
            "chaîne v3 (référence, 0.697)",
            vec![(0.0, 0.0), (1.0, 0.0), (2.3, 0.0), (4.2, 0.0), (7.0, 0.0)],
            vec![0.05, 0.15, 0.4, 0.9, 2.0],
        ),
        (
            "chaîne v6 (5 niveaux, plus serrée)",
            vec![(0.0, 0.0), (0.8, 0.0), (1.9, 0.0), (3.6, 0.0), (6.2, 0.0)],
            vec![0.04, 0.12, 0.35, 0.8, 1.9],
        ),
        (
            "chaîne v7 (6 niveaux)",
            vec![(0.0, 0.0), (0.8, 0.0), (1.8, 0.0), (3.2, 0.0), (5.4, 0.0), (9.0, 0.0)],
            vec![0.03, 0.1, 0.25, 0.55, 1.1, 2.2],
        ),
        (
            "chaîne v8 (6 niveaux, ratio plus fort)",
            vec![(0.0, 0.0), (0.7, 0.0), (1.7, 0.0), (3.3, 0.0), (5.8, 0.0), (9.5, 0.0)],
            vec![0.025, 0.09, 0.22, 0.5, 1.1, 2.4],
        ),
    ];

    for (name, centers, stds) in &configs {
        let data = make_test(centers, stds, 100, 42);
        let ari = best_ari(&data);
        println!("{name}: meilleur ARI DBSCAN (large balayage) = {ari:.3}");
    }
}
