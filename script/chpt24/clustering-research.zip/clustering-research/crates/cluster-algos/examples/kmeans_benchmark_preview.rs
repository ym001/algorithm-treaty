//! Aperçu rapide des performances de K-Means sur la suite standard de
//! bancs d'essai (Phase 1). Ce n'est pas le harnais d'expériences complet
//! (Phase 6) : juste une vérification de sanité qualitative avant de
//! passer à l'algorithme suivant.

use cluster_algos::KMeans;
use cluster_core::ClusteringAlgorithm;
use cluster_data::{make_blobs, make_moons, make_circles, make_anisotropic, make_varied_blobs, make_varied_density};
use cluster_metrics::{adjusted_rand_index, silhouette_score};

fn report(name: &str, points: &[Vec<f64>], labels_true: Option<&[i32]>, k: usize) {
    let data = cluster_core::Dataset::new(points.to_vec(), labels_true.map(|l| l.to_vec()), name);
    let mut km = KMeans::new(k, 42);
    let result = km.fit(&data);
    let sil = silhouette_score(points, &result.labels);
    match labels_true {
        Some(truth) => {
            let ari = adjusted_rand_index(truth, &result.labels);
            println!("{name:<20} k={k}  ARI={ari:.3}  Silhouette={sil:.3}  temps={:?}", result.runtime);
        }
        None => {
            println!("{name:<20} k={k}  ARI=  n/a  Silhouette={sil:.3}  temps={:?}", result.runtime);
        }
    }
}

fn main() {
    let n = 300;
    let seed = 42;

    let blobs = make_blobs(n, 3, 0.8, seed);
    report("blobs", &blobs.points, blobs.labels_true.as_deref(), 3);

    let aniso = make_anisotropic(n, 3, 0.8, seed);
    report("anisotropic", &aniso.points, aniso.labels_true.as_deref(), 3);

    let varied = make_varied_blobs(n, seed);
    report("varied_blobs", &varied.points, varied.labels_true.as_deref(), 3);

    let moons = make_moons(n, 0.08, seed);
    report("moons", &moons.points, moons.labels_true.as_deref(), 2);

    let circles = make_circles(n, 0.06, 0.5, seed);
    report("circles", &circles.points, circles.labels_true.as_deref(), 2);

    let density = make_varied_density(n, seed);
    report("varied_density", &density.points, density.labels_true.as_deref(), 3);
}
