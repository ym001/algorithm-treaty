//! Exporte les résultats du regroupement hiérarchique (Rust, 4 critères
//! de liaison) sur les blobs pour validation croisée contre
//! `scipy.cluster.hierarchy.linkage` (voir `validation/compare_hierarchical.py`).

use cluster_algos::{HierarchicalClustering, Linkage};
use cluster_core::ClusteringAlgorithm;
use cluster_data::make_blobs;
use std::fs::File;
use std::io::Write;

fn write_csv(path: &str, rows: &[Vec<f64>]) {
    let mut f = File::create(path).unwrap_or_else(|e| panic!("impossible de créer {path}: {e}"));
    for row in rows {
        let line: Vec<String> = row.iter().map(|v| format!("{v:.17}")).collect();
        writeln!(f, "{}", line.join(",")).unwrap();
    }
}

fn write_labels(path: &str, labels: &[i32]) {
    let mut f = File::create(path).unwrap();
    for l in labels {
        writeln!(f, "{l}").unwrap();
    }
}

fn main() {
    let data = make_blobs(150, 3, 0.8, 42);
    write_csv("validation/hc_points.csv", &data.points);

    for (linkage, name) in [
        (Linkage::Single, "single"),
        (Linkage::Complete, "complete"),
        (Linkage::Average, "average"),
        (Linkage::Ward, "ward"),
    ] {
        let mut hc = HierarchicalClustering::new(3, linkage);
        let result = hc.fit(&data);
        write_labels(&format!("validation/hc_rust_labels_{name}.csv"), &result.labels);
        println!("{name}: n_clusters={}", result.n_clusters);
    }
}
