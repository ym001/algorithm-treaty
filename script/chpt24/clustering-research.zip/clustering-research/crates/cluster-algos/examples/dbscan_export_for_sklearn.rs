//! Exporte les résultats DBSCAN (Rust) sur blobs et moons pour validation
//! croisée contre `sklearn.cluster.DBSCAN` (voir
//! `validation/compare_dbscan.py`). DBSCAN étant un algorithme
//! déterministe et sans ambiguïté d'initialisation, on s'attend à un
//! accord quasi parfait (à d'éventuels points de bordure à distance
//! exactement eps près, mesure nulle en pratique sur données continues).

use cluster_algos::Dbscan;
use cluster_core::ClusteringAlgorithm;
use cluster_data::{make_blobs, make_moons};
use std::fs::File;
use std::io::Write;

fn write_csv(path: &str, rows: &[Vec<f64>]) {
    let mut f = File::create(path).unwrap_or_else(|e| panic!("impossible de créer {path}: {e}"));
    for row in rows {
        let line: Vec<String> = row.iter().map(|v| format!("{v:.17}")).collect();
        writeln!(f, "{}", line.join(",")).unwrap();
    }
}

fn write_labels(path: &str, labels: &[i32]) {
    let mut f = File::create(path).unwrap();
    for l in labels {
        writeln!(f, "{l}").unwrap();
    }
}

fn main() {
    let blobs = make_blobs(300, 3, 0.8, 42);
    let mut db_blobs = Dbscan::new(1.5, 5);
    let r_blobs = db_blobs.fit(&blobs);
    write_csv("validation/db_blobs_points.csv", &blobs.points);
    write_labels("validation/db_blobs_rust_labels.csv", &r_blobs.labels);

    let moons = make_moons(300, 0.08, 42);
    let mut db_moons = Dbscan::new(0.2, 10);
    let r_moons = db_moons.fit(&moons);
    write_csv("validation/db_moons_points.csv", &moons.points);
    write_labels("validation/db_moons_rust_labels.csv", &r_moons.labels);

    println!(
        "blobs: n_clusters={} noise={} | moons: n_clusters={} noise={}",
        r_blobs.n_clusters,
        r_blobs.labels.iter().filter(|&&l| l == -1).count(),
        r_moons.n_clusters,
        r_moons.labels.iter().filter(|&&l| l == -1).count()
    );
}
