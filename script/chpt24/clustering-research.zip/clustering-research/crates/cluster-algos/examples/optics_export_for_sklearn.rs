//! Exporte le résultat OPTICS (Rust) pour validation croisée contre
//! `sklearn.cluster.OPTICS(cluster_method='dbscan')`, qui utilise la même
//! méthode d'extraction simple que celle implémentée ici (voir
//! `validation/compare_optics.py`).

use cluster_algos::Optics;
use cluster_core::ClusteringAlgorithm;
use cluster_data::make_blobs;
use std::fs::File;
use std::io::Write;

fn write_csv(path: &str, rows: &[Vec<f64>]) {
    let mut f = File::create(path).unwrap_or_else(|e| panic!("impossible de créer {path}: {e}"));
    for row in rows {
        let line: Vec<String> = row.iter().map(|v| format!("{v:.17}")).collect();
        writeln!(f, "{}", line.join(",")).unwrap();
    }
}

fn write_labels(path: &str, labels: &[i32]) {
    let mut f = File::create(path).unwrap();
    for l in labels {
        writeln!(f, "{l}").unwrap();
    }
}

fn main() {
    let data = make_blobs(300, 3, 0.8, 42);
    let eps = 1.5;
    let min_samples = 5;

    let mut optics = Optics::new(eps, min_samples, eps);
    let result = optics.fit(&data);

    write_csv("validation/optics_points.csv", &data.points);
    write_labels("validation/optics_rust_labels.csv", &result.labels);

    println!("n_clusters Rust={}, eps={eps}, min_samples={min_samples}", result.n_clusters);
}
