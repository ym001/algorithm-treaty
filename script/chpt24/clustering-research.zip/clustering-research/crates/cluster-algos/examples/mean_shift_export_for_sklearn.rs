//! Exporte le résultat de Mean-Shift (Rust) sur les blobs pour validation
//! croisée contre `sklearn.cluster.MeanShift` (voir
//! `validation/compare_mean_shift.py`). Contrairement à K-Means, il n'y a
//! pas d'initialisation partagée possible à faire coïncider terme à terme
//! (Mean-Shift n'a pas d'aléa mais l'algorithme de fusion des modes n'a
//! pas une correspondance 1-1 triviale avec celui de scikit-learn) : la
//! comparaison porte donc sur le nombre de clusters trouvés et l'ARI entre
//! les deux étiquetages, pas sur une égalité numérique exacte.

use cluster_algos::MeanShift;
use cluster_core::ClusteringAlgorithm;
use cluster_data::make_blobs;
use std::fs::File;
use std::io::Write;

fn write_csv(path: &str, rows: &[Vec<f64>]) {
    let mut f = File::create(path).unwrap_or_else(|e| panic!("impossible de créer {path}: {e}"));
    for row in rows {
        let line: Vec<String> = row.iter().map(|v| format!("{v:.17}")).collect();
        writeln!(f, "{}", line.join(",")).unwrap();
    }
}

fn main() {
    let data = make_blobs(300, 3, 0.8, 42);
    let bandwidth = 2.5;
    let mut ms = MeanShift::new(bandwidth);
    let result = ms.fit(&data);

    write_csv("validation/ms_points.csv", &data.points);
    write_csv(
        "validation/ms_rust_labels.csv",
        &result.labels.iter().map(|&l| vec![l as f64]).collect::<Vec<_>>(),
    );
    println!("n_clusters Rust = {}, bandwidth={bandwidth}", result.n_clusters);
}
