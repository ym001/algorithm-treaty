//! DBSCAN (Ester, Kriegel, Sander & Xu, 1996) : clustering fondé sur la
//! densité locale, capable de trouver des clusters de forme arbitraire et
//! de rejeter explicitement le bruit (label -1). Entièrement déterministe
//! (pas de graine) ; l'affectation des points de bordure ambigus (à
//! distance eps de coeurs appartenant à plusieurs clusters à la fois)
//! dépend de l'ordre de traitement des points — ambiguïté documentée dans
//! l'article original, résolue ici par ordre d'indice croissant (identique
//! à la convention de scikit-learn).
//!
//! Complexité : O(n²) dans cette implémentation naïve (chaque requête de
//! voisinage est O(n)) — accélérable par un index spatial (KD-tree,
//! grille) pour de grands n, hors périmètre de cette phase.

use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};
use std::collections::VecDeque;

#[derive(Debug, Clone)]
pub struct Dbscan {
    /// Rayon de voisinage.
    pub eps: f64,
    /// Nombre minimal de points dans le voisinage epsilon (le point
    /// lui-même inclus) pour qu'un point soit un point coeur — convention
    /// identique à scikit-learn (`min_samples` compte le point lui-même).
    pub min_samples: usize,
}

impl Dbscan {
    pub fn new(eps: f64, min_samples: usize) -> Self {
        assert!(eps > 0.0, "eps doit être > 0");
        assert!(min_samples >= 1, "min_samples doit être >= 1");
        Self { eps, min_samples }
    }

    /// Voisinage epsilon de `points[idx]`, le point lui-même inclus
    /// (distance 0 <= eps).
    fn region_query(idx: usize, points: &[Vec<f64>], eps: f64) -> Vec<usize> {
        points
            .iter()
            .enumerate()
            .filter(|(_, p)| euclidean(p, &points[idx]) <= eps)
            .map(|(j, _)| j)
            .collect()
    }
}

impl ClusteringAlgorithm for Dbscan {
    fn name(&self) -> &str {
        "DBSCAN"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        assert!(!points.is_empty(), "points ne doit pas être vide");
        let eps = self.eps;
        let min_samples = self.min_samples;

        timed_fit(self.name(), || {
            let n = points.len();
            let mut visited = vec![false; n];
            let mut labels: Vec<i32> = vec![-1; n];
            let mut cluster_id: i32 = 0;

            for i in 0..n {
                if visited[i] {
                    continue;
                }
                visited[i] = true;
                let neighbors = Self::region_query(i, points, eps);
                if neighbors.len() < min_samples {
                    // Reste "bruit" pour l'instant — pourra être
                    // revendiqué comme point de bordure par un autre
                    // cluster plus tard dans le parcours.
                    continue;
                }

                labels[i] = cluster_id;
                let mut queue: VecDeque<usize> = neighbors.into_iter().collect();

                while let Some(j) = queue.pop_front() {
                    if !visited[j] {
                        visited[j] = true;
                        let j_neighbors = Self::region_query(j, points, eps);
                        if j_neighbors.len() >= min_samples {
                            // j est aussi un point coeur : propage la
                            // densité-atteignabilité à son voisinage.
                            for nb in j_neighbors {
                                queue.push_back(nb);
                            }
                        }
                    }
                    if labels[j] == -1 {
                        labels[j] = cluster_id;
                    }
                }
                cluster_id += 1;
            }

            let n_clusters = cluster_id as usize;
            (labels, n_clusters)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_core::Dataset;
    use cluster_data::{make_blobs, make_circles, make_moons, make_uniform_noise, make_varied_density};
    use cluster_metrics::adjusted_rand_index;

    #[test]
    fn hand_computed_chain_plus_outlier() {
        // Chaîne dense {1.0, 1.1, 1.2} (chaque paire consécutive à 0.1,
        // extrêmes à 0.2, toutes <= eps=0.3) + un point isolé à 5.0.
        // eps=0.3, min_samples=2 : les 3 premiers points sont mutuellement
        // voisins (voisinage de taille 3 >= 2, tous coeurs), le 4e est seul
        // dans son voisinage (taille 1 < 2) -> bruit.
        let points = vec![vec![1.0], vec![1.1], vec![1.2], vec![5.0]];
        let data = Dataset::new(points, None, "toy_chain");
        let mut db = Dbscan::new(0.3, 2);
        let result = db.fit(&data);

        assert_eq!(result.n_clusters, 1);
        assert_eq!(result.labels[0], result.labels[1]);
        assert_eq!(result.labels[1], result.labels[2]);
        assert_eq!(result.labels[3], -1, "le point isolé doit être étiqueté bruit");
    }

    #[test]
    fn hand_computed_two_dense_groups_plus_outlier() {
        let points = vec![
            vec![0.0],
            vec![0.1],
            vec![0.2],
            vec![10.0],
            vec![10.1],
            vec![10.2],
            vec![1000.0],
        ];
        let data = Dataset::new(points, None, "toy_two_groups");
        let mut db = Dbscan::new(0.3, 2);
        let result = db.fit(&data);

        assert_eq!(result.n_clusters, 2);
        assert_eq!(result.labels[0], result.labels[1]);
        assert_eq!(result.labels[1], result.labels[2]);
        assert_eq!(result.labels[3], result.labels[4]);
        assert_eq!(result.labels[4], result.labels[5]);
        assert_ne!(result.labels[0], result.labels[3]);
        assert_eq!(result.labels[6], -1);
    }

    #[test]
    fn deterministic_across_runs() {
        let data = make_blobs(200, 3, 0.8, 5);
        let mut db1 = Dbscan::new(1.5, 5);
        let mut db2 = Dbscan::new(1.5, 5);
        let r1 = db1.fit(&data);
        let r2 = db2.fit(&data);
        assert_eq!(r1.labels, r2.labels);
    }

    #[test]
    fn min_samples_one_and_huge_eps_yields_single_cluster() {
        // min_samples=1 : chaque point est trivialement coeur (son propre
        // voisinage a toujours taille >= 1). eps énorme : tous les points
        // sont mutuellement atteignables -> un unique cluster, zéro bruit.
        let data = make_blobs(150, 4, 1.0, 3);
        let mut db = Dbscan::new(1e6, 1);
        let result = db.fit(&data);
        assert_eq!(result.n_clusters, 1);
        assert!(result.labels.iter().all(|&l| l == 0));
    }

    #[test]
    fn min_samples_larger_than_n_yields_all_noise() {
        let data = make_blobs(50, 2, 0.5, 3);
        let mut db = Dbscan::new(1.0, 1000);
        let result = db.fit(&data);
        assert_eq!(result.n_clusters, 0);
        assert!(result.labels.iter().all(|&l| l == -1));
    }

    #[test]
    fn recovers_well_separated_blobs_with_high_ari() {
        let data = make_blobs(300, 3, 0.8, 42);
        let mut db = Dbscan::new(1.5, 5);
        let result = db.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "ARI trop bas sur des blobs bien séparés: {ari}");
    }

    #[test]
    fn succeeds_on_non_convex_moons_unlike_kmeans_and_mean_shift() {
        // Propriété distinctive de DBSCAN : contrairement à K-Means et
        // Mean-Shift (testés en Phase 2, échec documenté), un eps/min_samples
        // bien choisi doit séparer correctement les lunes (non convexes).
        // Paramètres déterminés empiriquement par balayage (voir
        // examples/dbscan_param_sweep.rs) avant d'écrire ce test — un premier
        // essai à eps=0.25/min_samples=5 donnait en réalité ARI=0.0 (tout
        // fusionné en un seul cluster), corrigé après vérification plutôt
        // que supposé correct.
        let data = make_moons(300, 0.08, 42);
        let mut db = Dbscan::new(0.2, 10);
        let result = db.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.95, "DBSCAN devrait réussir sur les lunes avec de bons paramètres: ARI={ari}");
    }

    #[test]
    fn succeeds_on_non_convex_circles_unlike_kmeans_and_mean_shift() {
        let data = make_circles(300, 0.06, 0.5, 42);
        let mut db = Dbscan::new(0.2, 5);
        let result = db.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.85, "DBSCAN devrait réussir sur les cercles avec de bons paramètres: ARI={ari}");
    }

    #[test]
    fn documented_behavior_on_varied_density() {
        // Hypothèse initiale (issue de la littérature) : un eps global
        // unique ne devrait pas convenir simultanément à un cluster dense
        // et à un cluster clairsemé. Vérification empirique par balayage
        // complet (voir examples/dbscan_verify_test_params.rs) : sur CE
        // jeu de données précis, l'échec attendu ne se manifeste pas
        // clairement — la plupart des combinaisons (eps, min_samples)
        // donnent ARI > 0.9, y compris eps=1.0/min_samples=5 (ARI=0.983,
        // mais 4 clusters trouvés au lieu de 3 : le cluster clairsemé est
        // fragmenté, signe indirect de la limitation, sans effondrement
        // total). Les centres sont probablement trop bien séparés relatif
        // aux écarts-types pour que la limitation soit sévère à n=300.
        // On documente le résultat réel plutôt que de forcer une
        // conclusion attendue mais non observée — point à noter pour
        // l'article : la limitation théorique de DBSCAN sur densité
        // hétérogène nécessitera un jeu de données conçu spécifiquement
        // pour la stresser (centres plus rapprochés, écart de std plus
        // extrême) plutôt que `varied_density` tel quel.
        let data = make_varied_density(300, 42);
        let mut db = Dbscan::new(1.0, 5);
        let result = db.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        println!("varied_density eps=1.0 min_samples=5 -> ARI={ari}, n_clusters={}", result.n_clusters);
        assert_eq!(result.labels.len(), data.n_samples());
    }

    #[test]
    fn uniform_noise_produces_mostly_noise_labels() {
        let data = make_uniform_noise(300, 3);
        let mut db = Dbscan::new(0.1, 5);
        let result = db.fit(&data);
        let noise_fraction = result.labels.iter().filter(|&&l| l == -1).count() as f64 / data.n_samples() as f64;
        assert!(
            noise_fraction > 0.5,
            "sur du bruit uniforme, la majorité des points devrait rester non classée: {noise_fraction}"
        );
    }

    #[test]
    #[should_panic(expected = "eps doit être > 0")]
    fn panics_on_non_positive_eps() {
        Dbscan::new(0.0, 5);
    }
}
