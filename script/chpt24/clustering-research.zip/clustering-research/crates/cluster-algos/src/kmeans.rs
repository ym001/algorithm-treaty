//! K-Means : algorithme de Lloyd (1957/1982) / MacQueen (1967), avec
//! initialisation k-means++ (Arthur & Vassilvitskii, 2007) et redémarrages
//! multiples (`n_init`, conserve le meilleur run par inertie).
//!
//! `lloyd()` est exposée publiquement à initialisation explicite (pas
//! d'aléa) spécifiquement pour permettre une validation croisée numérique
//! contre une implémentation de référence externe (scikit-learn) à
//! initialisation identique — voir `tests/kmeans_sklearn_cross_validation`
//! à la racine du workspace.

use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use std::collections::HashSet;

#[derive(Debug, Clone)]
pub struct KMeans {
    pub k: usize,
    pub max_iter: usize,
    pub tol: f64,
    pub n_init: usize,
    pub seed: u64,
}

impl KMeans {
    /// Paramètres par défaut alignés sur ceux de scikit-learn
    /// (`max_iter=300`, `tol=1e-4`, `n_init=10`) pour faciliter la
    /// comparaison directe des résultats.
    pub fn new(k: usize, seed: u64) -> Self {
        Self {
            k,
            max_iter: 300,
            tol: 1e-4,
            n_init: 10,
            seed,
        }
    }

    /// Initialisation k-means++ : le premier centroïde est tiré
    /// uniformément parmi les points ; chaque centroïde suivant est tiré
    /// avec une probabilité proportionnelle au carré de la distance au
    /// centroïde déjà choisi le plus proche.
    /// Visibilité `pub(crate)` : réutilisée telle quelle par
    /// `spectral::SpectralClustering` pour l'étape K-Means finale sur le
    /// plongement spectral, afin de ne pas dupliquer l'initialisation
    /// k-means++ déjà validée.
    pub(crate) fn kmeans_plus_plus_init(points: &[Vec<f64>], k: usize, rng: &mut ChaCha8Rng) -> Vec<Vec<f64>> {
        let n = points.len();
        let mut centroids: Vec<Vec<f64>> = Vec::with_capacity(k);
        let first = rng.gen_range(0..n);
        centroids.push(points[first].clone());

        let mut dist_sq: Vec<f64> = points.iter().map(|p| euclidean(p, &centroids[0]).powi(2)).collect();

        while centroids.len() < k {
            let total: f64 = dist_sq.iter().sum();
            let chosen_idx = if total <= 0.0 {
                // Tous les points restants coïncident avec un centroïde
                // déjà choisi : repli sur un tirage uniforme pour ne pas
                // rester bloqué (cas dégénéré, ex : moins de k points
                // distincts).
                rng.gen_range(0..n)
            } else {
                let target = rng.gen::<f64>() * total;
                let mut cum = 0.0;
                let mut idx = n - 1;
                for (i, &d) in dist_sq.iter().enumerate() {
                    cum += d;
                    if cum >= target {
                        idx = i;
                        break;
                    }
                }
                idx
            };
            let new_centroid = points[chosen_idx].clone();
            for (i, p) in points.iter().enumerate() {
                let d = euclidean(p, &new_centroid).powi(2);
                if d < dist_sq[i] {
                    dist_sq[i] = d;
                }
            }
            centroids.push(new_centroid);
        }
        centroids
    }

    /// Affecte chaque point au centroïde le plus proche (distance
    /// euclidienne). En cas d'égalité exacte, le centroïde de plus petit
    /// indice l'emporte (déterminisme garanti). Retourne aussi l'inertie
    /// (somme des distances au carré), l'objectif minimisé par K-Means.
    fn assign(points: &[Vec<f64>], centroids: &[Vec<f64>]) -> (Vec<usize>, f64) {
        let mut labels = Vec::with_capacity(points.len());
        let mut inertia = 0.0;
        for p in points {
            let mut best = 0usize;
            let mut best_d = f64::INFINITY;
            for (c_idx, c) in centroids.iter().enumerate() {
                let d = euclidean(p, c).powi(2);
                if d < best_d {
                    best_d = d;
                    best = c_idx;
                }
            }
            labels.push(best);
            inertia += best_d;
        }
        (labels, inertia)
    }

    /// Recalcule chaque centroïde comme la moyenne des points qui lui sont
    /// affectés. Un cluster vide est réinitialisé sur le point le plus
    /// éloigné de son centroïde assigné (pratique standard, évite de
    /// perdre définitivement un cluster).
    fn update_centroids(
        points: &[Vec<f64>],
        labels: &[usize],
        k: usize,
        dim: usize,
        assignment_centroids: &[Vec<f64>],
    ) -> Vec<Vec<f64>> {
        let mut sums = vec![vec![0.0; dim]; k];
        let mut counts = vec![0usize; k];
        for (p, &l) in points.iter().zip(labels.iter()) {
            counts[l] += 1;
            for (j, &pj) in p.iter().enumerate() {
                sums[l][j] += pj;
            }
        }
        for c in 0..k {
            if counts[c] == 0 {
                let (farthest_idx, _) = points
                    .iter()
                    .enumerate()
                    .map(|(i, p)| (i, euclidean(p, &assignment_centroids[labels[i]])))
                    .fold((0usize, f64::NEG_INFINITY), |acc, x| if x.1 > acc.1 { x } else { acc });
                sums[c] = points[farthest_idx].clone();
            } else {
                for v in sums[c].iter_mut() {
                    *v /= counts[c] as f64;
                }
            }
        }
        sums
    }

    /// Un run complet de l'algorithme de Lloyd à partir de centroïdes
    /// initiaux explicites (aucun aléa). Publique pour permettre une
    /// validation croisée numérique contre une implémentation de
    /// référence à initialisation identique.
    pub fn lloyd(
        points: &[Vec<f64>],
        init_centroids: Vec<Vec<f64>>,
        max_iter: usize,
        tol: f64,
    ) -> (Vec<usize>, Vec<Vec<f64>>, f64) {
        assert!(!points.is_empty(), "points ne doit pas être vide");
        let dim = points[0].len();
        let k = init_centroids.len();
        let mut centroids = init_centroids;
        let mut labels = vec![0usize; points.len()];
        let mut inertia = f64::INFINITY;

        for _ in 0..max_iter.max(1) {
            let (new_labels, new_inertia) = Self::assign(points, &centroids);
            let new_centroids = Self::update_centroids(points, &new_labels, k, dim, &centroids);

            let shift: f64 = centroids
                .iter()
                .zip(new_centroids.iter())
                .map(|(a, b)| euclidean(a, b))
                .sum();

            labels = new_labels;
            inertia = new_inertia;
            centroids = new_centroids;

            if shift < tol {
                break;
            }
        }
        (labels, centroids, inertia)
    }
}

impl ClusteringAlgorithm for KMeans {
    fn name(&self) -> &str {
        "K-Means"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        assert!(self.k >= 1, "k doit être >= 1");
        assert!(
            data.n_samples() >= self.k,
            "n_samples ({}) doit être >= k ({})",
            data.n_samples(),
            self.k
        );

        let points = &data.points;
        let k = self.k;
        let max_iter = self.max_iter;
        let tol = self.tol;
        let n_init = self.n_init.max(1);
        let mut rng = ChaCha8Rng::seed_from_u64(self.seed);

        timed_fit(self.name(), || {
            let mut best_labels: Option<Vec<usize>> = None;
            let mut best_inertia = f64::INFINITY;
            for _ in 0..n_init {
                let init = Self::kmeans_plus_plus_init(points, k, &mut rng);
                let (labels, _centroids, inertia) = Self::lloyd(points, init, max_iter, tol);
                if inertia < best_inertia {
                    best_inertia = inertia;
                    best_labels = Some(labels);
                }
            }
            let labels = best_labels.unwrap();
            let n_clusters = labels.iter().collect::<HashSet<_>>().len();
            (labels.into_iter().map(|l| l as i32).collect(), n_clusters)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_data::{make_blobs, make_moons};
    use cluster_metrics::adjusted_rand_index;

    #[test]
    fn hand_computed_two_clusters_1d() {
        // {0.0, 1.0} et {10.0, 11.0} : optimum connu analytiquement.
        // Cluster gauche : moyenne 0.5, SS = 0.25+0.25 = 0.5.
        // Cluster droit  : moyenne 10.5, SS = 0.25+0.25 = 0.5.
        // Inertie totale optimale = 1.0.
        let points = vec![vec![0.0], vec![1.0], vec![10.0], vec![11.0]];
        let init = vec![vec![0.0], vec![10.0]]; // init proche de l'optimum, déterministe
        let (labels, _centroids, inertia) = KMeans::lloyd(&points, init, 300, 1e-6);

        assert_eq!(labels[0], labels[1]);
        assert_eq!(labels[2], labels[3]);
        assert_ne!(labels[0], labels[2]);
        assert!((inertia - 1.0).abs() < 1e-9, "inertia={inertia}");
    }

    #[test]
    fn deterministic_given_same_seed() {
        let data = make_blobs(200, 3, 1.0, 5);
        let mut km1 = KMeans::new(3, 123);
        let mut km2 = KMeans::new(3, 123);
        let r1 = km1.fit(&data);
        let r2 = km2.fit(&data);
        assert_eq!(r1.labels, r2.labels);
    }

    #[test]
    fn recovers_well_separated_blobs_with_high_ari() {
        let data = make_blobs(300, 3, 0.8, 42);
        let mut km = KMeans::new(3, 7);
        let result = km.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "ARI trop bas sur des blobs bien séparés: {ari}");
        assert_eq!(result.n_clusters, 3);
    }

    #[test]
    fn documented_failure_on_non_convex_moons() {
        // K-Means suppose des clusters convexes (cellules de Voronoï) :
        // sur les lunes (non convexes), il ne peut structurellement pas
        // retrouver la vérité terrain. Ce test documente et fige ce
        // comportement attendu de la littérature, ce n'est pas un bug.
        let data = make_moons(300, 0.08, 42);
        let mut km = KMeans::new(2, 7);
        let result = km.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari < 0.6, "ARI inattendument haut sur des lunes non convexes: {ari}");
    }

    #[test]
    fn lloyd_inertia_is_monotonically_non_increasing() {
        let points = vec![
            vec![0.0, 0.0],
            vec![0.2, 0.1],
            vec![9.8, 10.0],
            vec![10.0, 9.9],
            vec![5.0, 5.0],
        ];
        let init = vec![vec![0.0, 0.0], vec![10.0, 10.0]];

        let (_labels_1step, _c1, inertia_1step) = KMeans::lloyd(&points, init.clone(), 1, 0.0);
        let (_labels_full, _c_full, inertia_full) = KMeans::lloyd(&points, init, 300, 1e-9);

        assert!(
            inertia_full <= inertia_1step + 1e-9,
            "l'inertie doit décroître (ou stagner) avec plus d'itérations: 1 itér={inertia_1step}, convergé={inertia_full}"
        );
    }

    #[test]
    fn empty_cluster_is_reinitialized_without_panicking() {
        // 3 points confondus en 0.0 et 1 point isolé en 100.0, avec k=3 :
        // le centroïde initial à 1.0 ne reçoit structurellement aucun
        // point au premier tour (0.0 est plus proche de 0.0, 100.0 est
        // plus proche de 2.0) -> cluster vide garanti.
        let points = vec![vec![0.0], vec![0.0], vec![0.0], vec![100.0]];
        let init = vec![vec![0.0], vec![1.0], vec![2.0]];
        let (labels, centroids, _inertia) = KMeans::lloyd(&points, init, 300, 1e-6);
        assert_eq!(labels.len(), 4);
        assert_eq!(centroids.len(), 3);
    }

    #[test]
    #[should_panic(expected = "n_samples")]
    fn panics_if_k_exceeds_n_samples() {
        let data = make_blobs(3, 2, 0.5, 0);
        let mut km = KMeans::new(10, 0);
        km.fit(&data);
    }
}
