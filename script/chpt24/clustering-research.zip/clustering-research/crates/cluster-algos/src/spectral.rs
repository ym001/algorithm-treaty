//! Spectral Clustering (Ng, Jordan & Weiss, 2002 ; normalisation
//! symétrique du laplacien de graphe). Contrairement aux algorithmes
//! précédents, ne travaille pas directement dans l'espace des données mais
//! dans un espace spectral dérivé d'un graphe de similarité — capable, en
//! principe, de séparer des clusters non convexes (comme DBSCAN) via une
//! notion de similarité locale plutôt que de distance globale.
//!
//! Pipeline :
//! 1. **Matrice d'affinité** RBF : `W_ij = exp(-gamma * d(x_i,x_j)²)`.
//! 2. **Normalisation symétrique** : `M = D^{-1/2} W D^{-1/2}`, où `D` est
//!    la matrice de degré (diagonale, `D_ii = sum_j W_ij`). Les k plus
//!    grands vecteurs propres de `M` correspondent aux k plus petits du
//!    laplacien normalisé `L_sym = I - M` (mêmes vecteurs propres,
//!    valeurs propres décalées de 1) — travailler sur `M` évite de
//!    calculer `L_sym` explicitement.
//! 3. **k plus grands vecteurs propres** de `M`, calculés par itération de
//!    puissance + déflation (pas de dépendance à une bibliothèque
//!    d'algèbre linéaire externe).
//! 4. **Plongement spectral** : matrice `U` (n × k) de ces vecteurs
//!    propres en colonnes, lignes renormalisées à norme unité (Ng-Jordan-Weiss).
//! 5. **K-Means final** sur les lignes de `U` — réutilise directement
//!    `KMeans::lloyd`, déjà validé à la précision machine contre
//!    scikit-learn en Phase 2.
//!
//! Complexité : O(n²) pour construire l'affinité, O(k × n² × iterations)
//! pour l'itération de puissance + déflation.

use crate::kmeans::KMeans;
use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;

fn matvec(m: &[Vec<f64>], v: &[f64]) -> Vec<f64> {
    m.iter().map(|row| row.iter().zip(v.iter()).map(|(a, b)| a * b).sum()).collect()
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b.iter()).map(|(x, y)| x * y).sum()
}

fn l2_norm(v: &[f64]) -> f64 {
    dot(v, v).sqrt()
}

fn normalize_in_place(v: &mut [f64]) {
    let n = l2_norm(v);
    if n > 1e-15 {
        for x in v.iter_mut() {
            *x /= n;
        }
    }
}

/// Itération de puissance : converge vers le vecteur propre associé à la
/// valeur propre de plus grande valeur absolue de `matrix` (matrice
/// symétrique). La valeur propre elle-même est récupérée via le quotient
/// de Rayleigh `v^T M v` une fois convergé (plus précis que la norme
/// utilisée pendant l'itération).
fn power_iteration(matrix: &[Vec<f64>], n: usize, max_iter: usize, tol: f64, rng: &mut ChaCha8Rng) -> (Vec<f64>, f64) {
    let mut v: Vec<f64> = (0..n).map(|_| rng.gen::<f64>() - 0.5).collect();
    normalize_in_place(&mut v);

    for _ in 0..max_iter {
        let mut mv = matvec(matrix, &v);
        normalize_in_place(&mut mv);
        let shift: f64 = v.iter().zip(mv.iter()).map(|(a, b)| (a - b).abs()).sum();
        let shift_flipped: f64 = v.iter().zip(mv.iter()).map(|(a, b)| (a + b).abs()).sum();
        v = mv;
        // Convergence à un signe près (un vecteur propre et son opposé
        // sont tous deux valides), d'où le test sur les deux orientations.
        if shift.min(shift_flipped) < tol {
            break;
        }
    }
    let mv = matvec(matrix, &v);
    let eigenvalue = dot(&v, &mv);
    (v, eigenvalue)
}

/// Les `k` vecteurs propres de plus grande valeur propre (en valeur
/// signée, pas en valeur absolue — valide ici car la matrice normalisée
/// d'affinité a son spectre dominé par des valeurs propres positives) via
/// itération de puissance répétée + déflation : après avoir trouvé
/// `(v, λ)`, on soustrait `λ v vᵀ` de la matrice de travail avant de
/// chercher le suivant, ce qui élimine cette composante du spectre.
fn top_k_eigenvectors(matrix: &[Vec<f64>], n: usize, k: usize, max_iter: usize, tol: f64, seed: u64) -> Vec<(Vec<f64>, f64)> {
    let mut rng = ChaCha8Rng::seed_from_u64(seed);
    let mut working: Vec<Vec<f64>> = matrix.to_vec();
    let mut results = Vec::with_capacity(k);

    for _ in 0..k {
        let (v, lambda) = power_iteration(&working, n, max_iter, tol, &mut rng);
        for a in 0..n {
            for b in 0..n {
                working[a][b] -= lambda * v[a] * v[b];
            }
        }
        results.push((v, lambda));
    }
    results
}

fn rbf_affinity(points: &[Vec<f64>], gamma: f64) -> Vec<Vec<f64>> {
    let n = points.len();
    let mut w = vec![vec![0.0; n]; n];
    for i in 0..n {
        w[i][i] = 1.0; // exp(-gamma*0) = 1
        for j in (i + 1)..n {
            let d2 = euclidean(&points[i], &points[j]).powi(2);
            let sim = (-gamma * d2).exp();
            w[i][j] = sim;
            w[j][i] = sim;
        }
    }
    w
}

/// Normalisation symétrique `M = D^{-1/2} W D^{-1/2}`.
fn normalized_affinity(w: &[Vec<f64>]) -> Vec<Vec<f64>> {
    let n = w.len();
    let degree: Vec<f64> = w.iter().map(|row| row.iter().sum()).collect();
    let inv_sqrt_degree: Vec<f64> = degree.iter().map(|&d| if d > 1e-15 { 1.0 / d.sqrt() } else { 0.0 }).collect();

    let mut m = vec![vec![0.0; n]; n];
    for i in 0..n {
        for j in 0..n {
            m[i][j] = w[i][j] * inv_sqrt_degree[i] * inv_sqrt_degree[j];
        }
    }
    m
}

#[derive(Debug, Clone)]
pub struct SpectralClustering {
    pub n_clusters: usize,
    /// Paramètre du noyau RBF : `W_ij = exp(-gamma * d(x_i,x_j)²)`. Plus
    /// grand = similarité plus rapidement décroissante avec la distance
    /// (graphe de voisinage plus "local").
    pub gamma: f64,
    pub seed: u64,
    pub max_iter_eigen: usize,
    pub tol_eigen: f64,
}

impl SpectralClustering {
    pub fn new(n_clusters: usize, gamma: f64, seed: u64) -> Self {
        assert!(n_clusters >= 1, "n_clusters doit être >= 1");
        assert!(gamma > 0.0, "gamma doit être > 0");
        Self { n_clusters, gamma, seed, max_iter_eigen: 500, tol_eigen: 1e-9 }
    }
}

impl ClusteringAlgorithm for SpectralClustering {
    fn name(&self) -> &str {
        "Spectral Clustering"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        let n = points.len();
        assert!(n >= self.n_clusters, "n_samples doit être >= n_clusters");
        let k = self.n_clusters;
        let gamma = self.gamma;
        let seed = self.seed;
        let max_iter_eigen = self.max_iter_eigen;
        let tol_eigen = self.tol_eigen;

        timed_fit(self.name(), || {
            let w = rbf_affinity(points, gamma);
            let m = normalized_affinity(&w);
            let eigvecs = top_k_eigenvectors(&m, n, k, max_iter_eigen, tol_eigen, seed);

            // U (n x k) : colonnes = vecteurs propres ; puis renormalisation
            // de chaque LIGNE à norme unité (Ng-Jordan-Weiss).
            let mut u = vec![vec![0.0; k]; n];
            for (col, (v, _lambda)) in eigvecs.iter().enumerate() {
                for row in 0..n {
                    u[row][col] = v[row];
                }
            }
            for row in u.iter_mut() {
                normalize_in_place(row);
            }

            // K-Means final sur les lignes de U, réutilisant l'implémentation
            // déjà validée (k-means++ + Lloyd) du crate.
            let mut rng = ChaCha8Rng::seed_from_u64(seed.wrapping_add(1));
            let mut best_labels: Option<Vec<usize>> = None;
            let mut best_inertia = f64::INFINITY;
            for _ in 0..10 {
                let init = KMeans::kmeans_plus_plus_init(&u, k, &mut rng);
                let (labels, _centroids, inertia) = KMeans::lloyd(&u, init, 300, 1e-6);
                if inertia < best_inertia {
                    best_inertia = inertia;
                    best_labels = Some(labels);
                }
            }
            let labels = best_labels.unwrap();
            let n_clusters = labels.iter().collect::<std::collections::HashSet<_>>().len();
            (labels.into_iter().map(|l| l as i32).collect(), n_clusters)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_data::{make_blobs, make_circles, make_moons};
    use cluster_metrics::adjusted_rand_index;

    #[test]
    fn power_iteration_hand_computed_2x2() {
        // Matrice [[2,1],[1,2]] : valeurs propres 3 et 1, vecteurs propres
        // (1,1)/sqrt(2) et (1,-1)/sqrt(2) respectivement. L'itération de
        // puissance doit converger vers la valeur propre dominante (3).
        let matrix = vec![vec![2.0, 1.0], vec![1.0, 2.0]];
        let mut rng = ChaCha8Rng::seed_from_u64(0);
        let (v, lambda) = power_iteration(&matrix, 2, 200, 1e-12, &mut rng);
        assert!((lambda - 3.0).abs() < 1e-6, "lambda={lambda}");
        // v doit être colinéaire à (1,1)/sqrt(2), à signe près.
        let expected = 1.0 / 2.0_f64.sqrt();
        assert!((v[0].abs() - expected).abs() < 1e-4, "v={v:?}");
        assert!((v[1].abs() - expected).abs() < 1e-4, "v={v:?}");
        assert!((v[0] - v[1]).abs() < 1e-4 || (v[0] + v[1]).abs() < 1e-4, "v={v:?}");
    }

    #[test]
    fn top_k_eigenvectors_recovers_both_eigenvalues_of_2x2() {
        let matrix = vec![vec![2.0, 1.0], vec![1.0, 2.0]];
        let results = top_k_eigenvectors(&matrix, 2, 2, 200, 1e-12, 0);
        let mut lambdas: Vec<f64> = results.iter().map(|(_, l)| *l).collect();
        lambdas.sort_by(|a, b| b.partial_cmp(a).unwrap());
        assert!((lambdas[0] - 3.0).abs() < 1e-6, "lambdas={lambdas:?}");
        assert!((lambdas[1] - 1.0).abs() < 1e-6, "lambdas={lambdas:?}");
    }

    #[test]
    fn rbf_affinity_hand_computed() {
        // Deux points à distance 1, gamma=1 : W_01 = exp(-1*1²) = exp(-1).
        // Diagonale = 1 (similarité à soi-même).
        let points = vec![vec![0.0], vec![1.0]];
        let w = rbf_affinity(&points, 1.0);
        assert!((w[0][0] - 1.0).abs() < 1e-12);
        assert!((w[1][1] - 1.0).abs() < 1e-12);
        assert!((w[0][1] - (-1.0_f64).exp()).abs() < 1e-12);
        assert_eq!(w[0][1], w[1][0]);
    }

    #[test]
    fn normalized_affinity_hand_computed() {
        // Graphe 2 points, W=[[1,0.5],[0.5,1]]. Degrés: D0=1.5, D1=1.5.
        // M_01 = W_01 / sqrt(D0*D1) = 0.5/1.5 = 1/3.
        let w = vec![vec![1.0, 0.5], vec![0.5, 1.0]];
        let m = normalized_affinity(&w);
        assert!((m[0][1] - (1.0 / 3.0)).abs() < 1e-9, "m={m:?}");
        assert!((m[0][0] - (1.0 / 1.5)).abs() < 1e-9);
    }

    #[test]
    fn deterministic_across_runs() {
        let data = make_blobs(150, 3, 0.8, 5);
        let mut s1 = SpectralClustering::new(3, 0.5, 7);
        let mut s2 = SpectralClustering::new(3, 0.5, 7);
        assert_eq!(s1.fit(&data).labels, s2.fit(&data).labels);
    }

    #[test]
    fn recovers_well_separated_blobs_with_high_ari() {
        let data = make_blobs(200, 3, 0.8, 42);
        let mut sc = SpectralClustering::new(3, 0.5, 7);
        let result = sc.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "ARI trop bas sur des blobs bien séparés: {ari}");
    }

    #[test]
    fn succeeds_on_non_convex_moons_with_appropriate_gamma() {
        // Propriété distinctive de Spectral Clustering (comme DBSCAN) :
        // capable de séparer des clusters non convexes, contrairement à
        // K-Means/Ward. gamma=15 donne ARI=0.934 (le maximum du balayage,
        // gamma=25, donne ARI=1.000 mais 15 suffit largement à démontrer
        // la propriété et laisse une marge de robustesse pour ce test).
        // Voir examples/spectral_gamma_sweep.rs pour le balayage complet.
        let data = make_moons(300, 0.08, 42);
        let mut sc = SpectralClustering::new(2, 15.0, 7);
        let result = sc.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "Spectral Clustering devrait réussir sur les lunes avec un bon gamma: ARI={ari}");
    }

    #[test]
    fn succeeds_on_non_convex_circles_with_appropriate_gamma() {
        // gamma déterminé par balayage complet (voir
        // examples/spectral_gamma_sweep.rs) : gamma=15 (qui fonctionne pour
        // les lunes) donne ARI=-0.003 ici, échec total — les cercles sont à
        // une échelle différente et nécessitent gamma=50 pour ARI=1.000.
        // Corrigé après vérification plutôt que supposé identique aux lunes.
        let data = make_circles(300, 0.06, 0.5, 42);
        let mut sc = SpectralClustering::new(2, 50.0, 7);
        let result = sc.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "Spectral Clustering devrait réussir sur les cercles avec un bon gamma: ARI={ari}");
    }

    #[test]
    #[should_panic(expected = "gamma doit être > 0")]
    fn panics_on_non_positive_gamma() {
        SpectralClustering::new(3, 0.0, 0);
    }
}
