//! BIRCH (Zhang, Ramakrishnan & Livny, 1996) : construit un arbre CF
//! (Clustering Feature) en une seule passe sur les données, puis applique
//! un algorithme de clustering global sur les micro-clusters obtenus
//! (feuilles de l'arbre), et enfin réaffecte chaque point original au
//! centre final le plus proche.
//!
//! Une CF (Clustering Feature) résume un ensemble de points par un triplet
//! additif (N, LS, SS) — nombre de points, somme vectorielle, somme des
//! normes au carré — ce qui permet de calculer centroïde et rayon sans
//! conserver les points bruts, et de fusionner deux CF en O(d).
//!
//! Portée de cette implémentation : Phase 1 (construction de l'arbre) et
//! Phase 3+4 (clustering global + réaffectation) de l'article original.
//! La Phase 2 (reconstruction de l'arbre avec un seuil plus grand en cas
//! de dépassement mémoire) est omise : à l'échelle de nos bancs d'essai
//! (quelques centaines à milliers de points), la contrainte mémoire qui
//! motive cette phase ne s'applique pas — documenté explicitement plutôt
//! que silencieusement absent.
//!
//! Complexité : O(n × hauteur_arbre × branching_factor) pour la
//! construction (la raison d'être de BIRCH : passage à l'échelle linéaire,
//! contrairement aux O(n²)/O(n³) des algorithmes précédents de ce
//! workspace), plus O(m³) pour le clustering global sur les m
//! micro-clusters (m << n en pratique).

use crate::hierarchical::{HierarchicalClustering, Linkage};
use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};

/// Clustering Feature : résumé additif (N, LS, SS) d'un ensemble de points.
#[derive(Debug, Clone)]
struct Cf {
    n: usize,
    ls: Vec<f64>,
    ss: f64,
}

impl Cf {
    fn new_empty(dim: usize) -> Self {
        Cf { n: 0, ls: vec![0.0; dim], ss: 0.0 }
    }

    fn from_point(p: &[f64]) -> Self {
        Cf { n: 1, ls: p.to_vec(), ss: p.iter().map(|v| v * v).sum() }
    }

    fn add_point(&mut self, p: &[f64]) {
        self.n += 1;
        for (a, b) in self.ls.iter_mut().zip(p.iter()) {
            *a += b;
        }
        self.ss += p.iter().map(|v| v * v).sum::<f64>();
    }

    fn merge(&mut self, other: &Cf) {
        self.n += other.n;
        for (a, b) in self.ls.iter_mut().zip(other.ls.iter()) {
            *a += b;
        }
        self.ss += other.ss;
    }

    fn centroid(&self) -> Vec<f64> {
        debug_assert!(self.n > 0, "centroid() appelé sur un CF vide");
        let n = self.n as f64;
        self.ls.iter().map(|v| v / n).collect()
    }

    /// Rayon : racine de la moyenne des distances au carré au centroïde.
    /// Identité utilisée : sum_i ||x_i - c||^2 = SS - N*||c||^2, avec
    /// c = LS/N (moyenne). Vérifiée indépendamment dans les tests.
    fn radius(&self) -> f64 {
        if self.n == 0 {
            return 0.0;
        }
        let n = self.n as f64;
        let mean_sq_norm: f64 = self.ls.iter().map(|v| (v / n).powi(2)).sum();
        (self.ss / n - mean_sq_norm).max(0.0).sqrt()
    }
}

fn aggregate(entries: &[Cf]) -> Cf {
    if entries.is_empty() {
        return Cf::new_empty(0);
    }
    let mut cf = Cf::new_empty(entries[0].ls.len());
    for e in entries {
        cf.merge(e);
    }
    cf
}

fn aggregate_pairs(children: &[(Cf, Box<Node>)]) -> Cf {
    if children.is_empty() {
        return Cf::new_empty(0);
    }
    let mut cf = Cf::new_empty(children[0].0.ls.len());
    for (c, _) in children {
        cf.merge(c);
    }
    cf
}

fn aggregate_node(node: &Node) -> Cf {
    match node {
        Node::Leaf(entries) => aggregate(entries),
        Node::Internal(children) => {
            let mut cf = Cf::new_empty(children[0].0.ls.len());
            for (c, _) in children {
                cf.merge(c);
            }
            cf
        }
    }
}

fn closest_index(centroids: &[Vec<f64>], point: &[f64]) -> Option<usize> {
    centroids
        .iter()
        .enumerate()
        .map(|(i, c)| (i, euclidean(c, point)))
        .min_by(|a, b| a.1.partial_cmp(&b.1).expect("distance ne doit jamais être NaN"))
        .map(|(i, _)| i)
}

/// Partition d'un ensemble de centroïdes en deux groupes via la méthode
/// des graines les plus éloignées (standard pour la scission d'un noeud
/// de B-tree / R-tree / CF-tree) : les deux entrées à distance maximale
/// deviennent les graines des deux groupes, chaque autre entrée rejoint
/// le groupe de la graine la plus proche. `false` = groupe A, `true` =
/// groupe B ; la graine A et la graine B sont toujours dans des groupes
/// différents par construction (garantit deux groupes non vides dès que
/// `centroids.len() >= 2`).
fn farthest_pair_partition(centroids: &[Vec<f64>]) -> Vec<bool> {
    let m = centroids.len();
    let mut seed_a = 0usize;
    let mut seed_b = if m >= 2 { 1 } else { 0 };
    let mut max_d = f64::NEG_INFINITY;
    for i in 0..m {
        for j in (i + 1)..m {
            let d = euclidean(&centroids[i], &centroids[j]);
            if d > max_d {
                max_d = d;
                seed_a = i;
                seed_b = j;
            }
        }
    }
    (0..m)
        .map(|i| {
            if i == seed_a {
                false
            } else if i == seed_b {
                true
            } else {
                let da = euclidean(&centroids[i], &centroids[seed_a]);
                let db = euclidean(&centroids[i], &centroids[seed_b]);
                db < da
            }
        })
        .collect()
}

#[derive(Debug)]
enum Node {
    Leaf(Vec<Cf>),
    Internal(Vec<(Cf, Box<Node>)>),
}

/// Insère un point dans le sous-arbre `node`. Retourne `Some((cf, node))`
/// si `node` a dû être scindé en deux (auquel cas l'appelant doit intégrer
/// ce nouveau frère dans son propre niveau, en propageant potentiellement
/// la scission plus haut — mécanique standard d'insertion de B-tree).
fn insert_point(node: &mut Node, point: &[f64], branching_factor: usize, threshold: f64) -> Option<(Cf, Box<Node>)> {
    match node {
        Node::Leaf(entries) => {
            let centroids: Vec<Vec<f64>> = entries.iter().map(|e| e.centroid()).collect();
            if let Some(idx) = closest_index(&centroids, point) {
                let mut trial = entries[idx].clone();
                trial.add_point(point);
                if trial.radius() <= threshold {
                    entries[idx] = trial;
                    return None;
                }
            }
            entries.push(Cf::from_point(point));
            if entries.len() > branching_factor {
                let cents: Vec<Vec<f64>> = entries.iter().map(|e| e.centroid()).collect();
                let assign = farthest_pair_partition(&cents);
                let taken = std::mem::take(entries);
                let mut group_a = Vec::new();
                let mut group_b = Vec::new();
                for (cf, is_b) in taken.into_iter().zip(assign) {
                    if is_b {
                        group_b.push(cf);
                    } else {
                        group_a.push(cf);
                    }
                }
                *entries = group_a;
                let sibling_cf = aggregate(&group_b);
                return Some((sibling_cf, Box::new(Node::Leaf(group_b))));
            }
            None
        }
        Node::Internal(children) => {
            let centroids: Vec<Vec<f64>> = children.iter().map(|(cf, _)| cf.centroid()).collect();
            let idx = closest_index(&centroids, point).expect("un noeud interne a toujours >= 2 enfants");
            let split = insert_point(&mut children[idx].1, point, branching_factor, threshold);
            children[idx].0.add_point(point);

            if let Some((sib_cf, sib_node)) = split {
                children.push((sib_cf, sib_node));
                if children.len() > branching_factor {
                    let cents: Vec<Vec<f64>> = children.iter().map(|(cf, _)| cf.centroid()).collect();
                    let assign = farthest_pair_partition(&cents);
                    let taken = std::mem::take(children);
                    let mut group_a = Vec::new();
                    let mut group_b = Vec::new();
                    for (child, is_b) in taken.into_iter().zip(assign) {
                        if is_b {
                            group_b.push(child);
                        } else {
                            group_a.push(child);
                        }
                    }
                    *children = group_a;
                    let sibling_cf = aggregate_pairs(&group_b);
                    return Some((sibling_cf, Box::new(Node::Internal(group_b))));
                }
            }
            None
        }
    }
}

fn collect_leaf_cfs(node: &Node, out: &mut Vec<Cf>) {
    match node {
        Node::Leaf(entries) => out.extend(entries.iter().cloned()),
        Node::Internal(children) => {
            for (_, child) in children {
                collect_leaf_cfs(child, out);
            }
        }
    }
}

/// Clustering global (Phase 3 de BIRCH) : agglomération pondérée des
/// micro-clusters (feuilles du CF-tree) jusqu'à `target_k` superclusters,
/// en réutilisant directement la récurrence de Lance-Williams déjà validée
/// dans `hierarchical.rs` (mêmes garanties de correction), initialisée ici
/// avec les tailles réelles `n` de chaque CF plutôt que 1 partout.
fn agglomerate_cfs(cfs: &[Cf], target_k: usize, linkage: Linkage) -> Vec<usize> {
    let m = cfs.len();
    if m <= target_k {
        return (0..m).collect();
    }
    let centroids: Vec<Vec<f64>> = cfs.iter().map(|cf| cf.centroid()).collect();
    let mut dist = vec![vec![0.0; m]; m];
    for i in 0..m {
        for j in (i + 1)..m {
            let d = euclidean(&centroids[i], &centroids[j]);
            dist[i][j] = d;
            dist[j][i] = d;
        }
    }
    let mut alive = vec![true; m];
    let mut size: Vec<f64> = cfs.iter().map(|cf| cf.n as f64).collect();
    let mut members: Vec<Vec<usize>> = (0..m).map(|i| vec![i]).collect();
    let mut n_active = m;

    while n_active > target_k {
        let mut best_i = usize::MAX;
        let mut best_j = usize::MAX;
        let mut best_d = f64::INFINITY;
        for i in 0..m {
            if !alive[i] {
                continue;
            }
            #[allow(clippy::needless_range_loop)]
            for j in (i + 1)..m {
                if !alive[j] {
                    continue;
                }
                if dist[i][j] < best_d {
                    best_d = dist[i][j];
                    best_i = i;
                    best_j = j;
                }
            }
        }
        let (i, j) = (best_i, best_j);
        let d_ij = dist[i][j];
        let n_i = size[i];
        let n_j = size[j];

        for k in 0..m {
            if !alive[k] || k == i || k == j {
                continue;
            }
            let new_d = HierarchicalClustering::lance_williams_update(linkage, dist[i][k], dist[j][k], d_ij, n_i, n_j, size[k]);
            dist[i][k] = new_d;
            dist[k][i] = new_d;
        }

        let j_members = std::mem::take(&mut members[j]);
        members[i].extend(j_members);
        size[i] += size[j];
        alive[j] = false;
        n_active -= 1;
    }

    let mut cf_to_cluster = vec![0usize; m];
    let mut cluster_id = 0usize;
    for slot in 0..m {
        if alive[slot] {
            for &idx in &members[slot] {
                cf_to_cluster[idx] = cluster_id;
            }
            cluster_id += 1;
        }
    }
    cf_to_cluster
}

#[derive(Debug, Clone)]
pub struct Birch {
    /// Rayon maximal autorisé pour un sous-cluster feuille avant qu'un
    /// nouveau point ne doive créer sa propre entrée plutôt que d'être
    /// absorbé.
    pub threshold: f64,
    /// Nombre maximal d'entrées par noeud avant scission.
    pub branching_factor: usize,
    pub n_clusters: usize,
    /// Critère de liaison utilisé pour le clustering global (Phase 3).
    /// Ward par défaut (cohérent avec `sklearn.cluster.Birch`, qui utilise
    /// `AgglomerativeClustering` par défaut).
    pub global_linkage: Linkage,
}

impl Birch {
    pub fn new(threshold: f64, branching_factor: usize, n_clusters: usize) -> Self {
        assert!(threshold > 0.0, "threshold doit être > 0");
        assert!(branching_factor >= 2, "branching_factor doit être >= 2");
        assert!(n_clusters >= 1, "n_clusters doit être >= 1");
        Self {
            threshold,
            branching_factor,
            n_clusters,
            global_linkage: Linkage::Ward,
        }
    }
}

impl ClusteringAlgorithm for Birch {
    fn name(&self) -> &str {
        "BIRCH"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        assert!(!points.is_empty(), "points ne doit pas être vide");
        let dim = points[0].len();
        let threshold = self.threshold;
        let branching_factor = self.branching_factor;
        let target_k = self.n_clusters;
        let linkage = self.global_linkage;

        timed_fit(self.name(), || {
            let mut root = Node::Leaf(Vec::new());
            for p in points.iter() {
                if let Some((sib_cf, sib_node)) = insert_point(&mut root, p, branching_factor, threshold) {
                    let old_root_cf = aggregate_node(&root);
                    let old_root = std::mem::replace(&mut root, Node::Leaf(Vec::new()));
                    root = Node::Internal(vec![(old_root_cf, Box::new(old_root)), (sib_cf, sib_node)]);
                }
            }

            let mut leaf_cfs = Vec::new();
            collect_leaf_cfs(&root, &mut leaf_cfs);

            let m = leaf_cfs.len();
            let k = target_k.min(m).max(1);
            let cf_to_cluster = agglomerate_cfs(&leaf_cfs, k, linkage);

            let mut merged: Vec<Cf> = (0..k).map(|_| Cf::new_empty(dim)).collect();
            for (cf, &cluster) in leaf_cfs.iter().zip(cf_to_cluster.iter()) {
                merged[cluster].merge(cf);
            }
            let final_centroids: Vec<Vec<f64>> = merged.iter().map(|cf| cf.centroid()).collect();

            let labels: Vec<i32> = points
                .iter()
                .map(|p| closest_index(&final_centroids, p).expect("au moins un centre final") as i32)
                .collect();

            (labels, k)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_core::Dataset;
    use cluster_data::make_blobs;
    use cluster_metrics::adjusted_rand_index;

    #[test]
    fn cf_centroid_and_radius_hand_computed() {
        // Points (0,0),(2,0),(0,2),(2,2) : centroïde=(1,1).
        // Distance au carré de chaque point au centroïde = 2 (ex: (0,0):
        // 1²+1²=2). Rayon = sqrt(moyenne(2,2,2,2)) = sqrt(2).
        let points = [vec![0.0, 0.0], vec![2.0, 0.0], vec![0.0, 2.0], vec![2.0, 2.0]];
        let mut cf = Cf::from_point(&points[0]);
        for p in &points[1..] {
            cf.add_point(p);
        }
        assert_eq!(cf.n, 4);
        let centroid = cf.centroid();
        assert!((centroid[0] - 1.0).abs() < 1e-12);
        assert!((centroid[1] - 1.0).abs() < 1e-12);
        let expected_radius = 2.0_f64.sqrt();
        assert!((cf.radius() - expected_radius).abs() < 1e-9, "radius={}", cf.radius());
    }

    #[test]
    fn cf_merge_matches_direct_computation() {
        let a = Cf::from_point(&[0.0, 0.0]);
        let b = Cf::from_point(&[4.0, 0.0]);
        let mut merged = a.clone();
        merged.merge(&b);
        assert_eq!(merged.n, 2);
        assert_eq!(merged.centroid(), vec![2.0, 0.0]);
        // Rayon attendu : chaque point à distance 2 du centroïde -> rayon=2.
        assert!((merged.radius() - 2.0).abs() < 1e-9);
    }

    #[test]
    fn leaf_entries_never_exceed_threshold_radius() {
        // Après insertion, toute entrée-feuille absorbée doit respecter
        // rayon <= threshold par construction (invariant de l'algorithme
        // d'insertion). Vérifié directement sur l'arbre interne.
        let data = make_blobs(200, 4, 0.5, 7);
        let threshold = 0.8;
        let mut root = Node::Leaf(Vec::new());
        for p in &data.points {
            if let Some((sib_cf, sib_node)) = insert_point(&mut root, p, 4, threshold) {
                let old_root_cf = aggregate_node(&root);
                let old_root = std::mem::replace(&mut root, Node::Leaf(Vec::new()));
                root = Node::Internal(vec![(old_root_cf, Box::new(old_root)), (sib_cf, sib_node)]);
            }
        }
        let mut leaf_cfs = Vec::new();
        collect_leaf_cfs(&root, &mut leaf_cfs);
        assert!(!leaf_cfs.is_empty());
        for cf in &leaf_cfs {
            assert!(
                cf.radius() <= threshold + 1e-9,
                "une entrée-feuille dépasse le seuil: radius={}, threshold={threshold}",
                cf.radius()
            );
        }
    }

    #[test]
    fn small_branching_factor_forces_multi_level_tree_without_panic() {
        // branching_factor=2 force de nombreuses scissions en cascade
        // (arbre profond) : test de robustesse de la récursion.
        let data = make_blobs(300, 5, 0.6, 11);
        let mut birch = Birch::new(0.5, 2, 5);
        let result = birch.fit(&data);
        assert_eq!(result.labels.len(), data.n_samples());
        assert!(result.n_clusters >= 1 && result.n_clusters <= 5);
    }

    #[test]
    fn hand_computed_two_well_separated_groups() {
        let points = vec![
            vec![0.0, 0.0],
            vec![0.1, 0.0],
            vec![0.0, 0.1],
            vec![10.0, 10.0],
            vec![10.1, 10.0],
            vec![10.0, 10.1],
        ];
        let data = Dataset::new(points, None, "toy");
        let mut birch = Birch::new(1.0, 4, 2);
        let result = birch.fit(&data);
        assert_eq!(result.labels[0], result.labels[1]);
        assert_eq!(result.labels[1], result.labels[2]);
        assert_eq!(result.labels[3], result.labels[4]);
        assert_eq!(result.labels[4], result.labels[5]);
        assert_ne!(result.labels[0], result.labels[3]);
    }

    #[test]
    fn deterministic_across_runs() {
        let data = make_blobs(200, 3, 0.8, 5);
        let mut b1 = Birch::new(1.5, 8, 3);
        let mut b2 = Birch::new(1.5, 8, 3);
        assert_eq!(b1.fit(&data).labels, b2.fit(&data).labels);
    }

    #[test]
    fn recovers_well_separated_blobs_with_high_ari() {
        let data = make_blobs(300, 3, 0.8, 42);
        let mut birch = Birch::new(1.0, 8, 3);
        let result = birch.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "ARI trop bas sur des blobs bien séparés: {ari}");
    }

    #[test]
    #[should_panic(expected = "threshold doit être > 0")]
    fn panics_on_non_positive_threshold() {
        Birch::new(0.0, 8, 3);
    }

    #[test]
    #[should_panic(expected = "branching_factor")]
    fn panics_on_branching_factor_below_2() {
        Birch::new(1.0, 1, 3);
    }
}
