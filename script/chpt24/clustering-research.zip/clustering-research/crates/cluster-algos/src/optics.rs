//! OPTICS (Ankerst, Breunig, Kriegel & Sander, 1999) : généralise DBSCAN
//! en calculant, pour un ordre de visite des points, la **distance de
//! atteignabilité** de chacun plutôt qu'une affectation directe à un
//! cluster. Ce graphique d'atteignabilité encode implicitement la
//! structure de clustering à *toutes* les échelles de eps <= max_eps
//! simultanément, contrairement à DBSCAN qui n'en capture qu'une seule.
//!
//! Deux étapes distinctes :
//! 1. **Ordonnancement** (`compute_ordering`) : parcours glouton des
//!    points par distance de atteignabilité croissante, exactement comme
//!    Prim construit un MST — ce n'est d'ailleurs pas un hasard, OPTICS et
//!    le MST sur distance de atteignabilité mutuelle (HDBSCAN) sont
//!    étroitement liés.
//! 2. **Extraction** (`extract_dbscan_clusters`) : méthode la plus simple
//!    de l'article original (section 4.1), reproduisant un clustering
//!    équivalent à DBSCAN à un seuil `eps' <= max_eps` donné, directement
//!    depuis l'ordonnancement déjà calculé (sans nouveau passage sur les
//!    données). La méthode plus sophistiquée à base de détection de pente
//!    (« xi », par défaut dans scikit-learn) n'est pas implémentée ici —
//!    documenté explicitement comme hors périmètre de cette phase, à
//!    l'image de la Phase 2 rebuild de BIRCH.
//!
//! Complexité : O(n²), comme DBSCAN.

use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};

/// Distance de coeur au sens DBSCAN/OPTICS : distance au `min_samples`-ième
/// plus proche point, **le point lui-même inclus** (convention identique à
/// `Dbscan`, différente de celle de `Hdbscan` qui exclut le point
/// lui-même). Retourne `None` si cette distance dépasse `eps` (point non
/// coeur à cette échelle).
fn core_distance(idx: usize, points: &[Vec<f64>], eps: f64, min_samples: usize) -> Option<f64> {
    let mut dists: Vec<f64> = points.iter().map(|p| euclidean(&points[idx], p)).collect();
    dists.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let d = dists[(min_samples - 1).min(dists.len() - 1)];
    if d <= eps {
        Some(d)
    } else {
        None
    }
}

/// Calcule l'ordonnancement OPTICS et la distance de atteignabilité de
/// chaque point. Implémentation simplifiée mais équivalente à la liste de
/// graines de l'article original : à chaque étape, on choisit parmi les
/// points non encore traités celui de plus petite distance de
/// atteignabilité connue (INFINITY si jamais atteint, départage par indice
/// croissant) — stratégie globalement gloutonne strictement équivalente à
/// la gestion de liste de graines classique, car les valeurs de
/// atteignabilité ne peuvent que diminuer au fil du parcours.
fn compute_ordering(points: &[Vec<f64>], eps: f64, min_samples: usize) -> (Vec<usize>, Vec<f64>, Vec<Option<f64>>) {
    let n = points.len();
    let mut processed = vec![false; n];
    let mut reachability = vec![f64::INFINITY; n];
    let mut ordering = Vec::with_capacity(n);
    let mut core_dist_of = vec![None; n];

    for _ in 0..n {
        let next = (0..n)
            .filter(|&i| !processed[i])
            .min_by(|&a, &b| reachability[a].partial_cmp(&reachability[b]).unwrap().then(a.cmp(&b)))
            .expect("il doit rester au moins un point non traité");
        processed[next] = true;
        ordering.push(next);

        let cd = core_distance(next, points, eps, min_samples);
        core_dist_of[next] = cd;
        if let Some(core_dist) = cd {
            for j in 0..n {
                if processed[j] || j == next {
                    continue;
                }
                let d = euclidean(&points[next], &points[j]);
                if d <= eps {
                    let new_reach = core_dist.max(d);
                    if new_reach < reachability[j] {
                        reachability[j] = new_reach;
                    }
                }
            }
        }
    }
    (ordering, reachability, core_dist_of)
}

/// Extraction de clusters façon DBSCAN à partir d'un ordonnancement déjà
/// calculé (article original, section 4.1). `eps_extract` doit être
/// `<= eps` utilisé pour `compute_ordering` (sinon le graphique
/// d'atteignabilité n'a pas exploré suffisamment loin pour être valide à
/// ce seuil).
fn extract_dbscan_clusters(ordering: &[usize], reachability: &[f64], core_dist_of: &[Option<f64>], eps_extract: f64) -> Vec<i32> {
    let n = ordering.len();
    let mut labels = vec![-1i32; n];
    let mut cluster_id: i32 = -1;

    for &idx in ordering {
        if reachability[idx] > eps_extract {
            match core_dist_of[idx] {
                Some(cd) if cd <= eps_extract => {
                    cluster_id += 1;
                    labels[idx] = cluster_id;
                }
                _ => {
                    labels[idx] = -1;
                }
            }
        } else {
            labels[idx] = cluster_id; // reste -1 si aucun cluster n'a encore démarré
        }
    }
    labels
}

#[derive(Debug, Clone)]
pub struct Optics {
    /// Rayon maximal exploré pour construire l'ordonnancement (`max_eps`
    /// dans la terminologie scikit-learn).
    pub eps: f64,
    pub min_samples: usize,
    /// Seuil d'extraction des clusters finaux, `<= eps`. À `eps_extract ==
    /// eps`, reproduit exactement `Dbscan::new(eps, min_samples)` — voir
    /// test `extraction_at_full_eps_matches_dbscan_exactly`.
    pub eps_extract: f64,
}

impl Optics {
    pub fn new(eps: f64, min_samples: usize, eps_extract: f64) -> Self {
        assert!(eps > 0.0, "eps doit être > 0");
        assert!(min_samples >= 1, "min_samples doit être >= 1");
        assert!(eps_extract > 0.0 && eps_extract <= eps, "eps_extract doit être dans (0, eps]");
        Self { eps, min_samples, eps_extract }
    }
}

impl ClusteringAlgorithm for Optics {
    fn name(&self) -> &str {
        "OPTICS"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        assert!(!points.is_empty(), "points ne doit pas être vide");
        let eps = self.eps;
        let min_samples = self.min_samples;
        let eps_extract = self.eps_extract;

        timed_fit(self.name(), || {
            let (ordering, reachability, core_dist_of) = compute_ordering(points, eps, min_samples);
            let labels = extract_dbscan_clusters(&ordering, &reachability, &core_dist_of, eps_extract);
            let n_clusters = (labels.iter().max().copied().unwrap_or(-1) + 1).max(0) as usize;
            (labels, n_clusters)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_data::{make_blobs, make_moons};
    use cluster_metrics::adjusted_rand_index;

    #[test]
    fn core_distance_hand_computed() {
        // Mêmes points que le test DBSCAN équivalent : convention
        // "point lui-même inclus" partagée avec Dbscan (contrairement à
        // Hdbscan). Points 1D : 1.0, 1.1, 1.2, 5.0. min_samples=2.
        // Point 0 (x=1.0): distances triées à tous (soi inclus) = [0, 0.1, 0.2, 4.0]
        // -> 2e plus proche (indice 1) = 0.1.
        let points = vec![vec![1.0], vec![1.1], vec![1.2], vec![5.0]];
        let cd = core_distance(0, &points, 10.0, 2);
        assert!((cd.unwrap() - 0.1).abs() < 1e-9, "cd={cd:?}");
        // Le point isolé (x=5.0), min_samples=2, eps=0.3 : 2e plus proche
        // est à distance 3.8 (vers 1.2) > eps=0.3 -> None.
        let cd_outlier = core_distance(3, &points, 0.3, 2);
        assert_eq!(cd_outlier, None);
    }

    #[test]
    fn hand_computed_ordering_and_reachability() {
        // Chaîne dense {0.0,0.1,0.2} + point isolé {5.0}. eps=0.3, min_samples=2.
        // Ordonnancement attendu : on démarre par un point de la chaîne
        // (reachability=INFINITY au départ, tous égaux -> indice le plus
        // petit gagne = point 0), puis 1 et 2 sont atteints avec une
        // faible distance de atteignabilité, puis 5.0 reste isolé
        // (jamais atteint depuis la chaîne car distance > eps) et démarre
        // sa propre "branche" avec reachability=INFINITY.
        let points = vec![vec![0.0], vec![0.1], vec![0.2], vec![5.0]];
        let (ordering, reachability, core_dist_of) = compute_ordering(&points, 0.3, 2);
        assert_eq!(ordering.len(), 4);
        assert_eq!(ordering[0], 0); // premier point traité = indice 0 (tous à INFINITY au départ)
        assert!(reachability[0].is_infinite());
        assert!(core_dist_of[0].is_some());
        // Le point isolé (indice 3) ne peut jamais être atteint depuis la
        // chaîne (distance > eps) : sa reachability reste INFINITY, il
        // démarre donc sa propre branche.
        assert!(reachability[3].is_infinite());
    }

    #[test]
    fn extraction_at_full_eps_matches_dbscan_exactly() {
        // Propriété structurelle forte : à eps_extract == eps, extraire
        // les clusters depuis l'ordonnancement OPTICS doit reproduire
        // EXACTEMENT le résultat de Dbscan au même (eps, min_samples),
        // car les deux algorithmes explorent la même relation de
        // densité-atteignabilité, seule la représentation diffère.
        let data = make_blobs(200, 3, 0.8, 42);
        let eps = 1.5;
        let min_samples = 5;

        let mut optics = Optics::new(eps, min_samples, eps);
        let r_optics = optics.fit(&data);

        let mut dbscan = crate::Dbscan::new(eps, min_samples);
        let r_dbscan = dbscan.fit(&data);

        assert_eq!(r_optics.labels, r_dbscan.labels, "OPTICS à eps_extract=eps doit reproduire DBSCAN exactement");
    }

    #[test]
    fn deterministic_across_runs() {
        let data = make_blobs(150, 3, 0.8, 5);
        let mut o1 = Optics::new(1.5, 5, 1.5);
        let mut o2 = Optics::new(1.5, 5, 1.5);
        assert_eq!(o1.fit(&data).labels, o2.fit(&data).labels);
    }

    #[test]
    fn recovers_well_separated_blobs_with_high_ari() {
        let data = make_blobs(300, 3, 0.8, 42);
        let mut optics = Optics::new(1.5, 5, 1.5);
        let result = optics.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "ARI trop bas sur des blobs bien séparés: {ari}");
    }

    #[test]
    fn succeeds_on_non_convex_moons_like_dbscan() {
        // Même propriété que DBSCAN (dont OPTICS généralise le
        // mécanisme) : doit séparer les lunes avec de bons paramètres.
        let data = make_moons(300, 0.08, 42);
        let mut optics = Optics::new(0.2, 10, 0.2);
        let result = optics.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.95, "OPTICS devrait réussir sur les lunes comme DBSCAN: ARI={ari}");
    }

    #[test]
    fn smaller_eps_extract_can_only_refine_not_coarsen() {
        // Propriété structurelle : réduire eps_extract (à eps/min_samples
        // fixés pour l'ordonnancement) ne peut que fragmenter ou
        // maintenir les clusters, jamais les fusionner davantage — le
        // nombre de clusters (hors bruit) doit être monotone non
        // décroissant quand eps_extract décroît.
        let data = make_blobs(200, 4, 0.6, 3);
        let mut wide = Optics::new(3.0, 5, 3.0);
        let mut narrow = Optics::new(3.0, 5, 0.5);
        let r_wide = wide.fit(&data);
        let r_narrow = narrow.fit(&data);
        assert!(
            r_narrow.n_clusters >= r_wide.n_clusters,
            "eps_extract plus petit ({} clusters) devrait fragmenter au moins autant que eps_extract large ({} clusters)",
            r_narrow.n_clusters,
            r_wide.n_clusters
        );
    }

    #[test]
    #[should_panic(expected = "eps_extract doit être dans (0, eps]")]
    fn panics_if_eps_extract_exceeds_eps() {
        Optics::new(1.0, 5, 2.0);
    }
}
