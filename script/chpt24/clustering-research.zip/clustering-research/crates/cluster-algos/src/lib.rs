//! `cluster-algos`: implémentations des algorithmes de clustering
//! classiques et récents de la littérature, chacun implémentant le trait
//! `cluster_core::ClusteringAlgorithm` défini en Phase 1.
//!
//! Statut (Phase 2) :
//! - [x] K-Means (Lloyd + k-means++)
//! - [ ] Mean-Shift
//! - [ ] DBSCAN
//! - [ ] Regroupement hiérarchique
//! - [ ] BIRCH

mod birch;
mod dbscan;
mod hdbscan;
mod hierarchical;
mod kmeans;
mod mean_shift;
mod optics;
mod spectral;

pub use birch::Birch;
pub use dbscan::Dbscan;
pub use hdbscan::Hdbscan;
pub use hierarchical::{HierarchicalClustering, Linkage};
pub use kmeans::KMeans;
pub use mean_shift::MeanShift;
pub use optics::Optics;
pub use spectral::SpectralClustering;
