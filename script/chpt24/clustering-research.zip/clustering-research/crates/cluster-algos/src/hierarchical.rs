//! Regroupement hiérarchique agglomératif (Ward, 1963 ; formulation
//! générale par la récurrence de Lance & Williams, 1967), quatre critères
//! de liaison : Single, Complete, Average (UPGMA), Ward.
//!
//! Convention (identique à `scipy.cluster.hierarchy.linkage`) : la matrice
//! de distances initiale contient des distances euclidiennes **non
//! carrées**, pour les quatre critères — y compris Ward, dont la
//! récurrence de Lance-Williams élève au carré puis reprend la racine en
//! interne (voir `lance_williams_update`), ce qui permet une
//! initialisation uniforme et une comparaison directe avec scipy.
//!
//! Complexité : O(n³) dans cette implémentation naïve (recherche du
//! minimum par balayage complet à chaque fusion) — scipy utilise
//! l'algorithme de chaîne des plus proches voisins en O(n²), hors
//! périmètre de cette phase.

use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Linkage {
    Single,
    Complete,
    Average,
    Ward,
}

#[derive(Debug, Clone)]
pub struct HierarchicalClustering {
    pub n_clusters: usize,
    pub linkage: Linkage,
}

impl HierarchicalClustering {
    pub fn new(n_clusters: usize, linkage: Linkage) -> Self {
        assert!(n_clusters >= 1, "n_clusters doit être >= 1");
        Self { n_clusters, linkage }
    }

    /// Récurrence de Lance-Williams : distance entre le cluster fusionné
    /// `ij` (issu de `i` et `j`) et un troisième cluster `k`, à partir des
    /// trois distances déjà connues `d(i,k)`, `d(j,k)`, `d(i,j)` et des
    /// tailles `n_i, n_j, n_k`. Fonction pure, testée indépendamment de la
    /// boucle de fusion gloutonne pour isoler toute erreur de formule
    /// d'une erreur d'orchestration. Visibilité `pub(crate)` : réutilisée
    /// telle quelle par `birch` pour l'étape de clustering global pondéré,
    /// afin de ne pas dupliquer une formule mathématique déjà validée.
    pub(crate) fn lance_williams_update(linkage: Linkage, d_ik: f64, d_jk: f64, d_ij: f64, n_i: f64, n_j: f64, n_k: f64) -> f64 {
        match linkage {
            Linkage::Single => d_ik.min(d_jk),
            Linkage::Complete => d_ik.max(d_jk),
            Linkage::Average => (n_i * d_ik + n_j * d_jk) / (n_i + n_j),
            Linkage::Ward => {
                let num = (n_i + n_k) * d_ik.powi(2) + (n_j + n_k) * d_jk.powi(2) - n_k * d_ij.powi(2);
                (num / (n_i + n_j + n_k)).max(0.0).sqrt()
            }
        }
    }
}

impl ClusteringAlgorithm for HierarchicalClustering {
    fn name(&self) -> &str {
        match self.linkage {
            Linkage::Single => "Hierarchical (single)",
            Linkage::Complete => "Hierarchical (complete)",
            Linkage::Average => "Hierarchical (average)",
            Linkage::Ward => "Hierarchical (ward)",
        }
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        let n = points.len();
        assert!(n >= 1, "points ne doit pas être vide");
        assert!(
            n >= self.n_clusters,
            "n_samples ({n}) doit être >= n_clusters ({})",
            self.n_clusters
        );
        let linkage = self.linkage;
        let target_k = self.n_clusters;

        timed_fit(self.name(), || {
            let mut dist = vec![vec![0.0; n]; n];
            for i in 0..n {
                for j in (i + 1)..n {
                    let d = euclidean(&points[i], &points[j]);
                    dist[i][j] = d;
                    dist[j][i] = d;
                }
            }
            let mut alive = vec![true; n];
            let mut size = vec![1usize; n];
            let mut members: Vec<Vec<usize>> = (0..n).map(|i| vec![i]).collect();
            let mut n_active = n;

            while n_active > target_k {
                // Recherche du couple (i,j) vivant de distance minimale.
                // En cas d'égalité stricte, le premier couple rencontré
                // dans l'ordre (i croissant, puis j croissant) l'emporte
                // — comportement déterministe, documenté et testé.
                let mut best_i = usize::MAX;
                let mut best_j = usize::MAX;
                let mut best_d = f64::INFINITY;
                for i in 0..n {
                    if !alive[i] {
                        continue;
                    }
                    #[allow(clippy::needless_range_loop)]
                    for j in (i + 1)..n {
                        if !alive[j] {
                            continue;
                        }
                        if dist[i][j] < best_d {
                            best_d = dist[i][j];
                            best_i = i;
                            best_j = j;
                        }
                    }
                }
                let (i, j) = (best_i, best_j);
                let d_ij = dist[i][j];
                let n_i = size[i] as f64;
                let n_j = size[j] as f64;

                for k in 0..n {
                    if !alive[k] || k == i || k == j {
                        continue;
                    }
                    let d_ik = dist[i][k];
                    let d_jk = dist[j][k];
                    let n_k = size[k] as f64;
                    let new_d = Self::lance_williams_update(linkage, d_ik, d_jk, d_ij, n_i, n_j, n_k);
                    dist[i][k] = new_d;
                    dist[k][i] = new_d;
                }

                let j_members = std::mem::take(&mut members[j]);
                members[i].extend(j_members);
                size[i] += size[j];
                alive[j] = false;
                n_active -= 1;
            }

            let mut labels = vec![-1i32; n];
            let mut cluster_id = 0i32;
            for slot in 0..n {
                if alive[slot] {
                    for &point_idx in &members[slot] {
                        labels[point_idx] = cluster_id;
                    }
                    cluster_id += 1;
                }
            }
            let n_clusters = cluster_id as usize;
            (labels, n_clusters)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_core::Dataset;
    use cluster_data::{make_blobs, make_moons};
    use cluster_metrics::adjusted_rand_index;

    // -------- Tests unitaires de la formule de Lance-Williams seule --------

    #[test]
    fn lance_williams_single_is_min() {
        let d = HierarchicalClustering::lance_williams_update(Linkage::Single, 3.0, 5.0, 1.0, 1.0, 1.0, 1.0);
        assert!((d - 3.0).abs() < 1e-12);
    }

    #[test]
    fn lance_williams_complete_is_max() {
        let d = HierarchicalClustering::lance_williams_update(Linkage::Complete, 3.0, 5.0, 1.0, 1.0, 1.0, 1.0);
        assert!((d - 5.0).abs() < 1e-12);
    }

    #[test]
    fn lance_williams_average_hand_computed() {
        // n_i=2, n_j=3, d_ik=4, d_jk=6 -> (2*4+3*6)/5 = (8+18)/5 = 5.2
        let d = HierarchicalClustering::lance_williams_update(Linkage::Average, 4.0, 6.0, 999.0, 2.0, 3.0, 1.0);
        assert!((d - 5.2).abs() < 1e-9, "d={d}");
    }

    #[test]
    fn lance_williams_ward_matches_direct_variance_increase() {
        // Vérification indépendante : on fusionne deux points isolés i=(0,0)
        // et j=(3,4) (distance euclidienne 5), avec un troisième point
        // singleton k=(3,0). Formule de Ward :
        // d(ij,k) = sqrt( [(1+1)*d_ik^2 + (1+1)*d_jk^2 - 1*d_ij^2] / (1+1+1) )
        // d_ik = dist((0,0),(3,0)) = 3, d_jk = dist((3,4),(3,0)) = 4, d_ij=5.
        // = sqrt( [2*9 + 2*16 - 25] / 3 ) = sqrt( [18+32-25]/3 ) = sqrt(25/3)
        let d_ik = 3.0;
        let d_jk = 4.0;
        let d_ij = 5.0;
        let expected = (25.0_f64 / 3.0).sqrt();
        let d = HierarchicalClustering::lance_williams_update(Linkage::Ward, d_ik, d_jk, d_ij, 1.0, 1.0, 1.0);
        assert!((d - expected).abs() < 1e-9, "d={d}, expected={expected}");
    }

    // -------- Tests de bout en bout --------

    #[test]
    fn hand_computed_single_linkage_two_pairs() {
        // Points 1D : 0.0, 1.0, 5.0, 6.0. Distances : d(0,1)=1, d(2,3)=1
        // (toutes deux minimales, égalité), d(1,2)=4, le reste plus grand.
        // n_clusters=2 : doit produire {0,1} et {2,3} pour les 4 critères
        // (le premier merge est toujours (0,1) par la règle de
        // désambiguïsation déterministe, puis (2,3) est la seule paire
        // restante de distance minimale).
        let points = vec![vec![0.0], vec![1.0], vec![5.0], vec![6.0]];
        for linkage in [Linkage::Single, Linkage::Complete, Linkage::Average, Linkage::Ward] {
            let data = Dataset::new(points.clone(), None, "toy");
            let mut hc = HierarchicalClustering::new(2, linkage);
            let result = hc.fit(&data);
            assert_eq!(result.labels[0], result.labels[1], "linkage={:?}", linkage);
            assert_eq!(result.labels[2], result.labels[3], "linkage={:?}", linkage);
            assert_ne!(result.labels[0], result.labels[2], "linkage={:?}", linkage);
        }
    }

    #[test]
    fn single_linkage_chains_through_bridge_complete_does_not() {
        // Démonstration de l'effet de chaînage : deux blobs denses reliés
        // par un pont de points régulièrement espacés (écart 2.0, très
        // supérieur à la densité intra-blob ~0.1, très inférieur à la
        // distance directe blob-blob ~20).
        //
        // Hypothèse initiale (fausse, corrigée après vérification
        // empirique via examples/hierarchical_explore.rs) : on s'attendait
        // à ce que single linkage fusionne les DEUX blobs ensemble à k=2.
        // Ce n'est pas ce qui se passe : à cause du critère glouton +
        // désambiguïsation par indice croissant, le pont entier est
        // absorbé par le cluster de GAUCHE uniquement (14 points, étendue
        // spatiale 18 unités) tandis que le cluster de droite reste intact
        // et compact (5 points, étendue 0.4 unité) — un déséquilibre
        // net (ratio 2.8), signature du chaînage, mais asymétrique plutôt
        // que symétrique. Preuve la plus directe : le point le plus
        // éloigné du pont (index 18, à 18 unités du blob gauche) se
        // retrouve dans le MÊME cluster que le blob gauche pour single
        // linkage, mais pas pour complete linkage.
        let mut points = Vec::new();
        for i in 0..5 {
            points.push(vec![0.1 * i as f64, 0.0]); // blob gauche dense, x in [0, 0.4]
        }
        for i in 0..5 {
            points.push(vec![20.0 + 0.1 * i as f64, 0.0]); // blob droit dense, x in [20, 20.4]
        }
        for i in 1..10 {
            points.push(vec![2.0 * i as f64, 0.0]); // pont, x = 2,4,...,18
        }
        let far_bridge_point_idx = 18; // x = 18.0, à 17.6 du blob gauche, 2.0 du blob droit
        let data = Dataset::new(points, None, "bridge");

        let mut single = HierarchicalClustering::new(2, Linkage::Single);
        let r_single = single.fit(&data);
        assert_eq!(
            r_single.labels[0], r_single.labels[far_bridge_point_idx],
            "single linkage : le point du pont le plus éloigné (18 unités) devrait quand même être \
             absorbé par le cluster du blob gauche (chaînage)"
        );

        let mut complete = HierarchicalClustering::new(2, Linkage::Complete);
        let r_complete = complete.fit(&data);
        assert_ne!(
            r_complete.labels[0], r_complete.labels[far_bridge_point_idx],
            "complete linkage : le point du pont le plus éloigné ne devrait PAS être absorbé par \
             le cluster du blob gauche (pas de chaînage, clusters plus compacts)"
        );

        // Déséquilibre de taille : signature quantitative du chaînage.
        let size = |labels: &[i32], target: i32| labels.iter().filter(|&&l| l == target).count();
        let single_sizes = (size(&r_single.labels, 0), size(&r_single.labels, 1));
        let complete_sizes = (size(&r_complete.labels, 0), size(&r_complete.labels, 1));
        let single_ratio = single_sizes.0.max(single_sizes.1) as f64 / single_sizes.0.min(single_sizes.1) as f64;
        let complete_ratio = complete_sizes.0.max(complete_sizes.1) as f64 / complete_sizes.0.min(complete_sizes.1) as f64;
        assert!(
            single_ratio > complete_ratio,
            "single linkage devrait produire des clusters plus déséquilibrés que complete linkage \
             sur ce jeu : single_ratio={single_ratio}, complete_ratio={complete_ratio}"
        );
    }

    #[test]
    fn deterministic_across_runs() {
        let data = make_blobs(150, 3, 0.8, 5);
        let mut hc1 = HierarchicalClustering::new(3, Linkage::Ward);
        let mut hc2 = HierarchicalClustering::new(3, Linkage::Ward);
        assert_eq!(hc1.fit(&data).labels, hc2.fit(&data).labels);
    }

    #[test]
    fn recovers_well_separated_blobs_all_linkages() {
        let data = make_blobs(200, 3, 0.8, 42);
        for linkage in [Linkage::Single, Linkage::Complete, Linkage::Average, Linkage::Ward] {
            let mut hc = HierarchicalClustering::new(3, linkage);
            let result = hc.fit(&data);
            let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
            assert!(ari > 0.9, "linkage={:?} ARI trop bas sur blobs séparés: {ari}", linkage);
        }
    }

    #[test]
    fn single_linkage_excels_on_moons_at_k3_not_k2() {
        // Découverte empirique (voir examples/hierarchical_explore.rs) :
        // à k=2, single linkage donne ARI=0 (un point aberrant isolé vole
        // un cluster entier : tailles {299, 1}) — signature classique de
        // la fragilité de single linkage au bruit/outliers. Mais dès
        // k=3 (un cluster « poubelle » d'un seul point aberrant + les deux
        // vraies lunes), ARI=0.980 : bien meilleur que Ward à k=2 (0.358,
        // voir test précédent). C'est un point méthodologique important
        // pour l'article : single linkage peut être excellent sur données
        // non convexes, mais est structurellement fragile à k fixé sans
        // mécanisme de rejet du bruit — exactement pourquoi DBSCAN (qui a
        // un label -1 dédié) est plus robuste en pratique que single
        // linkage à ce même k.
        let data = make_moons(300, 0.08, 42);

        let mut single_k2 = HierarchicalClustering::new(2, Linkage::Single);
        let ari_k2 = adjusted_rand_index(
            data.labels_true.as_ref().unwrap(),
            &single_k2.fit(&data).labels,
        );
        assert!(ari_k2 < 0.1, "k=2 devrait échouer à cause d'un outlier qui vole un cluster: ARI={ari_k2}");

        let mut single_k3 = HierarchicalClustering::new(3, Linkage::Single);
        let ari_k3 = adjusted_rand_index(
            data.labels_true.as_ref().unwrap(),
            &single_k3.fit(&data).labels,
        );
        assert!(ari_k3 > 0.95, "k=3 devrait bien récupérer les deux lunes + l'outlier isolé: ARI={ari_k3}");
    }

    #[test]
    fn ward_underperforms_single_on_moons_documented() {
        // Comme K-Means (Phase 2), Ward favorise des clusters compacts et
        // échoue structurellement sur des formes non convexes. On mesure
        // et documente plutôt que de figer une valeur arbitraire.
        let data = make_moons(300, 0.08, 42);
        let mut ward = HierarchicalClustering::new(2, Linkage::Ward);
        let r_ward = ward.fit(&data);
        let ari_ward = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &r_ward.labels);
        println!("moons: ward k=2 ARI={ari_ward}");
        assert_eq!(r_ward.labels.len(), data.n_samples());
    }

    #[test]
    #[should_panic(expected = "n_clusters")]
    fn panics_if_n_clusters_exceeds_n_samples() {
        let data = make_blobs(3, 2, 0.5, 0);
        let mut hc = HierarchicalClustering::new(10, Linkage::Ward);
        hc.fit(&data);
    }
}
