//! HDBSCAN (Campello, Moulavi & Sander, 2013 ; McInnes & Healy, 2017) :
//! extension hiérarchique de DBSCAN qui élimine le besoin d'un unique
//! rayon `eps` global, en construisant un arbre de fusion sur la distance
//! de **atteignabilité mutuelle** puis en le condensant pour ne garder que
//! les fusions correspondant à de vrais clusters (taille >= min_cluster_size).
//!
//! Pipeline complet :
//! 1. **Distance de coeur** `core_dist_k(x)` : distance au k-ième plus
//!    proche voisin (k = `min_samples`), analogue du voisinage DBSCAN mais
//!    utilisée comme pénalité plutôt que comme seuil binaire.
//! 2. **Distance de atteignabilité mutuelle** :
//!    `d_mreach(i,j) = max(core_dist(i), core_dist(j), d(i,j))`.
//! 3. **Arbre couvrant de poids minimal (MST)** sur le graphe complet
//!    pondéré par `d_mreach` (algorithme de Prim, O(n²)).
//! 4. **Dendrogramme single-linkage** construit à partir des arêtes du MST
//!    triées par poids croissant (équivalence MST ↔ dendrogramme
//!    single-linkage, classique).
//! 5. **Condensation** : parcours du dendrogramme de la racine vers les
//!    feuilles ; une fusion (vue à l'envers = scission) n'est un « vrai »
//!    événement que si ses deux parts font chacune >= `min_cluster_size` ;
//!    sinon la petite part « tombe » du cluster hérité comme bruit à cette
//!    densité, sans créer de nouveau cluster.
//! 6. **Stabilité** de chaque cluster condensé : somme, sur tous les
//!    points qui en ont un jour été membres, de `(λ_départ - λ_naissance)`.
//! 7. **Extraction Excess-of-Mass (EOM)** : sélection récursive
//!    bottom-up du sous-ensemble de clusters condensés (sans relation
//!    ancêtre-descendant entre eux) maximisant la stabilité totale.
//!
//! Complexité : O(n²) pour le MST (dominant), O(n log n) pour le tri des
//! arêtes, O(n) pour la condensation et l'extraction EOM.

use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};
use std::collections::{HashMap, HashSet};

/// Distance de coeur de chaque point : distance à son k-ième plus proche
/// voisin (`k = min_samples`), voisin lui-même exclu.
fn core_distances(points: &[Vec<f64>], min_samples: usize) -> Vec<f64> {
    let n = points.len();
    (0..n)
        .map(|i| {
            let mut dists: Vec<f64> = (0..n).filter(|&j| j != i).map(|j| euclidean(&points[i], &points[j])).collect();
            dists.sort_by(|a, b| a.partial_cmp(b).unwrap());
            dists[(min_samples - 1).min(dists.len() - 1)]
        })
        .collect()
}

fn mutual_reachability(core_dist: &[f64], i: usize, j: usize, d_ij: f64) -> f64 {
    core_dist[i].max(core_dist[j]).max(d_ij)
}

/// Arbre couvrant de poids minimal sur le graphe complet pondéré par la
/// distance de atteignabilité mutuelle (algorithme de Prim).
fn minimum_spanning_tree(points: &[Vec<f64>], core_dist: &[f64]) -> Vec<(usize, usize, f64)> {
    let n = points.len();
    let mut in_tree = vec![false; n];
    let mut best_dist = vec![f64::INFINITY; n];
    let mut best_from = vec![0usize; n];
    in_tree[0] = true;
    for v in 1..n {
        let d_uv = euclidean(&points[0], &points[v]);
        best_dist[v] = mutual_reachability(core_dist, 0, v, d_uv);
        best_from[v] = 0;
    }

    let mut edges = Vec::with_capacity(n.saturating_sub(1));
    for _ in 0..n.saturating_sub(1) {
        let u = (0..n)
            .filter(|&i| !in_tree[i])
            .min_by(|&a, &b| best_dist[a].partial_cmp(&best_dist[b]).unwrap())
            .unwrap();
        in_tree[u] = true;
        edges.push((best_from[u], u, best_dist[u]));
        for v in 0..n {
            if !in_tree[v] {
                let d_uv = euclidean(&points[u], &points[v]);
                let d = mutual_reachability(core_dist, u, v, d_uv);
                if d < best_dist[v] {
                    best_dist[v] = d;
                    best_from[v] = u;
                }
            }
        }
    }
    edges
}

#[derive(Debug, Clone)]
struct DendroNode {
    left: usize,
    right: usize,
    distance: f64,
    size: usize,
}

struct Dsu {
    parent: Vec<usize>,
    node_id: Vec<usize>,
    size: Vec<usize>,
}

impl Dsu {
    fn new(n: usize) -> Self {
        Dsu { parent: (0..n).collect(), node_id: (0..n).collect(), size: vec![1; n] }
    }

    fn find(&mut self, x: usize) -> usize {
        if self.parent[x] != x {
            self.parent[x] = self.find(self.parent[x]);
        }
        self.parent[x]
    }

    /// Fusionne les composantes de `a` et `b`, leur assigne `new_node_id`
    /// comme représentant, et retourne les identifiants de noeud
    /// (dendrogramme) qu'avaient les deux composantes juste avant fusion,
    /// ainsi que la taille combinée.
    fn union(&mut self, a: usize, b: usize, new_node_id: usize) -> (usize, usize, usize) {
        let ra = self.find(a);
        let rb = self.find(b);
        let node_a = self.node_id[ra];
        let node_b = self.node_id[rb];
        let combined = self.size[ra] + self.size[rb];
        if self.size[ra] < self.size[rb] {
            self.parent[ra] = rb;
            self.size[rb] = combined;
            self.node_id[rb] = new_node_id;
        } else {
            self.parent[rb] = ra;
            self.size[ra] = combined;
            self.node_id[ra] = new_node_id;
        }
        (node_a, node_b, combined)
    }
}

/// Construit le dendrogramme single-linkage à partir des arêtes du MST
/// (triées par poids croissant + union-find). `nodes[i]` correspond à
/// l'identifiant de noeud `n + i`. Identité classique : le MST trié en
/// ordre croissant produit exactement la même séquence de fusions qu'un
/// clustering single-linkage sur la même matrice de distances.
fn build_dendrogram(n: usize, mut edges: Vec<(usize, usize, f64)>) -> Vec<DendroNode> {
    edges.sort_by(|a, b| a.2.partial_cmp(&b.2).unwrap());
    let mut dsu = Dsu::new(n);
    let mut nodes = Vec::with_capacity(n.saturating_sub(1));
    for (i, (a, b, d)) in edges.into_iter().enumerate() {
        let new_id = n + i;
        let (node_a, node_b, size) = dsu.union(a, b, new_id);
        nodes.push(DendroNode { left: node_a, right: node_b, distance: d, size });
    }
    nodes
}

fn subtree_size(node: usize, n: usize, nodes: &[DendroNode]) -> usize {
    if node < n {
        1
    } else {
        nodes[node - n].size
    }
}

#[derive(Debug, Clone)]
struct CondensedCluster {
    parent: Option<usize>,
    stability: f64,
}

/// Marque tous les points originaux du sous-arbre `node` comme ayant pour
/// dernière appartenance connue `cluster_id` (ils ne seront plus jamais
/// revisités : soit ils tombent définitivement en bruit, soit `cluster_id`
/// finit par être sélectionné et ils lui seront rattachés).
fn assign_subtree(node: usize, n: usize, nodes: &[DendroNode], cluster_id: Option<usize>, point_final: &mut [Option<usize>]) {
    if node < n {
        point_final[node] = cluster_id;
    } else {
        let dn = nodes[node - n].clone();
        assign_subtree(dn.left, n, nodes, cluster_id, point_final);
        assign_subtree(dn.right, n, nodes, cluster_id, point_final);
    }
}

/// Condensation récursive (racine -> feuilles). Voir la documentation de
/// module pour la description complète de l'algorithme et son
/// raisonnement.
#[allow(clippy::too_many_arguments)]
fn condense(
    node: usize,
    n: usize,
    nodes: &[DendroNode],
    min_cluster_size: usize,
    inherited: Option<usize>,
    inherited_birth: f64,
    clusters: &mut Vec<CondensedCluster>,
    point_final: &mut [Option<usize>],
) {
    let dn = nodes[node - n].clone();
    let lambda = if dn.distance > 0.0 { 1.0 / dn.distance } else { f64::INFINITY };
    let left_size = subtree_size(dn.left, n, nodes);
    let right_size = subtree_size(dn.right, n, nodes);

    let both_qualify = left_size >= min_cluster_size && right_size >= min_cluster_size;

    if both_qualify {
        if let Some(cid) = inherited {
            clusters[cid].stability += (dn.size as f64) * (lambda - inherited_birth);
        }
        let left_id = clusters.len();
        clusters.push(CondensedCluster { parent: inherited, stability: 0.0 });
        let right_id = clusters.len();
        clusters.push(CondensedCluster { parent: inherited, stability: 0.0 });

        if dn.left >= n {
            condense(dn.left, n, nodes, min_cluster_size, Some(left_id), lambda, clusters, point_final);
        } else {
            assign_subtree(dn.left, n, nodes, Some(left_id), point_final);
        }
        if dn.right >= n {
            condense(dn.right, n, nodes, min_cluster_size, Some(right_id), lambda, clusters, point_final);
        } else {
            assign_subtree(dn.right, n, nodes, Some(right_id), point_final);
        }
    } else if left_size < min_cluster_size && right_size < min_cluster_size {
        assign_subtree(dn.left, n, nodes, inherited, point_final);
        assign_subtree(dn.right, n, nodes, inherited, point_final);
        if let Some(cid) = inherited {
            clusters[cid].stability += (dn.size as f64) * (lambda - inherited_birth);
        }
    } else {
        let (small, small_size, large) = if left_size < min_cluster_size {
            (dn.left, left_size, dn.right)
        } else {
            (dn.right, right_size, dn.left)
        };
        assign_subtree(small, n, nodes, inherited, point_final);
        if let Some(cid) = inherited {
            clusters[cid].stability += (small_size as f64) * (lambda - inherited_birth);
        }
        if large >= n {
            condense(large, n, nodes, min_cluster_size, inherited, inherited_birth, clusters, point_final);
        } else {
            assign_subtree(large, n, nodes, inherited, point_final);
        }
    }
}

fn compute_best_scores(cluster_id: usize, clusters: &[CondensedCluster], children: &HashMap<usize, Vec<usize>>, best: &mut HashMap<usize, f64>) -> f64 {
    let own = clusters[cluster_id].stability;
    let score = match children.get(&cluster_id) {
        None => own,
        Some(kids) => {
            let child_sum: f64 = kids.iter().map(|&k| compute_best_scores(k, clusters, children, best)).sum();
            own.max(child_sum)
        }
    };
    best.insert(cluster_id, score);
    score
}

fn select_clusters(cluster_id: usize, clusters: &[CondensedCluster], children: &HashMap<usize, Vec<usize>>, best: &HashMap<usize, f64>, selected: &mut HashSet<usize>, visited: &mut HashSet<usize>) {
    visited.insert(cluster_id);
    let own = clusters[cluster_id].stability;
    match children.get(&cluster_id) {
        None => {
            selected.insert(cluster_id);
        }
        Some(kids) => {
            let child_sum: f64 = kids.iter().map(|&k| best[&k]).sum();
            if own >= child_sum {
                selected.insert(cluster_id);
            } else {
                for &k in kids {
                    select_clusters(k, clusters, children, best, selected, visited);
                }
            }
        }
    }
}

/// Résout le cluster final (sélectionné) d'un point à partir du cluster
/// condensé le plus profond dont il a fait partie (`cid`).
///
/// Distinction essentielle : si `cid` a été *visité* par `select_clusters`
/// mais n'est pas sélectionné, cela signifie que `cid` a délégué sa
/// sélection à SES PROPRES enfants (stabilité combinée meilleure) — mais
/// CE point a quitté `cid` avant que cette scission n'ait lieu, donc il
/// n'a jamais fait partie de ces enfants sélectionnés : il devient bruit
/// (on ne remonte PAS vers un ancêtre dans ce cas). En revanche, si `cid`
/// n'a jamais été visité, c'est qu'un ANCÊTRE a été sélectionné directement
/// (arrêtant la récursion avant d'atteindre `cid`) : il faut alors remonter
/// jusqu'à cet ancêtre. Confondre ces deux cas était le bug initial (voir
/// historique : un premier essai remontait toujours vers le parent, ce qui
/// provoquait un panic sur `adversarial_density`, corrigé après diagnostic
/// direct plutôt que supposé correct).
fn resolve_final_cluster(cid: usize, clusters: &[CondensedCluster], selected: &HashSet<usize>, visited: &HashSet<usize>) -> Option<usize> {
    let mut cur = cid;
    loop {
        if selected.contains(&cur) {
            return Some(cur);
        }
        if visited.contains(&cur) {
            // Visité et non sélectionné => délégué à ses propres enfants ;
            // ce point n'y a pas survécu => bruit.
            return None;
        }
        match clusters[cur].parent {
            Some(p) => cur = p,
            None => return None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct Hdbscan {
    pub min_cluster_size: usize,
    pub min_samples: usize,
}

impl Hdbscan {
    pub fn new(min_cluster_size: usize, min_samples: usize) -> Self {
        assert!(min_cluster_size >= 2, "min_cluster_size doit être >= 2");
        assert!(min_samples >= 1, "min_samples doit être >= 1");
        Self { min_cluster_size, min_samples }
    }
}

impl ClusteringAlgorithm for Hdbscan {
    fn name(&self) -> &str {
        "HDBSCAN"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        let n = points.len();
        assert!(n >= 2, "HDBSCAN requiert au moins 2 points");
        let min_cluster_size = self.min_cluster_size;
        let min_samples = self.min_samples.min(n - 1).max(1);

        timed_fit(self.name(), || {
            let core_dist = core_distances(points, min_samples);
            let mst_edges = minimum_spanning_tree(points, &core_dist);
            let nodes = build_dendrogram(n, mst_edges);

            let mut point_final: Vec<Option<usize>> = vec![None; n];
            let mut clusters: Vec<CondensedCluster> = Vec::new();

            if !nodes.is_empty() {
                let root = n + nodes.len() - 1;
                condense(root, n, &nodes, min_cluster_size, None, f64::INFINITY, &mut clusters, &mut point_final);
            }

            let labels = if clusters.is_empty() {
                vec![-1i32; n]
            } else {
                let mut children: HashMap<usize, Vec<usize>> = HashMap::new();
                for (id, c) in clusters.iter().enumerate() {
                    if let Some(p) = c.parent {
                        children.entry(p).or_default().push(id);
                    }
                }
                let roots: Vec<usize> = (0..clusters.len()).filter(|&id| clusters[id].parent.is_none()).collect();

                let mut best = HashMap::new();
                for &r in &roots {
                    compute_best_scores(r, &clusters, &children, &mut best);
                }
                let mut selected = HashSet::new();
                let mut visited = HashSet::new();
                for &r in &roots {
                    select_clusters(r, &clusters, &children, &best, &mut selected, &mut visited);
                }

                let mut selected_sorted: Vec<usize> = selected.iter().copied().collect();
                selected_sorted.sort_unstable();
                let compact: HashMap<usize, i32> = selected_sorted.iter().enumerate().map(|(i, &cid)| (cid, i as i32)).collect();

                point_final
                    .iter()
                    .map(|&pf| match pf {
                        None => -1,
                        Some(cid) => match resolve_final_cluster(cid, &clusters, &selected, &visited) {
                            Some(anc) => compact[&anc],
                            None => -1,
                        },
                    })
                    .collect()
            };

            let n_clusters = labels.iter().filter(|&&l| l >= 0).collect::<HashSet<_>>().len();
            (labels, n_clusters)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_core::Dataset;
    use cluster_data::{make_adversarial_density, make_blobs};
    use cluster_metrics::adjusted_rand_index;

    #[test]
    fn core_distance_hand_computed() {
        // Points 1D : 0, 1, 3, 6. min_samples=2 -> distance au 2e plus
        // proche voisin (le voisin lui-même exclu).
        // Point 0 (x=0): voisins triés = [1 (d=1), 3(d=3), 6(d=6)] -> 2e = 3.0
        // Point 1 (x=1): voisins triés = [0(d=1), 3(d=2), 6(d=5)] -> 2e = 2.0
        let points = vec![vec![0.0], vec![1.0], vec![3.0], vec![6.0]];
        let cd = core_distances(&points, 2);
        assert!((cd[0] - 3.0).abs() < 1e-9, "cd[0]={}", cd[0]);
        assert!((cd[1] - 2.0).abs() < 1e-9, "cd[1]={}", cd[1]);
    }

    #[test]
    fn mst_hand_computed_simple_line() {
        // Points 1D équidistants 0,1,2,3 avec core_dist nulle partout
        // (simulé via min_samples=1 sur des points assez proches pour que
        // le plus proche voisin domine) : le MST doit être la chaîne
        // 0-1-2-3 de poids total 3.
        let points = vec![vec![0.0], vec![1.0], vec![2.0], vec![3.0]];
        let core_dist = core_distances(&points, 1);
        let edges = minimum_spanning_tree(&points, &core_dist);
        assert_eq!(edges.len(), 3);
        let total_weight: f64 = edges.iter().map(|&(_, _, d)| d).sum();
        assert!((total_weight - 3.0).abs() < 1e-9, "poids total={total_weight}");
    }

    #[test]
    fn dendrogram_root_has_full_size() {
        let points = vec![vec![0.0], vec![0.1], vec![5.0], vec![5.1]];
        let core_dist = core_distances(&points, 1);
        let edges = minimum_spanning_tree(&points, &core_dist);
        let nodes = build_dendrogram(4, edges);
        assert_eq!(nodes.len(), 3);
        assert_eq!(nodes.last().unwrap().size, 4);
    }

    #[test]
    fn hand_computed_two_dense_clusters_no_noise() {
        // Deux groupes denses bien séparés, sans point de bruit explicite :
        // devrait donner exactement 2 clusters couvrant tous les points.
        let points = vec![
            vec![0.0, 0.0],
            vec![0.1, 0.0],
            vec![0.0, 0.1],
            vec![0.1, 0.1],
            vec![10.0, 10.0],
            vec![10.1, 10.0],
            vec![10.0, 10.1],
            vec![10.1, 10.1],
        ];
        let data = Dataset::new(points, None, "toy");
        let mut hdb = Hdbscan::new(3, 2);
        let result = hdb.fit(&data);
        assert_eq!(result.n_clusters, 2);
        assert_eq!(result.labels[0], result.labels[1]);
        assert_eq!(result.labels[1], result.labels[2]);
        assert_eq!(result.labels[2], result.labels[3]);
        assert_eq!(result.labels[4], result.labels[5]);
        assert_ne!(result.labels[0], result.labels[4]);
        assert!(result.labels.iter().all(|&l| l >= 0), "aucun bruit attendu ici");
    }

    #[test]
    fn hand_computed_outlier_is_noise() {
        let mut points = vec![vec![0.0, 0.0], vec![0.1, 0.0], vec![0.0, 0.1], vec![0.1, 0.1]];
        for i in 0..4 {
            points.push(vec![10.0 + 0.1 * (i % 2) as f64, 10.0 + 0.1 * (i / 2) as f64]);
        }
        points.push(vec![50.0, 50.0]); // outlier net
        let data = Dataset::new(points, None, "toy_outlier");
        let mut hdb = Hdbscan::new(3, 2);
        let result = hdb.fit(&data);
        assert_eq!(result.labels[8], -1, "l'outlier isolé doit être étiqueté bruit");
        assert_eq!(result.n_clusters, 2);
    }

    #[test]
    fn deterministic_across_runs() {
        let data = make_blobs(200, 3, 0.8, 5);
        let mut h1 = Hdbscan::new(10, 5);
        let mut h2 = Hdbscan::new(10, 5);
        assert_eq!(h1.fit(&data).labels, h2.fit(&data).labels);
    }

    #[test]
    fn recovers_well_separated_blobs_with_high_ari() {
        let data = make_blobs(300, 3, 0.8, 42);
        let mut hdb = Hdbscan::new(15, 5);
        let result = hdb.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "ARI trop bas sur des blobs bien séparés: {ari}");
    }

    #[test]
    fn documented_comparison_with_dbscan_on_adversarial_density() {
        // Hypothèse initiale (issue de la littérature) : HDBSCAN devrait
        // dominer DBSCAN sur données à densité hétérogène puisqu'il ne
        // dépend pas d'un eps global unique. Vérification empirique par
        // double balayage complet (voir
        // examples/hdbscan_param_sweep.rs et
        // examples/hdbscan_vs_dbscan_comparison.rs) : à hyperparamètres
        // optimaux pour CHACUN, DBSCAN atteint ARI=0.713 sur
        // adversarial_density, HDBSCAN plafonne à 0.708 — quasiment à
        // égalité, HDBSCAN ne domine PAS ici. Ce résultat contre-intuitif
        // a été confirmé sur 4 configurations différentes (voir
        // hdbscan_vs_dbscan_comparison.rs), toutes donnant DBSCAN >=
        // HDBSCAN. Confirmé non-bug : accord exact (ARI=1.000, 100% des
        // labels) avec scikit-learn 1.8.0 sur ce même jeu de données (voir
        // validation/compare_hdbscan.py).
        //
        // Interprétation pour l'article : l'avantage pratique de HDBSCAN
        // n'est probablement pas "un plafond de performance plus haut"
        // mais plutôt une plus grande ROBUSTESSE au choix des
        // hyperparamètres (moins sensible qu'un mauvais réglage de eps),
        // point à creuser en Phase 6 en comparant la variance des ARI
        // sur la grille de recherche plutôt que le seul maximum.
        let data = make_adversarial_density(300, 42);
        let mut hdb = Hdbscan::new(8, 1);
        let result = hdb.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        println!("adversarial_density: HDBSCAN (meilleur réglage) ARI={ari} (DBSCAN meilleur réglage: 0.713)");
        assert_eq!(result.labels.len(), data.n_samples());
    }

    #[test]
    #[should_panic(expected = "min_cluster_size")]
    fn panics_on_min_cluster_size_below_2() {
        Hdbscan::new(1, 5);
    }
}
