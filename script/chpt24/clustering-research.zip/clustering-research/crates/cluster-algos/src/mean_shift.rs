//! Mean-Shift (Fukunaga & Hostetler, 1975 ; Cheng, 1995 ; Comaniciu & Meer,
//! 2002) : algorithme de recherche de modes par décalage itératif vers la
//! moyenne locale (noyau plat/uniforme, comme l'implémentation par défaut
//! de scikit-learn). Contrairement à K-Means, entièrement déterministe : ne
//! dépend d'aucune graine aléatoire, chaque point sert de graine de départ.
//!
//! Complexité : O(n² × iterations) dans cette implémentation naïve (chaque
//! requête de voisinage est O(n)). C'est une limitation connue et
//! documentée de Mean-Shift en toute généralité (accélérable par KD-tree
//! pour de grands n, hors périmètre de cette phase).

use cluster_core::{euclidean, timed_fit, ClusterResult, ClusteringAlgorithm, Dataset};

#[derive(Debug, Clone)]
pub struct MeanShift {
    /// Rayon du noyau plat : un point est voisin s'il est à distance
    /// <= bandwidth. Hyperparamètre principal, analogue au epsilon de
    /// DBSCAN mais utilisé pour une moyenne glissante plutôt qu'un seuil
    /// de densité binaire.
    pub bandwidth: f64,
    pub max_iter: usize,
    pub tol: f64,
    /// Si `true` (par défaut, comme scikit-learn), tous les points sont
    /// affectés au mode le plus proche même s'ils sont hors bandwidth de
    /// tout mode. Si `false`, ces points reçoivent le label -1 (bruit).
    pub cluster_all: bool,
}

impl MeanShift {
    pub fn new(bandwidth: f64) -> Self {
        assert!(bandwidth > 0.0, "bandwidth doit être > 0");
        Self {
            bandwidth,
            max_iter: 300,
            tol: 1e-3,
            cluster_all: true,
        }
    }

    /// Fait converger un point de départ vers un mode local de densité par
    /// décalages itératifs vers la moyenne des voisins (noyau plat).
    /// Retourne la position finale et le nombre de voisins à convergence
    /// (utilisé comme proxy d'intensité pour le tri en Phase de fusion).
    fn shift_to_mode(start: &[f64], points: &[Vec<f64>], bandwidth: f64, max_iter: usize, tol: f64) -> (Vec<f64>, usize) {
        let dim = start.len();
        let mut y = start.to_vec();
        let mut neighbor_count = 0usize;

        for _ in 0..max_iter.max(1) {
            let neighbors: Vec<&Vec<f64>> = points.iter().filter(|p| euclidean(p, &y) <= bandwidth).collect();
            neighbor_count = neighbors.len();
            if neighbors.is_empty() {
                // Aucun voisin (bandwidth trop petit / point isolé) : le
                // point reste sur place, c'est son propre mode.
                break;
            }
            let mut mean = vec![0.0; dim];
            for p in &neighbors {
                for (j, &v) in p.iter().enumerate() {
                    mean[j] += v;
                }
            }
            for v in mean.iter_mut() {
                *v /= neighbors.len() as f64;
            }
            let shift = euclidean(&mean, &y);
            y = mean;
            if shift < tol {
                break;
            }
        }
        (y, neighbor_count)
    }

    /// Fusionne les modes candidats (un par point de départ) en centres de
    /// cluster définitifs : tri par intensité décroissante (nombre de
    /// voisins à convergence), puis acceptation gloutonne — un candidat
    /// n'est retenu comme nouveau centre que s'il est à distance >
    /// bandwidth de tous les centres déjà acceptés (sinon c'est un
    /// doublon du même mode, atteint depuis un autre point de départ).
    fn merge_modes(mut candidates: Vec<(Vec<f64>, usize)>, bandwidth: f64) -> Vec<Vec<f64>> {
        candidates.sort_by(|a, b| b.1.cmp(&a.1));
        let mut centers: Vec<Vec<f64>> = Vec::new();
        for (candidate, _count) in &candidates {
            let is_duplicate = centers.iter().any(|c| euclidean(c, candidate) <= bandwidth);
            if !is_duplicate {
                centers.push(candidate.clone());
            }
        }
        centers
    }
}

impl ClusteringAlgorithm for MeanShift {
    fn name(&self) -> &str {
        "Mean-Shift"
    }

    fn fit(&mut self, data: &Dataset) -> ClusterResult {
        let points = &data.points;
        assert!(!points.is_empty(), "points ne doit pas être vide");
        let bandwidth = self.bandwidth;
        let max_iter = self.max_iter;
        let tol = self.tol;
        let cluster_all = self.cluster_all;

        timed_fit(self.name(), || {
            let candidates: Vec<(Vec<f64>, usize)> = points
                .iter()
                .map(|p| Self::shift_to_mode(p, points, bandwidth, max_iter, tol))
                .collect();

            let centers = Self::merge_modes(candidates, bandwidth);

            let mut labels = Vec::with_capacity(points.len());
            for p in points.iter() {
                let mut best = 0usize;
                let mut best_d = f64::INFINITY;
                for (c_idx, c) in centers.iter().enumerate() {
                    let d = euclidean(p, c);
                    if d < best_d {
                        best_d = d;
                        best = c_idx;
                    }
                }
                if cluster_all || best_d <= bandwidth {
                    labels.push(best as i32);
                } else {
                    labels.push(-1);
                }
            }

            let n_clusters = centers.len();
            (labels, n_clusters)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cluster_data::{make_blobs, make_moons};
    use cluster_metrics::adjusted_rand_index;

    #[test]
    fn hand_computed_two_groups_1d() {
        // Groupe 1: {0.0, 0.2}, groupe 2: {10.0, 10.2}, bandwidth=1.0
        // (> écart intra-groupe 0.2, < écart inter-groupe 9.8).
        // Convergence analytique : mode1 = moyenne(0.0,0.2) = 0.1,
        // mode2 = moyenne(10.0,10.2) = 10.1 (point fixe dès la 1ère itération
        // car les voisinages ne changent plus).
        let points = vec![vec![0.0], vec![0.2], vec![10.0], vec![10.2]];
        let data = cluster_core::Dataset::new(points, None, "toy");
        let mut ms = MeanShift::new(1.0);
        let result = ms.fit(&data);

        assert_eq!(result.n_clusters, 2);
        assert_eq!(result.labels[0], result.labels[1]);
        assert_eq!(result.labels[2], result.labels[3]);
        assert_ne!(result.labels[0], result.labels[2]);
    }

    #[test]
    fn shift_to_mode_converges_to_analytic_value() {
        let points = vec![vec![0.0], vec![0.2]];
        let (mode, count) = MeanShift::shift_to_mode(&points[0], &points, 1.0, 300, 1e-9);
        assert_eq!(count, 2);
        assert!((mode[0] - 0.1).abs() < 1e-9, "mode={:?}", mode);
    }

    #[test]
    fn fully_deterministic_across_runs() {
        let data = make_blobs(200, 3, 0.8, 5);
        let mut ms1 = MeanShift::new(2.5);
        let mut ms2 = MeanShift::new(2.5);
        let r1 = ms1.fit(&data);
        let r2 = ms2.fit(&data);
        assert_eq!(r1.labels, r2.labels);
    }

    #[test]
    fn recovers_well_separated_blobs_with_high_ari() {
        let data = make_blobs(300, 3, 0.8, 42);
        let mut ms = MeanShift::new(2.5);
        let result = ms.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        assert!(ari > 0.9, "ARI trop bas sur des blobs bien séparés: {ari}, n_clusters={}", result.n_clusters);
    }

    #[test]
    fn isolated_point_becomes_its_own_mode() {
        // Un point très éloigné de tout, avec un petit bandwidth, ne
        // fusionne avec rien : il doit rester son propre cluster.
        let points = vec![vec![0.0], vec![0.1], vec![0.2], vec![1000.0]];
        let data = cluster_core::Dataset::new(points, None, "toy_outlier");
        let mut ms = MeanShift::new(0.5);
        let result = ms.fit(&data);
        assert_eq!(result.n_clusters, 2);
        assert_ne!(result.labels[3], result.labels[0]);
    }

    #[test]
    fn bandwidth_controls_granularity_monotonically() {
        // Plus le bandwidth est grand, moins on doit trouver de clusters
        // (fusion progressive des modes) — propriété structurelle attendue.
        let data = make_blobs(200, 4, 0.6, 3);
        let mut narrow = MeanShift::new(1.0);
        let mut wide = MeanShift::new(15.0);
        let r_narrow = narrow.fit(&data);
        let r_wide = wide.fit(&data);
        assert!(
            r_wide.n_clusters <= r_narrow.n_clusters,
            "bandwidth large ({} clusters) devrait fusionner plus que bandwidth étroit ({} clusters)",
            r_wide.n_clusters,
            r_narrow.n_clusters
        );
    }

    #[test]
    fn moons_behavior_is_documented_not_assumed() {
        // Contrairement à K-Means, Mean-Shift est fondé sur la densité et
        // peut en principe suivre des structures non convexes — mais rien
        // ne garantit qu'il sépare les lunes pour un bandwidth donné (la
        // frontière entre les deux lunes est une zone de densité continue).
        // On mesure et on documente le résultat réel plutôt que de figer
        // une attente théorique non vérifiée.
        let data = make_moons(300, 0.08, 42);
        let mut ms = MeanShift::new(0.3);
        let result = ms.fit(&data);
        let ari = adjusted_rand_index(data.labels_true.as_ref().unwrap(), &result.labels);
        // Seule assertion : le calcul se termine et produit un résultat
        // valide (pas de panic, labels de la bonne taille). La valeur d'ARI
        // est rapportée dans le README, pas figée ici en dur.
        assert_eq!(result.labels.len(), data.n_samples());
        println!("moons bandwidth=0.3 -> ARI={ari}, n_clusters={}", result.n_clusters);
    }

    #[test]
    #[should_panic(expected = "bandwidth doit être > 0")]
    fn panics_on_non_positive_bandwidth() {
        MeanShift::new(0.0);
    }
}
