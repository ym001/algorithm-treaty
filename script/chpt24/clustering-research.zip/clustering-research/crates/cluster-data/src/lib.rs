//! `cluster-data`: générateurs de jeux de données synthétiques 2D,
//! reproductibles (graine explicite, ChaCha8), reprenant la suite de
//! bancs d'essai standard de la littérature en clustering (blobs isotropes,
//! blobs anisotropes, blobs de variances différentes, lunes imbriquées,
//! cercles concentriques, densité variable, bruit uniforme sans structure).
//!
//! Chaque jeu de données inclut la vérité terrain (`labels_true`) quand
//! elle est bien définie par construction, ce qui permet d'utiliser des
//! métriques externes (ARI, NMI) en plus des métriques internes.
//!
//! Reproductibilité : tous les générateurs prennent une graine `seed:
//! u64` explicite et utilisent `ChaCha8Rng`, un générateur pseudo-aléatoire
//! déterministe indépendant de la plateforme. Pour une même graine, deux
//! appels produisent des jeux de données bit-à-bit identiques (voir tests).

use cluster_core::Dataset;
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;
use rand_distr::{Normal, Uniform};
use std::f64::consts::PI;

fn rng_from_seed(seed: u64) -> ChaCha8Rng {
    ChaCha8Rng::seed_from_u64(seed)
}

/// Blobs gaussiens isotropes : le cas "facile" de référence. Les centres
/// sont placés régulièrement sur un cercle dont le rayon croît avec
/// `n_clusters`, afin de garder une séparation raisonnable entre clusters
/// indépendamment de leur nombre.
pub fn make_blobs(n_samples: usize, n_clusters: usize, cluster_std: f64, seed: u64) -> Dataset {
    assert!(n_clusters > 0, "n_clusters doit être > 0");
    let mut rng = rng_from_seed(seed);
    let radius = 5.0 * (n_clusters as f64).sqrt();
    let centers: Vec<(f64, f64)> = (0..n_clusters)
        .map(|k| {
            let theta = 2.0 * PI * (k as f64) / (n_clusters as f64);
            (radius * theta.cos(), radius * theta.sin())
        })
        .collect();
    let normal = Normal::new(0.0, cluster_std).unwrap();

    let mut points = Vec::with_capacity(n_samples);
    let mut labels = Vec::with_capacity(n_samples);
    for i in 0..n_samples {
        let k = i % n_clusters;
        let (cx, cy) = centers[k];
        points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
        labels.push(k as i32);
    }
    Dataset::new(
        points,
        Some(labels),
        format!("blobs_n{n_samples}_k{n_clusters}_std{cluster_std}"),
    )
}

/// Blobs anisotropes : mêmes blobs isotropes, déformés par une
/// transformation linéaire fixe (cisaillement), ce qui casse l'hypothèse
/// de symétrie sphérique implicitement utilisée par K-Means et met en
/// évidence ses limites face à des covariances non isotropes.
pub fn make_anisotropic(n_samples: usize, n_clusters: usize, cluster_std: f64, seed: u64) -> Dataset {
    let mut base = make_blobs(n_samples, n_clusters, cluster_std, seed);
    const TRANSFORM: [[f64; 2]; 2] = [[0.6, -0.6], [-0.4, 0.8]];
    for p in base.points.iter_mut() {
        let (x, y) = (p[0], p[1]);
        p[0] = TRANSFORM[0][0] * x + TRANSFORM[0][1] * y;
        p[1] = TRANSFORM[1][0] * x + TRANSFORM[1][1] * y;
    }
    base.name = format!("anisotropic_n{n_samples}_k{n_clusters}_std{cluster_std}");
    base
}

/// Blobs de variances différentes par cluster (3 clusters, écarts-types
/// 0.5 / 1.0 / 2.5) : met en évidence les algorithmes qui supposent
/// (à tort) une variance intra-cluster homogène.
pub fn make_varied_blobs(n_samples: usize, seed: u64) -> Dataset {
    const STDS: [f64; 3] = [0.5, 1.0, 2.5];
    let n_clusters = STDS.len();
    let mut rng = rng_from_seed(seed);
    let radius = 9.0;
    let centers: Vec<(f64, f64)> = (0..n_clusters)
        .map(|k| {
            let theta = 2.0 * PI * (k as f64) / (n_clusters as f64);
            (radius * theta.cos(), radius * theta.sin())
        })
        .collect();

    let mut points = Vec::with_capacity(n_samples);
    let mut labels = Vec::with_capacity(n_samples);
    for i in 0..n_samples {
        let k = i % n_clusters;
        let normal = Normal::new(0.0, STDS[k]).unwrap();
        let (cx, cy) = centers[k];
        points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
        labels.push(k as i32);
    }
    Dataset::new(points, Some(labels), format!("varied_blobs_n{n_samples}"))
}

/// Deux lunes imbriquées non convexes : cas classique où K-Means échoue
/// structurellement (clusters non séparables linéairement) alors que
/// DBSCAN/HDBSCAN réussissent typiquement.
pub fn make_moons(n_samples: usize, noise: f64, seed: u64) -> Dataset {
    let mut rng = rng_from_seed(seed);
    let n_out = n_samples / 2;
    let n_in = n_samples - n_out;
    let normal = Normal::new(0.0, noise).unwrap();

    let mut points = Vec::with_capacity(n_samples);
    let mut labels = Vec::with_capacity(n_samples);

    for i in 0..n_out {
        let theta = PI * (i as f64) / ((n_out.max(2) - 1) as f64);
        points.push(vec![
            theta.cos() + normal.sample(&mut rng),
            theta.sin() + normal.sample(&mut rng),
        ]);
        labels.push(0);
    }
    for i in 0..n_in {
        let theta = PI * (i as f64) / ((n_in.max(2) - 1) as f64);
        points.push(vec![
            1.0 - theta.cos() + normal.sample(&mut rng),
            0.5 - theta.sin() + normal.sample(&mut rng),
        ]);
        labels.push(1);
    }
    Dataset::new(points, Some(labels), format!("moons_n{n_samples}_noise{noise}"))
}

/// Deux cercles concentriques : autre cas non convexe classique,
/// complémentaire des lunes (symétrie radiale plutôt que translation).
pub fn make_circles(n_samples: usize, noise: f64, factor: f64, seed: u64) -> Dataset {
    assert!((0.0..1.0).contains(&factor), "factor doit être dans (0,1)");
    let mut rng = rng_from_seed(seed);
    let n_out = n_samples / 2;
    let n_in = n_samples - n_out;
    let normal = Normal::new(0.0, noise).unwrap();

    let mut points = Vec::with_capacity(n_samples);
    let mut labels = Vec::with_capacity(n_samples);

    for i in 0..n_out {
        let theta = 2.0 * PI * (i as f64) / (n_out as f64);
        points.push(vec![
            theta.cos() + normal.sample(&mut rng),
            theta.sin() + normal.sample(&mut rng),
        ]);
        labels.push(0);
    }
    for i in 0..n_in {
        let theta = 2.0 * PI * (i as f64) / (n_in as f64);
        points.push(vec![
            factor * theta.cos() + normal.sample(&mut rng),
            factor * theta.sin() + normal.sample(&mut rng),
        ]);
        labels.push(1);
    }
    Dataset::new(
        points,
        Some(labels),
        format!("circles_n{n_samples}_noise{noise}_factor{factor}"),
    )
}

/// Densité variable entre clusters (proportions d'échantillons 60/30/10 %,
/// écarts-types différents) : met en évidence les algorithmes à seuil de
/// densité global unique (DBSCAN classique) par rapport à ceux qui
/// s'adaptent localement (HDBSCAN, OPTICS).
pub fn make_varied_density(n_samples: usize, seed: u64) -> Dataset {
    const FRACTIONS: [f64; 3] = [0.6, 0.3, 0.1];
    const STDS: [f64; 3] = [0.3, 1.0, 2.0];
    const CENTERS: [(f64, f64); 3] = [(-6.0, 0.0), (6.0, 0.0), (0.0, 8.0)];

    let mut rng = rng_from_seed(seed);
    let mut points = Vec::with_capacity(n_samples);
    let mut labels = Vec::with_capacity(n_samples);

    for k in 0..3 {
        let n_k = ((n_samples as f64) * FRACTIONS[k]).round() as usize;
        let normal = Normal::new(0.0, STDS[k]).unwrap();
        let (cx, cy) = CENTERS[k];
        for _ in 0..n_k {
            points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
            labels.push(k as i32);
        }
    }
    Dataset::new(points, Some(labels), format!("varied_density_n{n_samples}"))
}

/// Bruit uniforme sans structure de cluster : jeu de contrôle négatif.
/// Un bon algorithme (avec une bonne métrique interne pour choisir K, ou un
/// mécanisme de rejet comme le label de bruit -1) doit éviter d'imposer une
/// structure artificielle. `labels_true` est `None` par construction : il
/// n'existe pas de vérité terrain pertinente ici.
pub fn make_uniform_noise(n_samples: usize, seed: u64) -> Dataset {
    let mut rng = rng_from_seed(seed);
    let uniform = Uniform::new(-1.0, 1.0);
    let points = (0..n_samples)
        .map(|_| vec![uniform.sample(&mut rng), uniform.sample(&mut rng)])
        .collect();
    Dataset::new(points, None, format!("uniform_noise_n{n_samples}"))
}

/// Densité hétérogène **adverse** : contrairement à `make_varied_density`
/// (Phase 1), dont le balayage DBSCAN en Phase 2 a montré qu'elle ne
/// stressait pas réellement la limitation théorique du eps global unique
/// (DBSCAN y atteignait ARI=1.000), ce générateur est conçu
/// spécifiquement pour qu'aucun eps unique ne puisse satisfaire
/// simultanément tous les niveaux de densité. Une recherche empirique
/// (voir `examples/adversarial_search.rs`) a testé une vingtaine de
/// configurations (2 à 6 clusters, écarts-types et espacements variés) ;
/// une chaîne de **6 niveaux de densité géométriquement croissants**,
/// rapprochés le long d'un axe, s'est révélée la plus adverse : le
/// meilleur (eps, min_samples) trouvé par balayage complet ne dépasse pas
/// ARI=0.670 (contre ARI=1.000 pour la première tentative à 2 clusters).
pub fn make_adversarial_density(n_samples: usize, seed: u64) -> Dataset {
    const CENTERS: [(f64, f64); 6] = [(0.0, 0.0), (0.8, 0.0), (1.8, 0.0), (3.2, 0.0), (5.4, 0.0), (9.0, 0.0)];
    const STDS: [f64; 6] = [0.03, 0.1, 0.25, 0.55, 1.1, 2.2];
    let n_clusters = CENTERS.len();

    let mut rng = rng_from_seed(seed);
    let mut points = Vec::with_capacity(n_samples);
    let mut labels = Vec::with_capacity(n_samples);

    for k in 0..n_clusters {
        let n_k = n_samples / n_clusters + usize::from(k < n_samples % n_clusters);
        let normal = Normal::new(0.0, STDS[k]).unwrap();
        let (cx, cy) = CENTERS[k];
        for _ in 0..n_k {
            points.push(vec![cx + normal.sample(&mut rng), cy + normal.sample(&mut rng)]);
            labels.push(k as i32);
        }
    }
    Dataset::new(points, Some(labels), format!("adversarial_density_n{n_samples}"))
}

/// Graine par défaut utilisée dans `standard_benchmark_suite`, à documenter
/// systématiquement dans le papier pour la reproductibilité des résultats.
pub const DEFAULT_SEED: u64 = 42;

/// Suite standard de bancs d'essai synthétiques, taille `n_samples`
/// chacun, utilisée comme protocole d'évaluation commun à tous les
/// algorithmes de la Phase 2 et suivantes.
pub fn standard_benchmark_suite(n_samples: usize, seed: u64) -> Vec<Dataset> {
    vec![
        make_blobs(n_samples, 3, 0.8, seed),
        make_anisotropic(n_samples, 3, 0.8, seed),
        make_varied_blobs(n_samples, seed),
        make_moons(n_samples, 0.08, seed),
        make_circles(n_samples, 0.06, 0.5, seed),
        make_varied_density(n_samples, seed),
        make_uniform_noise(n_samples, seed),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn blobs_has_correct_size_and_labels() {
        let d = make_blobs(150, 3, 0.5, 0);
        assert_eq!(d.n_samples(), 150);
        assert_eq!(d.n_features(), 2);
        let labels = d.labels_true.unwrap();
        assert_eq!(labels.len(), 150);
        assert!(labels.iter().all(|&l| (0..3).contains(&l)));
    }

    #[test]
    fn same_seed_is_bit_for_bit_reproducible() {
        let d1 = make_blobs(200, 4, 1.0, 7);
        let d2 = make_blobs(200, 4, 1.0, 7);
        assert_eq!(d1.points, d2.points);
        assert_eq!(d1.labels_true, d2.labels_true);
    }

    #[test]
    fn different_seed_changes_output() {
        let d1 = make_blobs(200, 4, 1.0, 7);
        let d2 = make_blobs(200, 4, 1.0, 8);
        assert_ne!(d1.points, d2.points);
    }

    #[test]
    fn moons_and_circles_have_two_classes() {
        let moons = make_moons(300, 0.05, 1);
        let circles = make_circles(300, 0.05, 0.5, 1);
        for d in [&moons, &circles] {
            let labels = d.labels_true.as_ref().unwrap();
            let n0 = labels.iter().filter(|&&l| l == 0).count();
            let n1 = labels.iter().filter(|&&l| l == 1).count();
            assert_eq!(n0 + n1, d.n_samples());
            assert!(n0 > 0 && n1 > 0);
        }
    }

    #[test]
    fn varied_density_respects_fractions_roughly() {
        let d = make_varied_density(1000, 3);
        let labels = d.labels_true.unwrap();
        let n0 = labels.iter().filter(|&&l| l == 0).count();
        // ~60% attendu dans le cluster dense (label 0)
        assert!(n0 > 550 && n0 < 650, "n0={n0}");
    }

    #[test]
    fn uniform_noise_has_no_ground_truth() {
        let d = make_uniform_noise(500, 3);
        assert!(d.labels_true.is_none());
        assert_eq!(d.n_samples(), 500);
    }

    #[test]
    fn adversarial_density_has_six_balanced_classes() {
        let d = make_adversarial_density(300, 3);
        let labels = d.labels_true.unwrap();
        assert_eq!(labels.len(), 300);
        let n_distinct = labels.iter().collect::<std::collections::HashSet<_>>().len();
        assert_eq!(n_distinct, 6);
        for k in 0..6 {
            let count = labels.iter().filter(|&&l| l == k).count();
            assert!(count >= 40, "cluster {k} sous-représenté: {count}");
        }
    }

    #[test]
    fn standard_suite_has_seven_datasets() {
        let suite = standard_benchmark_suite(300, DEFAULT_SEED);
        assert_eq!(suite.len(), 7);
        for d in &suite {
            assert_eq!(d.n_samples(), 300);
        }
    }
}
