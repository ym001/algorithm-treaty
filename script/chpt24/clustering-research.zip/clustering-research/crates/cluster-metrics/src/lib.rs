//! `cluster-metrics`: métriques d'évaluation reproductibles pour comparer
//! des algorithmes de clustering.
//!
//! Deux familles, toutes deux nécessaires dans le protocole expérimental :
//! - **externes** (nécessitent une vérité terrain, disponible pour les
//!   bancs d'essai synthétiques) : [`adjusted_rand_index`],
//!   [`normalized_mutual_info`] ;
//! - **internes** (ne nécessitent aucune vérité terrain, utilisables aussi
//!   sur données réelles) : [`silhouette_score`], [`davies_bouldin_index`],
//!   [`calinski_harabasz_index`].
//!
//! Toutes les fonctions sont déterministes (aucun aléa) : à entrée fixée,
//! la sortie est strictement reproductible, ce qui est la propriété
//! recherchée pour un protocole d'évaluation d'article.

use cluster_core::euclidean;
use std::collections::HashMap;

fn comb2(n: usize) -> f64 {
    if n < 2 {
        0.0
    } else {
        (n * (n - 1)) as f64 / 2.0
    }
}

type Contingency = (HashMap<(i32, i32), usize>, HashMap<i32, usize>, HashMap<i32, usize>, usize);

fn contingency_table(labels_true: &[i32], labels_pred: &[i32]) -> Contingency {
    assert_eq!(
        labels_true.len(),
        labels_pred.len(),
        "les deux étiquetages doivent avoir la même longueur"
    );
    let n = labels_true.len();
    let mut table: HashMap<(i32, i32), usize> = HashMap::new();
    let mut a: HashMap<i32, usize> = HashMap::new();
    let mut b: HashMap<i32, usize> = HashMap::new();
    for (&t, &p) in labels_true.iter().zip(labels_pred.iter()) {
        *table.entry((t, p)).or_insert(0) += 1;
        *a.entry(t).or_insert(0) += 1;
        *b.entry(p).or_insert(0) += 1;
    }
    (table, a, b, n)
}

/// Indice de Rand ajusté (Hubert & Arabie, 1985). Métrique externe :
/// 1.0 = accord parfait (à permutation des labels près), ~0.0 = accord
/// attendu au hasard, valeurs négatives possibles (pire que le hasard).
pub fn adjusted_rand_index(labels_true: &[i32], labels_pred: &[i32]) -> f64 {
    let (table, a, b, n) = contingency_table(labels_true, labels_pred);
    if n < 2 {
        return 1.0;
    }
    let index: f64 = table.values().map(|&nij| comb2(nij)).sum();
    let sum_a: f64 = a.values().map(|&ai| comb2(ai)).sum();
    let sum_b: f64 = b.values().map(|&bj| comb2(bj)).sum();
    let total_pairs = comb2(n);
    let expected = sum_a * sum_b / total_pairs;
    let max_index = 0.5 * (sum_a + sum_b);
    let denom = max_index - expected;
    if denom.abs() < 1e-12 {
        // Cas dégénéré (ex : un seul cluster dans les deux étiquetages, ou
        // chaque point isolé dans les deux) : convention standard
        // (scikit-learn) — accord parfait -> 1.0, sinon 0.0.
        return if (index - max_index).abs() < 1e-9 { 1.0 } else { 0.0 };
    }
    (index - expected) / denom
}

/// Information mutuelle normalisée (NMI), normalisation par la moyenne
/// arithmétique des entropies marginales. Métrique externe, dans [0, 1] :
/// 1.0 = accord parfait, 0.0 = étiquetages indépendants.
pub fn normalized_mutual_info(labels_true: &[i32], labels_pred: &[i32]) -> f64 {
    let (table, a, b, n) = contingency_table(labels_true, labels_pred);
    if n == 0 {
        return 1.0;
    }
    let n_f = n as f64;

    let mutual_info: f64 = table
        .iter()
        .filter(|(_, &nij)| nij > 0)
        .map(|(&(t, p), &nij)| {
            let nij_f = nij as f64;
            let ai = a[&t] as f64;
            let bj = b[&p] as f64;
            (nij_f / n_f) * ((n_f * nij_f) / (ai * bj)).ln()
        })
        .sum();

    let entropy = |counts: &HashMap<i32, usize>| -> f64 {
        counts
            .values()
            .map(|&c| {
                let p = c as f64 / n_f;
                -p * p.ln()
            })
            .sum()
    };
    let h_true = entropy(&a);
    let h_pred = entropy(&b);

    if h_true + h_pred < 1e-12 {
        // Les deux étiquetages n'ont qu'un seul cluster : accord trivial -> 1.0.
        return 1.0;
    }
    (2.0 * mutual_info / (h_true + h_pred)).clamp(0.0, 1.0)
}

fn group_by_label(labels: &[i32]) -> HashMap<i32, Vec<usize>> {
    let mut groups: HashMap<i32, Vec<usize>> = HashMap::new();
    for (i, &l) in labels.iter().enumerate() {
        groups.entry(l).or_default().push(i);
    }
    groups
}

fn centroid(points: &[Vec<f64>], indices: &[usize]) -> Vec<f64> {
    let d = points[0].len();
    let mut c = vec![0.0; d];
    for &i in indices {
        for (j, cj) in c.iter_mut().enumerate() {
            *cj += points[i][j];
        }
    }
    let n = indices.len() as f64;
    for v in c.iter_mut() {
        *v /= n;
    }
    c
}

/// Score de silhouette (Rousseeuw, 1987). Métrique interne, dans [-1, 1] :
/// pour chaque point, compare sa cohésion intra-cluster à sa séparation
/// vis-à-vis du cluster voisin le plus proche. Plus haut = meilleur.
///
/// Convention : chaque valeur de label présente (y compris -1) est traitée
/// comme un cluster à part entière. Pour exclure le bruit DBSCAN/HDBSCAN
/// de l'évaluation (convention courante), filtrer les points de label -1
/// avant l'appel.
///
/// # Panics
/// Si moins de 2 clusters ou plus de `n_samples - 1` clusters sont présents
/// (silhouette non définie dans ces cas, comme dans scikit-learn).
pub fn silhouette_score(points: &[Vec<f64>], labels: &[i32]) -> f64 {
    assert_eq!(points.len(), labels.len());
    let n = points.len();
    let groups = group_by_label(labels);
    assert!(
        groups.len() >= 2 && groups.len() <= n.saturating_sub(1),
        "silhouette requiert 2 <= n_clusters <= n_samples - 1 (trouvé {} clusters pour {} points)",
        groups.len(),
        n
    );

    let mut total = 0.0;
    for i in 0..n {
        let own_label = labels[i];
        let own_group = &groups[&own_label];

        let a_i = if own_group.len() <= 1 {
            0.0
        } else {
            own_group
                .iter()
                .filter(|&&j| j != i)
                .map(|&j| euclidean(&points[i], &points[j]))
                .sum::<f64>()
                / (own_group.len() - 1) as f64
        };

        let b_i = groups
            .iter()
            .filter(|&(&label, _)| label != own_label)
            .map(|(_, other_group)| {
                other_group.iter().map(|&j| euclidean(&points[i], &points[j])).sum::<f64>()
                    / other_group.len() as f64
            })
            .fold(f64::INFINITY, f64::min);

        let s_i = if a_i.max(b_i) > 0.0 { (b_i - a_i) / a_i.max(b_i) } else { 0.0 };
        total += s_i;
    }
    total / n as f64
}

/// Indice de Davies-Bouldin (1979). Métrique interne : moyenne, sur tous
/// les clusters, du pire ratio (dispersion intra-cluster combinée) /
/// (distance inter-centroïdes). Plus **bas** = meilleur (0 = optimal
/// théorique). Contrairement à silhouette/Calinski-Harabasz, ce n'est PAS
/// "plus haut = mieux" — attention lors de l'agrégation des résultats.
///
/// # Panics
/// Si moins de 2 clusters sont présents.
pub fn davies_bouldin_index(points: &[Vec<f64>], labels: &[i32]) -> f64 {
    assert_eq!(points.len(), labels.len());
    let groups = group_by_label(labels);
    let k = groups.len();
    assert!(k >= 2, "Davies-Bouldin requiert au moins 2 clusters (trouvé {k})");

    let label_list: Vec<i32> = groups.keys().copied().collect();
    let centroids: HashMap<i32, Vec<f64>> =
        label_list.iter().map(|&l| (l, centroid(points, &groups[&l]))).collect();
    let spread: HashMap<i32, f64> = label_list
        .iter()
        .map(|&l| {
            let idx = &groups[&l];
            let c = &centroids[&l];
            let s = idx.iter().map(|&i| euclidean(&points[i], c)).sum::<f64>() / idx.len() as f64;
            (l, s)
        })
        .collect();

    let mut total = 0.0;
    for &li in &label_list {
        let mut worst = f64::NEG_INFINITY;
        for &lj in &label_list {
            if li == lj {
                continue;
            }
            let d = euclidean(&centroids[&li], &centroids[&lj]);
            let r = if d > 1e-12 { (spread[&li] + spread[&lj]) / d } else { f64::INFINITY };
            worst = worst.max(r);
        }
        total += worst;
    }
    total / k as f64
}

/// Indice de Calinski-Harabasz (1974), "variance ratio criterion".
/// Métrique interne : ratio dispersion inter-cluster / dispersion
/// intra-cluster, normalisé par les degrés de liberté. Plus **haut** =
/// meilleur.
///
/// # Panics
/// Si moins de 2 clusters, ou si `n_samples <= n_clusters`.
pub fn calinski_harabasz_index(points: &[Vec<f64>], labels: &[i32]) -> f64 {
    assert_eq!(points.len(), labels.len());
    let n = points.len();
    let groups = group_by_label(labels);
    let k = groups.len();
    assert!(k >= 2, "Calinski-Harabasz requiert au moins 2 clusters (trouvé {k})");
    assert!(n > k, "Calinski-Harabasz requiert n_samples > n_clusters");

    let all_idx: Vec<usize> = (0..n).collect();
    let overall_mean = centroid(points, &all_idx);

    let mut between = 0.0;
    let mut within = 0.0;
    for idx in groups.values() {
        let c = centroid(points, idx);
        between += idx.len() as f64 * euclidean(&c, &overall_mean).powi(2);
        for &i in idx {
            within += euclidean(&points[i], &c).powi(2);
        }
    }

    if within < 1e-12 {
        return f64::INFINITY;
    }
    (between / (k - 1) as f64) / (within / (n - k) as f64)
}

#[cfg(test)]
mod tests {
    use super::*;

    // -------- ARI --------

    #[test]
    fn ari_perfect_agreement_is_one() {
        let t = vec![0, 0, 1, 1];
        let p = vec![0, 0, 1, 1];
        assert!((adjusted_rand_index(&t, &p) - 1.0).abs() < 1e-9);
    }

    #[test]
    fn ari_perfect_agreement_up_to_permutation_is_one() {
        let t = vec![0, 0, 1, 1];
        let p = vec![1, 1, 0, 0];
        assert!((adjusted_rand_index(&t, &p) - 1.0).abs() < 1e-9);
    }

    #[test]
    fn ari_hand_computed_example() {
        // true = [0,0,1,1], pred = [0,1,0,1] : chaque paire de même vérité
        // terrain se retrouve dans des clusters prédits différents.
        // Calcul à la main (voir dérivation dans la conversation) : ARI = -0.5.
        let t = vec![0, 0, 1, 1];
        let p = vec![0, 1, 0, 1];
        let ari = adjusted_rand_index(&t, &p);
        assert!((ari - (-0.5)).abs() < 1e-9, "ARI={ari}");
    }

    // -------- NMI --------

    #[test]
    fn nmi_perfect_agreement_is_one() {
        let t = vec![0, 0, 1, 1, 2, 2];
        let p = vec![0, 0, 1, 1, 2, 2];
        assert!((normalized_mutual_info(&t, &p) - 1.0).abs() < 1e-9);
    }

    #[test]
    fn nmi_single_cluster_both_sides_is_one() {
        let t = vec![0, 0, 0, 0];
        let p = vec![0, 0, 0, 0];
        assert!((normalized_mutual_info(&t, &p) - 1.0).abs() < 1e-9);
    }

    #[test]
    fn nmi_is_bounded_in_0_1() {
        let t = vec![0, 0, 1, 1, 0, 1];
        let p = vec![0, 1, 0, 1, 1, 0];
        let nmi = normalized_mutual_info(&t, &p);
        assert!((0.0..=1.0).contains(&nmi), "nmi={nmi}");
    }

    // -------- Silhouette / Davies-Bouldin / Calinski-Harabasz --------
    // Jeu jouet 1D à deux clusters très séparés : {0.0, 0.1} et {10.0, 10.1}.

    fn well_separated_toy() -> (Vec<Vec<f64>>, Vec<i32>) {
        let points = vec![vec![0.0], vec![0.1], vec![10.0], vec![10.1]];
        let labels = vec![0, 0, 1, 1];
        (points, labels)
    }

    #[test]
    fn silhouette_well_separated_is_near_one() {
        let (points, labels) = well_separated_toy();
        let s = silhouette_score(&points, &labels);
        // Calcul à la main : pour x=0.0, a=0.1, b=10.05 -> s=(10.05-0.1)/10.05≈0.99005
        // pour x=0.1, a=0.1, b=9.95 -> s=(9.95-0.1)/9.95≈0.98995 ; moyenne ≈0.98999997
        assert!((s - 0.99).abs() < 0.001, "silhouette={s}");
    }

    #[test]
    fn davies_bouldin_well_separated_is_near_zero() {
        let (points, labels) = well_separated_toy();
        let db = davies_bouldin_index(&points, &labels);
        // Calcul à la main : Si = 0.05 pour chaque cluster, d(centroïdes)=10
        // => DB = (0.05+0.05)/10 = 0.01
        assert!((db - 0.01).abs() < 1e-9, "db={db}");
    }

    #[test]
    fn calinski_harabasz_hand_computed() {
        let (points, labels) = well_separated_toy();
        let ch = calinski_harabasz_index(&points, &labels);
        // Calcul à la main : B=100, W=0.01, k=2, n=4 => CH = (100/1)/(0.01/2) = 20000
        assert!((ch - 20000.0).abs() < 1e-6, "ch={ch}");
    }

    #[test]
    #[should_panic(expected = "au moins 2 clusters")]
    fn davies_bouldin_panics_on_single_cluster() {
        let points = vec![vec![0.0], vec![1.0]];
        let labels = vec![0, 0];
        davies_bouldin_index(&points, &labels);
    }
}
